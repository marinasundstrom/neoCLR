	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 26, 2	sdk_version 26, 2
	.globl	_neoclr_gc_lookup_profile_v1    ; -- Begin function neoclr_gc_lookup_profile_v1
	.p2align	2
_neoclr_gc_lookup_profile_v1:           ; @neoclr_gc_lookup_profile_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh0:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh1:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0, #32]
	stp	q0, q1, [x8, #32]
	ldp	q0, q1, [x0, #64]
	stp	q0, q1, [x8, #64]
	ldp	q0, q1, [x0]
	stp	q0, q1, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_lookup_profile_reset_v1 ; -- Begin function neoclr_gc_lookup_profile_reset_v1
	.p2align	2
_neoclr_gc_lookup_profile_reset_v1:     ; @neoclr_gc_lookup_profile_reset_v1
	.cfi_startproc
; %bb.0:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_profile_v1           ; -- Begin function neoclr_gc_profile_v1
	.p2align	2
_neoclr_gc_profile_v1:                  ; @neoclr_gc_profile_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh2:
	adrp	x0, _profile@TLVPPAGE
Lloh3:
	ldr	x0, [x0, _profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x1, x0
	mov	x0, x8
	mov	w2, #584                        ; =0x248
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_memcpy
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_profile_reset_v1     ; -- Begin function neoclr_gc_profile_reset_v1
	.p2align	2
_neoclr_gc_profile_reset_v1:            ; @neoclr_gc_profile_reset_v1
	.cfi_startproc
; %bb.0:
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_heap_acquire_v1      ; -- Begin function neoclr_gc_heap_acquire_v1
	.p2align	2
_neoclr_gc_heap_acquire_v1:             ; @neoclr_gc_heap_acquire_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x9, x0
Lloh4:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh5:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w8, #3                          ; =0x3
	cbz	x9, LBB4_6
; %bb.1:
	ldr	x10, [x0]
	cbnz	x10, LBB4_6
; %bb.2:
	ldp	x10, x8, [x9, #8]
	and	x11, x8, #0x7
	cmp	x8, x10
	ccmp	x11, #0, #0, ls
	b.ne	LBB4_4
; %bb.3:
	ldr	x11, [x9]
	cmp	x11, #0
	ccmp	x10, #0, #4, eq
	and	x12, x11, #0x7
	orr	x8, x12, x8
	ccmp	x8, #0, #0, eq
	b.eq	LBB4_5
LBB4_4:
	mov	w8, #3                          ; =0x3
	b	LBB4_6
LBB4_5:
	mov	w8, #0                          ; =0x0
	stp	x9, x11, [x0]
	stp	xzr, xzr, [x0, #24]
	str	x10, [x0, #16]
LBB4_6:
	mov	x0, x8
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_heap_release_v1      ; -- Begin function neoclr_gc_heap_release_v1
	.p2align	2
_neoclr_gc_heap_release_v1:             ; @neoclr_gc_heap_release_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	cbz	x0, LBB5_3
; %bb.1:
	mov	x8, x0
Lloh6:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh7:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	mov	w19, #3                         ; =0x3
	cmp	x9, x8
	b.ne	LBB5_4
; %bb.2:
	mov	x20, x0
	mov	x0, x8
	bl	_blocks_valid
	cmp	w0, #0
	csel	w19, w19, wzr, eq
	mov	x0, x20
	mov	w1, #552                        ; =0x228
	bl	_bzero
	b	LBB5_4
LBB5_3:
	mov	w19, #3                         ; =0x3
LBB5_4:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function blocks_valid
_blocks_valid:                          ; @blocks_valid
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_12
; %bb.1:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh8:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh9:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x10, [x0]
	cmp	x10, x8
	b.eq	LBB6_7
; %bb.2:
	ldp	x9, x11, [x8, #8]
LBB6_3:
	and	x12, x11, #0x7
	cmp	x11, x9
	ccmp	x12, #0, #0, ls
	b.ne	LBB6_10
; %bb.4:
	ldr	x12, [x8]
	cmp	x12, #0
	ccmp	x9, #0, #4, eq
	and	x9, x12, #0x7
	ccmp	x9, #0, #0, eq
	b.ne	LBB6_10
; %bb.5:
	ldr	x9, [x0, #32]
	cmp	x10, x8
	csel	x9, x9, xzr, eq
	cbz	x11, LBB6_26
; %bb.6:
	mov	x13, #0                         ; =0x0
	b	LBB6_15
LBB6_7:
	ldr	x9, [x8]
	ldr	x11, [x0, #8]
	cmp	x9, x11
	b.ne	LBB6_10
; %bb.8:
	ldr	x9, [x8, #8]
	ldr	x11, [x0, #16]
	cmp	x9, x11
	b.ne	LBB6_10
; %bb.9:
	ldr	x11, [x8, #16]
	ldr	x12, [x0, #24]
	cmp	x11, x12
	b.eq	LBB6_3
LBB6_10:
	mov	w0, #0                          ; =0x0
LBB6_11:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB6_12:
	ret
LBB6_13:                                ;   in Loop: Header=BB6_15 Depth=1
	cmp	x10, x8
	b.eq	LBB6_23
LBB6_14:                                ;   in Loop: Header=BB6_15 Depth=1
	add	x13, x14, x13
	cmp	x13, x11
	b.hs	LBB6_26
LBB6_15:                                ; =>This Inner Loop Header: Depth=1
	sub	x16, x11, x13
	cmp	x16, #32
	b.lo	LBB6_25
; %bb.16:                               ;   in Loop: Header=BB6_15 Depth=1
	add	x15, x12, x13
	ldr	x14, [x15]
	cmp	x14, x16
	b.hi	LBB6_25
; %bb.17:                               ;   in Loop: Header=BB6_15 Depth=1
	and	x16, x14, #0x7
	cmp	x14, #40
	ccmp	x16, #0, #0, hs
	b.ne	LBB6_25
; %bb.18:                               ;   in Loop: Header=BB6_15 Depth=1
	ldr	x16, [x15, #24]
	cmp	x16, #7
	b.hi	LBB6_25
; %bb.19:                               ;   in Loop: Header=BB6_15 Depth=1
	cbz	x16, LBB6_13
; %bb.20:                               ;   in Loop: Header=BB6_15 Depth=1
	tbz	w16, #0, LBB6_25
; %bb.21:                               ;   in Loop: Header=BB6_15 Depth=1
	ldr	x16, [x15, #8]
	sub	x17, x14, #32
	sub	x16, x16, #1
	cmp	x16, x17
	b.hs	LBB6_25
; %bb.22:                               ;   in Loop: Header=BB6_15 Depth=1
	ldr	x15, [x15, #16]
	sub	x15, x15, #7
	cmn	x15, #6
	b.hs	LBB6_14
	b	LBB6_25
LBB6_23:                                ;   in Loop: Header=BB6_15 Depth=1
	orr	x16, x13, #0x1
	cmp	x9, x16
	b.ne	LBB6_25
; %bb.24:                               ;   in Loop: Header=BB6_15 Depth=1
	ldr	x9, [x15, #8]
	b	LBB6_14
LBB6_25:
	mov	w8, #0                          ; =0x0
	b	LBB6_27
LBB6_26:
	mov	w8, #1                          ; =0x1
LBB6_27:
	cmp	x9, #0
	csel	w0, wzr, w8, ne
	b	LBB6_11
	.loh AdrpLdr	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_allocation_info_v1   ; -- Begin function neoclr_gc_allocation_info_v1
	.p2align	2
_neoclr_gc_allocation_info_v1:          ; @neoclr_gc_allocation_info_v1
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB7_8
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	cbz	x1, LBB7_7
; %bb.2:
	mov	x21, x2
	cbz	x2, LBB7_7
; %bb.3:
	mov	x19, x3
	cbz	x3, LBB7_7
; %bb.4:
	add	x0, x8, #1048
	mov	x1, x20
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB7_6
; %bb.5:
	mov	w0, #0                          ; =0x0
	ldur	x8, [x20, #-24]
	str	x8, [x21]
	ldur	x8, [x20, #-16]
	str	w8, [x19]
	b	LBB7_7
LBB7_6:
	mov	w0, #3                          ; =0x3
LBB7_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB7_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function validated_bases
_validated_bases:                       ; @validated_bases
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB8_8
; %bb.1:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh10:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh11:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x10, [x0]
	cmp	x10, x8
	b.eq	LBB8_21
; %bb.2:
	ldp	x9, x11, [x8, #8]
LBB8_3:
	and	x12, x11, #0x7
	cmp	x11, x9
	ccmp	x12, #0, #0, ls
	b.ne	LBB8_24
; %bb.4:
	ldr	x12, [x8]
	cmp	x12, #0
	ccmp	x9, #0, #4, eq
	and	x9, x12, #0x7
	ccmp	x9, #0, #0, eq
	b.ne	LBB8_24
; %bb.5:
	cmp	x10, x8
	b.eq	LBB8_26
LBB8_6:
	cmp	x1, #0
	cset	w14, eq
	cmp	x2, #0
	cset	w15, eq
	mov	x13, #0                         ; =0x0
	cbz	x11, LBB8_33
; %bb.7:
	cmp	x2, #0
	cset	w15, eq
	cmp	x1, #0
	cset	w14, eq
	b	LBB8_10
LBB8_8:
	mov	w0, #0                          ; =0x0
	ret
LBB8_9:                                 ;   in Loop: Header=BB8_10 Depth=1
	add	x13, x16, x13
	cmp	x13, x11
	b.hs	LBB8_31
LBB8_10:                                ; =>This Inner Loop Header: Depth=1
	cbz	w14, LBB8_12
; %bb.11:                               ;   in Loop: Header=BB8_10 Depth=1
	cbnz	w15, LBB8_31
LBB8_12:                                ;   in Loop: Header=BB8_10 Depth=1
	sub	x3, x11, x13
	cmp	x3, #32
	b.lo	LBB8_24
; %bb.13:                               ;   in Loop: Header=BB8_10 Depth=1
	mov	w9, #0                          ; =0x0
	add	x17, x12, x13
	ldr	x16, [x17]
	cmp	x16, x3
	b.hi	LBB8_25
; %bb.14:                               ;   in Loop: Header=BB8_10 Depth=1
	and	x3, x16, #0x7
	cmp	x16, #40
	ccmp	x3, #0, #0, hs
	b.ne	LBB8_25
; %bb.15:                               ;   in Loop: Header=BB8_10 Depth=1
	ldr	x9, [x17, #24]
	cmp	x9, #7
	b.hi	LBB8_24
; %bb.16:                               ;   in Loop: Header=BB8_10 Depth=1
	cbz	x9, LBB8_9
; %bb.17:                               ;   in Loop: Header=BB8_10 Depth=1
	tbz	w9, #0, LBB8_24
; %bb.18:                               ;   in Loop: Header=BB8_10 Depth=1
	ldr	x9, [x17, #8]
	sub	x3, x16, #32
	sub	x9, x9, #1
	cmp	x9, x3
	b.hs	LBB8_24
; %bb.19:                               ;   in Loop: Header=BB8_10 Depth=1
	ldr	x9, [x17, #16]
	sub	x9, x9, #7
	cmn	x9, #6
	b.lo	LBB8_24
; %bb.20:                               ;   in Loop: Header=BB8_10 Depth=1
	add	x9, x17, #32
	cmp	x9, x1
	cset	w17, eq
	orr	w14, w14, w17
	cmp	x9, x2
	cset	w9, eq
	orr	w15, w15, w9
	b	LBB8_9
LBB8_21:
	ldr	x9, [x8]
	ldr	x11, [x0, #8]
	cmp	x9, x11
	b.ne	LBB8_24
; %bb.22:
	ldr	x9, [x8, #8]
	ldr	x11, [x0, #16]
	cmp	x9, x11
	b.ne	LBB8_24
; %bb.23:
	ldr	x11, [x8, #16]
	ldr	x12, [x0, #24]
	cmp	x11, x12
	b.eq	LBB8_3
LBB8_24:
	mov	w9, #0                          ; =0x0
LBB8_25:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	mov	x0, x9
	ret
LBB8_26:
	cbz	x1, LBB8_28
; %bb.27:
	ubfx	x9, x1, #3, #29
	eor	w9, w9, w1, lsr #9
	and	x9, x9, #0x3f
	add	x9, x0, x9, lsl #3
	ldr	x9, [x9, #40]
	cmp	x9, x1
	b.ne	LBB8_6
LBB8_28:
	cbz	x2, LBB8_30
; %bb.29:
	ubfx	x9, x2, #3, #29
	eor	w9, w9, w2, lsr #9
	and	x9, x9, #0x3f
	add	x9, x0, x9, lsl #3
	ldr	x9, [x9, #40]
	cmp	x9, x2
	b.ne	LBB8_6
LBB8_30:
	mov	w9, #1                          ; =0x1
	b	LBB8_25
LBB8_31:
	cmp	w14, #0
	cset	w14, ne
	cmp	w15, #0
	cset	w15, ne
	b	LBB8_33
LBB8_32:                                ;   in Loop: Header=BB8_33 Depth=1
	add	x13, x16, x13
LBB8_33:                                ; =>This Inner Loop Header: Depth=1
	cmp	x13, x11
	b.hs	LBB8_42
; %bb.34:                               ;   in Loop: Header=BB8_33 Depth=1
	sub	x3, x11, x13
	cmp	x3, #32
	b.lo	LBB8_24
; %bb.35:                               ;   in Loop: Header=BB8_33 Depth=1
	mov	w9, #0                          ; =0x0
	add	x17, x12, x13
	ldr	x16, [x17]
	cmp	x16, x3
	b.hi	LBB8_25
; %bb.36:                               ;   in Loop: Header=BB8_33 Depth=1
	and	x3, x16, #0x7
	cmp	x16, #40
	ccmp	x3, #0, #0, hs
	b.ne	LBB8_25
; %bb.37:                               ;   in Loop: Header=BB8_33 Depth=1
	ldr	x9, [x17, #24]
	cmp	x9, #7
	b.hi	LBB8_24
; %bb.38:                               ;   in Loop: Header=BB8_33 Depth=1
	cbz	x9, LBB8_32
; %bb.39:                               ;   in Loop: Header=BB8_33 Depth=1
	tbz	w9, #0, LBB8_24
; %bb.40:                               ;   in Loop: Header=BB8_33 Depth=1
	ldr	x9, [x17, #8]
	sub	x3, x16, #32
	sub	x9, x9, #1
	cmp	x9, x3
	b.hs	LBB8_24
; %bb.41:                               ;   in Loop: Header=BB8_33 Depth=1
	ldr	x9, [x17, #16]
	sub	x9, x9, #7
	cmn	x9, #6
	b.hs	LBB8_32
	b	LBB8_24
LBB8_42:
	cmp	x10, x8
	cset	w8, eq
	and	w8, w8, w14
	and	w8, w8, w15
	cmp	w8, #1
	b.ne	LBB8_47
; %bb.43:
	cbz	x1, LBB8_45
; %bb.44:
	ubfx	x8, x1, #3, #29
	eor	w8, w8, w1, lsr #9
	and	x8, x8, #0x3f
	add	x8, x0, x8, lsl #3
	str	x1, [x8, #40]
LBB8_45:
	cbz	x2, LBB8_47
; %bb.46:
	ubfx	x8, x2, #3, #29
	eor	w8, w8, w2, lsr #9
	and	x8, x8, #0x3f
	add	x8, x0, x8, lsl #3
	str	x2, [x8, #40]
LBB8_47:
	and	w9, w14, w15
	b	LBB8_25
	.loh AdrpLdr	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_resource_attach_v1   ; -- Begin function neoclr_gc_resource_attach_v1
	.p2align	2
_neoclr_gc_resource_attach_v1:          ; @neoclr_gc_resource_attach_v1
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x4
	mov	x21, x3
	mov	x19, x2
	mov	x22, x1
	mov	x23, x0
Lloh12:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh13:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x4, LBB9_15
; %bb.1:
	cbz	x19, LBB9_15
; %bb.2:
	cbz	x22, LBB9_15
; %bb.3:
	cbz	x23, LBB9_15
; %bb.4:
	ldr	w8, [x8, #88]
	cbnz	w8, LBB9_15
; %bb.5:
	add	x0, x23, #1048
	mov	x1, x22
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB9_14
; %bb.6:
Lloh14:
	adrp	x0, _resource_head@TLVPPAGE
Lloh15:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB9_11
; %bb.7:
	mov	w9, #0                          ; =0x0
	mov	x10, x8
LBB9_8:                                 ; =>This Inner Loop Header: Depth=1
	cmp	x10, x19
	b.eq	LBB9_14
; %bb.9:                                ;   in Loop: Header=BB9_8 Depth=1
	ldr	x11, [x10]
	cmp	x11, x23
	cinc	w9, w9, eq
	ldr	x10, [x10, #32]
	cbnz	x10, LBB9_8
; %bb.10:
	cmp	w9, #1023
	cset	w9, hi
	ldr	x10, [x19]
	cbnz	x10, LBB9_14
	b	LBB9_12
LBB9_11:
	mov	w9, #0                          ; =0x0
	ldr	x10, [x19]
	cbnz	x10, LBB9_14
LBB9_12:
	ldr	x10, [x19, #8]
	cbnz	x10, LBB9_14
; %bb.13:
	ldr	x10, [x19, #16]
	cbz	x10, LBB9_16
LBB9_14:
	mov	w0, #3                          ; =0x3
LBB9_15:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB9_16:
	mov	x10, x0
	ldr	x11, [x19, #24]
	mov	w0, #3                          ; =0x3
	cbnz	x11, LBB9_15
; %bb.17:
	ldr	x11, [x19, #32]
	cmp	x11, #0
	cset	w11, ne
	orr	w9, w11, w9
	mov	w11, #5                         ; =0x5
	csel	w0, w0, w11, ne
	tbnz	w9, #0, LBB9_15
; %bb.18:
	mov	w0, #0                          ; =0x0
	stp	x23, x22, [x19]
	stp	x21, x20, [x19, #16]
	str	x8, [x19, #32]
	str	x19, [x10]
	b	LBB9_15
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_resource_release_v1  ; -- Begin function neoclr_gc_resource_release_v1
	.p2align	2
_neoclr_gc_resource_release_v1:         ; @neoclr_gc_resource_release_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh16:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh17:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x19, x0
	ldr	w11, [x0, #88]
Lloh18:
	adrp	x0, _resource_head@TLVPPAGE
Lloh19:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	w9, #3                          ; =0x3
	cbz	x1, LBB10_8
; %bb.1:
	cbz	x8, LBB10_8
; %bb.2:
	ldr	x10, [x0]
	cmp	w11, #0
	ccmp	x10, #0, #4, eq
	b.ne	LBB10_4
	b	LBB10_8
LBB10_3:                                ;   in Loop: Header=BB10_4 Depth=1
	ldr	x9, [x10, #32]!
	mov	x0, x10
	mov	x10, x9
	cbz	x9, LBB10_7
LBB10_4:                                ; =>This Inner Loop Header: Depth=1
	cmp	x10, x1
	b.ne	LBB10_3
; %bb.5:                                ;   in Loop: Header=BB10_4 Depth=1
	ldr	x9, [x10]
	cmp	x9, x8
	b.ne	LBB10_3
; %bb.6:
	ldp	x8, x9, [x10, #16]
	ldr	x11, [x10, #32]
	str	x11, [x0]
	str	xzr, [x10, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x10]
	mov	w10, #1                         ; =0x1
	str	w10, [x19, #88]
	mov	x0, x8
	blr	x9
	mov	w9, #0                          ; =0x0
	str	wzr, [x19, #88]
	b	LBB10_8
LBB10_7:
	mov	w9, #3                          ; =0x3
LBB10_8:
	mov	x0, x9
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_host_root_create_v1  ; -- Begin function neoclr_gc_host_root_create_v1
	.p2align	2
_neoclr_gc_host_root_create_v1:         ; @neoclr_gc_host_root_create_v1
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB11_15
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	cbz	x2, LBB11_14
; %bb.2:
	mov	x20, x1
	mov	x21, x8
	add	x0, x8, #1048
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB11_7
; %bb.3:
Lloh20:
	adrp	x0, _host_roots@TLVPPAGE
Lloh21:
	ldr	x0, [x0, _host_roots@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w8, #256                        ; =0x100
LBB11_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x0]
	cbz	x9, LBB11_8
; %bb.5:                                ;   in Loop: Header=BB11_4 Depth=1
	add	x0, x0, #56
	subs	x8, x8, #1
	b.ne	LBB11_4
LBB11_6:
	mov	w0, #5                          ; =0x5
	b	LBB11_14
LBB11_7:
	mov	w0, #3                          ; =0x3
	b	LBB11_14
LBB11_8:
Lloh22:
	adrp	x8, _next_host_handle@PAGE
Lloh23:
	ldr	x10, [x8, _next_host_handle@PAGEOFF]
Lloh24:
	adrp	x8, _next_host_handle@PAGE
Lloh25:
	add	x8, x8, _next_host_handle@PAGEOFF
LBB11_9:                                ; =>This Inner Loop Header: Depth=1
	cmn	x10, #1
	b.eq	LBB11_6
; %bb.10:                               ;   in Loop: Header=BB11_9 Depth=1
	mov	x9, x10
	add	x11, x10, #1
	cas	x10, x11, [x8]
	cmp	x10, x9
	b.ne	LBB11_9
; %bb.11:
Lloh26:
	adrp	x8, _host_head@TLVPPAGE
Lloh27:
	ldr	x8, [x8, _host_head@TLVPPAGEOFF]
	ldr	x11, [x8]
	mov	x10, x0
	mov	x0, x8
	blr	x11
	mov	x8, x0
	ldr	x11, [x0]
	stp	x21, x20, [x10]
	stp	xzr, xzr, [x10, #16]
	stp	x9, xzr, [x10, #32]
	str	x11, [x10, #48]
	cbz	x11, LBB11_13
; %bb.12:
	str	x10, [x11, #40]
LBB11_13:
	mov	w0, #0                          ; =0x0
	str	x10, [x8]
	str	x9, [x19]
LBB11_14:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB11_15:
	ret
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_gc_host_root_create_owned_v1
lCPI12_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_gc_host_root_create_owned_v1
	.p2align	2
_neoclr_gc_host_root_create_owned_v1:   ; @neoclr_gc_host_root_create_owned_v1
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x1, LBB12_16
; %bb.1:
	cbz	x8, LBB12_16
; %bb.2:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x3
	cbz	x3, LBB12_15
; %bb.3:
	mov	x21, x2
	mov	x20, x1
	mov	x22, x8
	add	x0, x8, #1048
	mov	x1, x2
	mov	x2, x20
	bl	_validated_bases
	cbz	w0, LBB12_8
; %bb.4:
Lloh28:
	adrp	x0, _host_roots@TLVPPAGE
Lloh29:
	ldr	x0, [x0, _host_roots@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w8, #256                        ; =0x100
LBB12_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x0]
	cbz	x9, LBB12_9
; %bb.6:                                ;   in Loop: Header=BB12_5 Depth=1
	add	x0, x0, #56
	subs	x8, x8, #1
	b.ne	LBB12_5
LBB12_7:
	mov	w0, #5                          ; =0x5
	b	LBB12_15
LBB12_8:
	mov	w0, #3                          ; =0x3
	b	LBB12_15
LBB12_9:
Lloh30:
	adrp	x8, _next_host_handle@PAGE
Lloh31:
	ldr	x10, [x8, _next_host_handle@PAGEOFF]
Lloh32:
	adrp	x8, _next_host_handle@PAGE
Lloh33:
	add	x8, x8, _next_host_handle@PAGEOFF
LBB12_10:                               ; =>This Inner Loop Header: Depth=1
	cmn	x10, #1
	b.eq	LBB12_7
; %bb.11:                               ;   in Loop: Header=BB12_10 Depth=1
	mov	x9, x10
	add	x11, x10, #1
	cas	x10, x11, [x8]
	cmp	x10, x9
	b.ne	LBB12_10
; %bb.12:
Lloh34:
	adrp	x8, _host_head@TLVPPAGE
Lloh35:
	ldr	x8, [x8, _host_head@TLVPPAGEOFF]
	ldr	x11, [x8]
	mov	x10, x0
	mov	x0, x8
	blr	x11
	mov	x8, x0
	ldr	x11, [x0]
	stp	x22, x21, [x10]
	str	x20, [x10, #16]
Lloh36:
	adrp	x12, lCPI12_0@PAGE
Lloh37:
	ldr	d0, [x12, lCPI12_0@PAGEOFF]
	str	d0, [x10, #24]
	stp	x9, xzr, [x10, #32]
	str	x11, [x10, #48]
	cbz	x11, LBB12_14
; %bb.13:
	str	x10, [x11, #40]
LBB12_14:
	mov	w0, #0                          ; =0x0
	str	x10, [x8]
	str	x9, [x19]
LBB12_15:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB12_16:
	ret
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpLdr	Lloh34, Lloh35
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_host_root_replace_v1 ; -- Begin function neoclr_gc_host_root_replace_v1
	.p2align	2
_neoclr_gc_host_root_replace_v1:        ; @neoclr_gc_host_root_replace_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh38:
	adrp	x0, _host_head@TLVPPAGE
Lloh39:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB13_8
; %bb.1:
	cbz	x1, LBB13_8
; %bb.2:
	ldr	x19, [x9]
	cbnz	x19, LBB13_4
	b	LBB13_8
LBB13_3:                                ;   in Loop: Header=BB13_4 Depth=1
	ldr	x19, [x19, #48]
	cbz	x19, LBB13_7
LBB13_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	cmp	x9, x8
	b.ne	LBB13_3
; %bb.5:                                ;   in Loop: Header=BB13_4 Depth=1
	ldr	x9, [x19, #32]
	cmp	x9, x1
	b.ne	LBB13_3
; %bb.6:
	ldr	w9, [x19, #28]
	cbz	w9, LBB13_9
LBB13_7:
	mov	w0, #3                          ; =0x3
LBB13_8:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB13_9:
	add	x0, x8, #1048
	mov	x20, x2
	mov	x1, x2
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB13_7
; %bb.10:
	mov	w0, #0                          ; =0x0
	str	x20, [x19, #8]
	b	LBB13_8
	.loh AdrpLdr	Lloh38, Lloh39
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_host_root_read_v1    ; -- Begin function neoclr_gc_host_root_read_v1
	.p2align	2
_neoclr_gc_host_root_read_v1:           ; @neoclr_gc_host_root_read_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh40:
	adrp	x0, _host_head@TLVPPAGE
Lloh41:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB14_3
; %bb.1:
	cbz	x1, LBB14_3
; %bb.2:
	ldr	x9, [x9]
	cbnz	x9, LBB14_5
LBB14_3:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB14_4:                                ;   in Loop: Header=BB14_5 Depth=1
	ldr	x9, [x9, #48]
	cbz	x9, LBB14_10
LBB14_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9]
	cmp	x10, x8
	b.ne	LBB14_4
; %bb.6:                                ;   in Loop: Header=BB14_5 Depth=1
	ldr	x10, [x9, #32]
	cmp	x10, x1
	b.ne	LBB14_4
; %bb.7:
	mov	w0, #3                          ; =0x3
	cbz	x2, LBB14_3
; %bb.8:
	ldr	w8, [x9, #28]
	cbnz	w8, LBB14_3
; %bb.9:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x9, #8]
	str	x8, [x2]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB14_10:
	mov	w0, #3                          ; =0x3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh40, Lloh41
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_host_root_release_v1 ; -- Begin function neoclr_gc_host_root_release_v1
	.p2align	2
_neoclr_gc_host_root_release_v1:        ; @neoclr_gc_host_root_release_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh42:
	adrp	x0, _host_head@TLVPPAGE
Lloh43:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	w9, #3                          ; =0x3
	cbz	x8, LBB15_10
; %bb.1:
	cbz	x1, LBB15_10
; %bb.2:
	ldr	x10, [x0]
	cbnz	x10, LBB15_4
	b	LBB15_10
LBB15_3:                                ;   in Loop: Header=BB15_4 Depth=1
	ldr	x10, [x10, #48]
	cbz	x10, LBB15_9
LBB15_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x10]
	cmp	x9, x8
	b.ne	LBB15_3
; %bb.5:                                ;   in Loop: Header=BB15_4 Depth=1
	ldr	x9, [x10, #32]
	cmp	x9, x1
	b.ne	LBB15_3
; %bb.6:
	ldp	x8, x9, [x10, #40]
	add	x11, x8, #48
	cmp	x8, #0
	csel	x11, x0, x11, eq
	str	x9, [x11]
	cbz	x9, LBB15_8
; %bb.7:
	str	x8, [x9, #40]
LBB15_8:
	mov	w9, #0                          ; =0x0
	str	xzr, [x10, #48]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x10, #16]
	str	q0, [x10]
	b	LBB15_10
LBB15_9:
	mov	w9, #3                          ; =0x3
LBB15_10:
	mov	x0, x9
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh42, Lloh43
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_callback_read_v1     ; -- Begin function neoclr_gc_callback_read_v1
	.p2align	2
_neoclr_gc_callback_read_v1:            ; @neoclr_gc_callback_read_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x21, x1
	mov	x20, x0
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB16_3
LBB16_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x20
	b.eq	LBB16_18
; %bb.2:                                ;   in Loop: Header=BB16_1 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB16_1
LBB16_3:
Lloh44:
	adrp	x0, _host_head@TLVPPAGE
Lloh45:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x20, LBB16_19
; %bb.4:
	cbz	x21, LBB16_19
; %bb.5:
	ldr	x22, [x8]
	cbnz	x22, LBB16_7
	b	LBB16_19
LBB16_6:                                ;   in Loop: Header=BB16_7 Depth=1
	ldr	x22, [x22, #48]
	cbz	x22, LBB16_18
LBB16_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x22]
	cmp	x8, x20
	b.ne	LBB16_6
; %bb.8:                                ;   in Loop: Header=BB16_7 Depth=1
	ldr	x8, [x22, #32]
	cmp	x8, x21
	b.ne	LBB16_6
; %bb.9:
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB16_19
; %bb.10:
	ldr	w8, [x22, #24]
	cbnz	w8, LBB16_19
; %bb.11:
	ldr	x1, [x22, #8]
	cbz	x1, LBB16_19
; %bb.12:
	ldr	w8, [x20]
	cbnz	w8, LBB16_19
; %bb.13:
	add	x0, x20, #1048
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB16_18
; %bb.14:
	ldr	x8, [x22, #8]
	ldur	x9, [x8, #-16]
	cmp	x9, #2
	b.ne	LBB16_18
; %bb.15:
	ldur	x9, [x8, #-24]
	cmp	x9, #24
	b.ne	LBB16_18
; %bb.16:
	ldr	x9, [x8]
	mov	w10, #-1                        ; =0xffffffff
	cmp	x9, x10
	b.ne	LBB16_18
; %bb.17:
	mov	w0, #0                          ; =0x0
	str	x8, [x19]
	b	LBB16_19
LBB16_18:
	mov	w0, #3                          ; =0x3
LBB16_19:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh44, Lloh45
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_callback_read_suspended_v1 ; -- Begin function neoclr_gc_callback_read_suspended_v1
	.p2align	2
_neoclr_gc_callback_read_suspended_v1:  ; @neoclr_gc_callback_read_suspended_v1
	.cfi_startproc
; %bb.0:
	cbz	x3, LBB17_5
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x3
	mov	x19, x0
	mov	x22, x1
	mov	x21, x2
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x20
	b.ne	LBB17_3
; %bb.2:
	ldr	x8, [x20, #8]
	cmp	x8, x19
	b.eq	LBB17_6
LBB17_3:
	mov	w0, #3                          ; =0x3
LBB17_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB17_5:
	mov	w0, #3                          ; =0x3
	ret
LBB17_6:
Lloh46:
	adrp	x0, _host_head@TLVPPAGE
Lloh47:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB17_4
; %bb.7:
	cbz	x22, LBB17_4
; %bb.8:
	ldr	x20, [x8]
	cbz	x20, LBB17_4
; %bb.9:
	mov	x9, x22
	mov	x8, x21
	b	LBB17_11
LBB17_10:                               ;   in Loop: Header=BB17_11 Depth=1
	ldr	x20, [x20, #48]
	cbz	x20, LBB17_3
LBB17_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x20]
	cmp	x10, x19
	b.ne	LBB17_10
; %bb.12:                               ;   in Loop: Header=BB17_11 Depth=1
	ldr	x10, [x20, #32]
	cmp	x10, x9
	b.ne	LBB17_10
; %bb.13:
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB17_4
; %bb.14:
	ldr	w8, [x20, #24]
	cbnz	w8, LBB17_4
; %bb.15:
	ldr	x1, [x20, #8]
	cbz	x1, LBB17_4
; %bb.16:
	ldr	w8, [x19]
	cbnz	w8, LBB17_4
; %bb.17:
	add	x0, x19, #1048
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB17_3
; %bb.18:
	ldr	x8, [x20, #8]
	ldur	x9, [x8, #-16]
	cmp	x9, #2
	b.ne	LBB17_3
; %bb.19:
	ldur	x9, [x8, #-24]
	cmp	x9, #24
	b.ne	LBB17_3
; %bb.20:
	ldr	x9, [x8]
	mov	w10, #-1                        ; =0xffffffff
	cmp	x9, x10
	b.ne	LBB17_3
; %bb.21:
	mov	w0, #0                          ; =0x0
	str	x8, [x21]
	b	LBB17_4
	.loh AdrpLdr	Lloh46, Lloh47
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_roots_park_owned_v1  ; -- Begin function neoclr_gc_roots_park_owned_v1
	.p2align	2
_neoclr_gc_roots_park_owned_v1:         ; @neoclr_gc_roots_park_owned_v1
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB18_11
; %bb.1:
	cbz	x1, LBB18_11
; %bb.2:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	cbz	x2, LBB18_10
; %bb.3:
	mov	x21, x8
	add	x0, x8, #1048
	mov	x20, x1
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB18_9
; %bb.4:
	ldr	x8, [x19]
	cbnz	x8, LBB18_9
; %bb.5:
	ldr	x8, [x19, #8]
	cbnz	x8, LBB18_9
; %bb.6:
	ldr	x8, [x19, #16]
	cbnz	x8, LBB18_9
; %bb.7:
	ldr	x8, [x19, #24]
	cbnz	x8, LBB18_9
; %bb.8:
	ldr	w8, [x19, #32]
	cbz	w8, LBB18_12
LBB18_9:
	mov	w0, #3                          ; =0x3
LBB18_10:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB18_11:
	ret
LBB18_12:
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB18_15
LBB18_13:                               ; =>This Inner Loop Header: Depth=1
	cmp	x0, x19
	b.eq	LBB18_9
; %bb.14:                               ;   in Loop: Header=BB18_13 Depth=1
	ldr	x0, [x0, #8]
	cbnz	x0, LBB18_13
LBB18_15:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB18_18
LBB18_16:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x21
	b.ne	LBB18_9
; %bb.17:                               ;   in Loop: Header=BB18_16 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB18_16
LBB18_18:
	mov	x0, x19
	bl	_neoclr_roots_park_v1
	mov	w0, #0                          ; =0x0
	stp	x21, x20, [x19, #16]
	b	LBB18_10
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_complete_invocation_v1 ; -- Begin function neoclr_gc_complete_invocation_v1
	.p2align	2
_neoclr_gc_complete_invocation_v1:      ; @neoclr_gc_complete_invocation_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB19_11
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	add	x20, x0, #1048
	mov	x0, x20
	bl	_blocks_valid
	cbz	w0, LBB19_12
; %bb.2:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB19_5
LBB19_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x19
	b.eq	LBB19_12
; %bb.4:                                ;   in Loop: Header=BB19_3 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB19_3
LBB19_5:
	ldr	x8, [x19, #1064]
	cbz	x8, LBB19_13
; %bb.6:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x20]
	mov	w11, #3                         ; =0x3
	b	LBB19_8
LBB19_7:                                ;   in Loop: Header=BB19_8 Depth=1
	ldr	x12, [x12]
	add	x9, x12, x9
	cmp	x9, x8
	b.hs	LBB19_13
LBB19_8:                                ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9
	ldrb	w13, [x12, #24]
	tbz	w13, #0, LBB19_7
; %bb.9:                                ;   in Loop: Header=BB19_8 Depth=1
	ldr	x13, [x12, #16]
	cmp	x13, #6
	b.ne	LBB19_7
; %bb.10:                               ;   in Loop: Header=BB19_8 Depth=1
	str	x11, [x12, #16]
	b	LBB19_7
LBB19_11:
	mov	w0, #3                          ; =0x3
	ret
LBB19_12:
	mov	w0, #3                          ; =0x3
	b	LBB19_14
LBB19_13:
	mov	w0, #0                          ; =0x0
	str	xzr, [x19, #1072]
LBB19_14:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_entry_check_v1       ; -- Begin function neoclr_gc_entry_check_v1
	.p2align	2
_neoclr_gc_entry_check_v1:              ; @neoclr_gc_entry_check_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh48:
	adrp	x0, _resource_head@TLVPPAGE
Lloh49:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB20_3
LBB20_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x19
	b.eq	LBB20_16
; %bb.2:                                ;   in Loop: Header=BB20_1 Depth=1
	ldr	x8, [x8, #32]
	cbnz	x8, LBB20_1
LBB20_3:
	cbz	x19, LBB20_16
; %bb.4:
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB20_10
LBB20_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB20_7 Depth 2
	ldr	x8, [x0, #16]
	cmp	x8, x19
	b.eq	LBB20_16
; %bb.6:                                ;   in Loop: Header=BB20_5 Depth=1
	mov	x8, x0
LBB20_7:                                ;   Parent Loop BB20_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x8]
	cbz	x8, LBB20_9
; %bb.8:                                ;   in Loop: Header=BB20_7 Depth=2
	ldr	x9, [x8, #8]
	cmp	x9, x19
	b.ne	LBB20_7
	b	LBB20_16
LBB20_9:                                ;   in Loop: Header=BB20_5 Depth=1
	ldr	x0, [x0, #8]
	cbnz	x0, LBB20_5
LBB20_10:
Lloh50:
	adrp	x0, _host_head@TLVPPAGE
Lloh51:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB20_13
LBB20_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x19
	b.eq	LBB20_16
; %bb.12:                               ;   in Loop: Header=BB20_11 Depth=1
	ldr	x8, [x8, #48]
	cbnz	x8, LBB20_11
LBB20_13:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB20_17
LBB20_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x19
	b.eq	LBB20_16
; %bb.15:                               ;   in Loop: Header=BB20_14 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB20_14
	b	LBB20_17
LBB20_16:
	mov	w0, #3                          ; =0x3
LBB20_17:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpLdr	Lloh50, Lloh51
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_owned_roots_check_v1 ; -- Begin function neoclr_gc_owned_roots_check_v1
	.p2align	2
_neoclr_gc_owned_roots_check_v1:        ; @neoclr_gc_owned_roots_check_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh52:
	adrp	x0, _resource_head@TLVPPAGE
Lloh53:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB21_3
LBB21_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x19
	b.eq	LBB21_32
; %bb.2:                                ;   in Loop: Header=BB21_1 Depth=1
	ldr	x8, [x8, #32]
	cbnz	x8, LBB21_1
LBB21_3:
	mov	w8, #3                          ; =0x3
	cbz	x19, LBB21_33
; %bb.4:
	cmp	w2, #256
	b.hi	LBB21_33
; %bb.5:
	cbnz	x1, LBB21_7
; %bb.6:
	cbnz	w2, LBB21_33
LBB21_7:
	mov	x20, x1
	mov	x21, x2
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB21_13
LBB21_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB21_10 Depth 2
	ldr	x8, [x0, #16]
	cmp	x8, x19
	b.eq	LBB21_32
; %bb.9:                                ;   in Loop: Header=BB21_8 Depth=1
	mov	x8, x0
LBB21_10:                               ;   Parent Loop BB21_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x8]
	cbz	x8, LBB21_12
; %bb.11:                               ;   in Loop: Header=BB21_10 Depth=2
	ldr	x9, [x8, #8]
	cmp	x9, x19
	b.ne	LBB21_10
	b	LBB21_32
LBB21_12:                               ;   in Loop: Header=BB21_8 Depth=1
	ldr	x0, [x0, #8]
	cbnz	x0, LBB21_8
LBB21_13:
	bl	_neoclr_root_probe_head_v1
	mov	x9, x21
	mov	x10, x20
	cbz	x0, LBB21_16
LBB21_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x19
	b.eq	LBB21_32
; %bb.15:                               ;   in Loop: Header=BB21_14 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB21_14
LBB21_16:
Lloh54:
	adrp	x0, _host_head@TLVPPAGE
Lloh55:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	cbz	w9, LBB21_29
; %bb.17:
	ldr	x11, [x0]
	cbz	x11, LBB21_32
; %bb.18:
	mov	x12, #0                         ; =0x0
	mov	w13, w9
LBB21_19:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB21_22 Depth 2
                                        ;     Child Loop BB21_26 Depth 2
	ldr	x14, [x10, x12, lsl #3]
	cbz	x14, LBB21_32
; %bb.20:                               ;   in Loop: Header=BB21_19 Depth=1
	mov	x15, x11
	b	LBB21_22
LBB21_21:                               ;   in Loop: Header=BB21_22 Depth=2
	ldr	x15, [x15, #48]
	mov	w8, #3                          ; =0x3
	cbz	x15, LBB21_33
LBB21_22:                               ;   Parent Loop BB21_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x15]
	cmp	x8, x19
	b.ne	LBB21_21
; %bb.23:                               ;   in Loop: Header=BB21_22 Depth=2
	ldr	x8, [x15, #32]
	cmp	x8, x14
	b.ne	LBB21_21
; %bb.24:                               ;   in Loop: Header=BB21_19 Depth=1
	cbz	x12, LBB21_28
; %bb.25:                               ;   in Loop: Header=BB21_19 Depth=1
	mov	x8, #0                          ; =0x0
LBB21_26:                               ;   Parent Loop BB21_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x15, [x10, x8, lsl #3]
	cmp	x15, x14
	b.eq	LBB21_32
; %bb.27:                               ;   in Loop: Header=BB21_26 Depth=2
	add	x8, x8, #1
	cmp	x12, x8
	b.ne	LBB21_26
LBB21_28:                               ;   in Loop: Header=BB21_19 Depth=1
	add	x12, x12, #1
	cmp	x12, x13
	b.ne	LBB21_19
LBB21_29:
	ldr	x8, [x0]
	cbz	x8, LBB21_34
; %bb.30:
	mov	w10, #0                         ; =0x0
LBB21_31:                               ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x8]
	cmp	x11, x19
	cinc	w10, w10, eq
	ldr	x8, [x8, #48]
	cbnz	x8, LBB21_31
	b	LBB21_35
LBB21_32:
	mov	w8, #3                          ; =0x3
LBB21_33:
	mov	x0, x8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB21_34:
	mov	w10, #0                         ; =0x0
LBB21_35:
	mov	w8, #3                          ; =0x3
	cmp	w10, w9
	csel	w8, wzr, w8, eq
	b	LBB21_33
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpLdr	Lloh54, Lloh55
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_allocate_v1          ; -- Begin function neoclr_gc_allocate_v1
	.p2align	2
_neoclr_gc_allocate_v1:                 ; @neoclr_gc_allocate_v1
	.cfi_startproc
; %bb.0:
	mov	w8, #3                          ; =0x3
	cbz	x0, LBB22_19
; %bb.1:
	cbz	x3, LBB22_19
; %bb.2:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
Lloh56:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh57:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x21, [x0]
	cmp	x21, x19
	b.eq	LBB22_14
; %bb.3:
	ldp	x9, x10, [x19, #8]
LBB22_4:
	mov	w8, #3                          ; =0x3
	subs	x13, x9, x10
	b.lo	LBB22_18
; %bb.5:
	and	x11, x10, #0x7
	cbnz	x11, LBB22_18
; %bb.6:
	ldr	x11, [x19]
	cbz	x9, LBB22_8
; %bb.7:
	cbz	x11, LBB22_18
LBB22_8:
	sub	w9, w2, #7
	cmn	w9, #6
	b.lo	LBB22_18
; %bb.9:
	cbz	x1, LBB22_18
; %bb.10:
	and	x9, x11, #0x7
	cbnz	x9, LBB22_18
; %bb.11:
	add	x8, x1, #7
	and	x8, x8, #0xfffffffffffffff8
	add	x9, x8, #32
	cmn	x1, #40
	csinv	x15, x9, xzr, ls
	add	x14, x0, #32
	cmp	x21, x19
	b.eq	LBB22_30
; %bb.12:
	mov	x12, #0                         ; =0x0
	cbz	x10, LBB22_44
; %bb.13:
	mov	x16, #0                         ; =0x0
	b	LBB22_22
LBB22_14:
	ldr	x8, [x19]
	ldr	x9, [x0, #8]
	cmp	x8, x9
	b.ne	LBB22_17
; %bb.15:
	ldr	x9, [x19, #8]
	ldr	x8, [x0, #16]
	cmp	x9, x8
	b.ne	LBB22_17
; %bb.16:
	ldr	x10, [x19, #16]
	ldr	x8, [x0, #24]
	cmp	x10, x8
	b.eq	LBB22_4
LBB22_17:
	mov	w8, #3                          ; =0x3
LBB22_18:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
LBB22_19:
	mov	x0, x8
	ret
LBB22_20:                               ;   in Loop: Header=BB22_22 Depth=1
	cmp	x17, x15
	csel	x8, xzr, x4, lo
	cmp	x12, #0
	csel	x12, x12, x8, ne
LBB22_21:                               ;   in Loop: Header=BB22_22 Depth=1
	add	x16, x17, x16
	cmp	x16, x10
	b.hs	LBB22_44
LBB22_22:                               ; =>This Inner Loop Header: Depth=1
	sub	x5, x10, x16
	cmp	x5, #32
	b.lo	LBB22_17
; %bb.23:                               ;   in Loop: Header=BB22_22 Depth=1
	add	x4, x11, x16
	ldr	x17, [x4]
	mov	w8, #3                          ; =0x3
	cmp	x17, x5
	b.hi	LBB22_18
; %bb.24:                               ;   in Loop: Header=BB22_22 Depth=1
	and	x5, x17, #0x7
	cmp	x17, #40
	ccmp	x5, #0, #0, hs
	b.ne	LBB22_18
; %bb.25:                               ;   in Loop: Header=BB22_22 Depth=1
	ldr	x8, [x4, #24]
	cmp	x8, #7
	b.hi	LBB22_17
; %bb.26:                               ;   in Loop: Header=BB22_22 Depth=1
	cbz	x8, LBB22_20
; %bb.27:                               ;   in Loop: Header=BB22_22 Depth=1
	tbz	w8, #0, LBB22_17
; %bb.28:                               ;   in Loop: Header=BB22_22 Depth=1
	ldr	x8, [x4, #8]
	sub	x5, x17, #32
	sub	x8, x8, #1
	cmp	x8, x5
	b.hs	LBB22_17
; %bb.29:                               ;   in Loop: Header=BB22_22 Depth=1
	ldr	x8, [x4, #16]
	sub	x8, x8, #7
	cmn	x8, #6
	b.hs	LBB22_21
	b	LBB22_17
LBB22_30:
	ldr	x16, [x14]
	cbz	x16, LBB22_43
LBB22_31:                               ; =>This Inner Loop Header: Depth=1
	sub	x5, x16, #1
	and	x8, x5, #0x7
	cmp	x8, #0
	ccmp	x10, x5, #0, eq
	b.ls	LBB22_17
; %bb.32:                               ;   in Loop: Header=BB22_31 Depth=1
	sub	x16, x10, x5
	cmp	x16, #32
	b.lo	LBB22_17
; %bb.33:                               ;   in Loop: Header=BB22_31 Depth=1
	add	x12, x11, x5
	ldr	x17, [x12]
	mov	w8, #3                          ; =0x3
	cmp	x17, x16
	b.hi	LBB22_18
; %bb.34:                               ;   in Loop: Header=BB22_31 Depth=1
	and	x16, x17, #0x7
	cmp	x17, #40
	ccmp	x16, #0, #0, hs
	b.ne	LBB22_18
; %bb.35:                               ;   in Loop: Header=BB22_31 Depth=1
	ldr	x8, [x12, #24]
	cbnz	x8, LBB22_17
; %bb.36:                               ;   in Loop: Header=BB22_31 Depth=1
	mov	x4, x12
	ldr	x16, [x4, #8]!
	cbz	x16, LBB22_40
; %bb.37:                               ;   in Loop: Header=BB22_31 Depth=1
	sub	x6, x16, #1
	add	x8, x17, x5
	cmp	x6, x8
	b.lo	LBB22_17
; %bb.38:                               ;   in Loop: Header=BB22_31 Depth=1
	mov	w8, #3                          ; =0x3
	cmp	x6, x10
	b.hs	LBB22_18
; %bb.39:                               ;   in Loop: Header=BB22_31 Depth=1
	and	x5, x6, #0x7
	cbnz	x5, LBB22_18
LBB22_40:                               ;   in Loop: Header=BB22_31 Depth=1
	cmp	x17, x15
	b.hs	LBB22_44
; %bb.41:                               ;   in Loop: Header=BB22_31 Depth=1
	mov	x14, x4
	cbnz	x16, LBB22_31
; %bb.42:
	mov	x12, #0                         ; =0x0
	mov	x14, x4
	b	LBB22_44
LBB22_43:
	mov	x12, #0                         ; =0x0
LBB22_44:
	cmn	x1, #40
	b.ls	LBB22_46
LBB22_45:
	mov	w8, #5                          ; =0x5
	b	LBB22_18
LBB22_46:
	cbz	x12, LBB22_50
; %bb.47:
	cmp	x21, x19
	b.eq	LBB22_52
; %bb.48:
	mov	x22, x3
	ldr	x8, [x12]
	sub	x10, x8, x9
	cmp	x10, #40
	b.lo	LBB22_56
; %bb.49:
	add	x8, x12, x9
	stp	x10, xzr, [x8]
	stp	xzr, xzr, [x8, #16]
	str	x9, [x12]
	b	LBB22_57
LBB22_50:
	cmp	x9, x13
	b.hi	LBB22_45
; %bb.51:
	mov	x22, x3
	add	x12, x11, x10
	str	x9, [x12]
	add	x8, x10, x9
	str	x8, [x19, #16]
	cmp	x21, x19
	b.ne	LBB22_57
	b	LBB22_55
LBB22_52:
	ldp	x10, x8, [x12]
	sub	x10, x10, x9
	mov	x22, x3
	cmp	x10, #39
	b.ls	LBB22_54
; %bb.53:
	add	x13, x12, x9
	sub	x11, x13, x11
	stp	x10, x8, [x13]
	stp	xzr, xzr, [x13, #16]
	add	x8, x11, #1
	str	x9, [x12]
LBB22_54:
	str	x8, [x14]
LBB22_55:
	ldr	x8, [x19, #16]
	str	x8, [x0, #24]
	ldr	x9, [x12]
	b	LBB22_57
LBB22_56:
	mov	x9, x8
LBB22_57:
	mov	x23, x0
	mov	w8, w2
	stp	x1, x8, [x12, #8]
	mov	w8, #1                          ; =0x1
	str	x8, [x12, #24]
	add	x20, x12, #32
	sub	x1, x9, #32
	mov	x0, x20
	bl	_bzero
	cmp	x21, x19
	b.ne	LBB22_59
; %bb.58:
	ubfx	x8, x20, #3, #29
	eor	w8, w8, w20, lsr #9
	and	x8, x8, #0x3f
	add	x8, x23, x8, lsl #3
	str	x20, [x8, #40]
LBB22_59:
	str	x20, [x22]
Lloh58:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh59:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w8, #0                          ; =0x0
	ldr	x9, [x0, #32]
	add	x9, x9, #1
	str	x9, [x0, #32]
	b	LBB22_18
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpLdr	Lloh58, Lloh59
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_gc_allocate_rooted_values_v1
lCPI23_0:
	.long	8                               ; 0x8
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_gc_allocate_rooted_values_v1
	.p2align	2
_neoclr_gc_allocate_rooted_values_v1:   ; @neoclr_gc_allocate_rooted_values_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #464
	stp	x28, x27, [sp, #368]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #384]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #400]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #416]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #432]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #448]            ; 16-byte Folded Spill
	add	x29, sp, #448
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh60:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh61:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh62:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	cmp	w3, #16
	b.hi	LBB23_5
; %bb.1:
	mov	x19, x0
	cmp	x2, #0
	ccmp	w3, #0, #4, eq
	cset	w9, ne
Lloh63:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh64:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB23_6
; %bb.2:
	tbnz	w9, #0, LBB23_6
; %bb.3:
	ldr	w8, [x8, #88]
	cbnz	w8, LBB23_6
; %bb.4:
	mov	x25, x2
	mov	x24, x3
	mov	x22, x4
	mov	x21, x5
	mov	x20, x6
	mov	x26, x1
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x26
	b.eq	LBB23_8
LBB23_5:
	mov	w0, #3                          ; =0x3
LBB23_6:
	ldur	x8, [x29, #-88]
Lloh65:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh66:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh67:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB23_25
; %bb.7:
	ldp	x29, x30, [sp, #448]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #432]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #416]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #400]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #384]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #368]            ; 16-byte Folded Reload
	add	sp, sp, #464
	ret
LBB23_8:
	mov	x8, x26
	cbz	x26, LBB23_10
; %bb.9:
	ldr	x8, [x8, #8]
	cmp	x8, x19
	b.ne	LBB23_5
LBB23_10:
	add	x0, x19, #1048
	mov	x23, x22
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	bl	_neoclr_gc_allocate_v1
	cmp	w0, #5
	b.ne	LBB23_6
; %bb.11:
	cmn	x23, #40
	b.hi	LBB23_13
; %bb.12:
	add	x11, x23, #7
	and	x11, x11, #0xfffffffffffffff8
	add	x11, x11, #32
	ldr	x12, [x19, #1056]
	cmp	x11, x12
	b.ls	LBB23_14
LBB23_13:
	mov	w0, #5                          ; =0x5
	b	LBB23_6
LBB23_14:
	mov	x9, x26
	mov	x8, x24
	mov	x1, x26
	cbz	w24, LBB23_23
; %bb.15:
	mov	x10, x25
	mov	w11, w8
	adrp	x12, lCPI23_0@PAGE
	cmp	w8, #3
	b.hi	LBB23_17
; %bb.16:
	mov	x13, #0                         ; =0x0
	b	LBB23_20
LBB23_17:
	and	x13, x11, #0x1c
	add	x14, sp, #104
	add	x14, x14, #32
	ldr	d0, [x12, lCPI23_0@PAGEOFF]
	mov	x15, x10
	mov	x16, x13
LBB23_18:                               ; =>This Inner Loop Header: Depth=1
	add	x17, x15, #8
	stur	x15, [x14, #-32]
	add	x0, x15, #16
	add	x1, x15, #24
	stur	x17, [x14, #-16]
	str	x0, [x14]
	str	x1, [x14, #16]
	stur	d0, [x14, #-24]
	stur	d0, [x14, #-8]
	str	d0, [x14, #8]
	str	d0, [x14, #24]
	add	x14, x14, #64
	add	x15, x15, #32
	subs	x16, x16, #4
	b.ne	LBB23_18
; %bb.19:
	cmp	x13, x11
	b.eq	LBB23_22
LBB23_20:
	add	x14, sp, #104
	add	x14, x14, x13, lsl #4
	add	x14, x14, #8
	add	x10, x10, x13, lsl #3
	sub	x11, x11, x13
	ldr	d0, [x12, lCPI23_0@PAGEOFF]
LBB23_21:                               ; =>This Inner Loop Header: Depth=1
	stur	x10, [x14, #-8]
	str	d0, [x14], #16
	add	x10, x10, #8
	subs	x11, x11, #1
	b.ne	LBB23_21
LBB23_22:
	mov	x1, sp
LBB23_23:
	stp	x9, x19, [sp]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #16]
	add	x9, sp, #104
	stp	x9, xzr, [sp, #48]
	str	w8, [sp, #64]
	stur	q0, [sp, #68]
	stur	q0, [sp, #84]
	str	wzr, [sp, #100]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cbnz	w0, LBB23_6
; %bb.24:
	add	x0, x19, #1048
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	bl	_neoclr_gc_allocate_v1
	b	LBB23_6
LBB23_25:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh60, Lloh61, Lloh62
	.loh AdrpLdr	Lloh63, Lloh64
	.loh AdrpLdrGotLdr	Lloh65, Lloh66, Lloh67
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_collect_v1           ; -- Begin function neoclr_gc_collect_v1
	.p2align	2
_neoclr_gc_collect_v1:                  ; @neoclr_gc_collect_v1
	.cfi_startproc
; %bb.0:
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	b	_neoclr_gc_collect_conditional_v1
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_allocate_rooted_v1   ; -- Begin function neoclr_gc_allocate_rooted_v1
	.p2align	2
_neoclr_gc_allocate_rooted_v1:          ; @neoclr_gc_allocate_rooted_v1
	.cfi_startproc
; %bb.0:
	mov	x6, x4
	mov	x5, x3
	mov	x4, x2
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	b	_neoclr_gc_allocate_rooted_values_v1
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_collect_conditional_v1 ; -- Begin function neoclr_gc_collect_conditional_v1
	.p2align	2
_neoclr_gc_collect_conditional_v1:      ; @neoclr_gc_collect_conditional_v1
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	sub	sp, sp, #2368
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	mov	x8, x0
Lloh68:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh69:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh70:
	ldr	x9, [x9]
	stur	x9, [x29, #-56]
Lloh71:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh72:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB26_41
; %bb.1:
	ldr	w9, [x9, #88]
	cbnz	w9, LBB26_41
; %bb.2:
	add	x10, x8, #1048
Lloh73:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh74:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	ldr	x11, [x0]
	cmp	x11, x10
	b.eq	LBB26_12
; %bb.3:
	ldr	x12, [x8, #1064]
	ldr	x13, [x8, #1056]
LBB26_4:
	mov	w0, #3                          ; =0x3
	cmp	x12, x13
	b.hi	LBB26_41
; %bb.5:
	and	x14, x12, #0x7
	cbnz	x14, LBB26_41
; %bb.6:
	ldr	x17, [x10]
	cmp	x17, #0
	ccmp	x13, #0, #4, eq
	b.ne	LBB26_41
; %bb.7:
	and	x13, x17, #0x7
	cbnz	x13, LBB26_41
; %bb.8:
	cbz	x12, LBB26_36
; %bb.9:
	sub	x14, x12, #1
	mov	w13, #5                         ; =0x5
LBB26_10:                               ; =>This Inner Loop Header: Depth=1
	add	w13, w13, #1
	lsr	x15, x14, x13
	cmp	x15, #255
	b.hi	LBB26_10
; %bb.11:
	mov	x15, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	ldr	x9, [x9, #32]
	cmp	x11, x10
	csel	x9, x9, xzr, eq
	add	x6, sp, #312
	add	x7, sp, #56
	b	LBB26_17
LBB26_12:
	ldr	x12, [x10]
	ldr	x13, [x9, #8]
	cmp	x12, x13
	b.ne	LBB26_40
; %bb.13:
	ldr	x13, [x8, #1056]
	ldr	x12, [x9, #16]
	cmp	x13, x12
	b.ne	LBB26_40
; %bb.14:
	ldr	x12, [x8, #1064]
	ldr	x14, [x9, #24]
	cmp	x12, x14
	b.eq	LBB26_4
	b	LBB26_40
LBB26_15:                               ;   in Loop: Header=BB26_17 Depth=1
	mov	w5, w5
LBB26_16:                               ;   in Loop: Header=BB26_17 Depth=1
	add	x16, x16, #1
	cmp	x4, x12
	b.hs	LBB26_39
LBB26_17:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB26_34 Depth 2
	sub	x21, x12, x4
	cmp	x21, #32
	b.lo	LBB26_40
; %bb.18:                               ;   in Loop: Header=BB26_17 Depth=1
	add	x19, x17, x4
	ldr	x20, [x19]
	mov	w0, #3                          ; =0x3
	cmp	x20, x21
	b.hi	LBB26_41
; %bb.19:                               ;   in Loop: Header=BB26_17 Depth=1
	and	x21, x20, #0x7
	cmp	x20, #40
	ccmp	x21, #0, #0, hs
	b.ne	LBB26_41
; %bb.20:                               ;   in Loop: Header=BB26_17 Depth=1
	ldr	x0, [x19, #24]
	cmp	x0, #7
	b.hi	LBB26_40
; %bb.21:                               ;   in Loop: Header=BB26_17 Depth=1
	cbz	x0, LBB26_30
; %bb.22:                               ;   in Loop: Header=BB26_17 Depth=1
	tbz	w0, #0, LBB26_40
; %bb.23:                               ;   in Loop: Header=BB26_17 Depth=1
	ldr	x21, [x19, #8]
	sub	x22, x20, #32
	sub	x21, x21, #1
	cmp	x21, x22
	b.hs	LBB26_40
; %bb.24:                               ;   in Loop: Header=BB26_17 Depth=1
	ldr	x21, [x19, #16]
	sub	x22, x21, #7
	cmn	x22, #6
	b.lo	LBB26_40
; %bb.25:                               ;   in Loop: Header=BB26_17 Depth=1
	cmp	x0, #1
	cset	w0, ne
	orr	w14, w14, w0
	cmp	x21, #6
	b.ne	LBB26_33
; %bb.26:                               ;   in Loop: Header=BB26_17 Depth=1
	cmp	x15, #32
	b.hi	LBB26_33
; %bb.27:                               ;   in Loop: Header=BB26_17 Depth=1
	b.eq	LBB26_29
; %bb.28:                               ;   in Loop: Header=BB26_17 Depth=1
	str	x19, [x7, x15, lsl #3]
LBB26_29:                               ;   in Loop: Header=BB26_17 Depth=1
	add	x15, x15, #1
	b	LBB26_33
LBB26_30:                               ;   in Loop: Header=BB26_17 Depth=1
	cmp	x11, x10
	b.ne	LBB26_33
; %bb.31:                               ;   in Loop: Header=BB26_17 Depth=1
	orr	x0, x4, #0x1
	cmp	x9, x0
	b.ne	LBB26_40
; %bb.32:                               ;   in Loop: Header=BB26_17 Depth=1
	ldr	x9, [x19, #8]
LBB26_33:                               ;   in Loop: Header=BB26_17 Depth=1
	add	x4, x20, x4
	cmp	x5, #255
	b.hi	LBB26_16
LBB26_34:                               ;   Parent Loop BB26_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x0, x5, x13
	cmp	x0, x4
	b.hs	LBB26_15
; %bb.35:                               ;   in Loop: Header=BB26_34 Depth=2
	str	x19, [x6, x5, lsl #3]
	add	x0, x5, #1
	mov	x5, x0
	cmp	x0, #256
	b.ne	LBB26_34
	b	LBB26_16
LBB26_36:
	ldr	x9, [x9, #32]
	cmp	x11, x10
	ccmp	x9, #0, #4, eq
	b.ne	LBB26_41
; %bb.37:
	mov	x15, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	mov	w13, #6                         ; =0x6
LBB26_38:
	add	x9, sp, #312
	add	x10, sp, #56
	stp	x9, x10, [sp]
	mov	w9, #256                        ; =0x100
	stp	w9, w13, [sp, #16]
	str	w15, [sp, #24]
	stp	x16, xzr, [sp, #32]
	str	w14, [sp, #48]
	mov	x4, sp
	mov	x0, x8
	bl	_collect_indexed
	b	LBB26_41
LBB26_39:
	cbz	x9, LBB26_43
LBB26_40:
	mov	w0, #3                          ; =0x3
LBB26_41:
	ldur	x8, [x29, #-56]
Lloh75:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh76:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh77:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB26_45
; %bb.42:
	add	sp, sp, #2368
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
LBB26_43:
	cmp	x16, #2049
	b.lo	LBB26_38
; %bb.44:
	mov	x0, x8
	bl	_collect_dense
	b	LBB26_41
LBB26_45:
	bl	___stack_chk_fail
	.loh AdrpLdr	Lloh71, Lloh72
	.loh AdrpLdrGotLdr	Lloh68, Lloh69, Lloh70
	.loh AdrpLdr	Lloh73, Lloh74
	.loh AdrpLdrGotLdr	Lloh75, Lloh76, Lloh77
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_idle_v1              ; -- Begin function neoclr_gc_idle_v1
	.p2align	2
_neoclr_gc_idle_v1:                     ; @neoclr_gc_idle_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cbnz	w0, LBB27_2
; %bb.1:
Lloh78:
	adrp	x8, _neoclr_execution_state_v1@TLVPPAGE
Lloh79:
	ldr	x8, [x8, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x10, [x8]
	mov	x9, x0
	mov	x0, x8
	blr	x10
	mov	x8, x0
	mov	x0, x9
	str	x19, [x8, #56]
	ldur	q0, [x8, #24]
	ext.16b	v0, v0, v0, #8
	str	q0, [x8, #64]
	str	xzr, [x8, #80]
LBB27_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh78, Lloh79
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_boundary_v1          ; -- Begin function neoclr_gc_boundary_v1
	.p2align	2
_neoclr_gc_boundary_v1:                 ; @neoclr_gc_boundary_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x1
	mov	x19, x0
Lloh80:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh81:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB28_4
; %bb.1:
	ldr	w8, [x20, #88]
	cbnz	w8, LBB28_4
; %bb.2:
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x21
	b.eq	LBB28_5
LBB28_3:
	mov	w0, #3                          ; =0x3
LBB28_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB28_5:
	cbz	x21, LBB28_7
; %bb.6:
	ldr	x8, [x21, #8]
	cmp	x8, x19
	b.ne	LBB28_3
LBB28_7:
	ldr	x8, [x20, #56]
	cmp	x8, x19
	b.ne	LBB28_12
; %bb.8:
	ldr	x8, [x20, #24]
	ldr	x9, [x20, #72]
	cmp	x8, x9
	b.ne	LBB28_12
; %bb.9:
	ldr	x8, [x20, #32]
	ldr	x9, [x20, #64]
	sub	x8, x8, x9
	cmp	x8, #255
	b.hi	LBB28_12
; %bb.10:
	ldr	x8, [x20, #80]
	add	x8, x8, #1
	str	x8, [x20, #80]
	cmp	x8, #1024
	b.hs	LBB28_12
; %bb.11:
	mov	w0, #0                          ; =0x0
	b	LBB28_4
LBB28_12:
	mov	x0, x19
	mov	x1, x21
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cbnz	w0, LBB28_4
; %bb.13:
	str	x19, [x20, #56]
	ldur	q0, [x20, #24]
	ext.16b	v0, v0, v0, #8
	str	q0, [x20, #64]
	str	xzr, [x20, #80]
	b	LBB28_4
	.loh AdrpLdr	Lloh80, Lloh81
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_published_boundary_v1 ; -- Begin function neoclr_gc_published_boundary_v1
	.p2align	2
_neoclr_gc_published_boundary_v1:       ; @neoclr_gc_published_boundary_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh82:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh83:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w8, #3                          ; =0x3
	cbz	x19, LBB29_12
; %bb.1:
	cbz	x1, LBB29_12
; %bb.2:
	ldr	w9, [x0, #88]
	cbnz	w9, LBB29_12
; %bb.3:
	ldr	x8, [x1, #8]
	cmp	x8, x19
	b.eq	LBB29_5
; %bb.4:
	mov	w8, #3                          ; =0x3
	b	LBB29_12
LBB29_5:
	ldr	x8, [x0, #56]
	cmp	x8, x19
	b.ne	LBB29_10
; %bb.6:
	ldr	x8, [x0, #24]
	ldr	x9, [x0, #72]
	cmp	x8, x9
	b.ne	LBB29_10
; %bb.7:
	ldr	x8, [x0, #32]
	ldr	x9, [x0, #64]
	sub	x8, x8, x9
	cmp	x8, #255
	b.hi	LBB29_10
; %bb.8:
	ldr	x8, [x0, #80]
	add	x8, x8, #1
	str	x8, [x0, #80]
	cmp	x8, #1024
	b.hs	LBB29_10
; %bb.9:
	mov	w8, #0                          ; =0x0
	b	LBB29_12
LBB29_10:
	mov	x20, x0
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	mov	x8, x0
	cbnz	w0, LBB29_12
; %bb.11:
	str	x19, [x20, #56]
	ldur	q0, [x20, #24]
	ext.16b	v0, v0, v0, #8
	str	q0, [x20, #64]
	str	xzr, [x20, #80]
LBB29_12:
	mov	x0, x8
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh82, Lloh83
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_statistics_v1        ; -- Begin function neoclr_gc_statistics_v1
	.p2align	2
_neoclr_gc_statistics_v1:               ; @neoclr_gc_statistics_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh84:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh85:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldur	q0, [x0, #24]
	ldur	q1, [x0, #40]
	stp	q0, q1, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh84, Lloh85
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_string_intern_v1        ; -- Begin function neoclr_string_intern_v1
	.p2align	2
_neoclr_string_intern_v1:               ; @neoclr_string_intern_v1
	.cfi_startproc
; %bb.0:
	mov	w3, #0                          ; =0x0
	b	_string_intern
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function string_intern
_string_intern:                         ; @string_intern
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x0
	mov	w0, #3                          ; =0x3
	cbz	x20, LBB32_26
; %bb.1:
	mov	x19, x2
	cbz	x2, LBB32_26
; %bb.2:
	mov	x21, x1
	str	w3, [sp, #12]                   ; 4-byte Folded Spill
	mov	x0, x1
	bl	_blocks_valid
	cbz	w0, LBB32_25
; %bb.3:
	ldr	x25, [x21, #16]
	cbz	x25, LBB32_15
; %bb.4:
	str	x19, [sp]                       ; 8-byte Folded Spill
	mov	x26, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	mov	x27, #0                         ; =0x0
	ldr	x28, [x21]
	mov	w9, #1048576                    ; =0x100000
	b	LBB32_7
LBB32_5:                                ;   in Loop: Header=BB32_7 Depth=1
	add	x24, x22, x24
	add	x26, x26, #1
LBB32_6:                                ;   in Loop: Header=BB32_7 Depth=1
	ldr	x8, [x23]
	add	x27, x8, x27
	cmp	x27, x25
	b.hs	LBB32_16
LBB32_7:                                ; =>This Inner Loop Header: Depth=1
	add	x23, x28, x27
	ldrb	w8, [x23, #24]
	tbz	w8, #0, LBB32_6
; %bb.8:                                ;   in Loop: Header=BB32_7 Depth=1
	ldr	x8, [x23, #16]
	cmp	x8, #6
	b.ne	LBB32_6
; %bb.9:                                ;   in Loop: Header=BB32_7 Depth=1
	ldr	x8, [x23, #8]
	cmp	x8, #8
	b.ne	LBB32_25
; %bb.10:                               ;   in Loop: Header=BB32_7 Depth=1
	ldr	x19, [x23, #32]
	cbz	x19, LBB32_25
; %bb.11:                               ;   in Loop: Header=BB32_7 Depth=1
	ldr	x22, [x19]
	sub	x8, x9, x24
	cmp	x22, x8
	b.hi	LBB32_25
; %bb.12:                               ;   in Loop: Header=BB32_7 Depth=1
	ldr	x8, [x20]
	cmp	x22, x8
	b.ne	LBB32_5
; %bb.13:                               ;   in Loop: Header=BB32_7 Depth=1
	add	x0, x19, #8
	add	x1, x20, #8
	mov	x2, x22
	bl	_memcmp
	mov	w9, #1048576                    ; =0x100000
	cbnz	w0, LBB32_5
; %bb.14:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x19, [x8]
	b	LBB32_26
LBB32_15:
	mov	w9, #1048576                    ; =0x100000
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	b	LBB32_18
LBB32_16:
	cmp	x26, #4095
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	b.hi	LBB32_19
; %bb.17:
	mov	w9, #1048576                    ; =0x100000
	sub	x9, x9, x24
	ldr	x19, [sp]                       ; 8-byte Folded Reload
LBB32_18:
	ldr	x10, [x20]
	cmp	x10, x9
	b.ls	LBB32_20
LBB32_19:
	mov	w0, #10                         ; =0xa
	b	LBB32_26
LBB32_20:
	cbz	w8, LBB32_27
; %bb.21:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB32_25
; %bb.22:
	mov	x1, x0
	ldr	x8, [x0, #8]
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB32_26
; %bb.23:
	add	x9, x8, #1048
	cmp	x9, x21
	b.ne	LBB32_26
; %bb.24:
	str	x20, [sp, #16]
	add	x2, sp, #16
	add	x6, sp, #24
	mov	x0, x8
	mov	w3, #1                          ; =0x1
	mov	w4, #8                          ; =0x8
	mov	w5, #6                          ; =0x6
	bl	_neoclr_gc_allocate_rooted_values_v1
	b	LBB32_28
LBB32_25:
	mov	w0, #3                          ; =0x3
LBB32_26:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB32_27:
	add	x3, sp, #24
	mov	x0, x21
	mov	w1, #8                          ; =0x8
	mov	w2, #6                          ; =0x6
	bl	_neoclr_gc_allocate_v1
LBB32_28:
	cbnz	w0, LBB32_26
; %bb.29:
	ldr	x8, [sp, #24]
	str	x20, [x8]
	str	x20, [x19]
	b	LBB32_26
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_string_intern_rooted_v1 ; -- Begin function neoclr_string_intern_rooted_v1
	.p2align	2
_neoclr_string_intern_rooted_v1:        ; @neoclr_string_intern_rooted_v1
	.cfi_startproc
; %bb.0:
	mov	w3, #1                          ; =0x1
	b	_string_intern
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_collect_managed_v1   ; -- Begin function neoclr_gc_collect_managed_v1
	.p2align	2
_neoclr_gc_collect_managed_v1:          ; @neoclr_gc_collect_managed_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_neoclr_root_probe_head_v1
	mov	x1, x0
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_neoclr_gc_collect_conditional_v1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_dense
_collect_dense:                         ; @collect_dense
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #33088                      ; =0x8140
Lloh86:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh87:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
Lloh88:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh89:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh90:
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	ldr	x11, [x0, #1064]
	cbz	x11, LBB35_15
; %bb.1:
	sub	x9, x11, #1
	mov	w8, #5                          ; =0x5
LBB35_2:                                ; =>This Inner Loop Header: Depth=1
	add	w8, w8, #1
	lsr	x10, x9, x8
	cmp	x10, #4095
	b.hi	LBB35_2
; %bb.3:
	mov	x13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	ldr	x14, [x0, #1048]
	add	x15, sp, #312
	add	x16, sp, #56
	b	LBB35_6
LBB35_4:                                ;   in Loop: Header=BB35_6 Depth=1
	mov	w13, w13
LBB35_5:                                ;   in Loop: Header=BB35_6 Depth=1
	orr	w9, w9, w17
	cmp	x12, x11
	b.hs	LBB35_16
LBB35_6:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB35_13 Depth 2
	add	x4, x14, x12
	ldr	x5, [x4, #24]
	cmp	x5, #1
	cset	w17, hi
	cbz	x5, LBB35_12
; %bb.7:                                ;   in Loop: Header=BB35_6 Depth=1
	ldr	x5, [x4, #16]
	cmp	x5, #6
	b.ne	LBB35_12
; %bb.8:                                ;   in Loop: Header=BB35_6 Depth=1
	cmp	x10, #32
	b.hi	LBB35_12
; %bb.9:                                ;   in Loop: Header=BB35_6 Depth=1
	b.eq	LBB35_11
; %bb.10:                               ;   in Loop: Header=BB35_6 Depth=1
	str	x4, [x16, x10, lsl #3]
LBB35_11:                               ;   in Loop: Header=BB35_6 Depth=1
	add	x10, x10, #1
LBB35_12:                               ;   in Loop: Header=BB35_6 Depth=1
	ldr	x5, [x4]
	add	x12, x5, x12
	cmp	x13, #4095
	b.hi	LBB35_5
LBB35_13:                               ;   Parent Loop BB35_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x5, x13, x8
	cmp	x5, x12
	b.hs	LBB35_4
; %bb.14:                               ;   in Loop: Header=BB35_13 Depth=2
	str	x4, [x15, x13, lsl #3]
	add	x5, x13, #1
	mov	x13, x5
	cmp	x5, #1, lsl #12                 ; =4096
	b.ne	LBB35_13
	b	LBB35_5
LBB35_15:
	mov	x10, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	mov	w8, #6                          ; =0x6
LBB35_16:
	add	x11, sp, #312
	add	x12, sp, #56
	stp	x11, x12, [sp]
	mov	w11, #4096                      ; =0x1000
	stp	w11, w8, [sp, #16]
	str	w10, [sp, #24]
	stp	xzr, xzr, [sp, #32]
	str	w9, [sp, #48]
	mov	x4, sp
	bl	_collect_indexed
	ldur	x8, [x29, #-24]
Lloh91:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh92:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh93:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB35_18
; %bb.17:
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #320
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
LBB35_18:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh88, Lloh89, Lloh90
	.loh AdrpLdrGotLdr	Lloh91, Lloh92, Lloh93
	.loh AdrpLdrGot	Lloh86, Lloh87
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_indexed
_collect_indexed:                       ; @collect_indexed
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1120
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh94:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh95:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh96:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cmp	w3, #256
	b.hi	LBB36_3
; %bb.1:
	mov	x19, x0
	cbnz	x2, LBB36_6
; %bb.2:
	cbz	w3, LBB36_6
LBB36_3:
	mov	w0, #3                          ; =0x3
LBB36_4:
	ldur	x8, [x29, #-96]
Lloh97:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh98:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh99:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB36_350
; %bb.5:
	add	sp, sp, #1120
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB36_6:
	add	x25, x19, #1048
Lloh100:
	adrp	x0, _resource_head@TLVPPAGE
Lloh101:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	ldr	x8, [x0]
	cbz	x8, LBB36_18
; %bb.7:
	mov	w0, #3                          ; =0x3
	b	LBB36_9
LBB36_8:                                ;   in Loop: Header=BB36_9 Depth=1
	ldr	x8, [x8, #32]
	cbz	x8, LBB36_18
LBB36_9:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_14 Depth 2
	ldr	x9, [x8]
	cmp	x9, x19
	b.ne	LBB36_8
; %bb.10:                               ;   in Loop: Header=BB36_9 Depth=1
	ldr	x9, [x8, #8]
	cbz	x9, LBB36_3
; %bb.11:                               ;   in Loop: Header=BB36_9 Depth=1
	ldr	x10, [x25]
	cmp	x10, x9
	b.hi	LBB36_3
; %bb.12:                               ;   in Loop: Header=BB36_9 Depth=1
	ldr	x11, [x19, #1064]
	sub	x12, x9, x10
	cmp	x12, x11
	b.hs	LBB36_3
; %bb.13:                               ;   in Loop: Header=BB36_9 Depth=1
	ldr	x13, [x4]
	ldr	w14, [x4, #20]
	lsr	x14, x12, x14
	ldr	x13, [x13, x14, lsl #3]
	sub	x14, x13, x10
LBB36_14:                               ;   Parent Loop BB36_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x14, x11
	b.hs	LBB36_3
; %bb.15:                               ;   in Loop: Header=BB36_14 Depth=2
	mov	x13, x14
	ldr	x14, [x10, x14]
	add	x14, x14, x13
	cmp	x12, x14
	b.hs	LBB36_14
; %bb.16:                               ;   in Loop: Header=BB36_9 Depth=1
	add	x10, x10, x13
	ldrb	w11, [x10, #24]
	tbz	w11, #0, LBB36_4
; %bb.17:                               ;   in Loop: Header=BB36_9 Depth=1
	add	x10, x10, #32
	cmp	x10, x9
	b.eq	LBB36_8
	b	LBB36_4
LBB36_18:
	cbz	w3, LBB36_38
; %bb.19:
	mov	x8, #0                          ; =0x0
	mov	w9, w3
	mov	w10, #24                        ; =0x18
LBB36_20:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_24 Depth 2
                                        ;     Child Loop BB36_32 Depth 2
	madd	x11, x8, x10, x2
	ldr	x12, [x11]
	cbz	x12, LBB36_36
; %bb.21:                               ;   in Loop: Header=BB36_20 Depth=1
	ldr	x13, [x25]
	cmp	x13, x12
	b.hi	LBB36_3
; %bb.22:                               ;   in Loop: Header=BB36_20 Depth=1
	ldr	x14, [x19, #1064]
	sub	x15, x12, x13
	cmp	x15, x14
	b.hs	LBB36_3
; %bb.23:                               ;   in Loop: Header=BB36_20 Depth=1
	ldr	x16, [x4]
	ldr	w17, [x4, #20]
	lsr	x17, x15, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x13
LBB36_24:                               ;   Parent Loop BB36_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x17, x14
	b.hs	LBB36_3
; %bb.25:                               ;   in Loop: Header=BB36_24 Depth=2
	mov	x16, x17
	ldr	x17, [x13, x17]
	add	x17, x17, x16
	cmp	x15, x17
	b.hs	LBB36_24
; %bb.26:                               ;   in Loop: Header=BB36_20 Depth=1
	add	x13, x13, x16
	mov	w0, #3                          ; =0x3
	ldrb	w14, [x13, #24]
	tbz	w14, #0, LBB36_4
; %bb.27:                               ;   in Loop: Header=BB36_20 Depth=1
	add	x13, x13, #32
	cmp	x13, x12
	b.ne	LBB36_4
; %bb.28:                               ;   in Loop: Header=BB36_20 Depth=1
	ldr	x11, [x11, #8]
	cbz	x11, LBB36_37
; %bb.29:                               ;   in Loop: Header=BB36_20 Depth=1
	ldr	x12, [x25]
	cmp	x12, x11
	b.hi	LBB36_4
; %bb.30:                               ;   in Loop: Header=BB36_20 Depth=1
	ldr	x13, [x19, #1064]
	sub	x14, x11, x12
	cmp	x14, x13
	b.hs	LBB36_4
; %bb.31:                               ;   in Loop: Header=BB36_20 Depth=1
	ldr	x15, [x4]
	ldr	w16, [x4, #20]
	lsr	x16, x14, x16
	ldr	x15, [x15, x16, lsl #3]
	sub	x16, x15, x12
LBB36_32:                               ;   Parent Loop BB36_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x16, x13
	b.hs	LBB36_3
; %bb.33:                               ;   in Loop: Header=BB36_32 Depth=2
	mov	x15, x16
	ldr	x16, [x12, x16]
	add	x16, x16, x15
	cmp	x14, x16
	b.hs	LBB36_32
; %bb.34:                               ;   in Loop: Header=BB36_20 Depth=1
	add	x12, x12, x15
	mov	w0, #3                          ; =0x3
	ldrb	w13, [x12, #24]
	tbz	w13, #0, LBB36_4
; %bb.35:                               ;   in Loop: Header=BB36_20 Depth=1
	add	x12, x12, #32
	cmp	x12, x11
	b.eq	LBB36_37
	b	LBB36_4
LBB36_36:                               ;   in Loop: Header=BB36_20 Depth=1
	ldr	x11, [x11, #8]
	cbnz	x11, LBB36_3
LBB36_37:                               ;   in Loop: Header=BB36_20 Depth=1
	add	x8, x8, #1
	cmp	x8, x9
	b.ne	LBB36_20
LBB36_38:
Lloh102:
	adrp	x0, _host_head@TLVPPAGE
Lloh103:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x21, x0
	ldr	x8, [x0]
	cbnz	x8, LBB36_42
LBB36_39:
	str	x2, [sp, #24]                   ; 8-byte Folded Spill
	str	w3, [sp, #32]                   ; 4-byte Folded Spill
	mov	x22, x4
	mov	x23, x1
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB36_72
; %bb.40:
	mov	x9, x22
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	b	LBB36_62
LBB36_41:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	x8, [x8, #48]
	cbz	x8, LBB36_39
LBB36_42:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_47 Depth 2
                                        ;     Child Loop BB36_57 Depth 2
	ldr	x9, [x8]
	cmp	x9, x19
	b.ne	LBB36_41
; %bb.43:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	x9, [x8, #8]
	cbz	x9, LBB36_51
; %bb.44:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	x10, [x25]
	cmp	x10, x9
	b.hi	LBB36_3
; %bb.45:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	x11, [x19, #1064]
	sub	x12, x9, x10
	cmp	x12, x11
	b.hs	LBB36_3
; %bb.46:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	x13, [x4]
	ldr	w14, [x4, #20]
	lsr	x14, x12, x14
	ldr	x13, [x13, x14, lsl #3]
	sub	x14, x13, x10
LBB36_47:                               ;   Parent Loop BB36_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x14, x11
	b.hs	LBB36_3
; %bb.48:                               ;   in Loop: Header=BB36_47 Depth=2
	mov	x13, x14
	ldr	x14, [x10, x14]
	add	x14, x14, x13
	cmp	x12, x14
	b.hs	LBB36_47
; %bb.49:                               ;   in Loop: Header=BB36_42 Depth=1
	add	x10, x10, x13
	mov	w0, #3                          ; =0x3
	ldrb	w11, [x10, #24]
	tbz	w11, #0, LBB36_4
; %bb.50:                               ;   in Loop: Header=BB36_42 Depth=1
	add	x10, x10, #32
	cmp	x10, x9
	b.ne	LBB36_4
LBB36_51:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	w9, [x8, #24]
	cbz	w9, LBB36_41
; %bb.52:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	w9, [x8, #28]
	cbnz	w9, LBB36_41
; %bb.53:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	x9, [x8, #16]
	cbz	x9, LBB36_3
; %bb.54:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	x10, [x25]
	cmp	x10, x9
	b.hi	LBB36_3
; %bb.55:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	x11, [x19, #1064]
	sub	x12, x9, x10
	cmp	x12, x11
	b.hs	LBB36_3
; %bb.56:                               ;   in Loop: Header=BB36_42 Depth=1
	ldr	x13, [x4]
	ldr	w14, [x4, #20]
	lsr	x14, x12, x14
	ldr	x13, [x13, x14, lsl #3]
	sub	x14, x13, x10
LBB36_57:                               ;   Parent Loop BB36_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x14, x11
	b.hs	LBB36_3
; %bb.58:                               ;   in Loop: Header=BB36_57 Depth=2
	mov	x13, x14
	ldr	x14, [x10, x14]
	add	x14, x14, x13
	cmp	x12, x14
	b.hs	LBB36_57
; %bb.59:                               ;   in Loop: Header=BB36_42 Depth=1
	add	x10, x10, x13
	mov	w0, #3                          ; =0x3
	ldrb	w11, [x10, #24]
	tbz	w11, #0, LBB36_4
; %bb.60:                               ;   in Loop: Header=BB36_42 Depth=1
	add	x10, x10, #32
	cmp	x10, x9
	b.eq	LBB36_41
	b	LBB36_4
LBB36_61:                               ;   in Loop: Header=BB36_62 Depth=1
	ldr	x8, [x8, #8]
	cbz	x8, LBB36_72
LBB36_62:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_68 Depth 2
	ldr	x10, [x8, #16]
	cmp	x10, x19
	b.ne	LBB36_61
; %bb.63:                               ;   in Loop: Header=BB36_62 Depth=1
	ldr	w10, [x8, #32]
	cbnz	w10, LBB36_61
; %bb.64:                               ;   in Loop: Header=BB36_62 Depth=1
	ldr	x10, [x8, #24]
	cbz	x10, LBB36_3
; %bb.65:                               ;   in Loop: Header=BB36_62 Depth=1
	ldr	x11, [x25]
	cmp	x11, x10
	b.hi	LBB36_3
; %bb.66:                               ;   in Loop: Header=BB36_62 Depth=1
	ldr	x12, [x19, #1064]
	sub	x13, x10, x11
	cmp	x13, x12
	b.hs	LBB36_3
; %bb.67:                               ;   in Loop: Header=BB36_62 Depth=1
	ldr	x14, [x9]
	ldr	w15, [x9, #20]
	lsr	x15, x13, x15
	ldr	x14, [x14, x15, lsl #3]
	sub	x15, x14, x11
LBB36_68:                               ;   Parent Loop BB36_62 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x15, x12
	b.hs	LBB36_3
; %bb.69:                               ;   in Loop: Header=BB36_68 Depth=2
	mov	x14, x15
	ldr	x15, [x11, x15]
	add	x15, x15, x14
	cmp	x13, x15
	b.hs	LBB36_68
; %bb.70:                               ;   in Loop: Header=BB36_62 Depth=1
	add	x11, x11, x14
	ldrb	w12, [x11, #24]
	tbz	w12, #0, LBB36_4
; %bb.71:                               ;   in Loop: Header=BB36_62 Depth=1
	add	x11, x11, #32
	cmp	x11, x10
	b.eq	LBB36_61
	b	LBB36_4
LBB36_72:
	add	x1, sp, #64
	mov	x0, x19
	mov	w2, #65                         ; =0x41
	bl	_neoclr_probe_fault_roots_v1
	tbnz	w0, #31, LBB36_3
; %bb.73:
	mov	x24, x0
	bl	_neoclr_roots_parked_v1
	mov	x1, x22
	cbnz	x0, LBB36_79
LBB36_74:
	ldr	w8, [x1, #48]
	cbnz	w8, LBB36_76
; %bb.75:
	ldr	w9, [x1, #24]
	cmp	w9, #32
	b.ls	LBB36_81
LBB36_76:
	ldr	x9, [x19, #1064]
	cbz	x9, LBB36_83
; %bb.77:
	mov	x10, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	ldr	x11, [x25]
	mov	w12, #7                         ; =0x7
	b	LBB36_103
LBB36_78:                               ;   in Loop: Header=BB36_79 Depth=1
	ldr	x0, [x0, #8]
	cbz	x0, LBB36_74
LBB36_79:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #16]
	cmp	x8, x19
	b.ne	LBB36_78
; %bb.80:                               ;   in Loop: Header=BB36_79 Depth=1
	str	wzr, [x0, #36]
	b	LBB36_78
LBB36_81:
	cbz	w9, LBB36_83
; %bb.82:
	mov	x10, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	ldr	x11, [x1, #8]
	ldr	x12, [x19, #1048]
	mov	w13, #7                         ; =0x7
	b	LBB36_117
LBB36_83:
	mov	x8, #0                          ; =0x0
LBB36_84:
	cbz	w24, LBB36_99
; %bb.85:
	mov	x9, #0                          ; =0x0
	add	x10, sp, #64
	mov	w11, #7                         ; =0x7
	mov	w12, w24
	b	LBB36_88
LBB36_86:                               ;   in Loop: Header=BB36_88 Depth=1
	orr	x8, x8, #0x3
	str	x8, [x14, #24]
	mov	x8, x14
LBB36_87:                               ;   in Loop: Header=BB36_88 Depth=1
	add	x9, x9, #1
	cmp	x9, x12
	b.eq	LBB36_99
LBB36_88:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_92 Depth 2
	add	x13, x10, x9, lsl #4
	ldr	w14, [x13, #8]
	cmp	w14, #8
	b.ne	LBB36_87
; %bb.89:                               ;   in Loop: Header=BB36_88 Depth=1
	ldr	x13, [x13]
	ldr	x13, [x13]
	ldr	x14, [x25]
	subs	x15, x13, x14
	b.lo	LBB36_87
; %bb.90:                               ;   in Loop: Header=BB36_88 Depth=1
	ldr	x16, [x19, #1064]
	cmp	x15, x16
	b.hs	LBB36_87
; %bb.91:                               ;   in Loop: Header=BB36_88 Depth=1
	ldr	x17, [x1]
	ldr	w0, [x1, #20]
	lsr	x0, x15, x0
	ldr	x17, [x17, x0, lsl #3]
	sub	x0, x17, x14
LBB36_92:                               ;   Parent Loop BB36_88 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x0, x16
	b.hs	LBB36_87
; %bb.93:                               ;   in Loop: Header=BB36_92 Depth=2
	mov	x17, x0
	ldr	x0, [x14, x0]
	add	x0, x0, x17
	cmp	x15, x0
	b.hs	LBB36_92
; %bb.94:                               ;   in Loop: Header=BB36_88 Depth=1
	add	x14, x14, x17
	ldr	x16, [x14, #24]
	cmp	x16, #0
	add	x15, x14, #32
	ccmp	x13, x15, #0, ne
	b.lo	LBB36_87
; %bb.95:                               ;   in Loop: Header=BB36_88 Depth=1
	tbnz	w16, #1, LBB36_87
; %bb.96:                               ;   in Loop: Header=BB36_88 Depth=1
	ldr	x16, [x14, #8]
	sub	x13, x13, x15
	cmp	x13, x16
	b.hs	LBB36_87
; %bb.97:                               ;   in Loop: Header=BB36_88 Depth=1
	ldr	x13, [x14, #16]
	orr	x13, x13, #0x2
	cmp	x13, #3
	b.ne	LBB36_86
; %bb.98:                               ;   in Loop: Header=BB36_88 Depth=1
	str	x11, [x14, #24]
	ldr	x13, [x1, #40]
	add	x13, x13, #1
	str	x13, [x1, #40]
	b	LBB36_87
LBB36_99:
	ldr	x9, [x21]
	cbz	x9, LBB36_142
; %bb.100:
	mov	w10, #7                         ; =0x7
	b	LBB36_130
LBB36_101:                              ;   in Loop: Header=BB36_103 Depth=1
	orr	x8, x8, #0x3
	str	x8, [x15, #24]
	mov	x8, x15
LBB36_102:                              ;   in Loop: Header=BB36_103 Depth=1
	ldr	x13, [x13]
	add	x10, x13, x10
	cmp	x10, x9
	b.hs	LBB36_84
LBB36_103:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_107 Depth 2
	add	x13, x11, x10
	ldr	x14, [x13, #24]
	and	x15, x14, #0x1
	str	x15, [x13, #24]
	tbz	w14, #0, LBB36_102
; %bb.104:                              ;   in Loop: Header=BB36_103 Depth=1
	ldr	x14, [x13, #16]
	cmp	x14, #6
	add	x14, x13, #32
	ccmp	x11, x14, #2, eq
	b.hi	LBB36_102
; %bb.105:                              ;   in Loop: Header=BB36_103 Depth=1
	sub	x15, x14, x11
	cmp	x15, x9
	b.hs	LBB36_102
; %bb.106:                              ;   in Loop: Header=BB36_103 Depth=1
	ldr	x16, [x1]
	ldr	w17, [x1, #20]
	lsr	x17, x15, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x11
LBB36_107:                              ;   Parent Loop BB36_103 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x17, x9
	b.hs	LBB36_102
; %bb.108:                              ;   in Loop: Header=BB36_107 Depth=2
	mov	x16, x17
	ldr	x17, [x11, x17]
	add	x17, x17, x16
	cmp	x15, x17
	b.hs	LBB36_107
; %bb.109:                              ;   in Loop: Header=BB36_103 Depth=1
	cmp	x16, x10
	b.gt	LBB36_102
; %bb.110:                              ;   in Loop: Header=BB36_103 Depth=1
	add	x15, x11, x16
	ldr	x16, [x15, #24]
	cbz	x16, LBB36_102
; %bb.111:                              ;   in Loop: Header=BB36_103 Depth=1
	tbnz	w16, #1, LBB36_102
; %bb.112:                              ;   in Loop: Header=BB36_103 Depth=1
	sub	x14, x14, x15
	sub	x14, x14, #32
	ldr	x16, [x15, #8]
	cmp	x14, x16
	b.hs	LBB36_102
; %bb.113:                              ;   in Loop: Header=BB36_103 Depth=1
	ldr	x14, [x15, #16]
	orr	x14, x14, #0x2
	cmp	x14, #3
	b.ne	LBB36_101
; %bb.114:                              ;   in Loop: Header=BB36_103 Depth=1
	str	x12, [x15, #24]
	ldr	x14, [x1, #40]
	add	x14, x14, #1
	str	x14, [x1, #40]
	b	LBB36_102
LBB36_115:                              ;   in Loop: Header=BB36_117 Depth=1
	orr	x8, x8, #0x3
	str	x8, [x16, #24]
	mov	x8, x16
LBB36_116:                              ;   in Loop: Header=BB36_117 Depth=1
	add	x10, x10, #1
	cmp	x10, x9
	b.eq	LBB36_84
LBB36_117:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_120 Depth 2
	ldr	x15, [x11, x10, lsl #3]
	add	x14, x15, #32
	cmp	x12, x14
	b.hi	LBB36_116
; %bb.118:                              ;   in Loop: Header=BB36_117 Depth=1
	ldr	x16, [x19, #1064]
	sub	x17, x14, x12
	cmp	x17, x16
	b.hs	LBB36_116
; %bb.119:                              ;   in Loop: Header=BB36_117 Depth=1
	ldr	x0, [x1]
	ldr	w2, [x1, #20]
	lsr	x2, x17, x2
	ldr	x0, [x0, x2, lsl #3]
	sub	x2, x0, x12
LBB36_120:                              ;   Parent Loop BB36_117 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x2, x16
	b.hs	LBB36_116
; %bb.121:                              ;   in Loop: Header=BB36_120 Depth=2
	mov	x0, x2
	ldr	x2, [x12, x2]
	add	x2, x2, x0
	cmp	x17, x2
	b.hs	LBB36_120
; %bb.122:                              ;   in Loop: Header=BB36_117 Depth=1
	add	x16, x12, x0
	cmp	x16, x15
	b.hi	LBB36_116
; %bb.123:                              ;   in Loop: Header=BB36_117 Depth=1
	ldr	x15, [x16, #24]
	cbz	x15, LBB36_116
; %bb.124:                              ;   in Loop: Header=BB36_117 Depth=1
	tbnz	w15, #1, LBB36_116
; %bb.125:                              ;   in Loop: Header=BB36_117 Depth=1
	sub	x14, x14, x16
	sub	x14, x14, #32
	ldr	x15, [x16, #8]
	cmp	x14, x15
	b.hs	LBB36_116
; %bb.126:                              ;   in Loop: Header=BB36_117 Depth=1
	ldr	x14, [x16, #16]
	orr	x14, x14, #0x2
	cmp	x14, #3
	b.ne	LBB36_115
; %bb.127:                              ;   in Loop: Header=BB36_117 Depth=1
	str	x13, [x16, #24]
	ldr	x14, [x1, #40]
	add	x14, x14, #1
	str	x14, [x1, #40]
	b	LBB36_116
LBB36_128:                              ;   in Loop: Header=BB36_130 Depth=1
	orr	x8, x8, #0x3
	str	x8, [x12, #24]
	mov	x8, x12
LBB36_129:                              ;   in Loop: Header=BB36_130 Depth=1
	ldr	x9, [x9, #48]
	cbz	x9, LBB36_142
LBB36_130:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_135 Depth 2
	ldr	x11, [x9]
	cmp	x11, x19
	b.ne	LBB36_129
; %bb.131:                              ;   in Loop: Header=BB36_130 Depth=1
	ldr	w11, [x9, #24]
	cbnz	w11, LBB36_129
; %bb.132:                              ;   in Loop: Header=BB36_130 Depth=1
	ldr	x11, [x9, #8]
	ldr	x12, [x25]
	cmp	x12, x11
	b.hi	LBB36_129
; %bb.133:                              ;   in Loop: Header=BB36_130 Depth=1
	ldr	x13, [x19, #1064]
	sub	x14, x11, x12
	cmp	x14, x13
	b.hs	LBB36_129
; %bb.134:                              ;   in Loop: Header=BB36_130 Depth=1
	ldr	x15, [x1]
	ldr	w16, [x1, #20]
	lsr	x16, x14, x16
	ldr	x15, [x15, x16, lsl #3]
	sub	x16, x15, x12
LBB36_135:                              ;   Parent Loop BB36_130 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x16, x13
	b.hs	LBB36_129
; %bb.136:                              ;   in Loop: Header=BB36_135 Depth=2
	mov	x15, x16
	ldr	x16, [x12, x16]
	add	x16, x16, x15
	cmp	x14, x16
	b.hs	LBB36_135
; %bb.137:                              ;   in Loop: Header=BB36_130 Depth=1
	add	x12, x12, x15
	ldr	x14, [x12, #24]
	cmp	x14, #0
	add	x13, x12, #32
	ccmp	x13, x11, #2, ne
	b.hi	LBB36_129
; %bb.138:                              ;   in Loop: Header=BB36_130 Depth=1
	tbnz	w14, #1, LBB36_129
; %bb.139:                              ;   in Loop: Header=BB36_130 Depth=1
	ldr	x14, [x12, #8]
	sub	x11, x11, x13
	cmp	x11, x14
	b.hs	LBB36_129
; %bb.140:                              ;   in Loop: Header=BB36_130 Depth=1
	ldr	x11, [x12, #16]
	orr	x11, x11, #0x2
	cmp	x11, #3
	b.ne	LBB36_128
; %bb.141:                              ;   in Loop: Header=BB36_130 Depth=1
	str	x10, [x12, #24]
	ldr	x11, [x1, #40]
	add	x11, x11, #1
	str	x11, [x1, #40]
	b	LBB36_129
LBB36_142:
	str	x8, [sp, #56]
	ldr	x9, [x19, #1072]
	ldr	x10, [x19, #1048]
	cmp	x10, x9
	b.hi	LBB36_148
; %bb.143:
	ldr	x11, [x19, #1064]
	sub	x12, x9, x10
	cmp	x12, x11
	b.hs	LBB36_148
; %bb.144:
	ldr	x13, [x1]
	ldr	w14, [x1, #20]
	lsr	x14, x12, x14
	ldr	x13, [x13, x14, lsl #3]
	sub	x14, x13, x10
LBB36_145:                              ; =>This Inner Loop Header: Depth=1
	cmp	x14, x11
	b.hs	LBB36_148
; %bb.146:                              ;   in Loop: Header=BB36_145 Depth=1
	mov	x13, x14
	ldr	x14, [x10, x14]
	add	x14, x14, x13
	cmp	x12, x14
	b.hs	LBB36_145
; %bb.147:
	add	x10, x10, x13
	ldr	x12, [x10, #24]
	cmp	x12, #0
	add	x11, x10, #32
	ccmp	x11, x9, #2, ne
	b.ls	LBB36_289
LBB36_148:
	str	x21, [sp, #8]                   ; 8-byte Folded Spill
	add	x3, sp, #56
	mov	x0, x19
	mov	x2, x23
	bl	_mark_frames
	bl	_neoclr_roots_parked_v1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	w10, [sp, #32]                  ; 4-byte Folded Reload
	cbz	x0, LBB36_153
; %bb.149:
	mov	x23, x0
	b	LBB36_151
LBB36_150:                              ;   in Loop: Header=BB36_151 Depth=1
	ldr	x23, [x23, #8]
	cbz	x23, LBB36_153
LBB36_151:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x23, #16]
	cbnz	x8, LBB36_150
; %bb.152:                              ;   in Loop: Header=BB36_151 Depth=1
	ldr	x2, [x23]
	add	x3, sp, #56
	mov	x0, x19
	mov	x1, x22
	bl	_mark_frames
	ldr	w10, [sp, #32]                  ; 4-byte Folded Reload
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	b	LBB36_150
LBB36_153:
	mov	w28, #4                         ; =0x4
	movk	w28, #32768, lsl #16
	ldr	x21, [sp, #56]
	mov	w7, #1                          ; =0x1
	mov	w26, #7                         ; =0x7
	mov	w27, #24                        ; =0x18
	mov	w23, #8                         ; =0x8
	mov	x30, #-5                        ; =0xfffffffffffffffb
	movk	x30, #32767, lsl #16
	mov	w24, w10
	mov	x1, x22
LBB36_154:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB36_158 Depth 2
                                        ;       Child Loop BB36_201 Depth 3
                                        ;       Child Loop BB36_182 Depth 3
                                        ;         Child Loop BB36_186 Depth 4
                                        ;           Child Loop BB36_189 Depth 5
                                        ;       Child Loop BB36_224 Depth 3
                                        ;         Child Loop BB36_229 Depth 4
                                        ;       Child Loop BB36_212 Depth 3
                                        ;         Child Loop BB36_215 Depth 4
                                        ;     Child Loop BB36_258 Depth 2
                                        ;       Child Loop BB36_263 Depth 3
                                        ;     Child Loop BB36_272 Depth 2
                                        ;       Child Loop BB36_279 Depth 3
                                        ;     Child Loop BB36_248 Depth 2
	ldr	x8, [x1, #40]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	cbnz	x21, LBB36_158
LBB36_155:                              ;   in Loop: Header=BB36_154 Depth=1
	cbz	w10, LBB36_244
; %bb.156:                              ;   in Loop: Header=BB36_154 Depth=1
	mov	x10, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	b	LBB36_258
LBB36_157:                              ;   in Loop: Header=BB36_158 Depth=2
	cbz	x21, LBB36_155
LBB36_158:                              ;   Parent Loop BB36_154 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB36_201 Depth 3
                                        ;       Child Loop BB36_182 Depth 3
                                        ;         Child Loop BB36_186 Depth 4
                                        ;           Child Loop BB36_189 Depth 5
                                        ;       Child Loop BB36_224 Depth 3
                                        ;         Child Loop BB36_229 Depth 4
                                        ;       Child Loop BB36_212 Depth 3
                                        ;         Child Loop BB36_215 Depth 4
	ldp	x13, x11, [x21, #16]
	and	x11, x11, #0xfffffffffffffff8
	str	x26, [x21, #24]
	add	x12, x21, #32
	cmp	x13, #4
	b.gt	LBB36_166
; %bb.159:                              ;   in Loop: Header=BB36_158 Depth=2
	cmp	x13, #2
	b.eq	LBB36_171
; %bb.160:                              ;   in Loop: Header=BB36_158 Depth=2
	cmp	x13, #4
	b.ne	LBB36_196
; %bb.161:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x12, [x21, #8]
	subs	x14, x12, #16
	b.lo	LBB36_286
; %bb.162:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	w12, [x21, #32]
	add	x13, x12, x30
	cmn	x13, #2
	b.lo	LBB36_286
; %bb.163:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x13, [x21, #40]
	cmp	x12, x28
	cinc	x15, x23, eq
	udiv	x14, x14, x15
	cmp	x13, x14
	b.hi	LBB36_286
; %bb.164:                              ;   in Loop: Header=BB36_158 Depth=2
	cbz	x13, LBB36_206
; %bb.165:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x14, #0                         ; =0x0
	add	x15, x21, #48
	add	x16, x15, x13, lsl #3
	mov	x21, x11
	b	LBB36_224
LBB36_166:                              ;   in Loop: Header=BB36_158 Depth=2
	cmp	x13, #5
	b.eq	LBB36_173
; %bb.167:                              ;   in Loop: Header=BB36_158 Depth=2
	cmp	x13, #6
	b.ne	LBB36_197
; %bb.168:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x13, [x21, #8]
	cmp	x13, #8
	b.ne	LBB36_286
; %bb.169:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x12, [x12]
	ldr	x13, [x25]
	subs	x14, x12, x13
	b.hs	LBB36_199
; %bb.170:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_171:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x13, [x21, #8]
	cmp	x13, #16
	b.hs	LBB36_198
; %bb.172:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_173:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x13, [x21, #8]
	subs	x15, x13, #24
	b.lo	LBB36_286
; %bb.174:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x13, [x21, #32]
	mov	w16, w13
	add	x17, x28, #1
	lsr	x14, x13, #32
	cmp	x14, #1024
	ccmp	x16, x17, #0, ls
	b.ne	LBB36_286
; %bb.175:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x13, [x21, #48]
	cmp	x13, #1
	ccmp	x14, #0, #4, ne
	b.ne	LBB36_286
; %bb.176:                              ;   in Loop: Header=BB36_158 Depth=2
	sub	x14, x13, #257
	cmn	x14, #256
	b.lo	LBB36_286
; %bb.177:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x14, [x21, #40]
	cmp	x14, #16, lsl #12               ; =65536
	b.hi	LBB36_286
; %bb.178:                              ;   in Loop: Header=BB36_158 Depth=2
	orr	x16, x7, x13, lsl #3
	udiv	x15, x15, x16
	cmp	x14, x15
	b.hi	LBB36_286
; %bb.179:                              ;   in Loop: Header=BB36_158 Depth=2
	cbz	x14, LBB36_207
; %bb.180:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x15, #0                         ; =0x0
	mul	x16, x14, x13
	add	x12, x12, x16, lsl #3
	add	x12, x12, #24
	add	x16, x21, #56
	mov	x21, x11
	b	LBB36_182
LBB36_181:                              ;   in Loop: Header=BB36_182 Depth=3
	add	x15, x15, #1
	cmp	x15, x14
	b.eq	LBB36_157
LBB36_182:                              ;   Parent Loop BB36_154 Depth=1
                                        ;     Parent Loop BB36_158 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB36_186 Depth 4
                                        ;           Child Loop BB36_189 Depth 5
	ldrb	w11, [x12, x15]
	cbz	w11, LBB36_181
; %bb.183:                              ;   in Loop: Header=BB36_182 Depth=3
	mov	x11, #0                         ; =0x0
	mul	x17, x15, x13
	ldr	x0, [x25]
	b	LBB36_186
LBB36_184:                              ;   in Loop: Header=BB36_186 Depth=4
	orr	x2, x21, #0x3
	str	x2, [x3, #24]
	mov	x21, x3
LBB36_185:                              ;   in Loop: Header=BB36_186 Depth=4
	add	x11, x11, #1
	cmp	x11, x13
	b.eq	LBB36_181
LBB36_186:                              ;   Parent Loop BB36_154 Depth=1
                                        ;     Parent Loop BB36_158 Depth=2
                                        ;       Parent Loop BB36_182 Depth=3
                                        ; =>      This Loop Header: Depth=4
                                        ;           Child Loop BB36_189 Depth 5
	add	x2, x11, x17
	ldr	x2, [x16, x2, lsl #3]
	subs	x3, x2, x0
	b.lo	LBB36_185
; %bb.187:                              ;   in Loop: Header=BB36_186 Depth=4
	ldr	x4, [x19, #1064]
	cmp	x3, x4
	b.hs	LBB36_185
; %bb.188:                              ;   in Loop: Header=BB36_186 Depth=4
	ldr	x5, [x1]
	ldr	w6, [x1, #20]
	lsr	x6, x3, x6
	ldr	x5, [x5, x6, lsl #3]
	sub	x6, x5, x0
LBB36_189:                              ;   Parent Loop BB36_154 Depth=1
                                        ;     Parent Loop BB36_158 Depth=2
                                        ;       Parent Loop BB36_182 Depth=3
                                        ;         Parent Loop BB36_186 Depth=4
                                        ; =>        This Inner Loop Header: Depth=5
	cmp	x6, x4
	b.hs	LBB36_185
; %bb.190:                              ;   in Loop: Header=BB36_189 Depth=5
	mov	x5, x6
	ldr	x6, [x0, x6]
	add	x6, x6, x5
	cmp	x3, x6
	b.hs	LBB36_189
; %bb.191:                              ;   in Loop: Header=BB36_186 Depth=4
	add	x3, x0, x5
	ldr	x5, [x3, #24]
	cmp	x5, #0
	add	x4, x3, #32
	ccmp	x2, x4, #0, ne
	b.lo	LBB36_185
; %bb.192:                              ;   in Loop: Header=BB36_186 Depth=4
	tbnz	w5, #1, LBB36_185
; %bb.193:                              ;   in Loop: Header=BB36_186 Depth=4
	ldr	x5, [x3, #8]
	sub	x2, x2, x4
	cmp	x2, x5
	b.hs	LBB36_185
; %bb.194:                              ;   in Loop: Header=BB36_186 Depth=4
	ldr	x2, [x3, #16]
	orr	x2, x2, #0x2
	cmp	x2, #3
	b.ne	LBB36_184
; %bb.195:                              ;   in Loop: Header=BB36_186 Depth=4
	str	x26, [x3, #24]
	add	x8, x8, #1
	str	x8, [x1, #40]
	b	LBB36_185
LBB36_196:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_197:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_198:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x14, [x25]
	mov	w16, #16                        ; =0x10
	mov	w15, #8                         ; =0x8
	mov	x21, x11
	b	LBB36_212
LBB36_199:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x15, [x19, #1064]
	cmp	x14, x15
	b.hs	LBB36_208
; %bb.200:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x16, [x1]
	ldr	w17, [x1, #20]
	lsr	x17, x14, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x13
LBB36_201:                              ;   Parent Loop BB36_154 Depth=1
                                        ;     Parent Loop BB36_158 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x17, x15
	b.hs	LBB36_209
; %bb.202:                              ;   in Loop: Header=BB36_201 Depth=3
	mov	x16, x17
	ldr	x17, [x13, x17]
	add	x17, x17, x16
	cmp	x14, x17
	b.hs	LBB36_201
; %bb.203:                              ;   in Loop: Header=BB36_158 Depth=2
	add	x21, x13, x16
	ldr	x13, [x21, #24]
	cbz	x13, LBB36_236
; %bb.204:                              ;   in Loop: Header=BB36_158 Depth=2
	add	x14, x21, #32
	subs	x12, x12, x14
	b.hs	LBB36_237
; %bb.205:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_206:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_207:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_208:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_209:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_210:                              ;   in Loop: Header=BB36_212 Depth=3
	orr	x11, x21, #0x3
	str	x11, [x16, #24]
	mov	x21, x16
LBB36_211:                              ;   in Loop: Header=BB36_212 Depth=3
	add	x16, x15, #8
	cmp	x16, x13
	b.hi	LBB36_157
LBB36_212:                              ;   Parent Loop BB36_154 Depth=1
                                        ;     Parent Loop BB36_158 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB36_215 Depth 4
	ldr	x11, [x12, x15]
	mov	x15, x16
	subs	x16, x11, x14
	b.lo	LBB36_211
; %bb.213:                              ;   in Loop: Header=BB36_212 Depth=3
	ldr	x17, [x19, #1064]
	cmp	x16, x17
	b.hs	LBB36_211
; %bb.214:                              ;   in Loop: Header=BB36_212 Depth=3
	ldr	x0, [x1]
	ldr	w2, [x1, #20]
	lsr	x2, x16, x2
	ldr	x0, [x0, x2, lsl #3]
	sub	x2, x0, x14
LBB36_215:                              ;   Parent Loop BB36_154 Depth=1
                                        ;     Parent Loop BB36_158 Depth=2
                                        ;       Parent Loop BB36_212 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	cmp	x2, x17
	b.hs	LBB36_211
; %bb.216:                              ;   in Loop: Header=BB36_215 Depth=4
	mov	x0, x2
	ldr	x2, [x14, x2]
	add	x2, x2, x0
	cmp	x16, x2
	b.hs	LBB36_215
; %bb.217:                              ;   in Loop: Header=BB36_212 Depth=3
	add	x16, x14, x0
	ldr	x0, [x16, #24]
	cmp	x0, #0
	add	x17, x16, #32
	ccmp	x11, x17, #0, ne
	b.lo	LBB36_211
; %bb.218:                              ;   in Loop: Header=BB36_212 Depth=3
	tbnz	w0, #1, LBB36_211
; %bb.219:                              ;   in Loop: Header=BB36_212 Depth=3
	ldr	x0, [x16, #8]
	sub	x11, x11, x17
	cmp	x11, x0
	b.hs	LBB36_211
; %bb.220:                              ;   in Loop: Header=BB36_212 Depth=3
	ldr	x11, [x16, #16]
	orr	x11, x11, #0x2
	cmp	x11, #3
	b.ne	LBB36_210
; %bb.221:                              ;   in Loop: Header=BB36_212 Depth=3
	str	x26, [x16, #24]
	add	x8, x8, #1
	str	x8, [x1, #40]
	b	LBB36_211
LBB36_222:                              ;   in Loop: Header=BB36_224 Depth=3
	orr	x11, x21, #0x3
	str	x11, [x17, #24]
	mov	x21, x17
LBB36_223:                              ;   in Loop: Header=BB36_224 Depth=3
	add	x14, x14, #1
	cmp	x14, x13
	b.eq	LBB36_157
LBB36_224:                              ;   Parent Loop BB36_154 Depth=1
                                        ;     Parent Loop BB36_158 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB36_229 Depth 4
	cmp	x12, x28
	b.ne	LBB36_226
; %bb.225:                              ;   in Loop: Header=BB36_224 Depth=3
	ldrb	w11, [x16, x14]
	cbz	w11, LBB36_223
LBB36_226:                              ;   in Loop: Header=BB36_224 Depth=3
	ldr	x11, [x15, x14, lsl #3]
	ldr	x17, [x25]
	subs	x0, x11, x17
	b.lo	LBB36_223
; %bb.227:                              ;   in Loop: Header=BB36_224 Depth=3
	ldr	x2, [x19, #1064]
	cmp	x0, x2
	b.hs	LBB36_223
; %bb.228:                              ;   in Loop: Header=BB36_224 Depth=3
	ldr	x3, [x1]
	ldr	w4, [x1, #20]
	lsr	x4, x0, x4
	ldr	x3, [x3, x4, lsl #3]
	sub	x4, x3, x17
LBB36_229:                              ;   Parent Loop BB36_154 Depth=1
                                        ;     Parent Loop BB36_158 Depth=2
                                        ;       Parent Loop BB36_224 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	cmp	x4, x2
	b.hs	LBB36_223
; %bb.230:                              ;   in Loop: Header=BB36_229 Depth=4
	mov	x3, x4
	ldr	x4, [x17, x4]
	add	x4, x4, x3
	cmp	x0, x4
	b.hs	LBB36_229
; %bb.231:                              ;   in Loop: Header=BB36_224 Depth=3
	add	x17, x17, x3
	ldr	x2, [x17, #24]
	cmp	x2, #0
	add	x0, x17, #32
	ccmp	x11, x0, #0, ne
	b.lo	LBB36_223
; %bb.232:                              ;   in Loop: Header=BB36_224 Depth=3
	tbnz	w2, #1, LBB36_223
; %bb.233:                              ;   in Loop: Header=BB36_224 Depth=3
	ldr	x2, [x17, #8]
	sub	x11, x11, x0
	cmp	x11, x2
	b.hs	LBB36_223
; %bb.234:                              ;   in Loop: Header=BB36_224 Depth=3
	ldr	x11, [x17, #16]
	orr	x11, x11, #0x2
	cmp	x11, #3
	b.ne	LBB36_222
; %bb.235:                              ;   in Loop: Header=BB36_224 Depth=3
	str	x26, [x17, #24]
	add	x8, x8, #1
	str	x8, [x1, #40]
	b	LBB36_223
LBB36_236:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_237:                              ;   in Loop: Header=BB36_158 Depth=2
	tbnz	w13, #1, LBB36_242
; %bb.238:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x13, [x21, #8]
	cmp	x12, x13
	b.hs	LBB36_241
; %bb.239:                              ;   in Loop: Header=BB36_158 Depth=2
	ldr	x12, [x21, #16]
	orr	x12, x12, #0x2
	cmp	x12, #3
	b.ne	LBB36_243
; %bb.240:                              ;   in Loop: Header=BB36_158 Depth=2
	str	x26, [x21, #24]
	add	x8, x8, #1
	str	x8, [x1, #40]
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_241:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_242:                              ;   in Loop: Header=BB36_158 Depth=2
	mov	x21, x11
	cbnz	x11, LBB36_158
	b	LBB36_155
LBB36_243:                              ;   in Loop: Header=BB36_158 Depth=2
	orr	x11, x11, #0x3
	str	x11, [x21, #24]
	cbnz	x21, LBB36_158
	b	LBB36_155
LBB36_244:                              ;   in Loop: Header=BB36_154 Depth=1
	mov	x21, #0                         ; =0x0
LBB36_245:                              ;   in Loop: Header=BB36_154 Depth=1
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x9, [x9]
	cbnz	x9, LBB36_272
LBB36_246:                              ;   in Loop: Header=BB36_154 Depth=1
	str	x21, [sp, #56]
	bl	_neoclr_roots_parked_v1
	mov	x1, x22
	mov	x23, x0
	ldr	w10, [sp, #32]                  ; 4-byte Folded Reload
	mov	w7, #1                          ; =0x1
	mov	x30, #-5                        ; =0xfffffffffffffffb
	movk	x30, #32767, lsl #16
	cbnz	x0, LBB36_248
	b	LBB36_254
LBB36_247:                              ;   in Loop: Header=BB36_248 Depth=2
	ldr	x23, [x23, #8]
	cbz	x23, LBB36_253
LBB36_248:                              ;   Parent Loop BB36_154 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x23, #16]
	cmp	x8, x19
	b.ne	LBB36_247
; %bb.249:                              ;   in Loop: Header=BB36_248 Depth=2
	ldr	w8, [x23, #32]
	cbnz	w8, LBB36_247
; %bb.250:                              ;   in Loop: Header=BB36_248 Depth=2
	ldr	w8, [x23, #36]
	cbnz	w8, LBB36_247
; %bb.251:                              ;   in Loop: Header=BB36_248 Depth=2
	ldr	x8, [x23, #24]
	ldurb	w8, [x8, #-8]
	tbz	w8, #1, LBB36_247
; %bb.252:                              ;   in Loop: Header=BB36_248 Depth=2
	str	w7, [x23, #36]
	ldr	x2, [x23]
	add	x3, sp, #56
	mov	x0, x19
	bl	_mark_frames
	mov	x30, #-5                        ; =0xfffffffffffffffb
	movk	x30, #32767, lsl #16
	mov	w7, #1                          ; =0x1
	mov	x1, x22
	ldr	w10, [sp, #32]                  ; 4-byte Folded Reload
	b	LBB36_247
LBB36_253:                              ;   in Loop: Header=BB36_154 Depth=1
	ldr	x21, [sp, #56]
LBB36_254:                              ;   in Loop: Header=BB36_154 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	mov	w23, #8                         ; =0x8
	cbnz	x21, LBB36_154
; %bb.255:                              ;   in Loop: Header=BB36_154 Depth=1
	ldr	x8, [x1, #40]
	ldr	x11, [sp, #16]                  ; 8-byte Folded Reload
	cmp	x11, x8
	b.ne	LBB36_154
	b	LBB36_293
LBB36_256:                              ;   in Loop: Header=BB36_258 Depth=2
	orr	x11, x21, #0x3
	str	x11, [x12, #24]
	mov	x21, x12
LBB36_257:                              ;   in Loop: Header=BB36_258 Depth=2
	add	x10, x10, #1
	cmp	x10, x24
	b.eq	LBB36_245
LBB36_258:                              ;   Parent Loop BB36_154 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB36_263 Depth 3
	madd	x11, x10, x27, x9
	ldr	x12, [x11]
	cbz	x12, LBB36_257
; %bb.259:                              ;   in Loop: Header=BB36_258 Depth=2
	ldurb	w12, [x12, #-8]
	tbz	w12, #1, LBB36_257
; %bb.260:                              ;   in Loop: Header=BB36_258 Depth=2
	ldr	x11, [x11, #8]
	ldr	x12, [x25]
	cmp	x12, x11
	b.hi	LBB36_257
; %bb.261:                              ;   in Loop: Header=BB36_258 Depth=2
	ldr	x13, [x19, #1064]
	sub	x14, x11, x12
	cmp	x14, x13
	b.hs	LBB36_257
; %bb.262:                              ;   in Loop: Header=BB36_258 Depth=2
	ldr	x15, [x1]
	ldr	w16, [x1, #20]
	lsr	x16, x14, x16
	ldr	x15, [x15, x16, lsl #3]
	sub	x16, x15, x12
LBB36_263:                              ;   Parent Loop BB36_154 Depth=1
                                        ;     Parent Loop BB36_258 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x16, x13
	b.hs	LBB36_257
; %bb.264:                              ;   in Loop: Header=BB36_263 Depth=3
	mov	x15, x16
	ldr	x16, [x12, x16]
	add	x16, x16, x15
	cmp	x14, x16
	b.hs	LBB36_263
; %bb.265:                              ;   in Loop: Header=BB36_258 Depth=2
	add	x12, x12, x15
	ldr	x14, [x12, #24]
	cmp	x14, #0
	add	x13, x12, #32
	ccmp	x13, x11, #2, ne
	b.hi	LBB36_257
; %bb.266:                              ;   in Loop: Header=BB36_258 Depth=2
	tbnz	w14, #1, LBB36_257
; %bb.267:                              ;   in Loop: Header=BB36_258 Depth=2
	ldr	x14, [x12, #8]
	sub	x11, x11, x13
	cmp	x11, x14
	b.hs	LBB36_257
; %bb.268:                              ;   in Loop: Header=BB36_258 Depth=2
	ldr	x11, [x12, #16]
	orr	x11, x11, #0x2
	cmp	x11, #3
	b.ne	LBB36_256
; %bb.269:                              ;   in Loop: Header=BB36_258 Depth=2
	str	x26, [x12, #24]
	add	x8, x8, #1
	str	x8, [x1, #40]
	b	LBB36_257
LBB36_270:                              ;   in Loop: Header=BB36_272 Depth=2
	orr	x10, x21, #0x3
	str	x10, [x11, #24]
	mov	x21, x11
LBB36_271:                              ;   in Loop: Header=BB36_272 Depth=2
	ldr	x9, [x9, #48]
	cbz	x9, LBB36_246
LBB36_272:                              ;   Parent Loop BB36_154 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB36_279 Depth 3
	ldr	x10, [x9]
	cmp	x10, x19
	b.ne	LBB36_271
; %bb.273:                              ;   in Loop: Header=BB36_272 Depth=2
	ldr	w10, [x9, #24]
	cbz	w10, LBB36_271
; %bb.274:                              ;   in Loop: Header=BB36_272 Depth=2
	ldr	w10, [x9, #28]
	cbnz	w10, LBB36_271
; %bb.275:                              ;   in Loop: Header=BB36_272 Depth=2
	ldr	x10, [x9, #16]
	ldurb	w10, [x10, #-8]
	tbz	w10, #1, LBB36_271
; %bb.276:                              ;   in Loop: Header=BB36_272 Depth=2
	ldr	x10, [x9, #8]
	ldr	x11, [x25]
	cmp	x11, x10
	b.hi	LBB36_271
; %bb.277:                              ;   in Loop: Header=BB36_272 Depth=2
	ldr	x12, [x19, #1064]
	sub	x13, x10, x11
	cmp	x13, x12
	b.hs	LBB36_271
; %bb.278:                              ;   in Loop: Header=BB36_272 Depth=2
	ldr	x14, [x1]
	ldr	w15, [x1, #20]
	lsr	x15, x13, x15
	ldr	x14, [x14, x15, lsl #3]
	sub	x15, x14, x11
LBB36_279:                              ;   Parent Loop BB36_154 Depth=1
                                        ;     Parent Loop BB36_272 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x15, x12
	b.hs	LBB36_271
; %bb.280:                              ;   in Loop: Header=BB36_279 Depth=3
	mov	x14, x15
	ldr	x15, [x11, x15]
	add	x15, x15, x14
	cmp	x13, x15
	b.hs	LBB36_279
; %bb.281:                              ;   in Loop: Header=BB36_272 Depth=2
	add	x11, x11, x14
	ldr	x13, [x11, #24]
	cmp	x13, #0
	add	x12, x11, #32
	ccmp	x12, x10, #2, ne
	b.hi	LBB36_271
; %bb.282:                              ;   in Loop: Header=BB36_272 Depth=2
	tbnz	w13, #1, LBB36_271
; %bb.283:                              ;   in Loop: Header=BB36_272 Depth=2
	ldr	x13, [x11, #8]
	sub	x10, x10, x12
	cmp	x10, x13
	b.hs	LBB36_271
; %bb.284:                              ;   in Loop: Header=BB36_272 Depth=2
	ldr	x10, [x11, #16]
	orr	x10, x10, #0x2
	cmp	x10, #3
	b.ne	LBB36_270
; %bb.285:                              ;   in Loop: Header=BB36_272 Depth=2
	str	x26, [x11, #24]
	add	x8, x8, #1
	str	x8, [x1, #40]
	b	LBB36_271
LBB36_286:
	ldr	x8, [x19, #1064]
	cbz	x8, LBB36_3
; %bb.287:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x25]
LBB36_288:                              ; =>This Inner Loop Header: Depth=1
	add	x11, x10, x9
	ldr	x12, [x11, #24]
	and	x12, x12, #0x1
	str	x12, [x11, #24]
	ldr	x11, [x11]
	add	x9, x11, x9
	cmp	x9, x8
	b.lo	LBB36_288
	b	LBB36_3
LBB36_289:
	tbnz	w12, #1, LBB36_148
; %bb.290:
	ldr	x12, [x10, #8]
	sub	x9, x9, x11
	cmp	x9, x12
	b.hs	LBB36_148
; %bb.291:
	ldr	x9, [x10, #16]
	orr	x9, x9, #0x2
	cmp	x9, #3
	b.ne	LBB36_344
; %bb.292:
	mov	w8, #7                          ; =0x7
	str	x8, [x10, #24]
	ldr	x8, [x1, #40]
	add	x8, x8, #1
	str	x8, [x1, #40]
	b	LBB36_148
LBB36_293:
	ldr	x8, [x20]
Lloh104:
	adrp	x22, _neoclr_execution_state_v1@TLVPPAGE
Lloh105:
	ldr	x22, [x22, _neoclr_execution_state_v1@TLVPPAGEOFF]
	cbz	x8, LBB36_299
; %bb.294:
	ldr	x9, [x22]
	mov	x0, x22
	blr	x9
	mov	x23, x0
	mov	w21, #1                         ; =0x1
	b	LBB36_296
LBB36_295:                              ;   in Loop: Header=BB36_296 Depth=1
	add	x20, x8, #32
	ldr	x8, [x20]
	cbz	x8, LBB36_299
LBB36_296:                              ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x19
	b.ne	LBB36_295
; %bb.297:                              ;   in Loop: Header=BB36_296 Depth=1
	ldr	x9, [x8, #8]
	ldurb	w9, [x9, #-8]
	tbnz	w9, #1, LBB36_295
; %bb.298:                              ;   in Loop: Header=BB36_296 Depth=1
	ldp	x0, x9, [x8, #16]
	ldr	x10, [x8, #32]
	str	x10, [x20]
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	str	w21, [x23, #88]
	blr	x9
	str	wzr, [x23, #88]
	ldr	x8, [x20]
	cbnz	x8, LBB36_296
LBB36_299:
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbz	x8, LBB36_307
; %bb.300:
	mov	w9, #1                          ; =0x1
	b	LBB36_302
LBB36_301:                              ;   in Loop: Header=BB36_302 Depth=1
	ldr	x8, [x8, #48]
	cbz	x8, LBB36_307
LBB36_302:                              ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x8]
	cmp	x10, x19
	b.ne	LBB36_301
; %bb.303:                              ;   in Loop: Header=BB36_302 Depth=1
	ldr	w10, [x8, #24]
	cbz	w10, LBB36_301
; %bb.304:                              ;   in Loop: Header=BB36_302 Depth=1
	ldr	w10, [x8, #28]
	cbnz	w10, LBB36_301
; %bb.305:                              ;   in Loop: Header=BB36_302 Depth=1
	ldr	x10, [x8, #16]
	ldurb	w10, [x10, #-8]
	tbnz	w10, #1, LBB36_301
; %bb.306:                              ;   in Loop: Header=BB36_302 Depth=1
	stp	xzr, xzr, [x8, #8]
	str	w9, [x8, #28]
	b	LBB36_301
LBB36_307:
	bl	_neoclr_roots_parked_v1
	ldr	w8, [sp, #32]                   ; 4-byte Folded Reload
	cbz	x0, LBB36_314
; %bb.308:
	mov	w9, #1                          ; =0x1
	b	LBB36_310
LBB36_309:                              ;   in Loop: Header=BB36_310 Depth=1
	ldr	x0, [x0, #8]
	cbz	x0, LBB36_314
LBB36_310:                              ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x0, #16]
	cmp	x10, x19
	b.ne	LBB36_309
; %bb.311:                              ;   in Loop: Header=BB36_310 Depth=1
	ldr	w10, [x0, #32]
	cbnz	w10, LBB36_309
; %bb.312:                              ;   in Loop: Header=BB36_310 Depth=1
	ldr	x10, [x0, #24]
	ldurb	w10, [x10, #-8]
	tbnz	w10, #1, LBB36_309
; %bb.313:                              ;   in Loop: Header=BB36_310 Depth=1
	str	xzr, [x0]
	str	xzr, [x0, #24]
	str	w9, [x0, #32]
	b	LBB36_309
LBB36_314:
	cbz	w8, LBB36_321
; %bb.315:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	add	x8, x8, #16
	b	LBB36_319
LBB36_316:                              ;   in Loop: Header=BB36_319 Depth=1
	str	wzr, [x8]
LBB36_317:                              ;   in Loop: Header=BB36_319 Depth=1
	stp	xzr, xzr, [x9]
LBB36_318:                              ;   in Loop: Header=BB36_319 Depth=1
	add	x8, x8, #24
	subs	x24, x24, #1
	b.eq	LBB36_321
LBB36_319:                              ; =>This Inner Loop Header: Depth=1
	mov	x9, x8
	ldr	x10, [x9, #-16]!
	cbz	x10, LBB36_316
; %bb.320:                              ;   in Loop: Header=BB36_319 Depth=1
	ldur	x10, [x10, #-8]
	ubfx	x11, x10, #1, #1
	str	w11, [x8]
	tbz	w10, #1, LBB36_317
	b	LBB36_318
LBB36_321:
	ldr	x8, [x19, #1064]
Lloh106:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh107:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	cbz	x8, LBB36_343
; %bb.322:
	ldr	x8, [x0]
	blr	x8
	mov	x21, x0
	ldr	x8, [x22]
	mov	x0, x22
	blr	x8
	mov	x23, x0
	mov	x27, #0                         ; =0x0
	str	xzr, [sp, #24]                  ; 8-byte Folded Spill
	mov	x26, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	add	x8, x21, #40
	stp	xzr, x8, [sp, #8]               ; 16-byte Folded Spill
	mov	w8, #1                          ; =0x1
	dup.2d	v0, x8
	str	q0, [sp, #32]                   ; 16-byte Folded Spill
	b	LBB36_326
LBB36_323:                              ;   in Loop: Header=BB36_326 Depth=1
	ldr	x8, [x21]
	cmp	x25, x8
	b.eq	LBB36_339
LBB36_324:                              ;   in Loop: Header=BB36_326 Depth=1
	mov	x28, x26
	str	x27, [sp, #24]                  ; 8-byte Folded Spill
LBB36_325:                              ;   in Loop: Header=BB36_326 Depth=1
	ldr	x8, [x19, #1064]
	add	x27, x20, x27
	cmp	x27, x8
	mov	x26, x28
	b.hs	LBB36_341
LBB36_326:                              ; =>This Inner Loop Header: Depth=1
	mov	x28, x24
	ldr	x8, [x25]
	add	x24, x8, x27
	ldr	x20, [x24]
	ldr	x8, [x24, #24]
	and	x9, x8, #0x2
	cmp	x8, #0
	ccmp	x9, #0, #0, ne
	b.eq	LBB36_332
; %bb.327:                              ;   in Loop: Header=BB36_326 Depth=1
	and	x9, x8, #0x1
	str	x9, [x24, #24]
	tbz	w8, #0, LBB36_336
; %bb.328:                              ;   in Loop: Header=BB36_326 Depth=1
	mov	x24, #0                         ; =0x0
	cbz	x28, LBB36_338
; %bb.329:                              ;   in Loop: Header=BB36_326 Depth=1
	ldr	x8, [x21]
	cmp	x25, x8
	b.ne	LBB36_338
; %bb.330:                              ;   in Loop: Header=BB36_326 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	add	x8, x8, #1
	mov	x24, #0                         ; =0x0
	cbnz	x26, LBB36_340
; %bb.331:                              ;   in Loop: Header=BB36_326 Depth=1
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB36_325
LBB36_332:                              ;   in Loop: Header=BB36_326 Depth=1
	mov	x22, x24
	ldr	x8, [x22, #8]!
	ldur	q0, [x23, #40]
	ldr	q1, [sp, #32]                   ; 16-byte Folded Reload
	mov.d	v1[1], x8
	add.2d	v0, v0, v1
	stur	q0, [x23, #40]
	ldr	x8, [x21]
	cmp	x25, x8
	b.ne	LBB36_335
; %bb.333:                              ;   in Loop: Header=BB36_326 Depth=1
	add	x9, x24, #32
	ubfx	x8, x9, #3, #29
	eor	w8, w8, w9, lsr #9
	and	x8, x8, #0x3f
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	ldr	x10, [x10, x8, lsl #3]
	cmp	x10, x9
	b.ne	LBB36_335
; %bb.334:                              ;   in Loop: Header=BB36_326 Depth=1
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	str	xzr, [x9, x8, lsl #3]
LBB36_335:                              ;   in Loop: Header=BB36_326 Depth=1
	sub	x2, x20, #32
	add	x0, x24, #32
	mov	w1, #221                        ; =0xdd
	bl	_memset
	stp	xzr, xzr, [x22, #8]
	str	xzr, [x22]
LBB36_336:                              ;   in Loop: Header=BB36_326 Depth=1
	cbz	x28, LBB36_323
; %bb.337:                              ;   in Loop: Header=BB36_326 Depth=1
	ldr	x8, [x28]
	add	x8, x8, x20
	str	x8, [x28]
	mov	x24, x28
LBB36_338:                              ;   in Loop: Header=BB36_326 Depth=1
	mov	x28, x26
	b	LBB36_325
LBB36_339:                              ;   in Loop: Header=BB36_326 Depth=1
	str	xzr, [x24, #8]
	b	LBB36_324
LBB36_340:                              ;   in Loop: Header=BB36_326 Depth=1
	str	x8, [x26, #8]
	b	LBB36_325
LBB36_341:
	cbz	x24, LBB36_345
; %bb.342:
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [x19, #1064]
	b	LBB36_346
LBB36_343:
	str	xzr, [sp, #8]                   ; 8-byte Folded Spill
	str	xzr, [sp, #24]                  ; 8-byte Folded Spill
	b	LBB36_347
LBB36_344:
	orr	x8, x8, #0x3
	str	x8, [x10, #24]
	str	x10, [sp, #56]
	b	LBB36_148
LBB36_345:
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
LBB36_346:
Lloh108:
	adrp	x22, _neoclr_execution_state_v1@TLVPPAGE
Lloh109:
	ldr	x22, [x22, _neoclr_execution_state_v1@TLVPPAGEOFF]
Lloh110:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh111:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
LBB36_347:
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x25, x8
	b.ne	LBB36_349
; %bb.348:
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	stp	x9, x8, [x0, #24]
LBB36_349:
	ldr	x8, [x22]
	mov	x0, x22
	blr	x8
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldr	x9, [x8, #24]
	add	x9, x9, #1
	str	x9, [x8, #24]
	b	LBB36_4
LBB36_350:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh94, Lloh95, Lloh96
	.loh AdrpLdrGotLdr	Lloh97, Lloh98, Lloh99
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpLdr	Lloh108, Lloh109
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mark_frames
_mark_frames:                           ; @mark_frames
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB37_48
; %bb.1:
	mov	w8, #7                          ; =0x7
	b	LBB37_3
LBB37_2:                                ;   in Loop: Header=BB37_3 Depth=1
	ldr	x2, [x2]
	cbz	x2, LBB37_48
LBB37_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB37_8 Depth 2
                                        ;       Child Loop BB37_12 Depth 3
                                        ;     Child Loop BB37_23 Depth 2
                                        ;       Child Loop BB37_27 Depth 3
                                        ;     Child Loop BB37_38 Depth 2
                                        ;       Child Loop BB37_41 Depth 3
	ldr	x9, [x2, #8]
	cmp	x9, x0
	b.ne	LBB37_2
; %bb.4:                                ;   in Loop: Header=BB37_3 Depth=1
	ldr	w9, [x2, #64]
	cbz	w9, LBB37_19
; %bb.5:                                ;   in Loop: Header=BB37_3 Depth=1
	mov	x10, #0                         ; =0x0
	ldr	x11, [x2, #48]
	b	LBB37_8
LBB37_6:                                ;   in Loop: Header=BB37_8 Depth=2
	ldr	x12, [x3]
	orr	x12, x12, #0x3
	str	x12, [x13, #24]
	str	x13, [x3]
LBB37_7:                                ;   in Loop: Header=BB37_8 Depth=2
	add	x10, x10, #1
	cmp	x10, x9
	b.eq	LBB37_19
LBB37_8:                                ;   Parent Loop BB37_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB37_12 Depth 3
	add	x12, x11, x10, lsl #4
	ldr	w13, [x12, #8]
	cmp	w13, #8
	b.ne	LBB37_7
; %bb.9:                                ;   in Loop: Header=BB37_8 Depth=2
	ldr	x12, [x12]
	ldr	x12, [x12]
	ldr	x13, [x0, #1048]
	subs	x14, x12, x13
	b.lo	LBB37_7
; %bb.10:                               ;   in Loop: Header=BB37_8 Depth=2
	ldr	x15, [x0, #1064]
	cmp	x14, x15
	b.hs	LBB37_7
; %bb.11:                               ;   in Loop: Header=BB37_8 Depth=2
	ldr	x16, [x1]
	ldr	w17, [x1, #20]
	lsr	x17, x14, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x13
LBB37_12:                               ;   Parent Loop BB37_3 Depth=1
                                        ;     Parent Loop BB37_8 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x17, x15
	b.hs	LBB37_7
; %bb.13:                               ;   in Loop: Header=BB37_12 Depth=3
	mov	x16, x17
	ldr	x17, [x13, x17]
	add	x17, x17, x16
	cmp	x14, x17
	b.hs	LBB37_12
; %bb.14:                               ;   in Loop: Header=BB37_8 Depth=2
	add	x13, x13, x16
	ldr	x15, [x13, #24]
	cmp	x15, #0
	add	x14, x13, #32
	ccmp	x12, x14, #0, ne
	b.lo	LBB37_7
; %bb.15:                               ;   in Loop: Header=BB37_8 Depth=2
	tbnz	w15, #1, LBB37_7
; %bb.16:                               ;   in Loop: Header=BB37_8 Depth=2
	ldr	x15, [x13, #8]
	sub	x12, x12, x14
	cmp	x12, x15
	b.hs	LBB37_7
; %bb.17:                               ;   in Loop: Header=BB37_8 Depth=2
	ldr	x12, [x13, #16]
	orr	x12, x12, #0x2
	cmp	x12, #3
	b.ne	LBB37_6
; %bb.18:                               ;   in Loop: Header=BB37_8 Depth=2
	str	x8, [x13, #24]
	ldr	x12, [x1, #40]
	add	x12, x12, #1
	str	x12, [x1, #40]
	b	LBB37_7
LBB37_19:                               ;   in Loop: Header=BB37_3 Depth=1
	ldr	w9, [x2, #88]
	cbz	w9, LBB37_34
; %bb.20:                               ;   in Loop: Header=BB37_3 Depth=1
	mov	x10, #0                         ; =0x0
	ldr	x11, [x2, #72]
	b	LBB37_23
LBB37_21:                               ;   in Loop: Header=BB37_23 Depth=2
	ldr	x12, [x3]
	orr	x12, x12, #0x3
	str	x12, [x13, #24]
	str	x13, [x3]
LBB37_22:                               ;   in Loop: Header=BB37_23 Depth=2
	add	x10, x10, #1
	cmp	x10, x9
	b.eq	LBB37_34
LBB37_23:                               ;   Parent Loop BB37_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB37_27 Depth 3
	add	x12, x11, x10, lsl #4
	ldr	w13, [x12, #8]
	cmp	w13, #8
	b.ne	LBB37_22
; %bb.24:                               ;   in Loop: Header=BB37_23 Depth=2
	ldr	x12, [x12]
	ldr	x12, [x12]
	ldr	x13, [x0, #1048]
	subs	x14, x12, x13
	b.lo	LBB37_22
; %bb.25:                               ;   in Loop: Header=BB37_23 Depth=2
	ldr	x15, [x0, #1064]
	cmp	x14, x15
	b.hs	LBB37_22
; %bb.26:                               ;   in Loop: Header=BB37_23 Depth=2
	ldr	x16, [x1]
	ldr	w17, [x1, #20]
	lsr	x17, x14, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x13
LBB37_27:                               ;   Parent Loop BB37_3 Depth=1
                                        ;     Parent Loop BB37_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x17, x15
	b.hs	LBB37_22
; %bb.28:                               ;   in Loop: Header=BB37_27 Depth=3
	mov	x16, x17
	ldr	x17, [x13, x17]
	add	x17, x17, x16
	cmp	x14, x17
	b.hs	LBB37_27
; %bb.29:                               ;   in Loop: Header=BB37_23 Depth=2
	add	x13, x13, x16
	ldr	x15, [x13, #24]
	cmp	x15, #0
	add	x14, x13, #32
	ccmp	x12, x14, #0, ne
	b.lo	LBB37_22
; %bb.30:                               ;   in Loop: Header=BB37_23 Depth=2
	tbnz	w15, #1, LBB37_22
; %bb.31:                               ;   in Loop: Header=BB37_23 Depth=2
	ldr	x15, [x13, #8]
	sub	x12, x12, x14
	cmp	x12, x15
	b.hs	LBB37_22
; %bb.32:                               ;   in Loop: Header=BB37_23 Depth=2
	ldr	x12, [x13, #16]
	orr	x12, x12, #0x2
	cmp	x12, #3
	b.ne	LBB37_21
; %bb.33:                               ;   in Loop: Header=BB37_23 Depth=2
	str	x8, [x13, #24]
	ldr	x12, [x1, #40]
	add	x12, x12, #1
	str	x12, [x1, #40]
	b	LBB37_22
LBB37_34:                               ;   in Loop: Header=BB37_3 Depth=1
	ldr	w9, [x2, #36]
	cbz	w9, LBB37_2
; %bb.35:                               ;   in Loop: Header=BB37_3 Depth=1
	mov	x10, #0                         ; =0x0
	b	LBB37_38
LBB37_36:                               ;   in Loop: Header=BB37_38 Depth=2
	ldr	x11, [x3]
	orr	x11, x11, #0x3
	str	x11, [x12, #24]
	str	x12, [x3]
LBB37_37:                               ;   in Loop: Header=BB37_38 Depth=2
	add	x10, x10, #1
	cmp	x10, x9
	b.eq	LBB37_2
LBB37_38:                               ;   Parent Loop BB37_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB37_41 Depth 3
	ldr	x11, [x2, #16]
	ldr	x11, [x11, x10, lsl #3]
	ldr	x12, [x0, #1048]
	subs	x13, x11, x12
	b.lo	LBB37_37
; %bb.39:                               ;   in Loop: Header=BB37_38 Depth=2
	ldr	x14, [x0, #1064]
	cmp	x13, x14
	b.hs	LBB37_37
; %bb.40:                               ;   in Loop: Header=BB37_38 Depth=2
	ldr	x15, [x1]
	ldr	w16, [x1, #20]
	lsr	x16, x13, x16
	ldr	x15, [x15, x16, lsl #3]
	sub	x16, x15, x12
LBB37_41:                               ;   Parent Loop BB37_3 Depth=1
                                        ;     Parent Loop BB37_38 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x16, x14
	b.hs	LBB37_37
; %bb.42:                               ;   in Loop: Header=BB37_41 Depth=3
	mov	x15, x16
	ldr	x16, [x12, x16]
	add	x16, x16, x15
	cmp	x13, x16
	b.hs	LBB37_41
; %bb.43:                               ;   in Loop: Header=BB37_38 Depth=2
	add	x12, x12, x15
	ldr	x14, [x12, #24]
	cmp	x14, #0
	add	x13, x12, #32
	ccmp	x11, x13, #0, ne
	b.lo	LBB37_37
; %bb.44:                               ;   in Loop: Header=BB37_38 Depth=2
	tbnz	w14, #1, LBB37_37
; %bb.45:                               ;   in Loop: Header=BB37_38 Depth=2
	ldr	x14, [x12, #8]
	sub	x11, x11, x13
	cmp	x11, x14
	b.hs	LBB37_37
; %bb.46:                               ;   in Loop: Header=BB37_38 Depth=2
	ldr	x11, [x12, #16]
	orr	x11, x11, #0x2
	cmp	x11, #3
	b.ne	LBB37_36
; %bb.47:                               ;   in Loop: Header=BB37_38 Depth=2
	str	x8, [x12, #24]
	ldr	x11, [x1, #40]
	add	x11, x11, #1
	str	x11, [x1, #40]
	b	LBB37_37
LBB37_48:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__DATA,__thread_data,thread_local_regular
	.p2align	3, 0x0                          ; @lookup_profile
_lookup_profile$tlv$init:
	.space	96

	.section	__DATA,__thread_vars,thread_local_variables
_lookup_profile:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_lookup_profile$tlv$init

	.section	__DATA,__thread_data,thread_local_regular
	.p2align	3, 0x0                          ; @profile
_profile$tlv$init:
	.space	584

	.section	__DATA,__thread_vars,thread_local_variables
_profile:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_profile$tlv$init

.tbss _owned_heap$tlv$init, 552, 3      ; @owned_heap

_owned_heap:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_owned_heap$tlv$init

.tbss _resource_head$tlv$init, 8, 3     ; @resource_head

_resource_head:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_resource_head$tlv$init

.tbss _host_head$tlv$init, 8, 3         ; @host_head

_host_head:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_host_head$tlv$init

.tbss _host_roots$tlv$init, 14336, 3    ; @host_roots

_host_roots:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_host_roots$tlv$init

	.section	__DATA,__data
	.p2align	3, 0x0                          ; @next_host_handle
_next_host_handle:
	.quad	1                               ; 0x1

.subsections_via_symbols
