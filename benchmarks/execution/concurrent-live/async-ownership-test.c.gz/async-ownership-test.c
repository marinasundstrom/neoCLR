/* Real retained-stack lifetime contract; scheduler is idle in this focused host. */
#include "native-runtime.h"
#include "socket-listener.h"
#include <stdio.h>
#include "native-stack.h"
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif
#define CHECK(x) do { if (!(x)) { fprintf(stderr, "check failed at %d\n", __LINE__); return 1; } } while (0)

#ifdef LIVE_GC
extern int32_t experiment_gc_begin(neoclr_aot_context *,const neoclr_probe_frame *,neoclr_gc_conditional_root *,uint32_t);
extern int experiment_gc_live_active(neoclr_aot_context *);
extern int32_t experiment_gc_store(neoclr_aot_context *,void *,uint64_t,uint32_t);
#endif
static unsigned epochs, mutations;
static int begin(neoclr_aot_context *c) {
#ifdef LIVE_GC
    if (experiment_gc_live_active(c)) return 0;
    int status=experiment_gc_begin(c,neoclr_root_probe_head_v1(),NULL,0);
    if(status || !experiment_gc_live_active(c)) return 1;
#else
    (void)c;
#endif
    ++epochs;return 0;
}
static int mutate(neoclr_aot_context *c,uint64_t *slot,uint64_t value) {
#ifdef LIVE_GC
    if(!experiment_gc_live_active(c)) return 1;
    int status=experiment_gc_store(c,slot,value,8);
    if(status) return status;
#else
    (void)c;*slot=value;
#endif
    ++mutations;return 0;
}
static uint64_t signal_id;
static int entered, resumed, managed, collect_at_idle;
static uint64_t *payload;
static int wait_calls;
void neoclr_scheduler_wait_v1(neoclr_aot_context *c) { (void)c; ++wait_calls; }
int32_t neoclr_scheduler_acquire_v1(neoclr_aot_context *c, uint64_t *out, const neoclr_probe_frame *f) {
    (void)out;
    if (collect_at_idle && neoclr_gc_idle_v1(c,f)) return -3;
    return NEOCLR_SCHEDULER_IDLE;
}
int32_t neoclr_scheduler_complete_v1(neoclr_aot_context *c, uint64_t id, const neoclr_probe_frame *f) {
    (void)c; (void)id; (void)f;
    return 3;
}
static int32_t invoke(uint64_t handle, neoclr_aot_context *c) {
    CHECK(!neoclr_native_stack_check_v1());
    void *callback = NULL;
    CHECK(!neoclr_gc_callback_read_v1(c, handle, &callback));
    void *owner = NULL;
    CHECK(!neoclr_runtime_async_currentowner_v1(c, &owner));
    CHECK(owner == (void *)(uintptr_t)((uint64_t *)callback)[1]);
    if (managed) CHECK(!neoclr_runtime_async_createowned_v1(owner, c, &signal_id));
    uint64_t *local = payload;
    neoclr_probe_storage slot = {&local, 8, 0};
    neoclr_probe_frame frame;
    neoclr_probe_enter_v3(&frame, c, 1, &slot, 1, "{}", 2);
    CHECK(!neoclr_gc_collect_v1(c, neoclr_root_probe_head_v1()));
    ++entered;
    CHECK(!begin(c));
    int32_t result;
    CHECK(!neoclr_runtime_async_waitcompletion_v1(signal_id, c, &result));
    CHECK(result && local[1] == 42);
    CHECK(local[3] && ((uint64_t *)(uintptr_t)local[3])[1]==99);
    CHECK(!mutate(c,local+1,43));
    CHECK(!mutate(c,local+1,42));
    CHECK(!neoclr_native_stack_check_v1());
    CHECK(!neoclr_gc_collect_v1(c, neoclr_root_probe_head_v1()));
    ++resumed;
    neoclr_probe_leave_v1(&frame);
    return 0;
}
static int32_t drain(neoclr_aot_context *c) { (void)c; return 0; }
static void *allocate(neoclr_aot_context *c) {
    void *p = NULL;
    return neoclr_gc_allocate_v1(&c->text, 24, NEOCLR_GC_OBJECT, &p) ? NULL : p;
}
static void *allocate_payload(neoclr_aot_context *c) {
    void *p=NULL;
    return neoclr_gc_allocate_v1(&c->text,32,NEOCLR_GC_OBJECT,&p) ? NULL : p;
}
int main(int argc, char **argv) {
    (void)argv;
#ifdef _WIN32
    if (argc > 1) CHECK(ConvertThreadToFiberEx(NULL, FIBER_FLAG_FLOAT_SWITCH));
    int host_fiber = !!IsThreadAFiber();
#else
    (void)argc;
#endif
    uint64_t storage[1024] = {0};
    neoclr_aot_context c = {.text = {(unsigned char *)storage, sizeof(storage), 0}};
    CHECK(!neoclr_gc_heap_acquire_v1(&c.text));
    for (int i = 0; i < 320; ++i) {
        managed = i >= 160;
        void *owner = allocate(&c);
        uint64_t *callback = allocate(&c);
        payload = allocate_payload(&c);
        CHECK(owner && callback && payload);
        callback[0] = UINT32_MAX; callback[1] = (uintptr_t)owner;
        payload[1] = 42; payload[2] = (uintptr_t)owner;
        uint64_t keep, body;
        CHECK(!neoclr_gc_host_root_create_v1(&c, owner, &keep));
        CHECK(!begin(&c));
        if (managed) {
            CHECK(!neoclr_runtime_async_startmanaged_v1(owner, callback, &c, &body, invoke));
        } else {
            CHECK(!neoclr_runtime_async_create_v1(&c, &signal_id));
            CHECK(!neoclr_runtime_async_start_owned_v1(owner, callback, &c, &body, invoke));
        }
        CHECK(entered == i + 1 && resumed == i / 2);
        CHECK(!neoclr_root_probe_head_v1());
        /* A new child becomes reachable only through the suspended local's object. */
        uint64_t *child=allocate(&c);CHECK(child);child[1]=99;
        CHECK(!mutate(&c,payload+3,(uintptr_t)child));
        CHECK(!neoclr_gc_collect_v1(&c, NULL));
        CHECK(payload[1] == 42 && ((uint64_t *)(uintptr_t)payload[3])[1]==99);
        CHECK(!begin(&c));
        int32_t result;
        if (!(i & 1)) {
            CHECK(!neoclr_gc_host_root_release_v1(&c, keep));
            CHECK(!neoclr_gc_collect_v1(&c, NULL) && !c.text.used);
            if (!(i & 2)) CHECK(!neoclr_runtime_async_reap_v1(&c));
            /* Other iterations exercise automatic pump reclamation. */
            /* Later external completion must not revive the abandoned body. */
            CHECK(!neoclr_runtime_async_completeunit_v1(signal_id, &c, &result) && result == !(managed && !(i & 2)));
            CHECK(!neoclr_runtime_async_pump_v1(&c, invoke, drain));
            CHECK(neoclr_runtime_async_iscompleted_v1(body, &c, &result) == 3);
            CHECK(resumed == i / 2);
            if (managed) CHECK(!neoclr_runtime_async_completeunit_v1(signal_id, &c, &result) && !result);
        } else {
            CHECK(!neoclr_runtime_async_completeunit_v1(signal_id, &c, &result) && result);
            CHECK(!neoclr_gc_host_root_release_v1(&c, keep));
            CHECK(!neoclr_gc_collect_v1(&c, NULL) && payload[1] == 42);
            CHECK(!begin(&c));
            CHECK(!neoclr_runtime_async_pump_v1(&c, invoke, drain));
            CHECK(resumed == (i + 1) / 2);
            if (managed) {
                CHECK(neoclr_runtime_async_iscompleted_v1(body, &c, &result) == 3);
                CHECK(!neoclr_runtime_async_release_v1(signal_id, &c, &result) && result);
            } else {
                CHECK(!neoclr_runtime_async_iscompleted_v1(body, &c, &result) && result);
                CHECK(!neoclr_runtime_async_release_v1(body, &c, &result) && result);
            }
            CHECK(!neoclr_gc_collect_v1(&c, NULL) && !c.text.used);
        }
        if (!managed) CHECK(!neoclr_runtime_async_release_v1(signal_id, &c, &result) && result);
        CHECK(!neoclr_gc_entry_check_v1(&c));
    }
    /* Owner expires inside scheduler acquire, after the pump's first scan. */
    {
        void *owner=allocate(&c); uint64_t *callback=allocate(&c);
        payload=allocate_payload(&c); CHECK(owner && callback && payload);
        callback[0]=UINT32_MAX;callback[1]=(uintptr_t)owner;
        payload[1]=42;payload[2]=(uintptr_t)owner;
        uint64_t keep,body;
        CHECK(!neoclr_gc_host_root_create_v1(&c,owner,&keep));
        CHECK(!neoclr_runtime_async_startmanaged_v1(owner,callback,&c,&body,invoke));
        CHECK(!neoclr_gc_host_root_release_v1(&c,keep));
        collect_at_idle=1;
        CHECK(!neoclr_runtime_async_pump_v1(&c,invoke,drain));
        collect_at_idle=0;
        int32_t result;
        CHECK(neoclr_runtime_async_iscompleted_v1(body,&c,&result)==3);
        CHECK(!neoclr_runtime_async_completeunit_v1(signal_id,&c,&result) && !result);
        CHECK(!c.text.used && entered==321 && resumed==160);
    }
    /* Exhaust strong activation capacity after dependent-handle allocation. */
    void *owner = allocate(&c);
    uint64_t *callback = allocate(&c);
    CHECK(owner && callback);
    callback[0] = UINT32_MAX;
    uint64_t handles[254], rejected = 777;
    for (unsigned i = 0; i < 254; ++i)
        CHECK(!neoclr_gc_host_root_create_v1(&c, NULL, &handles[i]));
    CHECK(neoclr_runtime_async_start_owned_v1(owner, callback, &c, &rejected, invoke) == 5);
    CHECK(rejected == 777 && entered == 321);
    for (unsigned i = 0; i < 254; ++i)
        CHECK(!neoclr_gc_host_root_release_v1(&c, handles[i]));
    CHECK(!neoclr_gc_collect_v1(&c, NULL) && !c.text.used);
    CHECK(!neoclr_gc_entry_check_v1(&c));
    CHECK(!neoclr_runtime_async_shutdown_v1(&c));
#ifdef _WIN32
    CHECK(!!IsThreadAFiber() == host_fiber);
    if (host_fiber) CHECK(ConvertFiberToThread());
#endif
    CHECK(!neoclr_gc_heap_release_v1(&c.text));
    CHECK(epochs>=640 && mutations==640);
    printf("ownership probe: beginPoints=%u mutations=%u\n",epochs,mutations);
    neoclr_async_statistics stats = neoclr_runtime_async_statistics_v1();
    CHECK(!stats.reserved_bytes && stats.mappings == stats.unmappings);
    printf("{\"entered\":%d,\"resumed\":%d,\"abandoned\":%d,\"reservedBytesAfterShutdown\":%llu}\n",
        entered, resumed, entered - resumed, (unsigned long long)stats.reserved_bytes);
    return 0;
}
