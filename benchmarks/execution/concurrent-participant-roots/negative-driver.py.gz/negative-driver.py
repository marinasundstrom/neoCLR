from pathlib import Path
import json,subprocess
root=Path.cwd();out=root/'target/participant-roots-negative-final';out.mkdir(exist_ok=False)
prior=json.loads((root/'target/participant-roots-native/results.json').read_text());recipe=prior['commands'][0]['command'];source=root/'runtime/native/gc/participant-roots.c';r={'passed':False,'commands':[]}
try:
 for name,old,new in [('lost-roots','if (output) output[*count] = value;','if (output) output[*count] = 0; (void)value;'),('follow-borrow','if(output) memcpy(&value,s->address,8);','if(output) {memcpy(&value,s->address,8);if(s->flags==2)memcpy(&value,(void *)(uintptr_t)value,8);}')]:
  text=source.read_text();assert text.count(old)==1;p=out/(name+'.c');p.write_text(text.replace(old,new));exe=out/name
  command=[str(p) if x==str(source) else x for x in recipe];command[command.index('-o')+1]=str(exe)
  for cmd in [command,[str(exe)]]:
   x=subprocess.run(cmd,capture_output=True,text=True,timeout=60);r['commands'].append(dict(command=cmd,exitCode=x.returncode,stdout=x.stdout,stderr=x.stderr));assert x.returncode==0 if len(cmd)>1 else x.returncode!=0
 r['passed']=True
finally:(out/'results.json').write_text(json.dumps(r,indent=2)+'\n')
