	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 26, 2	sdk_version 26, 2
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_probe_fault_roots_v1
lCPI0_0:
	.long	8                               ; 0x8
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_probe_fault_roots_v1
	.p2align	2
_neoclr_probe_fault_roots_v1:           ; @neoclr_probe_fault_roots_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_9
; %bb.1:
	ldr	w8, [x0]
	cbz	w8, LBB0_8
; %bb.2:
	ldr	w9, [x0, #4]
	mov	w8, #-1                         ; =0xffffffff
	cmp	w9, w2
	ccmp	x1, #0, #4, lo
	b.eq	LBB0_8
; %bb.3:
	cmp	w9, #64
	b.hi	LBB0_8
; %bb.4:
	add	x8, x0, #8
	str	x8, [x1]
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	d0, [x8, lCPI0_0@PAGEOFF]
	str	d0, [x1, #8]
	ldr	w8, [x0, #4]
	cbz	w8, LBB0_10
; %bb.5:
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	add	x10, x1, #24
LBB0_6:                                 ; =>This Inner Loop Header: Depth=1
	add	x8, x8, #1
	stur	x9, [x10, #-8]
	str	d0, [x10], #16
	ldr	w11, [x0, #4]
	add	x9, x9, #16
	cmp	x8, x11
	b.lo	LBB0_6
; %bb.7:
	add	w8, w11, #1
LBB0_8:
	mov	x0, x8
	ret
LBB0_9:
	mov	w0, #-1                         ; =0xffffffff
	ret
LBB0_10:
	mov	w0, #1                          ; =0x1
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_enter_v1             ; -- Begin function neoclr_gc_enter_v1
	.p2align	2
_neoclr_gc_enter_v1:                    ; @neoclr_gc_enter_v1
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	cbz	x0, LBB1_7
; %bb.1:
	mov	x25, x1
	cbz	x1, LBB1_7
; %bb.2:
	mov	x24, x2
	cmp	w2, #1, lsl #12                 ; =4096
	b.hs	LBB1_7
; %bb.3:
	mov	x23, x3
	cbz	x3, LBB1_7
; %bb.4:
	mov	x22, x5
	cbz	x5, LBB1_7
; %bb.5:
	mov	x19, x6
	mov	x21, x4
	mov	x20, x0
	mov	x0, x22
	bl	_strlen
	cmp	x0, w19, uxtw
	b.ne	LBB1_7
; %bb.6:
Lloh2:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh3:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	stp	x8, x25, [x20]
	stp	xzr, xzr, [x20, #24]
	str	xzr, [x20, #16]
	stp	w24, wzr, [x20, #40]
	stp	x23, x22, [x20, #48]
	stp	w21, w19, [x20, #64]
	movi.2d	v0, #0000000000000000
	stur	q0, [x20, #72]
	stur	q0, [x20, #88]
	str	x20, [x0]
	ldr	w8, [x0, #16]
	add	w8, w8, #1
	str	w8, [x0, #16]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB1_7:
	bl	_abort
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_leave_v1             ; -- Begin function neoclr_gc_leave_v1
	.p2align	2
_neoclr_gc_leave_v1:                    ; @neoclr_gc_leave_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	cbz	x0, LBB2_6
; %bb.1:
	mov	x8, x0
Lloh4:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh5:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x10, [x0]
	ldr	w9, [x0, #16]
	cmp	x10, x8
	ccmp	w9, #0, #4, eq
	b.eq	LBB2_6
; %bb.2:
	ldr	x10, [x8, #8]
	cbz	x10, LBB2_6
; %bb.3:
	ldr	w11, [x10]
	cbz	w11, LBB2_5
; %bb.4:
	ldr	w10, [x10, #4]
	cmp	w10, #65
	b.hs	LBB2_6
LBB2_5:
	ldr	x10, [x8]
	str	x10, [x0]
	sub	w9, w9, #1
	str	w9, [x0, #16]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8, #64]
	str	xzr, [x8, #96]
	stp	q0, q0, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB2_6:
	bl	_abort
	.loh AdrpLdr	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_enter_owned_v1       ; -- Begin function neoclr_gc_enter_owned_v1
	.p2align	2
_neoclr_gc_enter_owned_v1:              ; @neoclr_gc_enter_owned_v1
	.cfi_startproc
; %bb.0:
	mov	w7, #0                          ; =0x0
	b	_enter_owned
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function enter_owned
_enter_owned:                           ; @enter_owned
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	cbz	x3, LBB4_17
; %bb.1:
	mov	x19, x7
	mov	x22, x6
	mov	x24, x5
	mov	x23, x4
	mov	x25, x3
	mov	x26, x2
	mov	x21, x1
	mov	x20, x0
	mov	x0, x3
	mov	x1, x4
	mov	w2, #1                          ; =0x1
	bl	_validate_storage
	cbz	x20, LBB4_17
; %bb.2:
	cbz	x21, LBB4_17
; %bb.3:
	cmp	w26, #1, lsl #12                ; =4096
	b.hs	LBB4_17
; %bb.4:
	cbz	x24, LBB4_17
; %bb.5:
	tbnz	w19, #13, LBB4_7
; %bb.6:
	mov	x0, x24
	bl	_strlen
	cmp	x0, w22, uxtw
	b.eq	LBB4_10
	b	LBB4_17
LBB4_7:
	cmp	w22, #8
	b.ne	LBB4_17
; %bb.8:
	ldr	w8, [x24]
	mov	w9, #18254                      ; =0x474e
	movk	w9, #12627, lsl #16
	cmp	w8, w9
	b.ne	LBB4_17
; %bb.9:
	ldr	w8, [x24, #4]
	cmp	w8, w23
	b.ne	LBB4_17
LBB4_10:
	orr	w9, w19, #0x200
Lloh6:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh7:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	stp	x8, x21, [x20]
	stp	xzr, xzr, [x20, #24]
	str	xzr, [x20, #16]
	stp	w26, wzr, [x20, #40]
	stp	x25, x24, [x20, #48]
	stp	w23, w22, [x20, #64]
	stp	xzr, xzr, [x20, #80]
	str	xzr, [x20, #72]
	stp	wzr, w9, [x20, #96]
	str	x20, [x0]
	ldr	w9, [x0, #16]
	add	w9, w9, #1
	str	w9, [x0, #16]
	cbz	x8, LBB4_15
; %bb.11:
	ldr	w9, [x8, #100]
	tbz	w9, #12, LBB4_16
; %bb.12:
	ldr	x10, [x8, #8]
	cmp	x10, x21
	b.ne	LBB4_16
; %bb.13:
	tbnz	w9, #10, LBB4_15
; %bb.14:
	ldr	w8, [x8, #88]
	cbnz	w8, LBB4_16
LBB4_15:
	mov	w8, #4608                       ; =0x1200
	orr	w8, w19, w8
	str	w8, [x20, #100]
LBB4_16:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB4_17:
	bl	_abort
	.loh AdrpLdr	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_enter_map_v1         ; -- Begin function neoclr_gc_enter_map_v1
	.p2align	2
_neoclr_gc_enter_map_v1:                ; @neoclr_gc_enter_map_v1
	.cfi_startproc
; %bb.0:
	mov	w7, #8192                       ; =0x2000
	b	_enter_owned
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_stack_roots_v1       ; -- Begin function neoclr_gc_stack_roots_v1
	.p2align	2
_neoclr_gc_stack_roots_v1:              ; @neoclr_gc_stack_roots_v1
	.cfi_startproc
; %bb.0:
	mov	w6, #0                          ; =0x0
	b	_stack_roots
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function stack_roots
_stack_roots:                           ; @stack_roots
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x0, LBB7_42
; %bb.1:
	mov	x27, x6
	mov	x22, x5
	mov	x24, x4
	mov	x23, x3
	mov	x25, x2
	mov	x26, x1
	mov	x21, x0
Lloh8:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh9:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	cbz	x4, LBB7_42
; %bb.2:
	cbz	x25, LBB7_42
; %bb.3:
	cmp	w23, #2, lsl #12                ; =8192
	b.hi	LBB7_42
; %bb.4:
	lsr	w8, w26, #13
	cbnz	w8, LBB7_42
; %bb.5:
	mov	x19, x0
	ldr	x20, [x0]
	cmp	x20, x21
	b.ne	LBB7_42
; %bb.6:
	cbz	w27, LBB7_10
; %bb.7:
	cmp	w22, #8
	b.ne	LBB7_42
; %bb.8:
	ldr	w8, [x24]
	mov	w9, #18254                      ; =0x474e
	movk	w9, #12611, lsl #16
	cmp	w8, w9
	b.ne	LBB7_42
; %bb.9:
	ldr	w8, [x24, #4]
	cmp	w8, w23
	b.eq	LBB7_17
	b	LBB7_42
LBB7_10:
	mov	x0, x24
	bl	_strlen
	cmp	x0, w22, uxtw
	b.ne	LBB7_42
; %bb.11:
	ubfx	x8, x24, #4, #28
	eor	w8, w8, w24, lsr #12
	and	x28, x8, #0xff
	add	x13, x19, #96
	subs	w9, w22, #18
	b.lo	LBB7_15
; %bb.12:
	ldr	w8, [x13, x28, lsl #2]
	cbz	w8, LBB7_15
; %bb.13:
	sub	w10, w8, #1
	cmp	w10, w9
	b.hi	LBB7_15
; %bb.14:
	add	x8, x24, x8
	ldur	x9, [x8, #-1]
	ldur	x10, [x8, #7]
	ldurh	w8, [x8, #15]
	mov	x11, #25970                     ; =0x6572
	movk	x11, #30065, lsl #16
	movk	x11, #29289, lsl #32
	movk	x11, #25701, lsl #48
	cmp	x9, x11
	mov	x9, #28755                      ; =0x7053
	movk	x9, #27753, lsl #16
	movk	x9, #19564, lsl #32
	movk	x9, #28257, lsl #48
	ccmp	x10, x9, #0, eq
	mov	w9, #29541                      ; =0x7365
	ccmp	w8, w9, #0, eq
	b.eq	LBB7_17
LBB7_15:
	str	x13, [sp, #8]                   ; 8-byte Folded Spill
Lloh10:
	adrp	x1, _has_spill_marker.marker@PAGE
Lloh11:
	add	x1, x1, _has_spill_marker.marker@PAGEOFF
	mov	x0, x24
	bl	_strstr
	cbz	x0, LBB7_42
; %bb.16:
	sub	w8, w0, w24
	add	w8, w8, #1
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	str	w8, [x9, x28, lsl #2]
LBB7_17:
	ldr	w8, [x21, #100]
	mov	w9, #-19457                     ; =0xffffb3ff
	and	w8, w8, w9
	orr	w8, w8, w27
	stp	xzr, xzr, [x21, #80]
	str	xzr, [x21, #72]
	stp	wzr, w8, [x21, #96]
	str	w26, [x21, #44]
	stp	x25, x24, [x21, #16]
	stp	w22, w23, [x21, #32]
	tbnz	w8, #12, LBB7_28
; %bb.18:
	mov	x22, #0                         ; =0x0
	b	LBB7_20
LBB7_19:                                ;   in Loop: Header=BB7_20 Depth=1
	ldr	x20, [x20]
	cbz	x20, LBB7_31
LBB7_20:                                ; =>This Inner Loop Header: Depth=1
	mov	x8, x22
	ldr	x22, [x20, #8]
	cmp	x22, #0
	ccmp	x22, x8, #0, ne
	b.eq	LBB7_24
; %bb.21:                               ;   in Loop: Header=BB7_20 Depth=1
	cbz	x22, LBB7_42
; %bb.22:                               ;   in Loop: Header=BB7_20 Depth=1
	ldr	w8, [x22]
	cbz	w8, LBB7_24
; %bb.23:                               ;   in Loop: Header=BB7_20 Depth=1
	ldr	w8, [x22, #4]
	cmp	w8, #65
	b.hs	LBB7_42
LBB7_24:                                ;   in Loop: Header=BB7_20 Depth=1
	ldr	w8, [x20, #100]
	tbz	w8, #9, LBB7_26
; %bb.25:                               ;   in Loop: Header=BB7_20 Depth=1
	tbnz	w8, #10, LBB7_19
	b	LBB7_27
LBB7_26:                                ;   in Loop: Header=BB7_20 Depth=1
	ldr	x0, [x20, #48]
	ldr	w1, [x20, #64]
	mov	w2, #1                          ; =0x1
	bl	_validate_storage
	ldr	w8, [x20, #100]
	tbnz	w8, #10, LBB7_19
LBB7_27:                                ;   in Loop: Header=BB7_20 Depth=1
	ldr	x0, [x20, #72]
	ldr	w1, [x20, #88]
	mov	w2, #0                          ; =0x0
	bl	_validate_storage
	b	LBB7_19
LBB7_28:
	ldr	x8, [x21, #8]
	cbz	x8, LBB7_42
; %bb.29:
	ldr	w9, [x8]
	cbz	w9, LBB7_32
; %bb.30:
	ldr	w8, [x8, #4]
	cmp	w8, #65
	b.lo	LBB7_32
	b	LBB7_42
LBB7_31:
	ldr	x20, [x19]
LBB7_32:
	ldr	x8, [x19, #8]
	add	x8, x8, #1
	str	x8, [x19, #8]
	ldr	x0, [x21, #8]
	cbz	x0, LBB7_42
; %bb.33:
	cbz	x20, LBB7_42
; %bb.34:
	ldr	w8, [x19, #88]
	cbnz	w8, LBB7_42
; %bb.35:
	ldr	x8, [x20, #8]
	cmp	x8, x0
	b.ne	LBB7_42
; %bb.36:
	ldr	x8, [x19, #56]
	cmp	x8, x0
	b.ne	LBB7_40
; %bb.37:
	ldr	x8, [x19, #24]
	ldr	x9, [x19, #72]
	cmp	x8, x9
	b.ne	LBB7_40
; %bb.38:
	ldr	x8, [x19, #32]
	ldr	x9, [x19, #64]
	sub	x8, x8, x9
	cmp	x8, #255
	b.hi	LBB7_40
; %bb.39:
	ldr	x8, [x19, #80]
	add	x8, x8, #1
	str	x8, [x19, #80]
	cmp	x8, #1, lsl #12                 ; =4096
	b.lo	LBB7_41
LBB7_40:
	mov	x1, x20
	bl	_neoclr_gc_idle_v1
	cbnz	w0, LBB7_42
LBB7_41:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB7_42:
	bl	_abort
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdd	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_stack_map_v1         ; -- Begin function neoclr_gc_stack_map_v1
	.p2align	2
_neoclr_gc_stack_map_v1:                ; @neoclr_gc_stack_map_v1
	.cfi_startproc
; %bb.0:
	mov	w6, #2048                       ; =0x800
	b	_stack_roots
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_transient_v1         ; -- Begin function neoclr_gc_transient_v1
	.p2align	2
_neoclr_gc_transient_v1:                ; @neoclr_gc_transient_v1
	.cfi_startproc
; %bb.0:
	mov	w6, #0                          ; =0x0
	b	_publish_transient
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function publish_transient
_publish_transient:                     ; @publish_transient
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x25, x6
	mov	x21, x5
	mov	x24, x4
	mov	x20, x3
	mov	x19, x2
	mov	x22, x1
	mov	x23, x0
Lloh12:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh13:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	cbz	x23, LBB10_16
; %bb.1:
	ldr	x8, [x0]
	cmp	x8, x23
	b.ne	LBB10_16
; %bb.2:
	sub	w8, w22, #1
	cmp	w8, #2
	b.hi	LBB10_16
; %bb.3:
	cbz	x19, LBB10_16
; %bb.4:
	cbz	x24, LBB10_16
; %bb.5:
	tbnz	w25, #14, LBB10_7
; %bb.6:
	mov	x0, x24
	bl	_strlen
	cmp	x0, w21, uxtw
	b.eq	LBB10_10
	b	LBB10_16
LBB10_7:
	cmp	w21, #8
	b.ne	LBB10_16
; %bb.8:
	ldr	w8, [x24]
	mov	w9, #18254                      ; =0x474e
	movk	w9, #12628, lsl #16
	cmp	w8, w9
	b.ne	LBB10_16
; %bb.9:
	ldr	w8, [x24, #4]
	cmp	w8, w20
	b.ne	LBB10_16
LBB10_10:
	ldr	w8, [x23, #100]
	mov	w9, #-17409                     ; =0xffffbbff
	and	w8, w8, w9
	orr	w8, w8, w25
	stp	x19, x24, [x23, #72]
	stp	w20, w21, [x23, #88]
	stp	w22, w8, [x23, #96]
	cbz	w20, LBB10_15
; %bb.11:
	mov	w8, w20
	add	x9, x19, #8
LBB10_12:                               ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x9, #-8]
	cbz	x10, LBB10_16
; %bb.13:                               ;   in Loop: Header=BB10_12 Depth=1
	ldr	w10, [x9]
	cmp	w10, #4
	ccmp	w10, #8, #4, ne
	b.ne	LBB10_16
; %bb.14:                               ;   in Loop: Header=BB10_12 Depth=1
	add	x9, x9, #16
	subs	x8, x8, #1
	b.ne	LBB10_12
LBB10_15:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB10_16:
	bl	_abort
	.loh AdrpLdr	Lloh12, Lloh13
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_transient_owned_v1   ; -- Begin function neoclr_gc_transient_owned_v1
	.p2align	2
_neoclr_gc_transient_owned_v1:          ; @neoclr_gc_transient_owned_v1
	.cfi_startproc
; %bb.0:
	mov	w6, #1024                       ; =0x400
	b	_publish_transient
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_transient_map_v1     ; -- Begin function neoclr_gc_transient_map_v1
	.p2align	2
_neoclr_gc_transient_map_v1:            ; @neoclr_gc_transient_map_v1
	.cfi_startproc
; %bb.0:
	mov	w6, #17408                      ; =0x4400
	b	_publish_transient
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_root_probe_head_v1      ; -- Begin function neoclr_root_probe_head_v1
	.p2align	2
_neoclr_root_probe_head_v1:             ; @neoclr_root_probe_head_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh14:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh15:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x0, [x0]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_root_probe_count_v1     ; -- Begin function neoclr_root_probe_count_v1
	.p2align	2
_neoclr_root_probe_count_v1:            ; @neoclr_root_probe_count_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh16:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh17:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x0, [x0, #8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_root_probe_depth_v1     ; -- Begin function neoclr_root_probe_depth_v1
	.p2align	2
_neoclr_root_probe_depth_v1:            ; @neoclr_root_probe_depth_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh18:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh19:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w0, [x0, #16]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_roots_park_v1           ; -- Begin function neoclr_roots_park_v1
	.p2align	2
_neoclr_roots_park_v1:                  ; @neoclr_roots_park_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	cbz	x0, LBB16_10
; %bb.1:
	mov	x8, x0
	ldr	x9, [x0]
	cbnz	x9, LBB16_10
; %bb.2:
	ldr	x9, [x8, #8]
	cbnz	x9, LBB16_10
; %bb.3:
	ldr	x9, [x8, #16]
	cbnz	x9, LBB16_10
; %bb.4:
	ldr	x9, [x8, #24]
	cbnz	x9, LBB16_10
; %bb.5:
	ldr	w9, [x8, #32]
	cbnz	w9, LBB16_10
; %bb.6:
Lloh20:
	adrp	x0, _parked@TLVPPAGE
Lloh21:
	ldr	x0, [x0, _parked@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	ldr	x10, [x0]
	cbz	x10, LBB16_9
LBB16_7:                                ; =>This Inner Loop Header: Depth=1
	cmp	x10, x8
	b.eq	LBB16_10
; %bb.8:                                ;   in Loop: Header=BB16_7 Depth=1
	ldr	x10, [x10, #8]
	cbnz	x10, LBB16_7
LBB16_9:
Lloh22:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh23:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	str	x10, [x8]
	ldr	x10, [x9]
	str	x10, [x8, #8]
	str	x8, [x9]
	str	xzr, [x0]
	str	wzr, [x0, #16]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB16_10:
	bl	_abort
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh22, Lloh23
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_roots_resume_v1         ; -- Begin function neoclr_roots_resume_v1
	.p2align	2
_neoclr_roots_resume_v1:                ; @neoclr_roots_resume_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x9, x0
Lloh24:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh25:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	cbz	x9, LBB17_9
; %bb.1:
	mov	x8, x0
	ldr	x10, [x0]
	cbnz	x10, LBB17_9
; %bb.2:
	ldr	w10, [x9, #32]
	cbnz	w10, LBB17_9
; %bb.3:
Lloh26:
	adrp	x0, _parked@TLVPPAGE
Lloh27:
	ldr	x0, [x0, _parked@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
LBB17_4:                                ; =>This Inner Loop Header: Depth=1
	mov	x10, x0
	ldr	x11, [x0]
	add	x0, x11, #8
	cmp	x11, #0
	ccmp	x11, x9, #4, ne
	b.ne	LBB17_4
; %bb.5:
	cbz	x11, LBB17_9
; %bb.6:
	ldr	x11, [x9, #8]
	str	x11, [x10]
	ldr	x10, [x9]
	str	x10, [x8]
	movi.2d	v0, #0000000000000000
	str	xzr, [x9, #32]
	stp	q0, q0, [x9]
	mov	w9, #-1                         ; =0xffffffff
	mov	x10, x8
LBB17_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x10]
	add	w9, w9, #1
	cbnz	x10, LBB17_7
; %bb.8:
	str	w9, [x8, #16]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB17_9:
	bl	_abort
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_roots_parked_v1         ; -- Begin function neoclr_roots_parked_v1
	.p2align	2
_neoclr_roots_parked_v1:                ; @neoclr_roots_parked_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh28:
	adrp	x0, _parked@TLVPPAGE
Lloh29:
	ldr	x0, [x0, _parked@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x0, [x0]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh28, Lloh29
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_roots_discard_v1        ; -- Begin function neoclr_roots_discard_v1
	.p2align	2
_neoclr_roots_discard_v1:               ; @neoclr_roots_discard_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh30:
	adrp	x0, _parked@TLVPPAGE
Lloh31:
	ldr	x0, [x0, _parked@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
LBB19_1:                                ; =>This Inner Loop Header: Depth=1
	mov	x9, x0
	ldr	x10, [x0]
	add	x0, x10, #8
	cmp	x10, #0
	ccmp	x10, x8, #4, ne
	b.ne	LBB19_1
; %bb.2:
	cbz	x10, LBB19_4
; %bb.3:
	ldr	x10, [x8, #8]
	str	x10, [x9]
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB19_4:
	bl	_abort
	.loh AdrpLdr	Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_stack_trace_capture_v1  ; -- Begin function neoclr_stack_trace_capture_v1
	.p2align	2
_neoclr_stack_trace_capture_v1:         ; @neoclr_stack_trace_capture_v1
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #624
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	str	x3, [sp, #64]                   ; 8-byte Folded Spill
	mov	x9, x0
Lloh32:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh33:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh34:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	mov	w0, #3                          ; =0x3
	tbnz	w9, #31, LBB20_44
; %bb.1:
	cbz	x1, LBB20_44
; %bb.2:
	mov	x19, x2
	cbz	x2, LBB20_44
; %bb.3:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	cbz	x8, LBB20_44
; %bb.4:
Lloh35:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh36:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB20_21
; %bb.5:
	mov	w21, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	mov	w10, #52429                     ; =0xcccd
	movk	w10, #52428, lsl #16
	mov	w11, #65507                     ; =0xffe3
	add	x12, sp, #96
	mov	x13, x8
	b	LBB20_8
LBB20_6:                                ;   in Loop: Header=BB20_8 Depth=1
	sub	w9, w9, #1
LBB20_7:                                ;   in Loop: Header=BB20_8 Depth=1
	ldr	x13, [x13]
	cbz	x13, LBB20_18
LBB20_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB20_13 Depth 2
	ldr	x14, [x13, #8]
	cmp	x14, x1
	b.ne	LBB20_7
; %bb.9:                                ;   in Loop: Header=BB20_8 Depth=1
	cbnz	w9, LBB20_6
; %bb.10:                               ;   in Loop: Header=BB20_8 Depth=1
	ldr	w9, [x13, #40]
	cmp	w9, w4
	b.hs	LBB20_38
; %bb.11:                               ;   in Loop: Header=BB20_8 Depth=1
	ldr	x14, [sp, #64]                  ; 8-byte Folded Reload
	ldr	x9, [x14, x9, lsl #3]
	cbz	x9, LBB20_38
; %bb.12:                               ;   in Loop: Header=BB20_8 Depth=1
	ldr	w15, [x13, #44]
	mov	w14, #1                         ; =0x1
	cmp	w15, #10
	b.lo	LBB20_14
LBB20_13:                               ;   Parent Loop BB20_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x14, #1
	umull	x16, w15, w10
	lsr	x16, x16, #35
	cmp	w15, #99
	mov	x15, x16
	b.hi	LBB20_13
LBB20_14:                               ;   in Loop: Header=BB20_8 Depth=1
	cmp	w21, #64
	b.eq	LBB20_46
; %bb.15:                               ;   in Loop: Header=BB20_8 Depth=1
	ldr	x9, [x9]
	cmp	x9, #16, lsl #12                ; =65536
	b.hi	LBB20_46
; %bb.16:                               ;   in Loop: Header=BB20_8 Depth=1
	add	x9, x9, x14
	add	x14, x9, #22
	sub	x9, x11, x20
	cmp	x14, x9
	b.hi	LBB20_46
; %bb.17:                               ;   in Loop: Header=BB20_8 Depth=1
	mov	w9, #0                          ; =0x0
	str	x13, [x12, w21, uxtw #3]
	add	w21, w21, #1
	add	x20, x14, x20
	b	LBB20_7
LBB20_18:
	mov	w22, #1                         ; =0x1
	str	xzr, [sp, #72]
	cbz	x8, LBB20_22
LBB20_19:
	ldr	x9, [x8, #8]
	cmp	x9, x1
	b.eq	LBB20_22
; %bb.20:
	add	x0, x1, #1048
	add	x1, x20, #8
	add	x3, sp, #72
	mov	w2, #1                          ; =0x1
	bl	_neoclr_gc_allocate_v1
	cbnz	w0, LBB20_44
	b	LBB20_23
LBB20_21:
	mov	x20, #0                         ; =0x0
	mov	w21, #0                         ; =0x0
	str	xzr, [sp, #72]
	mov	w22, #1                         ; =0x1
LBB20_22:
	add	x2, x20, #8
	add	x4, sp, #72
	mov	x0, x1
	mov	x1, x8
	mov	w3, #1                          ; =0x1
	bl	_neoclr_gc_allocate_rooted_v1
	cbnz	w0, LBB20_44
LBB20_23:
	str	w22, [sp, #20]                  ; 4-byte Folded Spill
	stp	x20, x19, [sp, #24]             ; 16-byte Folded Spill
	ldr	x8, [sp, #72]
	mov	x9, x8
	str	x20, [x9], #8
	stp	x8, x9, [sp]                    ; 16-byte Folded Spill
	cbz	w21, LBB20_39
; %bb.24:
	mov	x26, #0                         ; =0x0
	add	x27, sp, #86
	sub	x11, x27, #32
	sub	x23, x27, #1
Lloh37:
	adrp	x8, l_.str.1@PAGE
Lloh38:
	add	x8, x8, l_.str.1@PAGEOFF
	ldur	x10, [x8, #6]
	str	x10, [sp, #56]                  ; 8-byte Folded Spill
	ldr	x8, [x8]
	stp	x11, x8, [sp, #40]              ; 16-byte Folded Spill
	mov	w28, #52429                     ; =0xcccd
	movk	w28, #52428, lsl #16
	mov	w25, #10                        ; =0xa
	mov	x20, x9
	mov	w22, w21
	b	LBB20_26
LBB20_25:                               ;   in Loop: Header=BB20_26 Depth=1
	mov	w9, #2653                       ; =0xa5d
	strh	w9, [x8], #2
	add	x26, x26, #1
	mov	x20, x8
	cmp	x26, x22
	b.eq	LBB20_40
LBB20_26:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB20_27 Depth 2
                                        ;     Child Loop BB20_35 Depth 2
                                        ;     Child Loop BB20_37 Depth 2
	add	x8, sp, #96
	ldr	x19, [x8, x26, lsl #3]
	ldr	w8, [x19, #40]
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x24, [x9, x8, lsl #3]
	mov	w8, #8308                       ; =0x2074
	strh	w8, [x20, #4]
	mov	w8, #8224                       ; =0x2020
	movk	w8, #24864, lsl #16
	str	w8, [x20]
	add	x21, x20, #6
	ldr	x2, [x24]
	add	x1, x24, #8
	mov	x0, x21
	bl	_memcpy
	mov	w9, #0                          ; =0x0
	ldr	x10, [x24]
	add	x8, x21, x10
	ldr	x11, [sp, #56]                  ; 8-byte Folded Reload
	stur	x11, [x8, #6]
	ldr	x11, [sp, #48]                  ; 8-byte Folded Reload
	str	x11, [x8]
	ldr	w11, [x19, #44]
	mov	w13, #1                         ; =0x1
LBB20_27:                               ;   Parent Loop BB20_26 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
                                        ; kill: def $w9 killed $w9 killed $x9
	mov	x12, x13
	umull	x13, w11, w28
	lsr	x14, x13, #35
	msub	w13, w14, w25, w11
	orr	w13, w13, #0x30
	strb	w13, [x27, w9, uxtw]
	add	w9, w9, #1
	add	w13, w12, #1
	cmp	w11, #9
	mov	x11, x14
	b.hi	LBB20_27
; %bb.28:                               ;   in Loop: Header=BB20_26 Depth=1
	add	x8, x8, #14
	cbz	w9, LBB20_25
; %bb.29:                               ;   in Loop: Header=BB20_26 Depth=1
	cmp	w9, #64
	b.hs	LBB20_31
; %bb.30:                               ;   in Loop: Header=BB20_26 Depth=1
	mov	x10, x9
	b	LBB20_37
LBB20_31:                               ;   in Loop: Header=BB20_26 Depth=1
	add	x13, x20, x10
	add	x10, x13, x9
	add	x10, x10, #20
	cmp	x27, x10
	cset	w10, lo
	add	x11, x27, x9
	cmp	x8, x11
	b.hs	LBB20_34
; %bb.32:                               ;   in Loop: Header=BB20_26 Depth=1
	tbz	w10, #0, LBB20_34
; %bb.33:                               ;   in Loop: Header=BB20_26 Depth=1
	mov	x10, x9
	b	LBB20_37
LBB20_34:                               ;   in Loop: Header=BB20_26 Depth=1
	and	x11, x9, #0xffffffc0
	and	x10, x9, #0x3f
	add	x8, x8, x11
	mov	w14, w12
	and	x12, x14, #0xffffffc0
	add	x13, x13, #68
	ldr	x15, [sp, #40]                  ; 8-byte Folded Reload
	add	x14, x15, x14
LBB20_35:                               ;   Parent Loop BB20_26 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x14]
	rev64.16b	v0, v0
	ext.16b	v0, v0, v0, #8
	rev64.16b	v1, v1
	ext.16b	v1, v1, v1, #8
	ldp	q3, q2, [x14, #-32]
	rev64.16b	v2, v2
	ext.16b	v2, v2, v2, #8
	rev64.16b	v3, v3
	ext.16b	v3, v3, v3, #8
	stp	q0, q1, [x13, #-48]
	stp	q2, q3, [x13, #-16]
	add	x13, x13, #64
	sub	x14, x14, #64
	sub	x12, x12, #64
	cbnz	x12, LBB20_35
; %bb.36:                               ;   in Loop: Header=BB20_26 Depth=1
	cmp	x11, x9
	b.eq	LBB20_25
LBB20_37:                               ;   Parent Loop BB20_26 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w9, [x23, x10]
	strb	w9, [x8], #1
	subs	x10, x10, #1
	b.ne	LBB20_37
	b	LBB20_25
LBB20_38:
	mov	w0, #3                          ; =0x3
	b	LBB20_44
LBB20_39:
	mov	x8, x9
LBB20_40:
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	tbnz	w9, #0, LBB20_42
; %bb.41:
Lloh39:
	adrp	x9, l___const.neoclr_stack_trace_capture_v1.marker@PAGE
Lloh40:
	add	x9, x9, l___const.neoclr_stack_trace_capture_v1.marker@PAGEOFF
	ldr	q0, [x9]
	str	q0, [x8]
	ldur	q0, [x9, #13]
	stur	q0, [x8, #13]
	add	x8, x8, #29
LBB20_42:
	ldp	x10, x9, [sp, #24]              ; 16-byte Folded Reload
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
	sub	x8, x8, x11
	cmp	x8, x10
	b.ne	LBB20_48
; %bb.43:
	mov	w0, #0                          ; =0x0
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [x9]
LBB20_44:
	ldur	x8, [x29, #-96]
Lloh41:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh42:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh43:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB20_47
; %bb.45:
	add	sp, sp, #624
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB20_46:
	mov	w22, #0                         ; =0x0
	add	x20, x20, #29
	str	xzr, [sp, #72]
	cbnz	x8, LBB20_19
	b	LBB20_22
LBB20_47:
	bl	___stack_chk_fail
LBB20_48:
	bl	_abort
	.loh AdrpLdrGotLdr	Lloh32, Lloh33, Lloh34
	.loh AdrpLdr	Lloh35, Lloh36
	.loh AdrpAdd	Lloh37, Lloh38
	.loh AdrpAdd	Lloh39, Lloh40
	.loh AdrpLdrGotLdr	Lloh41, Lloh42, Lloh43
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function validate_storage
_validate_storage:                      ; @validate_storage
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	cbz	w1, LBB21_7
; %bb.1:
	mov	w8, #0                          ; =0x0
	mov	w9, w1
	add	x10, x0, #12
	b	LBB21_4
LBB21_2:                                ;   in Loop: Header=BB21_4 Depth=1
	ldr	w12, [x10]
	cmp	w12, #2
	cset	w12, hi
LBB21_3:                                ;   in Loop: Header=BB21_4 Depth=1
	orr	w8, w8, w11
	orr	w8, w8, w12
	add	x10, x10, #16
	subs	x9, x9, #1
	b.eq	LBB21_6
LBB21_4:                                ; =>This Inner Loop Header: Depth=1
	ldur	x11, [x10, #-12]
	ldur	w12, [x10, #-4]
	cmp	w12, #4
	ccmp	w12, #8, #4, ne
	ccmp	x11, #0, #4, eq
	cset	w11, eq
	cbnz	w2, LBB21_2
; %bb.5:                                ;   in Loop: Header=BB21_4 Depth=1
	mov	w12, #0                         ; =0x0
	b	LBB21_3
LBB21_6:
	cbnz	w8, LBB21_8
LBB21_7:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB21_8:
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.private_extern	_neoclr_execution_state_v1 ; @neoclr_execution_state_v1
.tbss _neoclr_execution_state_v1$tlv$init, 1120, 3

	.section	__DATA,__thread_vars,thread_local_variables
	.globl	_neoclr_execution_state_v1
_neoclr_execution_state_v1:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_neoclr_execution_state_v1$tlv$init

.tbss _parked$tlv$init, 8, 3            ; @parked

_parked:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_parked$tlv$init

	.section	__TEXT,__cstring,cstring_literals
l___const.neoclr_stack_trace_capture_v1.marker: ; @__const.neoclr_stack_trace_capture_v1.marker
	.asciz	"   ... stack trace truncated\n"

l_.str:                                 ; @.str
	.asciz	"   at "

l_.str.1:                               ; @.str.1
	.asciz	" [instruction "

	.section	__TEXT,__const
_has_spill_marker.marker:               ; @has_spill_marker.marker
	.asciz	"requiredSpillLanes"

.subsections_via_symbols
