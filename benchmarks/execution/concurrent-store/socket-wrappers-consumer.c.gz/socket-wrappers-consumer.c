#include "socket-listener.h"
#include "native-gc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define REQUIRE(x) do { if(!(x)) { fprintf(stderr,"socket adapter line %d: %s\n",__LINE__,#x); abort(); } } while(0)
extern int32_t experiment_gc_begin(neoclr_aot_context *,const neoclr_probe_frame *,neoclr_gc_conditional_root *,uint32_t);
extern int32_t experiment_gc_store(neoclr_aot_context *,void *,uint64_t,uint32_t);
extern void experiment_gc_store_counts(uint64_t *);
static void *const *functions;
static uint64_t *result_owner, result_handle, before[5], calls[13];
static void prepare(neoclr_aot_context *c) {
    REQUIRE(!experiment_gc_store(c,result_owner+1,111,8));
    REQUIRE(!experiment_gc_store(c,result_owner+2,222,8));
    experiment_gc_store_counts(before);
}
static int finish(neoclr_aot_context *c,void *out,int status,unsigned bytes) {
    uint64_t after[5];experiment_gc_store_counts(after);
    REQUIRE(after[1]+after[2]-before[1]-before[2]==(status?0:bytes==16?2:1));
    if(status) REQUIRE(result_owner[1]==111 && result_owner[2]==222);
    else memcpy(out,result_owner+1,bytes);
    /* Native fixture continues after expected errors; preserve its explicit
     * recovery policy while checking the generated status and output above. */
    c->fault.code=0;
    return status;
}
static int collect_and_begin(neoclr_aot_context *c) {
    int status=neoclr_gc_collect_v1(c,NULL);
    return status?status:experiment_gc_begin(c,NULL,NULL,0);
}
typedef int32_t (*wrapper_0)(const neoclr_aot_text *, int32_t, int32_t,void *,neoclr_aot_context *);
static int32_t shim_listen(const neoclr_aot_text * address, int32_t port, int32_t backlog,neoclr_aot_context *c,void *out) {
    calls[0]++;prepare(c);
    int status=((wrapper_0)functions[0])(address, port, backlog,result_owner+1,c);
    return finish(c,out,status,16);
}
#define neoclr_socket_listen_v1 shim_listen
typedef int32_t (*wrapper_1)(uint64_t,void *,neoclr_aot_context *);
static int32_t shim_local_port(uint64_t handle,neoclr_aot_context *c,void *out) {
    calls[1]++;prepare(c);
    int status=((wrapper_1)functions[1])(handle,result_owner+1,c);
    return finish(c,out,status,16);
}
#define neoclr_socket_local_port_v1 shim_local_port
typedef int32_t (*wrapper_2)(uint64_t,void *,neoclr_aot_context *);
static int32_t shim_close(uint64_t handle,neoclr_aot_context *c,void *out) {
    calls[2]++;prepare(c);
    int status=((wrapper_2)functions[2])(handle,result_owner+1,c);
    return finish(c,out,status,16);
}
#define neoclr_socket_close_v1 shim_close
typedef int32_t (*wrapper_3)(uint64_t, void *,void *,neoclr_aot_context *);
static int32_t shim_accept(uint64_t listener, void * callback,neoclr_aot_context *c,void *out) {
    calls[3]++;prepare(c);
    int status=((wrapper_3)functions[3])(listener, callback,result_owner+1,c);
    return finish(c,out,status,16);
}
#define neoclr_socket_accept_v1 shim_accept
typedef int32_t (*wrapper_4)(uint64_t,void *,neoclr_aot_context *);
static int32_t shim_connect_result(uint64_t operation,neoclr_aot_context *c,void *out) {
    calls[4]++;prepare(c);
    int status=((wrapper_4)functions[4])(operation,result_owner+1,c);
    return finish(c,out,status,16);
}
#define neoclr_socket_connect_result_v1 shim_connect_result
typedef int32_t (*wrapper_5)(uint64_t,void *,neoclr_aot_context *);
static int32_t shim_cancel(uint64_t operation,neoclr_aot_context *c,int32_t *out) {
    calls[5]++;prepare(c);
    int status=((wrapper_5)functions[5])(operation,result_owner+1,c);
    return finish(c,out,status,4);
}
#define neoclr_socket_cancel_v1 shim_cancel
typedef int32_t (*wrapper_6)(int32_t,void *,neoclr_aot_context *);
static int32_t shim_deadline_after(int32_t milliseconds,neoclr_aot_context *c,int64_t *out) {
    calls[6]++;prepare(c);
    int status=((wrapper_6)functions[6])(milliseconds,result_owner+1,c);
    return finish(c,out,status,8);
}
#define neoclr_socket_deadline_after_v1 shim_deadline_after
typedef int32_t (*wrapper_7)(int64_t,void *,neoclr_aot_context *);
static int32_t shim_deadline_expired(int64_t stamp,neoclr_aot_context *c,int32_t *out) {
    calls[7]++;prepare(c);
    int status=((wrapper_7)functions[7])(stamp,result_owner+1,c);
    return finish(c,out,status,4);
}
#define neoclr_socket_deadline_expired_v1 shim_deadline_expired
typedef int32_t (*wrapper_8)(uint64_t, void *, int32_t, int32_t, void *,void *,neoclr_aot_context *);
static int32_t shim_receive(uint64_t socket, void * array, int32_t offset, int32_t count, void * callback,neoclr_aot_context *c,void *out) {
    calls[8]++;prepare(c);
    int status=((wrapper_8)functions[8])(socket, array, offset, count, callback,result_owner+1,c);
    return finish(c,out,status,16);
}
#define neoclr_socket_receive_v1 shim_receive
typedef int32_t (*wrapper_9)(uint64_t, void *, int32_t, int32_t, void *,void *,neoclr_aot_context *);
static int32_t shim_send(uint64_t socket, void * array, int32_t offset, int32_t count, void * callback,neoclr_aot_context *c,void *out) {
    calls[9]++;prepare(c);
    int status=((wrapper_9)functions[9])(socket, array, offset, count, callback,result_owner+1,c);
    return finish(c,out,status,16);
}
#define neoclr_socket_send_v1 shim_send
typedef int32_t (*wrapper_10)(uint64_t,void *,neoclr_aot_context *);
static int32_t shim_transfer_result(uint64_t operation,neoclr_aot_context *c,void *out) {
    calls[10]++;prepare(c);
    int status=((wrapper_10)functions[10])(operation,result_owner+1,c);
    return finish(c,out,status,16);
}
#define neoclr_socket_transfer_result_v1 shim_transfer_result
typedef int32_t (*wrapper_11)(uint64_t, void *, int32_t, int32_t, int64_t, void *,void *,neoclr_aot_context *);
static int32_t shim_receive_until(uint64_t socket, void * array, int32_t offset, int32_t count, int64_t deadline, void * callback,neoclr_aot_context *c,void *out) {
    calls[11]++;prepare(c);
    int status=((wrapper_11)functions[11])(socket, array, offset, count, deadline, callback,result_owner+1,c);
    return finish(c,out,status,16);
}
#define neoclr_socket_receive_until_v1 shim_receive_until
typedef int32_t (*wrapper_12)(uint64_t, void *, int32_t, int32_t, int64_t, void *,void *,neoclr_aot_context *);
static int32_t shim_send_until(uint64_t socket, void * array, int32_t offset, int32_t count, int64_t deadline, void * callback,neoclr_aot_context *c,void *out) {
    calls[12]++;prepare(c);
    int status=((wrapper_12)functions[12])(socket, array, offset, count, deadline, callback,result_owner+1,c);
    return finish(c,out,status,16);
}
#define neoclr_socket_send_until_v1 shim_send_until
#include "socket-listener.h"
#include "native-gc.h"
#include <string.h>
#define CHECK(x) do { if (!(x)) return __LINE__; } while (0)
static int run_socket_case(void) {
    uint64_t buffer[513] = {0}; buffer[512] = 1234567;
    neoclr_aot_context c = {.text = {(unsigned char *)buffer, 4096, 0}};
    CHECK(!neoclr_gc_heap_acquire_v1(&c.text));
    CHECK(!neoclr_gc_allocate_v1(&c.text,24,NEOCLR_GC_OBJECT,(void **)&result_owner));
    result_owner[0]=17;
    CHECK(!neoclr_gc_host_root_create_v1(&c,result_owner,&result_handle));
    CHECK(!experiment_gc_begin(&c,NULL,NULL,0));
    neoclr_socket_scope scope;
    CHECK(!neoclr_socket_scope_enter_v1(&scope, &c));
    const struct { uint64_t length; char bytes[16]; } address = {9, "127.0.0.1"};
    uint64_t result[2] = {99, 99};
    CHECK(!neoclr_socket_listen_v1((const void *)&address, 0, 4, &c, result) && result[0] == 5);
    uint64_t listener = result[1];
    CHECK(!neoclr_socket_local_port_v1(listener, &c, result) && result[0] == 1);
    struct sockaddr_in endpoint = {0};
    endpoint.sin_family = AF_INET; endpoint.sin_port = htons((uint16_t)result[1]);
    endpoint.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    void *callback = NULL;
    CHECK(!neoclr_allocate_object_v1(&c.text, UINT32_MAX, 24, &callback));
    ((uint64_t *)callback)[1] = 1;
    CHECK(!neoclr_socket_accept_v1(listener, callback, &c, result) && result[0] == 5);
    uint64_t operation = result[1], root = 999;
    CHECK(!collect_and_begin(&c) && c.text.used);
    CHECK(!neoclr_socket_poll_v1(&c, &root) && root == 999);
    CHECK(!neoclr_socket_accept_v1(listener, callback, &c, result) && result[0] == 2 && result[1] == 2);
    result[0] = result[1] = 99;
    CHECK(neoclr_socket_connect_result_v1(operation, &c, result) == 3 && result[0] == 99);
    neoclr_socket_descriptor peer = socket(AF_INET, SOCK_STREAM, 0);
    CHECK(peer != NEOCLR_INVALID_SOCKET && !connect(peer, (const void *)&endpoint, sizeof(endpoint)));
    int ready = 0;
    for (unsigned retry = 0; retry < 5000 && !ready; retry++) {
        ready = neoclr_socket_poll_v1(&c, &root);
        if (!ready) neoclr_os_pause();
    }
    CHECK(ready == 1);
    void *read = NULL;
    CHECK(!neoclr_gc_host_root_read_v1(&c, root, &read) && read == callback);
    CHECK(!neoclr_socket_poll_v1(&c, &root));
    int32_t cancelled = 99;
    CHECK(!neoclr_socket_cancel_v1(operation, &c, &cancelled) && !cancelled);
    CHECK(!neoclr_socket_connect_result_v1(operation, &c, result) && result[0] == 5);
    uint64_t accepted = result[1];
    CHECK(neoclr_socket_connect_result_v1(operation, &c, result) == 3);
    CHECK(neoclr_gc_host_root_read_v1(&c, root, &read) == 3);
    int64_t deadline = -99;
    int32_t expired = -99;
    CHECK(neoclr_socket_deadline_after_v1(0, &c, &deadline) == 3 && deadline == -99);
    CHECK(neoclr_socket_deadline_after_v1(60001, &c, &deadline) == 3 && deadline == -99);
    CHECK(!neoclr_socket_deadline_after_v1(60000, &c, &deadline) && deadline >= 60000);
    CHECK(!neoclr_socket_deadline_expired_v1(deadline, &c, &expired) && !expired);
    CHECK(!neoclr_socket_deadline_expired_v1(0, &c, &expired) && expired);
    expired = 99;
    CHECK(neoclr_socket_deadline_expired_v1(-1, &c, &expired) == 3 && expired == 99);
    CHECK(neoclr_socket_deadline_expired_v1(INT64_MAX, &c, &expired) == 3 && expired == 99);
    void *array = NULL;
    CHECK(!neoclr_reserve_bytes_v1(&c.text, 8, &array));
    uint64_t array_root;
    CHECK(!neoclr_gc_host_root_create_v1(&c, array, &array_root));
    CHECK(!neoclr_socket_receive_until_v1(accepted, array, 0, 0, 0, callback, &c, result) && result[0] == 2 && result[1] == 10);
    CHECK(!neoclr_socket_send_until_v1(accepted, array, 0, 1, 0, callback, &c, result) && result[0] == 2 && result[1] == 10);
    CHECK(neoclr_socket_receive_until_v1(accepted, array, 0, 1, -1, callback, &c, result) == 3);
    CHECK(!neoclr_socket_deadline_after_v1(4000, &c, &deadline));
    CHECK(!neoclr_socket_receive_until_v1(accepted, array, 2, 4, deadline, callback, &c, result) && result[0] == 5);
    operation = result[1];
    uint64_t shared_end = 0;
    for (unsigned i = 0; i < 64; i++) if (scope.operations[i].id == operation) shared_end = scope.operations[i].deadline;
    CHECK(shared_end);
    CHECK(!collect_and_begin(&c));
    CHECK(!neoclr_socket_receive_v1(accepted, array, 2, 4, callback, &c, result) && result[0] == 2 && result[1] == 2);
    CHECK(!neoclr_socket_poll_v1(&c, &root));
    CHECK(send(peer, "ping", 4, 0) == 4);
    ready = 0;
    for (unsigned retry = 0; retry < 5000 && !ready; retry++) {
        ready = neoclr_socket_poll_v1(&c, &root);
        if (!ready) neoclr_os_pause();
    }
    CHECK(ready == 1);
    CHECK(!neoclr_socket_transfer_result_v1(operation, &c, result) && result[0] == 1 && result[1] > 0 && result[1] <= 4);
    unsigned received = (unsigned)result[1];
    CHECK(!memcmp((unsigned char *)array + 18, "ping", received));
    CHECK(!neoclr_check_bytes_initialized_v1(array, 2, (int32_t)received));
    CHECK(neoclr_check_bytes_initialized_v1(array, 0, 1) == 3);
    /* Send snapshots the admitted initialized range; later guest writes cannot change it. */
    CHECK(!neoclr_socket_send_until_v1(accepted, array, 2, (int32_t)received, deadline, callback, &c, result) && result[0] == 5);
    operation = result[1];
    for (unsigned i = 0; i < 64; i++) if (scope.operations[i].id == operation) CHECK(scope.operations[i].deadline == shared_end);
    memset((unsigned char *)array + 18, 'x', received);
    CHECK(!collect_and_begin(&c));
    CHECK(neoclr_socket_poll_v1(&c, &root) == 1);
    CHECK(!neoclr_socket_transfer_result_v1(operation, &c, result) && result[0] == 1 && result[1] > 0 && result[1] <= received);
    char echo[8];
    int64_t read_count = recv(peer, echo, (int)result[1], MSG_WAITALL);
    CHECK(read_count == (int64_t)result[1] && !memcmp(echo, "ping", (size_t)read_count));
    CHECK(!scope.transfer_bytes);
    /* Cancellation and deadline settling cannot write into the destination later. */
    CHECK(!neoclr_socket_receive_v1(accepted, array, 0, 1, callback, &c, result) && result[0] == 5);
    operation = result[1];
    CHECK(!neoclr_socket_cancel_v1(operation, &c, &cancelled) && cancelled);
    CHECK(neoclr_socket_poll_v1(&c, &root) == 1);
    CHECK(!neoclr_socket_transfer_result_v1(operation, &c, result) && result[0] == 2 && result[1] == 5);
    CHECK(neoclr_check_bytes_initialized_v1(array, 0, 1) == 3 && !scope.transfer_bytes);
    CHECK(!neoclr_socket_receive_v1(accepted, array, 0, 1, callback, &c, result) && result[0] == 5);
    operation = result[1];
    for (unsigned i = 0; i < 64; i++) if (scope.operations[i].id == operation) scope.operations[i].deadline = 1;
    CHECK(neoclr_socket_poll_v1(&c, &root) == 1);
    CHECK(!neoclr_socket_transfer_result_v1(operation, &c, result) && result[0] == 2 && result[1] == 10);
    CHECK(neoclr_check_bytes_initialized_v1(array, 0, 1) == 3);
    CHECK(!neoclr_socket_send_v1(accepted, array, 8, 0, callback, &c, result) && result[0] == 5);
    operation = result[1];
    CHECK(neoclr_socket_poll_v1(&c, &root) == 1);
    CHECK(!neoclr_socket_transfer_result_v1(operation, &c, result) && result[0] == 1 && result[1] == 0);
    CHECK(!neoclr_socket_send_v1(accepted, array, 8, 1, callback, &c, result) && result[0] == 2 && result[1] == 3);
    CHECK(neoclr_socket_send_v1(accepted, array, 0, 1, callback, &c, result) == 3);
    neoclr_os_close(peer); peer = NEOCLR_INVALID_SOCKET;
    unsigned eof = 0;
    for (unsigned attempt = 0; attempt < 5 && !eof; attempt++) {
        CHECK(!neoclr_socket_receive_v1(accepted, array, 0, 8, callback, &c, result) && result[0] == 5);
        operation = result[1]; ready = 0;
        for (unsigned retry = 0; retry < 5000 && !ready; retry++) {
            ready = neoclr_socket_poll_v1(&c, &root);
            if (!ready) neoclr_os_pause();
        }
        CHECK(ready == 1);
        CHECK(!neoclr_socket_transfer_result_v1(operation, &c, result) && result[0] == 1);
        eof = result[1] == 0;
    }
    CHECK(eof);
    /* Teardown releases pending receive roots and native scratch on a fault. */
    CHECK(!neoclr_socket_receive_v1(accepted, array, 0, 1, callback, &c, result) && result[0] == 5);
    CHECK(!neoclr_gc_host_root_release_v1(&c, array_root));
    CHECK(!neoclr_socket_close_v1(listener,&c,result) && result[0]==0);
    CHECK(!neoclr_socket_close_v1(listener,&c,result) && result[0]==0);
    CHECK(!neoclr_socket_local_port_v1(listener,&c,result) && result[0]==2 && result[1]==1);
    c.fault.code = 4;
    if (peer != NEOCLR_INVALID_SOCKET) neoclr_os_close(peer);
    CHECK(!neoclr_socket_scope_leave_v1(&scope));
    c.fault.code = 0;
    CHECK(!neoclr_gc_host_root_release_v1(&c,result_handle));
    CHECK(!collect_and_begin(&c) && !c.text.used && !neoclr_gc_entry_check_v1(&c));
    CHECK(buffer[512] == 1234567);
    CHECK(!neoclr_gc_heap_release_v1(&c.text));
    return 0;
}

int managed_socket_consumer(void *const *table) {
    functions=table;
    for(unsigned i=0;i<32;i++) { int status=run_socket_case(); if(status) {fprintf(stderr,"socket case line %d\n",status);return status;} }
    for(unsigned i=0;i<13;i++) REQUIRE(calls[i]);
    puts("PASS 32 generated socket loopback cases: protected heap results, errors, accept, transfer and teardown");
    return 0;
}
#ifdef MANAGED_MAIN
extern int32_t live_socket_listen(const neoclr_aot_text *, int32_t, int32_t,void *,neoclr_aot_context *);
extern int32_t live_socket_local_port(uint64_t,void *,neoclr_aot_context *);
extern int32_t live_socket_close(uint64_t,void *,neoclr_aot_context *);
extern int32_t live_socket_accept(uint64_t, void *,void *,neoclr_aot_context *);
extern int32_t live_socket_connect_result(uint64_t,void *,neoclr_aot_context *);
extern int32_t live_socket_cancel(uint64_t,void *,neoclr_aot_context *);
extern int32_t live_socket_deadline_after(int32_t,void *,neoclr_aot_context *);
extern int32_t live_socket_deadline_expired(int64_t,void *,neoclr_aot_context *);
extern int32_t live_socket_receive(uint64_t, void *, int32_t, int32_t, void *,void *,neoclr_aot_context *);
extern int32_t live_socket_send(uint64_t, void *, int32_t, int32_t, void *,void *,neoclr_aot_context *);
extern int32_t live_socket_transfer_result(uint64_t,void *,neoclr_aot_context *);
extern int32_t live_socket_receive_until(uint64_t, void *, int32_t, int32_t, int64_t, void *,void *,neoclr_aot_context *);
extern int32_t live_socket_send_until(uint64_t, void *, int32_t, int32_t, int64_t, void *,void *,neoclr_aot_context *);
int main(void) { void *table[]={live_socket_listen,live_socket_local_port,live_socket_close,live_socket_accept,live_socket_connect_result,live_socket_cancel,live_socket_deadline_after,live_socket_deadline_expired,live_socket_receive,live_socket_send,live_socket_transfer_result,live_socket_receive_until,live_socket_send_until};return managed_socket_consumer(table); }
#endif
