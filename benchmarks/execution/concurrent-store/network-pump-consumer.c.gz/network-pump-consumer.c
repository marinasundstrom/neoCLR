#include "native-runtime.h"
#include "socket-listener.h"
#include "task-queue.h"
#include <stdio.h>
#include <stdlib.h>
#define CHECK(x) do { if (!(x)) { fprintf(stderr,"async wrappers line %d: %s\n",__LINE__,#x); abort(); } } while(0)
extern int32_t experiment_gc_begin(neoclr_aot_context *,const neoclr_probe_frame *,neoclr_gc_conditional_root *,uint32_t);
extern int experiment_gc_live_active(neoclr_aot_context *);
extern int32_t experiment_gc_store(neoclr_aot_context *,void *,uint64_t,uint32_t);
extern void experiment_gc_store_counts(uint64_t *);
typedef int32_t (*create_fn)(void *,neoclr_aot_context *);
typedef int32_t (*owned_start_fn)(uint64_t,uint64_t,void *,neoclr_aot_context *);
typedef int32_t (*operation_fn)(uint64_t,void *,neoclr_aot_context *);
int managed_async_consumer(void *const *functions) {
    create_fn create=(create_fn)functions[0];
    operation_fn complete=(operation_fn)functions[1],await=(operation_fn)functions[2],
        release=(operation_fn)functions[3],iscompleted=(operation_fn)functions[4],wait=(operation_fn)functions[5];
    operation_fn start=(operation_fn)functions[6];
    operation_fn createowned=(operation_fn)functions[7];
    create_fn currentowner=(create_fn)functions[8];
    owned_start_fn startmanaged=(owned_start_fn)functions[9];
    create_fn pump=(create_fn)functions[11];
    (void)functions[10];
    for(unsigned round=0;round<100;round++) {
        uint64_t heap[512]={0};
        neoclr_aot_context c={.text={(unsigned char *)heap,sizeof(heap),0}};
        CHECK(!neoclr_gc_heap_acquire_v1(&c.text));
        neoclr_socket_scope sockets;
        CHECK(!neoclr_socket_scope_enter_v1(&sockets,&c));
        neoclr_task_scope scope;
        CHECK(!neoclr_task_scope_enter_v1(&scope,&c));
        int32_t pump_result=777;
        c.fault.code=9;
        CHECK(pump(&pump_result,&c)==3 && pump_result==777 && c.fault.code==9);
        CHECK(!neoclr_root_probe_head_v1());
        c.fault.code=0;
        uint64_t *owner,*descriptor;
        CHECK(!neoclr_gc_allocate_v1(&c.text,64,NEOCLR_GC_OBJECT,(void **)&owner));
        CHECK(!neoclr_gc_allocate_v1(&c.text,24,NEOCLR_GC_OBJECT,(void **)&descriptor));
        /* The empty Object base occupies one private layout lane. */
        owner[0]=2;descriptor[0]=UINT32_MAX;descriptor[1]=1;descriptor[2]=(uintptr_t)owner;
        uint64_t keep,body;CHECK(!neoclr_gc_host_root_create_v1(&c,owner,&keep));
        CHECK(!currentowner(owner+5,&c) && !owner[5]);
        CHECK(startmanaged(0,(uintptr_t)descriptor,owner+6,&c)==3 && !owner[6]);c.fault.code=0;
        owner[4]=123;
        CHECK(createowned(0,owner+4,&c)==3 && owner[4]==123);c.fault.code=0;
        CHECK(!(round&1?createowned((uintptr_t)owner,owner+4,&c):create(owner+4,&c)) && owner[4]);
        uint64_t operation=owner[4];
        CHECK(!experiment_gc_begin(&c,NULL,NULL,0));
        if(round&1) {
            CHECK(!startmanaged((uintptr_t)owner,(uintptr_t)descriptor,owner+6,&c) && owner[6]);
            body=owner[6];
        } else {
            uint64_t before_start[5],after_start[5];experiment_gc_store_counts(before_start);
            CHECK(!start((uintptr_t)descriptor,owner+6,&c) && owner[6]);
            experiment_gc_store_counts(after_start);
            /* The callback boundary may complete the epoch before publication. */
            CHECK(after_start[1]+after_start[2]==before_start[1]+before_start[2]+2);
            body=owner[6];
        }
        CHECK(!owner[2] && !owner[3] && !neoclr_root_probe_head_v1());
        CHECK(owner[5]==((round&1)?(uintptr_t)owner:0));
        CHECK(!neoclr_gc_collect_v1(&c,NULL));
        CHECK(!experiment_gc_begin(&c,NULL,NULL,0));
        if(round%4==1) {
            /* Self-reference/current-owner storage must not keep abandoned
             * owned callbacks or their parked generated frames alive. */
            CHECK(!neoclr_gc_host_root_release_v1(&c,keep));
            CHECK(!neoclr_gc_collect_v1(&c,NULL) && !c.text.used);
            CHECK(!pump(&pump_result,&c) && !pump_result);
            int32_t late=123;
            CHECK(!complete(operation,&late,&c) && !late);
            CHECK(!release(operation,&late,&c) && !late);
            CHECK(!neoclr_runtime_async_shutdown_v1(&c));
            CHECK(!neoclr_gc_entry_check_v1(&c));
            CHECK(!neoclr_socket_scope_leave_v1(&sockets));
            CHECK(!neoclr_task_scope_leave_v1(&scope));
            CHECK(!neoclr_gc_heap_release_v1(&c.text));
            CHECK(!neoclr_runtime_async_statistics_v1().reserved_bytes);
            continue;
        }
        uint64_t before[5],after[5];experiment_gc_store_counts(before);
        CHECK(!iscompleted(operation,owner+2,&c) && !owner[2]);
        experiment_gc_store_counts(after);
        CHECK(after[2]==before[2]+1 && experiment_gc_live_active(&c));
        CHECK(!experiment_gc_store(&c,owner+2,123,8));
        CHECK(wait(operation,owner+2,&c)==3 && owner[2]==123);
        c.fault.code=0;
        CHECK(await(operation,owner+2,&c)==3 && owner[2]==123);
        c.fault.code=0;
        CHECK(!complete(operation,owner+2,&c) && (uint32_t)owner[2]==1);
        uint64_t collections=neoclr_gc_statistics_v1().collections;
        if(!(round&1)) {
            void *garbage;
            while(!neoclr_gc_allocate_v1(&c.text,24,NEOCLR_GC_OBJECT,&garbage)) {}
        }
        CHECK(!pump(&pump_result,&c) && !pump_result);
        CHECK((uint32_t)owner[2]==42 && owner[3] && !neoclr_root_probe_head_v1());
        if(!(round&1)) CHECK(neoclr_gc_statistics_v1().collections>collections);
        CHECK(!neoclr_gc_collect_v1(&c,NULL));
        CHECK(!experiment_gc_begin(&c,NULL,NULL,0));
        CHECK(!wait(operation,owner+2,&c) && (uint32_t)owner[2]==1);
        experiment_gc_store_counts(before);
        CHECK(!await(operation,owner+2,&c) && (uint32_t)owner[2]==1);
        experiment_gc_store_counts(after);CHECK(after[2]==before[2]);
        CHECK(!release(operation,owner+2,&c) && (uint32_t)owner[2]==1);
        if(!(round&1)) CHECK(!release(body,owner+2,&c) && (uint32_t)owner[2]==1);
        CHECK(iscompleted(operation,owner+2,&c)==3 && (uint32_t)owner[2]==1);
        c.fault.code=0;
        /* A real accept delivery must dispatch the generated callback through
         * the generated pump, while only host ownership retains its descriptor. */
        CHECK(!create(owner+4,&c));
        uint64_t network_operation=owner[4];
        int32_t completed=0;
        CHECK(!complete(network_operation,&completed,&c) && completed);
        uint64_t *network_callback;
        CHECK(!neoclr_gc_allocate_v1(&c.text,24,NEOCLR_GC_OBJECT,(void **)&network_callback));
        network_callback[0]=UINT32_MAX;network_callback[1]=1;network_callback[2]=(uintptr_t)owner;
        const struct { uint64_t length; char bytes[16]; } address={9,"127.0.0.1"};
        uint64_t result[2];
        CHECK(!neoclr_socket_listen_v1((const void *)&address,0,4,&c,result) && result[0]==5);
        uint64_t listener=result[1];
        CHECK(!neoclr_socket_local_port_v1(listener,&c,result) && result[0]==1);
        struct sockaddr_in endpoint={0};
        endpoint.sin_family=AF_INET;endpoint.sin_port=htons((uint16_t)result[1]);
        endpoint.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
        CHECK(!neoclr_socket_accept_v1(listener,network_callback,&c,result) && result[0]==5);
        uint64_t accepting=result[1];
        CHECK(!experiment_gc_store(&c,owner+7,accepting,8));
        CHECK(!neoclr_gc_collect_v1(&c,NULL));
        CHECK(!experiment_gc_begin(&c,NULL,NULL,0));
        CHECK(!experiment_gc_store(&c,owner+2,99,8));
        neoclr_socket_descriptor peer=socket(AF_INET,SOCK_STREAM,0);
        CHECK(peer!=NEOCLR_INVALID_SOCKET && !connect(peer,(const void *)&endpoint,sizeof(endpoint)));
        CHECK(!pump(&pump_result,&c) && !pump_result && owner[2]==42 && owner[3]);
        CHECK(!sockets.scheduler_delivery && !neoclr_root_probe_head_v1());
        CHECK(!owner[7]);
        CHECK(neoclr_socket_connect_result_v1(accepting,&c,result)==3);
        neoclr_os_close(peer);
        CHECK(!neoclr_socket_close_v1(listener,&c,result) && result[0]==0);
        CHECK(!release(network_operation,&completed,&c) && completed);
        CHECK(!neoclr_runtime_async_shutdown_v1(&c));
        /* A started callback may fault after native creation; no failed result
         * is published through the caller's heap alias. Shutdown owns cleanup. */
        uint64_t *failed_descriptor;
        CHECK(!neoclr_gc_allocate_v1(&c.text,24,NEOCLR_GC_OBJECT,(void **)&failed_descriptor));
        failed_descriptor[0]=UINT32_MAX;failed_descriptor[1]=2;failed_descriptor[2]=(uintptr_t)owner;
        CHECK(!experiment_gc_store(&c,owner+6,777,8));
        CHECK(start((uintptr_t)failed_descriptor,owner+6,&c)==3 && owner[6]==777);
        CHECK(c.fault.code==1 && !neoclr_root_probe_head_v1());c.fault.code=0;
        CHECK(start(0,owner+6,&c)==3 && owner[6]==777);
        CHECK(!neoclr_root_probe_head_v1());c.fault.code=0;
        CHECK(!neoclr_gc_host_root_release_v1(&c,keep));
        CHECK(!neoclr_gc_collect_v1(&c,NULL) && !c.text.used);
        /* Clearing the fault deliberately exposes the outstanding failed
         * operations as a shutdown error; cleanup must still finish. */
        CHECK(neoclr_runtime_async_shutdown_v1(&c)==3);
        CHECK(!neoclr_runtime_async_shutdown_v1(&c));
        CHECK(!neoclr_gc_entry_check_v1(&c));
        CHECK(!neoclr_socket_scope_leave_v1(&sockets));
            CHECK(!neoclr_task_scope_leave_v1(&scope));
            CHECK(!neoclr_gc_heap_release_v1(&c.text));
        CHECK(!neoclr_runtime_async_statistics_v1().reserved_bytes);
    }
    puts("PASS 100 real-scheduler pump cycles (75 loopback accepts): strong/owned startup, current owner, 75 resumed, 25 abandoned, faults, pressure and shutdown");
    return 0;
}
#ifdef MANAGED_MAIN
extern int32_t live_async_create(void *,neoclr_aot_context *);
extern int32_t live_async_complete(uint64_t,void *,neoclr_aot_context *);
extern int32_t live_async_await(uint64_t,void *,neoclr_aot_context *);
extern int32_t live_async_release(uint64_t,void *,neoclr_aot_context *);
extern int32_t live_async_iscompleted(uint64_t,void *,neoclr_aot_context *);
extern int32_t live_async_wait(uint64_t,void *,neoclr_aot_context *);
extern int32_t live_async_start(uint64_t,void *,neoclr_aot_context *);
extern int32_t live_async_createowned(uint64_t,void *,neoclr_aot_context *);
extern int32_t live_async_currentowner(void *,neoclr_aot_context *);
extern int32_t live_async_startmanaged(uint64_t,uint64_t,void *,neoclr_aot_context *);
extern int32_t neoclr_invoke_void_callback_v1(uint64_t,neoclr_aot_context *);
extern int32_t live_async_pump(void *,neoclr_aot_context *);
int main(void) {
    void *functions[]={live_async_create,live_async_complete,live_async_await,live_async_release,
        live_async_iscompleted,live_async_wait,live_async_start,live_async_createowned,live_async_currentowner,live_async_startmanaged,neoclr_invoke_void_callback_v1,live_async_pump};
    return managed_async_consumer(functions);
}
#endif
