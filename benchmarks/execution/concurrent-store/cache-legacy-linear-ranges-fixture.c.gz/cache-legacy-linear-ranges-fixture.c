#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wreturn-type"
#define main original_store_tests
#include "/Users/robert/Projects/neoclr/benchmarks/execution/concurrent-live/store-test.c"
#undef main
int main(void) { cached_range_lifetime(); cached_interior_header(); return 0; }

#pragma clang diagnostic pop
