	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 26, 2	sdk_version 26, 2
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_probe_fault_roots_v1
lCPI0_0:
	.long	8                               ; 0x8
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_probe_fault_roots_v1
	.p2align	2
_neoclr_probe_fault_roots_v1:           ; @neoclr_probe_fault_roots_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB0_9
; %bb.1:
	ldr	w8, [x0]
	cbz	w8, LBB0_8
; %bb.2:
	ldr	w9, [x0, #4]
	mov	w8, #-1                         ; =0xffffffff
	cmp	w9, w2
	ccmp	x1, #0, #4, lo
	b.eq	LBB0_8
; %bb.3:
	cmp	w9, #64
	b.hi	LBB0_8
; %bb.4:
	add	x8, x0, #8
	str	x8, [x1]
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	d0, [x8, lCPI0_0@PAGEOFF]
	str	d0, [x1, #8]
	ldr	w8, [x0, #4]
	cbz	w8, LBB0_10
; %bb.5:
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	add	x10, x1, #24
LBB0_6:                                 ; =>This Inner Loop Header: Depth=1
	add	x8, x8, #1
	stur	x9, [x10, #-8]
	str	d0, [x10], #16
	ldr	w11, [x0, #4]
	add	x9, x9, #16
	cmp	x8, x11
	b.lo	LBB0_6
; %bb.7:
	add	w8, w11, #1
LBB0_8:
	mov	x0, x8
	ret
LBB0_9:
	mov	w0, #-1                         ; =0xffffffff
	ret
LBB0_10:
	mov	w0, #1                          ; =0x1
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_enter_v1             ; -- Begin function neoclr_gc_enter_v1
	.p2align	2
_neoclr_gc_enter_v1:                    ; @neoclr_gc_enter_v1
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbz	x0, LBB1_7
; %bb.1:
	cbz	x1, LBB1_7
; %bb.2:
	cmp	w2, #1, lsl #12                 ; =4096
	b.hs	LBB1_7
; %bb.3:
	mov	x19, x6
	mov	x21, x5
	mov	x20, x4
	mov	x23, x3
	mov	x22, x0
Lloh2:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh3:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	xzr, [x22, #96]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x22, #64]
	stp	q0, q0, [x22, #32]
	stp	q0, q0, [x22]
	ldr	x8, [x0]
	stp	x8, x1, [x22]
	str	w2, [x22, #40]
	cbz	x3, LBB1_7
; %bb.4:
	cbz	x21, LBB1_7
; %bb.5:
	mov	x24, x0
	mov	x0, x21
	bl	_strlen
	cmp	x0, w19, uxtw
	b.ne	LBB1_7
; %bb.6:
	str	wzr, [x22, #100]
	stp	x23, x21, [x22, #48]
	stp	w20, w19, [x22, #64]
	str	x22, [x24]
	ldr	w8, [x24, #16]
	add	w8, w8, #1
	str	w8, [x24, #16]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB1_7:
	bl	_abort
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_leave_v1             ; -- Begin function neoclr_gc_leave_v1
	.p2align	2
_neoclr_gc_leave_v1:                    ; @neoclr_gc_leave_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	cbz	x0, LBB2_6
; %bb.1:
	mov	x8, x0
Lloh4:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh5:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x10, [x0]
	ldr	w9, [x0, #16]
	cmp	x10, x8
	ccmp	w9, #0, #4, eq
	b.eq	LBB2_6
; %bb.2:
	ldr	x10, [x8, #8]
	cbz	x10, LBB2_6
; %bb.3:
	ldr	w11, [x10]
	cbz	w11, LBB2_5
; %bb.4:
	ldr	w10, [x10, #4]
	cmp	w10, #65
	b.hs	LBB2_6
LBB2_5:
	ldr	x10, [x8]
	str	x10, [x0]
	sub	w9, w9, #1
	str	w9, [x0, #16]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8, #64]
	str	xzr, [x8, #96]
	stp	q0, q0, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB2_6:
	bl	_abort
	.loh AdrpLdr	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_enter_owned_v1       ; -- Begin function neoclr_gc_enter_owned_v1
	.p2align	2
_neoclr_gc_enter_owned_v1:              ; @neoclr_gc_enter_owned_v1
	.cfi_startproc
; %bb.0:
	mov	w7, #0                          ; =0x0
	b	_enter_owned
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function enter_owned
_enter_owned:                           ; @enter_owned
	.cfi_startproc
; %bb.0:
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
	cbz	x3, LBB4_31
; %bb.1:
	mov	x19, x7
	mov	x22, x6
	mov	x24, x5
	mov	x23, x4
	mov	x25, x3
	mov	x21, x1
	mov	x20, x0
	cbz	w4, LBB4_15
; %bb.2:
	mov	w8, w23
	cmp	w23, #5
	b.hs	LBB4_4
; %bb.3:
	mov	x9, #0                          ; =0x0
	mov	w11, #0                         ; =0x0
	b	LBB4_12
LBB4_4:
	cmp	w23, #17
	b.hs	LBB4_6
; %bb.5:
	mov	w11, #0                         ; =0x0
	mov	x9, #0                          ; =0x0
	b	LBB4_9
LBB4_6:
	ands	x9, x8, #0xf
	movi.2d	v1, #0000000000000000
	mov	w10, #16                        ; =0x10
	csel	x10, x10, x9, eq
	sub	x9, x8, x10
	add	x11, x25, #128
	mov	x12, x8
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.4s	v4, #8
	movi.4s	v3, #2
LBB4_7:                                 ; =>This Inner Loop Header: Depth=1
	sub	x13, x11, #128
	ld2.2d	{ v16, v17 }, [x13]
	sub	x13, x11, #96
	ld2.2d	{ v22, v23 }, [x13]
	sub	x13, x11, #64
	ld2.2d	{ v18, v19 }, [x13]
	sub	x13, x11, #32
	ld2.2d	{ v24, v25 }, [x13]
	mov	x13, x11
	ld2.2d	{ v20, v21 }, [x13], #32
	sub	x14, x11, #120
	ld4.4s	{ v26, v27, v28, v29 }, [x14]
	sub	x14, x11, #56
	ld4.4s	{ v8, v9, v10, v11 }, [x14]
	add	x14, x11, #8
	ld4.4s	{ v12, v13, v14, v15 }, [x14]
	add	x14, x11, #72
	movi.4s	v2, #4
	cmeq.4s	v30, v26, v2
	cmeq.4s	v31, v8, v2
	cmeq.4s	v0, v26, v4
	cmhi.4s	v26, v27, v3
	cmeq.4s	v27, v12, v2
	cmeq.4s	v28, v8, v4
	cmeq.4s	v29, v12, v4
	cmhi.4s	v8, v9, v3
	cmhi.4s	v9, v13, v3
	ld4.4s	{ v10, v11, v12, v13 }, [x14]
	cmeq.4s	v14, v10, v2
	cmeq.4s	v15, v10, v4
	cmhi.4s	v10, v11, v3
	cmeq.2d	v22, v22, #0
	add	x14, x11, #64
	cmeq.2d	v16, v16, #0
	uzp1.4s	v16, v16, v22
	ld2.2d	{ v22, v23 }, [x13]
	cmeq.2d	v17, v24, #0
	cmeq.2d	v18, v18, #0
	ld2.2d	{ v24, v25 }, [x14]
	add	x13, x11, #96
	uzp1.4s	v17, v18, v17
	cmeq.2d	v18, v20, #0
	ld2.2d	{ v19, v20 }, [x13]
	cmeq.2d	v21, v22, #0
	uzp1.4s	v18, v18, v21
	cmeq.2d	v19, v19, #0
	cmeq.2d	v20, v24, #0
	uzp1.4s	v19, v20, v19
	mvn.16b	v20, v30
	bic.16b	v0, v20, v0
	mvn.16b	v20, v31
	bic.16b	v20, v20, v28
	mvn.16b	v21, v27
	bic.16b	v21, v21, v29
	mvn.16b	v22, v14
	bic.16b	v22, v22, v15
	orr.16b	v0, v16, v0
	orr.16b	v16, v17, v20
	orr.16b	v17, v18, v21
	orr.16b	v18, v19, v22
	movi.4s	v2, #1
	and.16b	v19, v26, v2
	orr.16b	v1, v1, v19
	and.16b	v19, v8, v2
	orr.16b	v5, v5, v19
	and.16b	v19, v9, v2
	orr.16b	v6, v6, v19
	and.16b	v19, v10, v2
	orr.16b	v7, v7, v19
	and.16b	v0, v0, v2
	orr.16b	v1, v1, v0
	and.16b	v0, v16, v2
	orr.16b	v5, v5, v0
	and.16b	v0, v17, v2
	orr.16b	v6, v6, v0
	and.16b	v0, v18, v2
	orr.16b	v7, v7, v0
	add	x11, x11, #256
	sub	x12, x12, #16
	cmp	x10, x12
	b.ne	LBB4_7
; %bb.8:
	orr.16b	v0, v5, v1
	orr.16b	v0, v6, v0
	orr.16b	v0, v7, v0
	ext.16b	v1, v0, v0, #8
	orr.8b	v0, v0, v1
	fmov	x11, d0
	lsr	x12, x11, #32
	orr	w11, w11, w12
	cmp	x10, #4
	b.ls	LBB4_12
LBB4_9:
	mov	x12, x9
	ands	x9, x8, #0x3
	mov	w10, #4                         ; =0x4
	csel	x13, x10, x9, eq
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], w11
	add	x10, x25, x12, lsl #4
	sub	x9, x8, x13
	add	x10, x10, #8
	add	x11, x13, x12
	sub	x11, x11, x8
	movi.4s	v1, #4
	movi.4s	v2, #8
	movi.4s	v3, #1
	movi.4s	v4, #2
LBB4_10:                                ; =>This Inner Loop Header: Depth=1
	sub	x12, x10, #8
	ld2.2d	{ v5, v6 }, [x12]
	add	x12, x10, #24
	ld2.2d	{ v16, v17 }, [x12]
	cmeq.2d	v7, v16, #0
	cmeq.2d	v5, v5, #0
	ld4.4s	{ v16, v17, v18, v19 }, [x10], #64
	uzp1.4s	v5, v5, v7
	cmeq.4s	v6, v16, v1
	mvn.16b	v6, v6
	cmeq.4s	v7, v16, v2
	bic.16b	v6, v6, v7
	orr.16b	v5, v5, v6
	and.16b	v5, v5, v3
	cmhi.4s	v6, v17, v4
	and.16b	v6, v6, v3
	orr.16b	v0, v0, v6
	orr.16b	v0, v0, v5
	adds	x11, x11, #4
	b.ne	LBB4_10
; %bb.11:
	ext.16b	v1, v0, v0, #8
	orr.8b	v0, v0, v1
	fmov	x10, d0
	lsr	x11, x10, #32
	orr	w11, w10, w11
LBB4_12:
	sub	x8, x8, x9
	add	x9, x25, x9, lsl #4
	add	x9, x9, #12
LBB4_13:                                ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x9, #-12]
	ldp	w13, w12, [x9, #-4]
	cmp	w13, #4
	ccmp	w13, #8, #4, ne
	ccmp	x10, #0, #4, eq
	cset	w10, eq
	cmp	w12, #2
	cset	w12, hi
	orr	w11, w11, w12
	orr	w11, w11, w10
	add	x9, x9, #16
	subs	x8, x8, #1
	b.ne	LBB4_13
; %bb.14:
	cbnz	w11, LBB4_31
LBB4_15:
	cbz	x20, LBB4_31
; %bb.16:
	cbz	x21, LBB4_31
; %bb.17:
	cmp	w2, #1, lsl #12                 ; =4096
	b.hs	LBB4_31
; %bb.18:
Lloh6:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh7:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	xzr, [x20, #96]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x20, #64]
	stp	q0, q0, [x20, #32]
	stp	q0, q0, [x20]
	ldr	x26, [x0]
	stp	x26, x21, [x20]
	str	w2, [x20, #40]
	cbz	x24, LBB4_31
; %bb.19:
	tbnz	w19, #13, LBB4_21
; %bb.20:
	mov	x27, x0
	mov	x0, x24
	bl	_strlen
	mov	x8, x0
	mov	x0, x27
	cmp	x8, w22, uxtw
	b.eq	LBB4_24
	b	LBB4_31
LBB4_21:
	cmp	w22, #8
	b.ne	LBB4_31
; %bb.22:
	ldr	w8, [x24]
	mov	w9, #18254                      ; =0x474e
	movk	w9, #12627, lsl #16
	cmp	w8, w9
	b.ne	LBB4_31
; %bb.23:
	ldr	w8, [x24, #4]
	cmp	w8, w23
	b.ne	LBB4_31
LBB4_24:
	orr	w8, w19, #0x200
	str	w8, [x20, #100]
	stp	x25, x24, [x20, #48]
	stp	w23, w22, [x20, #64]
	str	x20, [x0]
	ldr	w8, [x0, #16]
	add	w8, w8, #1
	str	w8, [x0, #16]
	cbz	x26, LBB4_29
; %bb.25:
	ldr	w8, [x26, #100]
	tbz	w8, #12, LBB4_30
; %bb.26:
	ldr	x9, [x26, #8]
	cmp	x9, x21
	b.ne	LBB4_30
; %bb.27:
	tbnz	w8, #10, LBB4_29
; %bb.28:
	ldr	w8, [x26, #88]
	cbnz	w8, LBB4_30
LBB4_29:
	mov	w8, #4608                       ; =0x1200
	orr	w8, w19, w8
	str	w8, [x20, #100]
LBB4_30:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB4_31:
	bl	_abort
	.loh AdrpLdr	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_enter_map_v1         ; -- Begin function neoclr_gc_enter_map_v1
	.p2align	2
_neoclr_gc_enter_map_v1:                ; @neoclr_gc_enter_map_v1
	.cfi_startproc
; %bb.0:
	mov	w7, #8192                       ; =0x2000
	b	_enter_owned
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_stack_roots_v1       ; -- Begin function neoclr_gc_stack_roots_v1
	.p2align	2
_neoclr_gc_stack_roots_v1:              ; @neoclr_gc_stack_roots_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh8:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh9:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x7, x0
	mov	x0, x8
	mov	w6, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_stack_roots
	.loh AdrpLdr	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function stack_roots
_stack_roots:                           ; @stack_roots
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	d15, d14, [sp, #16]             ; 16-byte Folded Spill
	stp	d13, d12, [sp, #32]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #48]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #64]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #80]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -152
	.cfi_offset b15, -160
	cbz	x0, LBB7_67
; %bb.1:
	mov	x24, x4
	cbz	x4, LBB7_67
; %bb.2:
	mov	x25, x2
	cbz	x2, LBB7_67
; %bb.3:
	mov	x23, x3
	cmp	w3, #2, lsl #12                 ; =8192
	b.hi	LBB7_67
; %bb.4:
	mov	x26, x1
	lsr	w8, w1, #13
	cbnz	w8, LBB7_67
; %bb.5:
	mov	x21, x0
	ldr	x1, [x7]
	cmp	x1, x0
	b.ne	LBB7_67
; %bb.6:
	mov	x27, x6
	mov	x22, x5
	cbz	w6, LBB7_10
; %bb.7:
	cmp	w22, #8
	b.ne	LBB7_67
; %bb.8:
	ldr	w8, [x24]
	mov	w9, #18254                      ; =0x474e
	movk	w9, #12611, lsl #16
	cmp	w8, w9
	b.ne	LBB7_67
; %bb.9:
	ldr	w8, [x24, #4]
	cmp	w8, w23
	b.eq	LBB7_17
	b	LBB7_67
LBB7_10:
	str	x7, [sp, #8]                    ; 8-byte Folded Spill
	mov	x19, x1
	mov	x0, x24
	bl	_strlen
	cmp	x0, w22, uxtw
	b.ne	LBB7_67
; %bb.11:
	ubfx	x8, x24, #4, #28
	eor	w8, w8, w24, lsr #12
	and	x28, x8, #0xff
Lloh10:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh11:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	add	x20, x0, #96
	subs	w9, w22, #18
	ldr	x7, [sp, #8]                    ; 8-byte Folded Reload
	b.lo	LBB7_15
; %bb.12:
	ldr	w8, [x20, x28, lsl #2]
	cbz	w8, LBB7_15
; %bb.13:
	sub	w10, w8, #1
	cmp	w10, w9
	b.hi	LBB7_15
; %bb.14:
	mov	x1, x19
	add	x8, x24, x8
	ldur	x9, [x8, #-1]
	ldur	x10, [x8, #7]
	ldurh	w8, [x8, #15]
	mov	x11, #25970                     ; =0x6572
	movk	x11, #30065, lsl #16
	movk	x11, #29289, lsl #32
	movk	x11, #25701, lsl #48
	cmp	x9, x11
	mov	x9, #28755                      ; =0x7053
	movk	x9, #27753, lsl #16
	movk	x9, #19564, lsl #32
	movk	x9, #28257, lsl #48
	ccmp	x10, x9, #0, eq
	mov	w9, #29541                      ; =0x7365
	ccmp	w8, w9, #0, eq
	b.eq	LBB7_17
LBB7_15:
Lloh12:
	adrp	x1, _has_spill_marker.marker@PAGE
Lloh13:
	add	x1, x1, _has_spill_marker.marker@PAGEOFF
	mov	x0, x24
	bl	_strstr
	cbz	x0, LBB7_67
; %bb.16:
	sub	w8, w0, w24
	add	w8, w8, #1
	str	w8, [x20, x28, lsl #2]
	mov	x1, x19
	ldr	x7, [sp, #8]                    ; 8-byte Folded Reload
LBB7_17:
	ldr	w8, [x21, #100]
	mov	w9, #-19457                     ; =0xffffb3ff
	and	w8, w8, w9
	orr	w8, w8, w27
	stp	xzr, xzr, [x21, #80]
	str	xzr, [x21, #72]
	stp	wzr, w8, [x21, #96]
	str	w26, [x21, #44]
	stp	x25, x24, [x21, #16]
	stp	w22, w23, [x21, #32]
	tbnz	w8, #12, LBB7_55
; %bb.18:
	ldr	x8, [x7]
	cbz	x8, LBB7_58
; %bb.19:
	mov	x9, #0                          ; =0x0
	mov	w10, #4                         ; =0x4
	movi.4s	v0, #4
	movi.4s	v1, #8
	movi.4s	v2, #1
	mov	w11, #16                        ; =0x10
	movi.4s	v7, #2
	b	LBB7_21
LBB7_20:                                ;   in Loop: Header=BB7_21 Depth=1
	ldr	x8, [x8]
	cbz	x8, LBB7_58
LBB7_21:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB7_32 Depth 2
                                        ;     Child Loop BB7_35 Depth 2
                                        ;     Child Loop BB7_38 Depth 2
                                        ;     Child Loop BB7_47 Depth 2
                                        ;     Child Loop BB7_50 Depth 2
                                        ;     Child Loop BB7_53 Depth 2
	mov	x12, x9
	ldr	x9, [x8, #8]
	cmp	x9, #0
	ccmp	x9, x12, #0, ne
	b.eq	LBB7_25
; %bb.22:                               ;   in Loop: Header=BB7_21 Depth=1
	cbz	x9, LBB7_67
; %bb.23:                               ;   in Loop: Header=BB7_21 Depth=1
	ldr	w12, [x9]
	cbz	w12, LBB7_25
; %bb.24:                               ;   in Loop: Header=BB7_21 Depth=1
	ldr	w12, [x9, #4]
	cmp	w12, #65
	b.hs	LBB7_67
LBB7_25:                                ;   in Loop: Header=BB7_21 Depth=1
	ldr	w12, [x8, #100]
	tbnz	w12, #9, LBB7_40
; %bb.26:                               ;   in Loop: Header=BB7_21 Depth=1
	ldr	w13, [x8, #64]
	cbz	w13, LBB7_40
; %bb.27:                               ;   in Loop: Header=BB7_21 Depth=1
	ldr	x14, [x8, #48]
	cmp	w13, #5
	b.hs	LBB7_29
; %bb.28:                               ;   in Loop: Header=BB7_21 Depth=1
	mov	x15, #0                         ; =0x0
	mov	w17, #0                         ; =0x0
	b	LBB7_37
LBB7_29:                                ;   in Loop: Header=BB7_21 Depth=1
	cmp	w13, #17
	b.hs	LBB7_31
; %bb.30:                               ;   in Loop: Header=BB7_21 Depth=1
	mov	w17, #0                         ; =0x0
	mov	x15, #0                         ; =0x0
	b	LBB7_34
LBB7_31:                                ;   in Loop: Header=BB7_21 Depth=1
	ands	x15, x13, #0xf
	csel	x16, x11, x15, eq
	sub	x15, x13, x16
	add	x17, x14, #128
	movi.2d	v4, #0000000000000000
	mov	x0, x13
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
LBB7_32:                                ;   Parent Loop BB7_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x2, x17, #128
	ld2.2d	{ v16, v17 }, [x2]
	sub	x2, x17, #96
	ld2.2d	{ v22, v23 }, [x2]
	sub	x2, x17, #64
	ld2.2d	{ v18, v19 }, [x2]
	sub	x2, x17, #32
	ld2.2d	{ v24, v25 }, [x2]
	mov	x3, x17
	ld2.2d	{ v20, v21 }, [x3], #32
	sub	x2, x17, #120
	ld4.4s	{ v26, v27, v28, v29 }, [x2]
	sub	x2, x17, #56
	ld4.4s	{ v8, v9, v10, v11 }, [x2]
	add	x2, x17, #8
	ld4.4s	{ v12, v13, v14, v15 }, [x2]
	add	x2, x17, #72
	movi.4s	v0, #4
	cmeq.4s	v30, v26, v0
	cmeq.4s	v31, v8, v0
	movi.4s	v2, #8
	cmeq.4s	v3, v26, v2
	movi.4s	v1, #2
	cmhi.4s	v26, v27, v1
	cmeq.4s	v27, v12, v0
	cmeq.4s	v28, v8, v2
	cmeq.4s	v29, v12, v2
	cmhi.4s	v8, v9, v1
	cmhi.4s	v9, v13, v1
	ld4.4s	{ v10, v11, v12, v13 }, [x2]
	cmeq.4s	v14, v10, v0
	cmeq.4s	v15, v10, v2
	movi.4s	v2, #1
	cmhi.4s	v10, v11, v1
	cmeq.2d	v22, v22, #0
	add	x2, x17, #64
	cmeq.2d	v16, v16, #0
	uzp1.4s	v16, v16, v22
	ld2.2d	{ v22, v23 }, [x3]
	cmeq.2d	v17, v24, #0
	cmeq.2d	v18, v18, #0
	ld2.2d	{ v24, v25 }, [x2]
	add	x2, x17, #96
	uzp1.4s	v17, v18, v17
	cmeq.2d	v18, v20, #0
	ld2.2d	{ v19, v20 }, [x2]
	cmeq.2d	v21, v22, #0
	uzp1.4s	v18, v18, v21
	cmeq.2d	v19, v19, #0
	cmeq.2d	v20, v24, #0
	uzp1.4s	v19, v20, v19
	mvn.16b	v20, v30
	bic.16b	v3, v20, v3
	mvn.16b	v20, v31
	bic.16b	v20, v20, v28
	mvn.16b	v21, v27
	bic.16b	v21, v21, v29
	mvn.16b	v22, v14
	bic.16b	v22, v22, v15
	orr.16b	v3, v16, v3
	orr.16b	v16, v17, v20
	orr.16b	v17, v18, v21
	orr.16b	v18, v19, v22
	and.16b	v19, v26, v2
	orr.16b	v4, v4, v19
	and.16b	v19, v8, v2
	orr.16b	v5, v5, v19
	and.16b	v19, v9, v2
	orr.16b	v6, v6, v19
	and.16b	v19, v10, v2
	orr.16b	v7, v7, v19
	and.16b	v3, v3, v2
	orr.16b	v4, v4, v3
	and.16b	v3, v16, v2
	orr.16b	v5, v5, v3
	and.16b	v3, v17, v2
	orr.16b	v6, v6, v3
	and.16b	v3, v18, v2
	orr.16b	v7, v7, v3
	add	x17, x17, #256
	sub	x0, x0, #16
	cmp	x16, x0
	b.ne	LBB7_32
; %bb.33:                               ;   in Loop: Header=BB7_21 Depth=1
	orr.16b	v3, v5, v4
	orr.16b	v3, v6, v3
	orr.16b	v3, v7, v3
	ext.16b	v4, v3, v3, #8
	orr.8b	v3, v3, v4
	fmov	x17, d3
	lsr	x0, x17, #32
	orr	w17, w17, w0
	cmp	x16, #4
	movi.4s	v7, #2
	movi.4s	v1, #8
	b.ls	LBB7_37
LBB7_34:                                ;   in Loop: Header=BB7_21 Depth=1
	mov	x0, x15
	ands	x15, x13, #0x3
	csel	x2, x10, x15, eq
	add	x16, x14, x0, lsl #4
	sub	x15, x13, x2
	movi.2d	v4, #0000000000000000
	mov.s	v4[0], w17
	add	x16, x16, #8
	add	x17, x2, x0
	sub	x17, x17, x13
LBB7_35:                                ;   Parent Loop BB7_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x0, x16, #8
	ld2.2d	{ v5, v6 }, [x0]
	add	x0, x16, #24
	ld2.2d	{ v16, v17 }, [x0]
	cmeq.2d	v3, v16, #0
	cmeq.2d	v5, v5, #0
	ld4.4s	{ v16, v17, v18, v19 }, [x16], #64
	uzp1.4s	v3, v5, v3
	cmeq.4s	v5, v16, v0
	mvn.16b	v5, v5
	cmeq.4s	v6, v16, v1
	bic.16b	v5, v5, v6
	orr.16b	v3, v3, v5
	and.16b	v3, v3, v2
	cmhi.4s	v5, v17, v7
	and.16b	v5, v5, v2
	orr.16b	v4, v4, v5
	orr.16b	v4, v4, v3
	adds	x17, x17, #4
	b.ne	LBB7_35
; %bb.36:                               ;   in Loop: Header=BB7_21 Depth=1
	ext.16b	v3, v4, v4, #8
	orr.8b	v3, v4, v3
	fmov	x16, d3
	lsr	x17, x16, #32
	orr	w17, w16, w17
LBB7_37:                                ;   in Loop: Header=BB7_21 Depth=1
	sub	x13, x13, x15
	add	x14, x14, x15, lsl #4
	add	x14, x14, #12
LBB7_38:                                ;   Parent Loop BB7_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x15, [x14, #-12]
	ldp	w0, w16, [x14, #-4]
	cmp	w0, #4
	ccmp	w0, #8, #4, ne
	ccmp	x15, #0, #4, eq
	cset	w15, eq
	cmp	w16, #2
	cset	w16, hi
	orr	w16, w17, w16
	orr	w17, w16, w15
	add	x14, x14, #16
	subs	x13, x13, #1
	b.ne	LBB7_38
; %bb.39:                               ;   in Loop: Header=BB7_21 Depth=1
	cbnz	w17, LBB7_67
LBB7_40:                                ;   in Loop: Header=BB7_21 Depth=1
	tbnz	w12, #10, LBB7_20
; %bb.41:                               ;   in Loop: Header=BB7_21 Depth=1
	ldr	w12, [x8, #88]
	cbz	w12, LBB7_20
; %bb.42:                               ;   in Loop: Header=BB7_21 Depth=1
	ldr	x13, [x8, #72]
	cmp	w12, #5
	b.hs	LBB7_44
; %bb.43:                               ;   in Loop: Header=BB7_21 Depth=1
	mov	x14, #0                         ; =0x0
	mov	w16, #0                         ; =0x0
	b	LBB7_52
LBB7_44:                                ;   in Loop: Header=BB7_21 Depth=1
	cmp	w12, #17
	b.hs	LBB7_46
; %bb.45:                               ;   in Loop: Header=BB7_21 Depth=1
	mov	w16, #0                         ; =0x0
	mov	x14, #0                         ; =0x0
	b	LBB7_49
LBB7_46:                                ;   in Loop: Header=BB7_21 Depth=1
	ands	x14, x12, #0xf
	csel	x15, x11, x14, eq
	sub	x14, x12, x15
	add	x16, x13, #128
	movi.2d	v4, #0000000000000000
	mov	x17, x12
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
LBB7_47:                                ;   Parent Loop BB7_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x0, x16, #128
	ld2.2d	{ v16, v17 }, [x0]
	sub	x0, x16, #96
	ld2.2d	{ v18, v19 }, [x0]
	sub	x0, x16, #64
	ld2.2d	{ v20, v21 }, [x0]
	sub	x0, x16, #32
	ld2.2d	{ v22, v23 }, [x0]
	mov	x0, x16
	ld2.2d	{ v24, v25 }, [x0], #32
	ld2.2d	{ v26, v27 }, [x0]
	add	x0, x16, #64
	ld2.2d	{ v28, v29 }, [x0]
	add	x0, x16, #96
	ld2.2d	{ v30, v31 }, [x0]
	cmeq.2d	v3, v18, #0
	cmeq.2d	v16, v16, #0
	uzp1.4s	v3, v16, v3
	cmeq.2d	v16, v22, #0
	cmeq.2d	v17, v20, #0
	uzp1.4s	v16, v17, v16
	cmeq.2d	v17, v24, #0
	sub	x0, x16, #120
	sub	x4, x16, #56
	add	x2, x16, #8
	add	x3, x16, #72
	ld4.4s	{ v18, v19, v20, v21 }, [x0]
	ld4.4s	{ v22, v23, v24, v25 }, [x4]
	ld4.4s	{ v8, v9, v10, v11 }, [x2]
	ld4.4s	{ v12, v13, v14, v15 }, [x3]
	cmeq.2d	v26, v26, #0
	uzp1.4s	v17, v17, v26
	cmeq.2d	v26, v30, #0
	cmeq.2d	v27, v28, #0
	uzp1.4s	v26, v27, v26
	cmeq.4s	v27, v18, v0
	mvn.16b	v27, v27
	cmeq.4s	v28, v22, v0
	mvn.16b	v28, v28
	cmeq.4s	v29, v8, v0
	mvn.16b	v29, v29
	cmeq.4s	v30, v12, v0
	mvn.16b	v30, v30
	cmeq.4s	v18, v18, v1
	cmeq.4s	v19, v22, v1
	cmeq.4s	v20, v8, v1
	cmeq.4s	v21, v12, v1
	bic.16b	v18, v27, v18
	bic.16b	v19, v28, v19
	bic.16b	v20, v29, v20
	bic.16b	v21, v30, v21
	orr.16b	v3, v3, v18
	orr.16b	v16, v16, v19
	orr.16b	v17, v17, v20
	orr.16b	v18, v26, v21
	and.16b	v3, v3, v2
	and.16b	v16, v16, v2
	and.16b	v17, v17, v2
	and.16b	v18, v18, v2
	orr.16b	v4, v4, v3
	orr.16b	v5, v5, v16
	add	x16, x16, #256
	orr.16b	v6, v6, v17
	sub	x17, x17, #16
	orr.16b	v7, v7, v18
	cmp	x15, x17
	b.ne	LBB7_47
; %bb.48:                               ;   in Loop: Header=BB7_21 Depth=1
	orr.16b	v3, v5, v4
	orr.16b	v3, v6, v3
	orr.16b	v3, v7, v3
	ext.16b	v4, v3, v3, #8
	orr.8b	v3, v3, v4
	fmov	x16, d3
	lsr	x17, x16, #32
	orr	w16, w16, w17
	cmp	x15, #4
	movi.4s	v7, #2
	b.ls	LBB7_52
LBB7_49:                                ;   in Loop: Header=BB7_21 Depth=1
	mov	x17, x14
	ands	x14, x12, #0x3
	csel	x0, x10, x14, eq
	add	x15, x13, x17, lsl #4
	sub	x14, x12, x0
	movi.2d	v4, #0000000000000000
	mov.s	v4[0], w16
	add	x15, x15, #8
	add	x16, x0, x17
	sub	x16, x16, x12
LBB7_50:                                ;   Parent Loop BB7_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x17, x15, #8
	ld2.2d	{ v5, v6 }, [x17]
	add	x17, x15, #24
	ld2.2d	{ v16, v17 }, [x17]
	ld4.4s	{ v18, v19, v20, v21 }, [x15], #64
	cmeq.2d	v3, v16, #0
	cmeq.2d	v5, v5, #0
	uzp1.4s	v3, v5, v3
	cmeq.4s	v5, v18, v0
	mvn.16b	v5, v5
	cmeq.4s	v6, v18, v1
	bic.16b	v5, v5, v6
	orr.16b	v3, v3, v5
	and.16b	v3, v3, v2
	orr.16b	v4, v4, v3
	adds	x16, x16, #4
	b.ne	LBB7_50
; %bb.51:                               ;   in Loop: Header=BB7_21 Depth=1
	ext.16b	v3, v4, v4, #8
	orr.8b	v3, v4, v3
	fmov	x15, d3
	lsr	x16, x15, #32
	orr	w16, w15, w16
LBB7_52:                                ;   in Loop: Header=BB7_21 Depth=1
	sub	x12, x12, x14
	add	x13, x13, x14, lsl #4
	add	x13, x13, #8
LBB7_53:                                ;   Parent Loop BB7_21 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x14, [x13, #-8]
	ldr	w15, [x13], #16
	cmp	w15, #4
	ccmp	w15, #8, #4, ne
	ccmp	x14, #0, #4, eq
	cset	w14, eq
	orr	w16, w16, w14
	subs	x12, x12, #1
	b.ne	LBB7_53
; %bb.54:                               ;   in Loop: Header=BB7_21 Depth=1
	cbz	w16, LBB7_20
	b	LBB7_67
LBB7_55:
	ldr	x8, [x21, #8]
	cbz	x8, LBB7_67
; %bb.56:
	ldr	w9, [x8]
	cbz	w9, LBB7_58
; %bb.57:
	ldr	w8, [x8, #4]
	cmp	w8, #65
	b.hs	LBB7_67
LBB7_58:
	ldr	x8, [x7, #8]
	add	x8, x8, #1
	str	x8, [x7, #8]
	ldr	x0, [x21, #8]
	cbz	x0, LBB7_67
; %bb.59:
	ldr	w8, [x7, #88]
	cbnz	w8, LBB7_67
; %bb.60:
	ldr	x8, [x1, #8]
	cmp	x8, x0
	b.ne	LBB7_67
; %bb.61:
	ldr	x8, [x7, #56]
	cmp	x8, x0
	b.ne	LBB7_65
; %bb.62:
	ldr	x8, [x7, #24]
	ldr	x9, [x7, #72]
	cmp	x8, x9
	b.ne	LBB7_65
; %bb.63:
	ldr	x8, [x7, #32]
	ldr	x9, [x7, #64]
	sub	x8, x8, x9
	cmp	x8, #255
	b.hi	LBB7_65
; %bb.64:
	ldr	x8, [x7, #80]
	add	x8, x8, #1
	str	x8, [x7, #80]
	cmp	x8, #1, lsl #12                 ; =4096
	b.lo	LBB7_66
LBB7_65:
	bl	_neoclr_gc_idle_v1
	cbnz	w0, LBB7_67
LBB7_66:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #64]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #48]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #32]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
LBB7_67:
	bl	_abort
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdd	Lloh12, Lloh13
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_stack_map_v1         ; -- Begin function neoclr_gc_stack_map_v1
	.p2align	2
_neoclr_gc_stack_map_v1:                ; @neoclr_gc_stack_map_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh14:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh15:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x7, x0
	mov	x0, x8
	mov	w6, #2048                       ; =0x800
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_stack_roots
	.loh AdrpLdr	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_transient_v1         ; -- Begin function neoclr_gc_transient_v1
	.p2align	2
_neoclr_gc_transient_v1:                ; @neoclr_gc_transient_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh16:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh17:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x7, x0
	mov	x0, x8
	mov	w6, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_publish_transient
	.loh AdrpLdr	Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function publish_transient
_publish_transient:                     ; @publish_transient
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	cbz	x0, LBB10_16
; %bb.1:
	mov	x23, x0
	ldr	x8, [x7]
	cmp	x8, x0
	b.ne	LBB10_16
; %bb.2:
	mov	x22, x1
	sub	w8, w1, #1
	cmp	w8, #2
	b.hi	LBB10_16
; %bb.3:
	mov	x19, x2
	cbz	x2, LBB10_16
; %bb.4:
	mov	x24, x4
	cbz	x4, LBB10_16
; %bb.5:
	mov	x25, x6
	mov	x21, x5
	mov	x20, x3
	tbnz	w6, #14, LBB10_7
; %bb.6:
	mov	x0, x24
	bl	_strlen
	cmp	x0, w21, uxtw
	b.eq	LBB10_10
	b	LBB10_16
LBB10_7:
	cmp	w21, #8
	b.ne	LBB10_16
; %bb.8:
	ldr	w8, [x24]
	mov	w9, #18254                      ; =0x474e
	movk	w9, #12628, lsl #16
	cmp	w8, w9
	b.ne	LBB10_16
; %bb.9:
	ldr	w8, [x24, #4]
	cmp	w8, w20
	b.ne	LBB10_16
LBB10_10:
	ldr	w8, [x23, #100]
	mov	w9, #-17409                     ; =0xffffbbff
	and	w8, w8, w9
	orr	w8, w8, w25
	stp	x19, x24, [x23, #72]
	stp	w20, w21, [x23, #88]
	stp	w22, w8, [x23, #96]
	cbz	w20, LBB10_15
; %bb.11:
	mov	w8, w20
	add	x9, x19, #8
LBB10_12:                               ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x9, #-8]
	cbz	x10, LBB10_16
; %bb.13:                               ;   in Loop: Header=BB10_12 Depth=1
	ldr	w10, [x9]
	cmp	w10, #4
	ccmp	w10, #8, #4, ne
	b.ne	LBB10_16
; %bb.14:                               ;   in Loop: Header=BB10_12 Depth=1
	add	x9, x9, #16
	subs	x8, x8, #1
	b.ne	LBB10_12
LBB10_15:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB10_16:
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_transient_owned_v1   ; -- Begin function neoclr_gc_transient_owned_v1
	.p2align	2
_neoclr_gc_transient_owned_v1:          ; @neoclr_gc_transient_owned_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh18:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh19:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x7, x0
	mov	x0, x8
	mov	w6, #1024                       ; =0x400
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_publish_transient
	.loh AdrpLdr	Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_transient_map_v1     ; -- Begin function neoclr_gc_transient_map_v1
	.p2align	2
_neoclr_gc_transient_map_v1:            ; @neoclr_gc_transient_map_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh20:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh21:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x7, x0
	mov	x0, x8
	mov	w6, #17408                      ; =0x4400
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_publish_transient
	.loh AdrpLdr	Lloh20, Lloh21
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_root_probe_head_v1      ; -- Begin function neoclr_root_probe_head_v1
	.p2align	2
_neoclr_root_probe_head_v1:             ; @neoclr_root_probe_head_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh22:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh23:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x0, [x0]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh22, Lloh23
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_root_probe_count_v1     ; -- Begin function neoclr_root_probe_count_v1
	.p2align	2
_neoclr_root_probe_count_v1:            ; @neoclr_root_probe_count_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh24:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh25:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x0, [x0, #8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh24, Lloh25
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_root_probe_depth_v1     ; -- Begin function neoclr_root_probe_depth_v1
	.p2align	2
_neoclr_root_probe_depth_v1:            ; @neoclr_root_probe_depth_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh26:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh27:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w0, [x0, #16]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_roots_park_v1           ; -- Begin function neoclr_roots_park_v1
	.p2align	2
_neoclr_roots_park_v1:                  ; @neoclr_roots_park_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	cbz	x0, LBB16_10
; %bb.1:
	mov	x8, x0
	ldr	x9, [x0]
	cbnz	x9, LBB16_10
; %bb.2:
	ldr	x9, [x8, #8]
	cbnz	x9, LBB16_10
; %bb.3:
	ldr	x9, [x8, #16]
	cbnz	x9, LBB16_10
; %bb.4:
	ldr	x9, [x8, #24]
	cbnz	x9, LBB16_10
; %bb.5:
	ldr	w9, [x8, #32]
	cbnz	w9, LBB16_10
; %bb.6:
Lloh28:
	adrp	x0, _parked@TLVPPAGE
Lloh29:
	ldr	x0, [x0, _parked@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	ldr	x10, [x0]
	cbz	x10, LBB16_9
LBB16_7:                                ; =>This Inner Loop Header: Depth=1
	cmp	x10, x8
	b.eq	LBB16_10
; %bb.8:                                ;   in Loop: Header=BB16_7 Depth=1
	ldr	x10, [x10, #8]
	cbnz	x10, LBB16_7
LBB16_9:
Lloh30:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh31:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	str	x10, [x8]
	ldr	x10, [x9]
	str	x10, [x8, #8]
	str	x8, [x9]
	str	xzr, [x0]
	str	wzr, [x0, #16]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB16_10:
	bl	_abort
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_roots_resume_v1         ; -- Begin function neoclr_roots_resume_v1
	.p2align	2
_neoclr_roots_resume_v1:                ; @neoclr_roots_resume_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x9, x0
Lloh32:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh33:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	cbz	x9, LBB17_9
; %bb.1:
	mov	x8, x0
	ldr	x10, [x0]
	cbnz	x10, LBB17_9
; %bb.2:
	ldr	w10, [x9, #32]
	cbnz	w10, LBB17_9
; %bb.3:
Lloh34:
	adrp	x0, _parked@TLVPPAGE
Lloh35:
	ldr	x0, [x0, _parked@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
LBB17_4:                                ; =>This Inner Loop Header: Depth=1
	mov	x10, x0
	ldr	x11, [x0]
	add	x0, x11, #8
	cmp	x11, #0
	ccmp	x11, x9, #4, ne
	b.ne	LBB17_4
; %bb.5:
	cbz	x11, LBB17_9
; %bb.6:
	ldr	x11, [x9, #8]
	str	x11, [x10]
	ldr	x10, [x9]
	str	x10, [x8]
	movi.2d	v0, #0000000000000000
	str	xzr, [x9, #32]
	stp	q0, q0, [x9]
	mov	w9, #-1                         ; =0xffffffff
	mov	x10, x8
LBB17_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x10]
	add	w9, w9, #1
	cbnz	x10, LBB17_7
; %bb.8:
	str	w9, [x8, #16]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB17_9:
	bl	_abort
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpLdr	Lloh34, Lloh35
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_roots_parked_v1         ; -- Begin function neoclr_roots_parked_v1
	.p2align	2
_neoclr_roots_parked_v1:                ; @neoclr_roots_parked_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh36:
	adrp	x0, _parked@TLVPPAGE
Lloh37:
	ldr	x0, [x0, _parked@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x0, [x0]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh36, Lloh37
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_roots_discard_v1        ; -- Begin function neoclr_roots_discard_v1
	.p2align	2
_neoclr_roots_discard_v1:               ; @neoclr_roots_discard_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh38:
	adrp	x0, _parked@TLVPPAGE
Lloh39:
	ldr	x0, [x0, _parked@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
LBB19_1:                                ; =>This Inner Loop Header: Depth=1
	mov	x9, x0
	ldr	x10, [x0]
	add	x0, x10, #8
	cmp	x10, #0
	ccmp	x10, x8, #4, ne
	b.ne	LBB19_1
; %bb.2:
	cbz	x10, LBB19_4
; %bb.3:
	ldr	x10, [x8, #8]
	str	x10, [x9]
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB19_4:
	bl	_abort
	.loh AdrpLdr	Lloh38, Lloh39
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_stack_trace_capture_v1  ; -- Begin function neoclr_stack_trace_capture_v1
	.p2align	2
_neoclr_stack_trace_capture_v1:         ; @neoclr_stack_trace_capture_v1
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #624
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	str	x3, [sp, #64]                   ; 8-byte Folded Spill
	mov	x9, x0
Lloh40:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh41:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh42:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	mov	w0, #3                          ; =0x3
	tbnz	w9, #31, LBB20_44
; %bb.1:
	cbz	x1, LBB20_44
; %bb.2:
	mov	x19, x2
	cbz	x2, LBB20_44
; %bb.3:
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	cbz	x8, LBB20_44
; %bb.4:
Lloh43:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh44:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB20_21
; %bb.5:
	mov	w21, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	mov	w10, #52429                     ; =0xcccd
	movk	w10, #52428, lsl #16
	mov	w11, #65507                     ; =0xffe3
	add	x12, sp, #96
	mov	x13, x8
	b	LBB20_8
LBB20_6:                                ;   in Loop: Header=BB20_8 Depth=1
	sub	w9, w9, #1
LBB20_7:                                ;   in Loop: Header=BB20_8 Depth=1
	ldr	x13, [x13]
	cbz	x13, LBB20_18
LBB20_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB20_13 Depth 2
	ldr	x14, [x13, #8]
	cmp	x14, x1
	b.ne	LBB20_7
; %bb.9:                                ;   in Loop: Header=BB20_8 Depth=1
	cbnz	w9, LBB20_6
; %bb.10:                               ;   in Loop: Header=BB20_8 Depth=1
	ldr	w9, [x13, #40]
	cmp	w9, w4
	b.hs	LBB20_38
; %bb.11:                               ;   in Loop: Header=BB20_8 Depth=1
	ldr	x14, [sp, #64]                  ; 8-byte Folded Reload
	ldr	x9, [x14, x9, lsl #3]
	cbz	x9, LBB20_38
; %bb.12:                               ;   in Loop: Header=BB20_8 Depth=1
	ldr	w15, [x13, #44]
	mov	w14, #1                         ; =0x1
	cmp	w15, #10
	b.lo	LBB20_14
LBB20_13:                               ;   Parent Loop BB20_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x14, #1
	umull	x16, w15, w10
	lsr	x16, x16, #35
	cmp	w15, #99
	mov	x15, x16
	b.hi	LBB20_13
LBB20_14:                               ;   in Loop: Header=BB20_8 Depth=1
	cmp	w21, #64
	b.eq	LBB20_46
; %bb.15:                               ;   in Loop: Header=BB20_8 Depth=1
	ldr	x9, [x9]
	cmp	x9, #16, lsl #12                ; =65536
	b.hi	LBB20_46
; %bb.16:                               ;   in Loop: Header=BB20_8 Depth=1
	add	x9, x9, x14
	add	x14, x9, #22
	sub	x9, x11, x20
	cmp	x14, x9
	b.hi	LBB20_46
; %bb.17:                               ;   in Loop: Header=BB20_8 Depth=1
	mov	w9, #0                          ; =0x0
	str	x13, [x12, w21, uxtw #3]
	add	w21, w21, #1
	add	x20, x14, x20
	b	LBB20_7
LBB20_18:
	mov	w22, #1                         ; =0x1
	str	xzr, [sp, #72]
	cbz	x8, LBB20_22
LBB20_19:
	ldr	x9, [x8, #8]
	cmp	x9, x1
	b.eq	LBB20_22
; %bb.20:
	add	x0, x1, #1048
	add	x1, x20, #8
	add	x3, sp, #72
	mov	w2, #1                          ; =0x1
	bl	_neoclr_gc_allocate_v1
	cbnz	w0, LBB20_44
	b	LBB20_23
LBB20_21:
	mov	x20, #0                         ; =0x0
	mov	w21, #0                         ; =0x0
	str	xzr, [sp, #72]
	mov	w22, #1                         ; =0x1
LBB20_22:
	add	x2, x20, #8
	add	x4, sp, #72
	mov	x0, x1
	mov	x1, x8
	mov	w3, #1                          ; =0x1
	bl	_neoclr_gc_allocate_rooted_v1
	cbnz	w0, LBB20_44
LBB20_23:
	str	w22, [sp, #20]                  ; 4-byte Folded Spill
	stp	x20, x19, [sp, #24]             ; 16-byte Folded Spill
	ldr	x8, [sp, #72]
	mov	x9, x8
	str	x20, [x9], #8
	stp	x8, x9, [sp]                    ; 16-byte Folded Spill
	cbz	w21, LBB20_39
; %bb.24:
	mov	x26, #0                         ; =0x0
	add	x27, sp, #86
	sub	x11, x27, #32
	sub	x23, x27, #1
Lloh45:
	adrp	x8, l_.str.1@PAGE
Lloh46:
	add	x8, x8, l_.str.1@PAGEOFF
	ldur	x10, [x8, #6]
	str	x10, [sp, #56]                  ; 8-byte Folded Spill
	ldr	x8, [x8]
	stp	x11, x8, [sp, #40]              ; 16-byte Folded Spill
	mov	w28, #52429                     ; =0xcccd
	movk	w28, #52428, lsl #16
	mov	w25, #10                        ; =0xa
	mov	x20, x9
	mov	w22, w21
	b	LBB20_26
LBB20_25:                               ;   in Loop: Header=BB20_26 Depth=1
	mov	w9, #2653                       ; =0xa5d
	strh	w9, [x8], #2
	add	x26, x26, #1
	mov	x20, x8
	cmp	x26, x22
	b.eq	LBB20_40
LBB20_26:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB20_27 Depth 2
                                        ;     Child Loop BB20_35 Depth 2
                                        ;     Child Loop BB20_37 Depth 2
	add	x8, sp, #96
	ldr	x19, [x8, x26, lsl #3]
	ldr	w8, [x19, #40]
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldr	x24, [x9, x8, lsl #3]
	mov	w8, #8308                       ; =0x2074
	strh	w8, [x20, #4]
	mov	w8, #8224                       ; =0x2020
	movk	w8, #24864, lsl #16
	str	w8, [x20]
	add	x21, x20, #6
	ldr	x2, [x24]
	add	x1, x24, #8
	mov	x0, x21
	bl	_memcpy
	mov	w9, #0                          ; =0x0
	ldr	x10, [x24]
	add	x8, x21, x10
	ldr	x11, [sp, #56]                  ; 8-byte Folded Reload
	stur	x11, [x8, #6]
	ldr	x11, [sp, #48]                  ; 8-byte Folded Reload
	str	x11, [x8]
	ldr	w11, [x19, #44]
	mov	w13, #1                         ; =0x1
LBB20_27:                               ;   Parent Loop BB20_26 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
                                        ; kill: def $w9 killed $w9 killed $x9
	mov	x12, x13
	umull	x13, w11, w28
	lsr	x14, x13, #35
	msub	w13, w14, w25, w11
	orr	w13, w13, #0x30
	strb	w13, [x27, w9, uxtw]
	add	w9, w9, #1
	add	w13, w12, #1
	cmp	w11, #9
	mov	x11, x14
	b.hi	LBB20_27
; %bb.28:                               ;   in Loop: Header=BB20_26 Depth=1
	add	x8, x8, #14
	cbz	w9, LBB20_25
; %bb.29:                               ;   in Loop: Header=BB20_26 Depth=1
	cmp	w9, #64
	b.hs	LBB20_31
; %bb.30:                               ;   in Loop: Header=BB20_26 Depth=1
	mov	x10, x9
	b	LBB20_37
LBB20_31:                               ;   in Loop: Header=BB20_26 Depth=1
	add	x13, x20, x10
	add	x10, x13, x9
	add	x10, x10, #20
	cmp	x27, x10
	cset	w10, lo
	add	x11, x27, x9
	cmp	x8, x11
	b.hs	LBB20_34
; %bb.32:                               ;   in Loop: Header=BB20_26 Depth=1
	tbz	w10, #0, LBB20_34
; %bb.33:                               ;   in Loop: Header=BB20_26 Depth=1
	mov	x10, x9
	b	LBB20_37
LBB20_34:                               ;   in Loop: Header=BB20_26 Depth=1
	and	x11, x9, #0xffffffc0
	and	x10, x9, #0x3f
	add	x8, x8, x11
	mov	w14, w12
	and	x12, x14, #0xffffffc0
	add	x13, x13, #68
	ldr	x15, [sp, #40]                  ; 8-byte Folded Reload
	add	x14, x15, x14
LBB20_35:                               ;   Parent Loop BB20_26 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x14]
	rev64.16b	v0, v0
	ext.16b	v0, v0, v0, #8
	rev64.16b	v1, v1
	ext.16b	v1, v1, v1, #8
	ldp	q3, q2, [x14, #-32]
	rev64.16b	v2, v2
	ext.16b	v2, v2, v2, #8
	rev64.16b	v3, v3
	ext.16b	v3, v3, v3, #8
	stp	q0, q1, [x13, #-48]
	stp	q2, q3, [x13, #-16]
	add	x13, x13, #64
	sub	x14, x14, #64
	sub	x12, x12, #64
	cbnz	x12, LBB20_35
; %bb.36:                               ;   in Loop: Header=BB20_26 Depth=1
	cmp	x11, x9
	b.eq	LBB20_25
LBB20_37:                               ;   Parent Loop BB20_26 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldrb	w9, [x23, x10]
	strb	w9, [x8], #1
	subs	x10, x10, #1
	b.ne	LBB20_37
	b	LBB20_25
LBB20_38:
	mov	w0, #3                          ; =0x3
	b	LBB20_44
LBB20_39:
	mov	x8, x9
LBB20_40:
	ldr	w9, [sp, #20]                   ; 4-byte Folded Reload
	tbnz	w9, #0, LBB20_42
; %bb.41:
Lloh47:
	adrp	x9, l___const.neoclr_stack_trace_capture_v1.marker@PAGE
Lloh48:
	add	x9, x9, l___const.neoclr_stack_trace_capture_v1.marker@PAGEOFF
	ldr	q0, [x9]
	str	q0, [x8]
	ldur	q0, [x9, #13]
	stur	q0, [x8, #13]
	add	x8, x8, #29
LBB20_42:
	ldp	x10, x9, [sp, #24]              ; 16-byte Folded Reload
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
	sub	x8, x8, x11
	cmp	x8, x10
	b.ne	LBB20_48
; %bb.43:
	mov	w0, #0                          ; =0x0
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [x9]
LBB20_44:
	ldur	x8, [x29, #-96]
Lloh49:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh50:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh51:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB20_47
; %bb.45:
	add	sp, sp, #624
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB20_46:
	mov	w22, #0                         ; =0x0
	add	x20, x20, #29
	str	xzr, [sp, #72]
	cbnz	x8, LBB20_19
	b	LBB20_22
LBB20_47:
	bl	___stack_chk_fail
LBB20_48:
	bl	_abort
	.loh AdrpLdrGotLdr	Lloh40, Lloh41, Lloh42
	.loh AdrpLdr	Lloh43, Lloh44
	.loh AdrpAdd	Lloh45, Lloh46
	.loh AdrpAdd	Lloh47, Lloh48
	.loh AdrpLdrGotLdr	Lloh49, Lloh50, Lloh51
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_state_enter_v1       ; -- Begin function neoclr_gc_state_enter_v1
	.p2align	2
_neoclr_gc_state_enter_v1:              ; @neoclr_gc_state_enter_v1
	.cfi_startproc
; %bb.0:
	mov	w7, #8192                       ; =0x2000
	b	_enter_owned
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_state_stack_v1       ; -- Begin function neoclr_gc_state_stack_v1
	.p2align	2
_neoclr_gc_state_stack_v1:              ; @neoclr_gc_state_stack_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB22_2
; %bb.1:
	mov	x7, x0
	mov	x0, x1
	mov	x1, x2
	mov	x2, x3
	mov	x3, x4
	mov	x4, x5
	mov	x5, x6
	mov	w6, #2048                       ; =0x800
	b	_stack_roots
LBB22_2:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_state_transient_v1   ; -- Begin function neoclr_gc_state_transient_v1
	.p2align	2
_neoclr_gc_state_transient_v1:          ; @neoclr_gc_state_transient_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB23_2
; %bb.1:
	mov	x7, x0
	mov	x0, x1
	mov	x1, x2
	mov	x2, x3
	mov	x3, x4
	mov	x4, x5
	mov	x5, x6
	mov	w6, #17408                      ; =0x4400
	b	_publish_transient
LBB23_2:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_state_leave_v1       ; -- Begin function neoclr_gc_state_leave_v1
	.p2align	2
_neoclr_gc_state_leave_v1:              ; @neoclr_gc_state_leave_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	cbz	x0, LBB24_8
; %bb.1:
	cbz	x1, LBB24_8
; %bb.2:
	ldr	x8, [x0]
	cmp	x8, x1
	b.ne	LBB24_8
; %bb.3:
	ldr	w8, [x0, #16]
	cbz	w8, LBB24_8
; %bb.4:
	ldr	x9, [x1, #8]
	cbz	x9, LBB24_8
; %bb.5:
	ldr	w10, [x9]
	cbz	w10, LBB24_7
; %bb.6:
	ldr	w9, [x9, #4]
	cmp	w9, #65
	b.hs	LBB24_8
LBB24_7:
	ldr	x9, [x1]
	str	x9, [x0]
	sub	w8, w8, #1
	str	w8, [x0, #16]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x1, #32]
	stp	q0, q0, [x1, #64]
	str	xzr, [x1, #96]
	stp	q0, q0, [x1]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB24_8:
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.private_extern	_neoclr_execution_state_v1 ; @neoclr_execution_state_v1
.tbss _neoclr_execution_state_v1$tlv$init, 1120, 3

	.section	__DATA,__thread_vars,thread_local_variables
	.globl	_neoclr_execution_state_v1
_neoclr_execution_state_v1:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_neoclr_execution_state_v1$tlv$init

.tbss _parked$tlv$init, 8, 3            ; @parked

_parked:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_parked$tlv$init

	.section	__TEXT,__cstring,cstring_literals
l___const.neoclr_stack_trace_capture_v1.marker: ; @__const.neoclr_stack_trace_capture_v1.marker
	.asciz	"   ... stack trace truncated\n"

l_.str:                                 ; @.str
	.asciz	"   at "

l_.str.1:                               ; @.str.1
	.asciz	" [instruction "

	.section	__TEXT,__const
_has_spill_marker.marker:               ; @has_spill_marker.marker
	.asciz	"requiredSpillLanes"

.subsections_via_symbols
