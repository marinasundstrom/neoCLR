import json,subprocess,hashlib
from pathlib import Path
root=Path.cwd();base=root/'benchmarks/execution/concurrent-mutation-gate';out=root/'target/gate-workers-controls-final';out.mkdir(exist_ok=False)
r={'passed':False,'commands':[]}
def run(c,fail=False):
 x=subprocess.run(list(map(str,c)),capture_output=True,text=True,timeout=60);r['commands'].append(dict(command=list(map(str,c)),exitCode=x.returncode,stdout=x.stdout,stderr=x.stderr));assert (x.returncode!=0)==fail,x.stderr;return x
try:
 recipe=json.loads((root/'benchmarks/execution/call-layout/results.json').read_text())['builds'][1]['command'];cc=recipe[:recipe.index('-std=c11')]
 assemblies={}
 for name in ['baseline','current']:
  folder=out/name;folder.mkdir()
  for file in ['gate.c','gate.h']:
   data=subprocess.check_output(['git','show','ac12fa0fd463e1a117326af520b5b6dc54aec272:'+str((base/file).relative_to(root))]) if name=='baseline' else (base/file).read_bytes();(folder/file).write_bytes(data)
  obj=folder/'gate.o';run(cc+['-std=c11','-O2','-c',folder/'gate.c','-o',obj])
  assembly=run(['otool','-tvV',obj]).stdout.split('\n',1)[1];assemblies[name]=assembly
  (folder/'assembly.txt').write_text(assembly)
 r['ownerAssemblyIdentical']=assemblies['baseline']==assemblies['current']
 # Negative controls must fail without deletion logging or writer thread binding.
 source=(base/'gate.c').read_text()
 needles={
 'no-deletion-log':('if (g->active) for (size_t i = 0; i < count; i++) {','if (0 && g->active) for (size_t i = 0; i < count; i++) {'),
 'no-thread-check':('if (!result && !pthread_equal(g->writers[writer->slot].thread, pthread_self())) result = GATE_INVALID;','/* Deliberately broken thread authority. */')}
 for name,(old,new) in needles.items():
  assert old in source
  path=out/(name+'.c');start=source.index('static int write_locked')
  path.write_text(source[:start]+source[start:].replace(old,new,1));exe=out/name
  run(cc+['-std=c11','-O2','-pthread','-DNEOCLR_GATE_WORKERS','-DGATE_WORDS=64','-I',base,path,base/'workers-test.c','-o',exe]);run([exe],True)
 r['inputs']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [base/'gate.c',base/'gate.h',base/'workers-test.c']};r['passed']=True
finally:(out/'results.json').write_text(json.dumps(r,indent=2)+'\n')
print('identical owner assembly',r['ownerAssemblyIdentical'])
