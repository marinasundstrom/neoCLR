import copy,json,subprocess,tempfile,hashlib
from pathlib import Path
source=Path('target/concurrent-workloads');script=Path('benchmarks/execution/concurrent-workloads/summarize-whole-gap.py').resolve()
results=[]
for fault in ['none','profile-options','profile-input-hash','profile-response','measurement-pair']:
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp)
  for sample in ['plain','json']:
   for prefix in ['forward-elision-http','forward-profile-v2']:
    src=source/(prefix+'-'+sample)/'results.json';dst=root/(prefix+'-'+sample)/'results.json';dst.parent.mkdir();d=json.loads(src.read_text())
    if sample=='plain':
     if prefix=='forward-profile-v2':
      if fault=='profile-options':
       next(c['command'] for c in d['commands'] if '-o' in c['command']).append('-DUNMATCHED_PROFILE')
      if fault=='profile-input-hash':
       k=next(k for k in d['inputs'] if k.endswith('plain-sync.o'));d['inputs'][k]='0'*64
      if fault=='profile-response':d['trials'][0]['exitCode']=1
     elif fault=='measurement-pair':d['trials'].pop(0)
    dst.write_text(json.dumps(d))
   src=source/('forward-profile-v2-'+sample+'-summary.json');d=json.loads(src.read_text());p=root/('forward-profile-v2-'+sample)/'results.json'
   d['inputs'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
   (root/src.name).write_text(json.dumps(d))
  cmd=['python3',str(script),'--root',str(root),'--measurement-prefix','forward-elision-http','--profile-prefix','forward-profile-v2','--mode-suffix','inline-index','--verify-profile-builds','--output',str(root/'summary.json')]
  x=subprocess.run(cmd,capture_output=True,text=True);assert (x.returncode==0)==(fault=='none'),(fault,x.stderr)
  results.append(dict(case=fault,exitCode=x.returncode,expectedResult=True))
(source/'forward-gap-negative.json').write_text(json.dumps(dict(passed=True,cases=results),indent=2)+'\n')
