#include <stdint.h>
static _Thread_local int candidate_autostart;
static void candidate_cancel(void);
static _Thread_local uint64_t candidate_counts[5];
#include <stdint.h>
#ifndef NEOCLR_GC_PROFILE
#error Experimental pacing requires profiling
#endif
#ifdef NEOCLR_WORKER_GC
#error Shared heaps are not qualified
#endif
#include "gate.h"
#ifdef NEOCLR_WORKER_GC
#error Live shared heaps are not admitted
#endif
static void shadow_stop(void);
#include "native-gc.h"
/* Private owner-thread state only. The marker receives its snapshot explicitly;
 * it must never discover an owner's state through its own TLS. Heap ownership
 * and allocation proofs remain in the existing owned_heap service. */
#if !defined(NEOCLR_LIVE_NO_STORE_CACHE) && !defined(NEOCLR_LIVE_LINEAR_STORE)
#ifndef NEOCLR_LIVE_STORE_RANGES
#define NEOCLR_LIVE_STORE_RANGES 4
#endif
#if NEOCLR_LIVE_STORE_RANGES < 1 || NEOCLR_LIVE_STORE_RANGES > 16
#error "store range count must be between 1 and 16"
#endif
#endif
#ifdef NEOCLR_LIVE_SPLIT_TLS
static _Thread_local int candidate_active;
static _Thread_local neoclr_aot_context *candidate_context;
static _Thread_local uint64_t live_store_counts[5];
#else
typedef struct live_owner_state {
    neoclr_aot_context *context;
    int active;
    uint64_t stores[5]; /* outside, inactive/new, guarded old, cancelled, rejected */
#ifndef NEOCLR_LIVE_SPLIT_STORE_TLS
    struct {
        uint64_t lookups[2];
#ifdef NEOCLR_LIVE_WALK_PROFILE
        uint64_t walks[3];
#endif
#if !defined(NEOCLR_LIVE_NO_STORE_CACHE) && !defined(NEOCLR_LIVE_LINEAR_STORE)
#ifdef NEOCLR_LIVE_HEADER_PROOF
        struct { const void *payload; uint64_t span, bytes, kind; } header;
#else
        const void *payload;
#endif
#if NEOCLR_LIVE_STORE_RANGES > 1
        const void *recent[NEOCLR_LIVE_STORE_RANGES-1];
        unsigned next;
#endif
#endif
    } store;
#endif
} live_owner_state;
static _Thread_local live_owner_state live_owner;
#define candidate_active (live_owner.active)
#define candidate_context (live_owner.context)
#define live_store_counts (live_owner.stores)
#endif

#include "native-gc.h"
#include "execution-state.h"
/* Private owned-thread fallback. Tokens enforce nesting without heap allocation. */
static _Thread_local neoclr_aot_context *native_scope_context;
static _Thread_local uint64_t native_scope_tokens[64], native_scope_serial;
static _Thread_local uint32_t native_scope_depth;
static _Thread_local uint64_t native_scope_counts[4];
#include <string.h>
#include <stdatomic.h>
#ifdef NEOCLR_GC_PROFILE
#include <stdlib.h>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#else
#include <time.h>
#endif
#endif
#ifdef NEOCLR_GC_PROFILE
static _Thread_local neoclr_gc_trigger_profile trigger_profile;
static int32_t collect_requested(neoclr_aot_context *, const neoclr_probe_frame *, unsigned);
#define GC_REQUEST(c, h, reason) collect_requested(c, h, reason)
#else
#define GC_REQUEST(c, h, reason) neoclr_gc_collect_v1(c, h)
#endif
neoclr_gc_trigger_profile neoclr_gc_trigger_profile_v1(void) {
#ifdef NEOCLR_GC_PROFILE
    return trigger_profile;
#else
    return (neoclr_gc_trigger_profile){0};
#endif
}
void neoclr_gc_trigger_profile_reset_v1(void) {
#ifdef NEOCLR_GC_PROFILE
    trigger_profile = (neoclr_gc_trigger_profile){0};
#endif
}
static _Thread_local neoclr_gc_profile profile;
static _Thread_local neoclr_gc_lookup_profile lookup_profile;
neoclr_gc_lookup_profile neoclr_gc_lookup_profile_v1(void) { return lookup_profile; }
void neoclr_gc_lookup_profile_reset_v1(void) {
#ifdef NEOCLR_GC_PROFILE
    lookup_profile = (neoclr_gc_lookup_profile){0};
#endif
}
#ifdef NEOCLR_GC_PROFILE
#define LOOKUP_COUNT(field) (lookup_profile.field++)
#else
#define LOOKUP_COUNT(field) ((void)0)
#endif
neoclr_gc_profile neoclr_gc_profile_v1(void) { return profile; }
void neoclr_gc_profile_reset_v1(void) {
#ifdef NEOCLR_GC_PROFILE
    profile = (neoclr_gc_profile){0};
#endif
}
/* Allocation descriptors live in the same bounded buffer as payloads. Free
 * blocks coalesce; payload addresses never move. Object words are conservative
 * candidates; text/byte payloads are atomic, String arrays have explicit slots. */
typedef struct { uint64_t span, bytes, kind, state; } block;
_Static_assert(sizeof(block) == 32, "private allocation descriptor");
enum { ALLOCATED = 1, MARKED = 2, SCANNED = 4 };
/* Resolve the related hot GC state through one thread-local object. Individual
 * counters retain their existing lifetimes; no whole-state reset or sharing is
 * introduced. Pacing still checks the current root chain and cleanup guard. */
#define gc_state (neoclr_execution_state_v1.gc)

/* One exclusive runtime-owned arena per native thread. No per-object metadata
 * or allocation; an address-ordered free list is maintained by allocation and sweep.
 * Free blocks reuse their otherwise-unused bytes word for the next offset + 1;
 * zero terminates the list. Live object descriptors and payloads are unchanged. */
enum { OWNED_BASE_CACHE_SIZE = 256 };
static _Thread_local struct {
    neoclr_aot_text_arena *arena;
    unsigned char *data;
    uint64_t capacity, used, free_head;
    const void *bases[OWNED_BASE_CACHE_SIZE];
#ifdef NEOCLR_LIVE_ALLOCATION_INDEX
    uint64_t *starts, *start_summary, start_words, start_summary_words;
#endif
} owned_heap;
#if defined(NEOCLR_LIVE_EXACT_INDEX) && !defined(NEOCLR_LIVE_ALLOCATION_INDEX)
#error Exact allocation lookup requires the owned allocation index
#endif
/* Experimental owner-local allocation-start index. Never read by the marker.
 * Entries describe allocated payload bases, not arbitrary observed addresses. */
#ifdef NEOCLR_LIVE_ALLOCATION_INDEX
static _Thread_local uint64_t owned_index_counts[3]; /* successful native allocations, current bytes, peak bytes */
void experiment_gc_index_counts(uint64_t *out) { memcpy(out,owned_index_counts,sizeof(owned_index_counts)); }
static void owned_index_destroy(void) {
    free(owned_heap.starts);
    owned_index_counts[1]=0;
}
#ifdef NEOCLR_SHADOW_TEST
static _Thread_local int owned_index_fail_next;
void experiment_gc_index_fail_next(void) { owned_index_fail_next=1; }
#endif
static int owned_index_create(uint64_t capacity) {
    uint64_t words=capacity/512+(capacity%512!=0);
    uint64_t groups=words/64+(words%64!=0);
    if (words+groups>SIZE_MAX/sizeof(uint64_t)) return 0;
    uint64_t *memory;
#ifdef NEOCLR_SHADOW_TEST
    if (owned_index_fail_next) { owned_index_fail_next=0; memory=NULL; }
    else
#endif
    memory=words?calloc((size_t)(words+groups),sizeof(uint64_t)):NULL;
    if (words && !memory) return 0;
    uint64_t bytes=(words+groups)*sizeof(uint64_t);
    owned_index_counts[0]+=memory!=NULL;
    owned_index_counts[1]=bytes;
    if (bytes>owned_index_counts[2]) owned_index_counts[2]=bytes;
    owned_heap.starts=memory;
    owned_heap.start_summary=memory?memory+words:NULL;
    owned_heap.start_words=words;
    owned_heap.start_summary_words=groups;
    return 1;
}
static __attribute__((unused)) void owned_index_reset(void) {
    if (owned_heap.starts)
        memset(owned_heap.starts,0,(size_t)(owned_heap.start_words+owned_heap.start_summary_words)*sizeof(uint64_t));
}
static void owned_index_set(uint64_t offset) {
    uint64_t bit=offset/8, word=bit/64;
    owned_heap.starts[word]|=UINT64_C(1)<<(bit%64);
    owned_heap.start_summary[word/64]|=UINT64_C(1)<<(word%64);
}
static void owned_index_clear(uint64_t offset) {
    uint64_t bit=offset/8, word=bit/64;
    owned_heap.starts[word]&=~(UINT64_C(1)<<(bit%64));
    if (!owned_heap.starts[word])
        owned_heap.start_summary[word/64]&=~(UINT64_C(1)<<(word%64));
}
/* Caller has checked current ownership and offset < used <= capacity. */
static uint64_t owned_index_before(uint64_t offset) {
    uint64_t bit=offset/8, word=bit/64;
    uint64_t bits=owned_heap.starts[word] & (UINT64_MAX>>(63-bit%64));
    if (!bits) {
        uint64_t group=word/64;
        bits=owned_heap.start_summary[group] & ((UINT64_C(1)<<(word%64))-1);
        while (!bits && group) bits=owned_heap.start_summary[--group];
        if (!bits) return UINT64_MAX;
        word=group*64+63-(uint64_t)__builtin_clzll(bits);
        bits=owned_heap.starts[word];
    }
    return (word*64+63-(uint64_t)__builtin_clzll(bits))*8;
}
#endif
#if defined(NEOCLR_LIVE_ALLOCATION_INDEX) && defined(NEOCLR_SHADOW_TEST)
/* Test-only observation of index contents; no store authorization. */
void *experiment_gc_index_before(const neoclr_aot_context *context, uint64_t offset) {
    if (!context || owned_heap.arena!=&context->text || offset>=owned_heap.used) return NULL;
    uint64_t at=owned_index_before(offset);
    return at==UINT64_MAX?NULL:owned_heap.data+at;
}
#endif

/* Positive entries only: insertion requires a newly allocated payload or an
 * exact-base proof from the checked walk. Collisions only cause misses. */
static unsigned base_slot(const void *value) {
    uintptr_t word = (uintptr_t)value >> 3;
    return (unsigned)((word ^ (word >> 6)) & (OWNED_BASE_CACHE_SIZE - 1));
}
static void remember_base(const void *value) {
    if (value) owned_heap.bases[base_slot(value)] = value;
}
static int known_base(const void *value) {
#ifdef NEOCLR_LIVE_EXACT_INDEX
    if (!value) return 1;
    uintptr_t address=(uintptr_t)value, base=(uintptr_t)owned_heap.data;
    if (address<base || address-base>=owned_heap.used || ((address-base)&7)) return 0;
    uint64_t bit=(address-base)/8;
    return !!(owned_heap.starts[bit/64] & (UINT64_C(1)<<(bit%64)));
#else
    return !value || owned_heap.bases[base_slot(value)] == value;
#endif
}
static int valid(const neoclr_aot_text_arena *a) {
    return a && (a != owned_heap.arena ||
        (a->data == owned_heap.data && a->capacity == owned_heap.capacity && a->used == owned_heap.used)) &&
        a->used <= a->capacity && !(a->used & 7) &&
        (!a->capacity || a->data) && !((uintptr_t)a->data & 7);
}
#ifdef NEOCLR_LIVE_INLINE_VALIDATION
static inline __attribute__((always_inline)) int block_valid(const neoclr_aot_text_arena *a, uint64_t at)
#else
static int block_valid(const neoclr_aot_text_arena *a, uint64_t at)
#endif
{
    if (a->used - at < sizeof(block)) return 0;
    const block *b = (const void *)(a->data + at);
    return b->span >= sizeof(block) + 8 && !(b->span & 7) && b->span <= a->used - at &&
        b->state <= 7 && (!b->state || ((b->state & ALLOCATED) &&
            b->bytes && b->bytes <= b->span - sizeof(block) &&
            b->kind >= NEOCLR_GC_TEXT && b->kind <= NEOCLR_GC_INTERN));
}
static int blocks_valid(const neoclr_aot_text_arena *a) {
    if (!valid(a)) return 0;
    uint64_t next_free = a == owned_heap.arena ? owned_heap.free_head : 0;
    for (uint64_t at = 0; at < a->used;) {
        if (!block_valid(a, at)) return 0;
        const block *b = (const void *)(a->data + at);
        if (a == owned_heap.arena && !b->state) {
            if (next_free != at + 1) return 0;
            next_free = b->bytes;
        }
        at += b->span;
    }
    return !next_free;
}
int32_t neoclr_gc_heap_acquire_v1(neoclr_aot_text_arena *arena) {
    if (owned_heap.arena || !valid(arena) || arena->used) return 3;
#ifdef NEOCLR_LIVE_ALLOCATION_INDEX
    if (!owned_index_create(arena->capacity)) return 3;
#endif
    owned_heap.arena = arena;
    owned_heap.data = arena->data;
    owned_heap.capacity = arena->capacity;
    owned_heap.used = owned_heap.free_head = 0;
    return 0;
}
int32_t neoclr_gc_heap_release_v1(neoclr_aot_text_arena *arena) {
    if (native_scope_depth) return 3;
    if (candidate_active) candidate_cancel();
    shadow_stop();
    if (!arena || owned_heap.arena != arena) return 3;
    int32_t status = blocks_valid(arena) ? 0 : 3;
    /* Always relinquish on the owning thread, including after host corruption.
     * Failure never repairs or mutates the caller's arena. */
#ifdef NEOCLR_LIVE_ALLOCATION_INDEX
    owned_index_destroy();
#endif
    memset(&owned_heap, 0, sizeof(owned_heap));
    return status;
}
typedef struct host_root {
    neoclr_aot_context *context;
    void *value, *owner;
    int conditional, expired;
    uint64_t handle;
    struct host_root *previous, *next;
} host_root;
static _Thread_local host_root host_roots[NEOCLR_GC_HOST_ROOT_LIMIT];
static _Thread_local host_root *host_head;
static _Atomic uint64_t next_host_handle = 1;
/* Validate every span while finding exact bases. Never publish a result or
 * stop validation early: a matching prefix cannot hide a corrupt trailing block.
 * Null values retain their existing admitted-root meaning. */
static int validated_bases(const neoclr_aot_text_arena *arena, const void *value, const void *owner) {
    LOOKUP_COUNT(base_calls);
    if (!valid(arena)) return 0;
    int owned = arena == owned_heap.arena;
    if (owned && known_base(value) && known_base(owner)) {
        LOOKUP_COUNT(base_cache_hits);
        return 1;
    }
    LOOKUP_COUNT(base_walks);
    int found_value = !value, found_owner = !owner;
    uint64_t at = 0;
    while (at < arena->used && !(found_value && found_owner)) {
        LOOKUP_COUNT(base_spans);
        if (!block_valid(arena, at)) return 0;
        const block *b = (const void *)(arena->data + at);
        if (b->state & ALLOCATED) {
            found_value |= value == (const void *)(b + 1);
            found_owner |= owner == (const void *)(b + 1);
        }
        at += b->span;
    }
    /* Once both bases match, the remaining walk only needs integrity checks. */
    for (; at < arena->used;) {
        LOOKUP_COUNT(base_spans);
        if (!block_valid(arena, at)) return 0;
        const block *b = (const void *)(arena->data + at);
        at += b->span;
    }
    if (owned && found_value && found_owner) {
        remember_base(value);
        remember_base(owner);
    }
    return found_value && found_owner;
}
int32_t neoclr_gc_allocation_info_v1(neoclr_aot_context *context, const void *value,
    uint64_t *bytes, uint32_t *kind) {
    if (!context || !value || !bytes || !kind || !validated_bases(&context->text, value, NULL)) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    const block *b = (const block *)value - 1;
    *bytes = b->bytes;
    *kind = (uint32_t)b->kind;
    return 0;
}
static _Thread_local neoclr_gc_resource *resource_head;
static void resource_cleanup(neoclr_gc_resource **link) {
    neoclr_gc_resource *resource = *link;
    void *state = resource->state;
    void (*cleanup)(void *) = resource->cleanup;
    *link = resource->next;
    *resource = (neoclr_gc_resource){0};
    gc_state.cleanup_active = 1;
    cleanup(state);
    gc_state.cleanup_active = 0;
}
int32_t neoclr_gc_resource_attach_v1(neoclr_aot_context *context, void *owner,
    neoclr_gc_resource *resource, void *state, void (*cleanup)(void *)) {
    if (gc_state.cleanup_active || !context || !owner || !resource || !cleanup ||
        !validated_bases(&context->text, owner, NULL)) return 3;
    unsigned count = 0;
    for (neoclr_gc_resource *r = resource_head; r; r = r->next) {
        if (r == resource) return 3;
        count += r->context == context;
    }
    if (resource->context || resource->owner || resource->state || resource->cleanup || resource->next)
        return 3;
    if (count >= 1024) return NEOCLR_AOT_FAULT_NATIVE_MEMORY_LIMIT;
    *resource = (neoclr_gc_resource){context, owner, state, cleanup, resource_head};
    resource_head = resource;
    return 0;
}
int32_t neoclr_gc_resource_release_v1(neoclr_aot_context *context, neoclr_gc_resource *resource) {
    if (gc_state.cleanup_active || !context || !resource) return 3;
    for (neoclr_gc_resource **link = &resource_head; *link; link = &(*link)->next)
        if (*link == resource && (*link)->context == context) {
            resource_cleanup(link);
            return 0;
        }
    return 3;
}
static host_root *find_host_root(neoclr_aot_context *context, uint64_t handle) {
    if (!context || !handle) return NULL;
    for (host_root *root = host_head; root; root = root->next)
        if (root->context == context && root->handle == handle) return root;
    return NULL;
}
static int32_t host_root_create(neoclr_aot_context *context, void *owner, void *value,
    int conditional, uint64_t *output) {
    if (!context || !output || (conditional && !owner) ||
        !validated_bases(&context->text, value, conditional ? owner : NULL))
        return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    host_root *available = NULL;
    for (uint32_t i = 0; i < NEOCLR_GC_HOST_ROOT_LIMIT; i++)
        if (!host_roots[i].context) { available = &host_roots[i]; break; }
    if (!available) return NEOCLR_AOT_FAULT_NATIVE_MEMORY_LIMIT;
    uint64_t handle = atomic_load_explicit(&next_host_handle, memory_order_relaxed);
    do {
        if (handle == UINT64_MAX) return NEOCLR_AOT_FAULT_NATIVE_MEMORY_LIMIT;
    } while (!atomic_compare_exchange_weak_explicit(&next_host_handle, &handle, handle + 1,
                memory_order_relaxed, memory_order_relaxed));
    *available = (host_root){.context = context, .value = value, .owner = owner,
        .conditional = conditional, .handle = handle, .next = host_head};
    if (host_head) host_head->previous = available;
    host_head = available;
    *output = handle;
    return 0;
}
int32_t neoclr_gc_host_root_create_v1(neoclr_aot_context *context, void *value, uint64_t *output) {
    return host_root_create(context, NULL, value, 0, output);
}
int32_t neoclr_gc_host_root_create_owned_v1(neoclr_aot_context *context, void *owner,
    void *value, uint64_t *output) {
    return host_root_create(context, owner, value, 1, output);
}
int32_t neoclr_gc_host_root_replace_v1(neoclr_aot_context *context, uint64_t handle, void *value) {
    host_root *root = find_host_root(context, handle);
    if (!root || root->expired || !validated_bases(&context->text, value, NULL)) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    root->value = value;
    return 0;
}
int32_t neoclr_gc_host_root_read_v1(neoclr_aot_context *context, uint64_t handle, void **output) {
    host_root *root = find_host_root(context, handle);
    if (!root || root->expired || !output) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    *output = root->value;
    return 0;
}
int32_t neoclr_gc_host_root_release_v1(neoclr_aot_context *context, uint64_t handle) {
    host_root *root = find_host_root(context, handle);
    if (!root) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    if (root->previous) root->previous->next = root->next;
    else host_head = root->next;
    if (root->next) root->next->previous = root->previous;
    *root = (host_root){0};
    return 0;
}
static int32_t callback_read(neoclr_aot_context *context, uint64_t handle, void **output) {
    host_root *root = find_host_root(context, handle);
    if (!root || root->conditional || !output || !root->value || context->fault.code ||
        !validated_bases(&context->text, root->value, NULL)) return 3;
    const block *allocation = (const block *)root->value - 1;
    uint64_t kind;
    if (allocation->kind != NEOCLR_GC_OBJECT || allocation->bytes != 24) return 3;
    memcpy(&kind, root->value, 8);
    if (kind != UINT32_MAX) return 3;
    *output = root->value;
    return 0;
}
int32_t neoclr_gc_callback_read_v1(neoclr_aot_context *context, uint64_t handle, void **output) {
    for (const neoclr_probe_frame *f = neoclr_root_probe_head_v1(); f; f = f->previous)
        if (f->context == context) return 3;
    return callback_read(context, handle, output);
}
int32_t neoclr_gc_callback_read_suspended_v1(neoclr_aot_context *context, uint64_t handle,
    void **output, const neoclr_probe_frame *boundary) {
    if (!boundary || neoclr_root_probe_head_v1() != boundary || boundary->context != context) return 3;
    return callback_read(context, handle, output);
}
int32_t neoclr_gc_roots_park_owned_v1(neoclr_aot_context *context, void *owner,
    neoclr_parked_roots *record) {
    if (!context || !owner || !record || !validated_bases(&context->text, owner, NULL) || record->head || record->next ||
        record->owner_context || record->owner || record->expired) return 3;
    for (const neoclr_parked_roots *p = neoclr_roots_parked_v1(); p; p = p->next)
        if (p == record) return 3;
    for (const neoclr_probe_frame *f = neoclr_root_probe_head_v1(); f; f = f->previous)
        if (f->context != context) return 3;
    neoclr_roots_park_v1(record);
    record->owner_context = context;
    record->owner = owner;
    return 0;
}
int32_t neoclr_gc_complete_invocation_v1(neoclr_aot_context *context) {
    if (!context || !blocks_valid(&context->text)) return 3;
    for (const neoclr_probe_frame *frame = neoclr_root_probe_head_v1(); frame; frame = frame->previous)
        if (frame->context == context) return 3;
    if (candidate_active) candidate_cancel();
    /* Removing pool ownership never frees an exposed String. Any host/managed
     * roots still retain the original value normally until their own release. */
    for (uint64_t at = 0; at < context->text.used;) {
        block *b = (void *)(context->text.data + at);
        if ((b->state & ALLOCATED) && b->kind == NEOCLR_GC_INTERN)
            b->kind = NEOCLR_GC_BYTES;
        at += b->span;
    }
    context->static_storage = NULL;
    return 0;
}

int32_t neoclr_gc_entry_check_v1(neoclr_aot_context *context) {
    for (neoclr_gc_resource *r = resource_head; r; r = r->next)
        if (r->context == context) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    if (!context) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    for (const neoclr_parked_roots *p = neoclr_roots_parked_v1(); p; p = p->next) {
        if (p->owner_context == context) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
        for (const neoclr_probe_frame *f = p->head; f; f = f->previous)
            if (f->context == context) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    }

    for (host_root *root = host_head; root; root = root->next)
        if (root->context == context) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    for (const neoclr_probe_frame *frame = neoclr_root_probe_head_v1(); frame; frame = frame->previous)
        if (frame->context == context) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    if (candidate_active) candidate_cancel(); /* admitted entry resets the arena */
    return 0;
}
int32_t neoclr_gc_owned_roots_check_v1(neoclr_aot_context *context, const uint64_t *handles, uint32_t count) {
    for (neoclr_gc_resource *r = resource_head; r; r = r->next)
        if (r->context == context) return 3;
    if (!context || count > NEOCLR_GC_HOST_ROOT_LIMIT || (count && !handles)) return 3;
    for (const neoclr_parked_roots *p = neoclr_roots_parked_v1(); p; p = p->next) {
        if (p->owner_context == context) return 3;
        for (const neoclr_probe_frame *f = p->head; f; f = f->previous)
            if (f->context == context) return 3;
    }
    for (const neoclr_probe_frame *f = neoclr_root_probe_head_v1(); f; f = f->previous)
        if (f->context == context) return 3;
    for (uint32_t i = 0; i < count; i++) {
        if (!find_host_root(context, handles[i])) return 3;
        for (uint32_t j = 0; j < i; j++) if (handles[j] == handles[i]) return 3;
    }
    uint32_t actual = 0;
    for (host_root *r = host_head; r; r = r->next) actual += r->context == context;
    return actual == count ? 0 : 3;
}
int32_t neoclr_gc_allocate_v1(neoclr_aot_text_arena *a, uint64_t bytes,
                             uint32_t kind, void **output) {
    if (!output || !valid(a) || !bytes || kind < NEOCLR_GC_TEXT || kind > NEOCLR_GC_INTERN)
        return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    int oversized = bytes > UINT64_MAX - sizeof(block) - 7;
    uint64_t needed = oversized ? UINT64_MAX : sizeof(block) + ((bytes + 7) & ~UINT64_C(7));
    block *chosen = NULL;
    int owned = a == owned_heap.arena;
    uint64_t *free_link = &owned_heap.free_head;
    /* The owned list preserves first-fit address order while skipping live blocks.
     * Validate visited descriptors/links before mutation; collection and release
     * reconcile the complete list against the authoritative block walk. */
    if (owned) {
        while (*free_link) {
            uint64_t at = *free_link - 1;
            if (at >= a->used || (at & 7) || !block_valid(a, at)) return 3;
            block *b = (void *)(a->data + at);
            uint64_t next = b->bytes;
            if (b->state || (next && ((next - 1) < at + b->span ||
                (next - 1) >= a->used || ((next - 1) & 7)))) return 3;
            if (b->span >= needed) { chosen = b; break; }
            free_link = &b->bytes;
        }
    } else {
        /* External arenas still validate every descriptor, even after a fit. */
        for (uint64_t at = 0; at < a->used;) {
            if (!block_valid(a, at)) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
            block *b = (void *)(a->data + at);
            if (!chosen && !b->state && b->span >= needed) chosen = b;
            at += b->span;
        }
    }
    if (oversized) return NEOCLR_AOT_FAULT_NATIVE_MEMORY_LIMIT;
    if (chosen) {
        uint64_t next = owned ? chosen->bytes : 0;
        if (chosen->span - needed >= sizeof(block) + 8) {
            block *rest = (void *)((unsigned char *)chosen + needed);
            *rest = (block){chosen->span - needed, next, 0, 0};
            chosen->span = needed;
            if (owned) *free_link = (unsigned char *)rest - a->data + 1;
        } else if (owned) *free_link = next;
    } else {
        if (needed > a->capacity - a->used) return NEOCLR_AOT_FAULT_NATIVE_MEMORY_LIMIT;
        chosen = (void *)(a->data + a->used);
        chosen->span = needed;
        a->used += needed;
    }
    if (owned) {
        owned_heap.used = a->used;
    }
    chosen->bytes = bytes; chosen->kind = kind; chosen->state = ALLOCATED;
    memset(chosen + 1, 0, (size_t)(chosen->span - sizeof(block)));
    if (owned) remember_base(chosen + 1);
#ifdef NEOCLR_LIVE_ALLOCATION_INDEX
    if (owned) owned_index_set((unsigned char *)(chosen+1)-a->data);
#endif
    *output = chosen + 1;
    gc_state.statistics.allocations++;
#ifdef NEOCLR_GC_PROFILE
    profile.allocated_bytes += bytes;
    if (a->used > profile.peak_arena_used) profile.peak_arena_used = a->used;
#endif
    return 0;
}
/* Opt-in admission for callers that have published every live reference.
 * Keep the arena-only allocator non-collecting: native helpers may retain
 * unregistered intermediates between its calls. Never retry a whole operation. */
int32_t neoclr_gc_allocate_rooted_values_v1(neoclr_aot_context *context,
    const neoclr_probe_frame *boundary, const void *const *values, uint32_t count,
    uint64_t bytes, uint32_t kind, void **output) {
    if (count > 16 || (count && !values) || !context || gc_state.cleanup_active || boundary != neoclr_root_probe_head_v1() ||
        (boundary && boundary->context != context)) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    int32_t status = neoclr_gc_allocate_v1(&context->text, bytes, kind, output);
    if (status != NEOCLR_AOT_FAULT_NATIVE_MEMORY_LIMIT) return status;
    /* An impossible single block cannot benefit from collection. Arithmetic
     * mirrors the allocator, including descriptor and alignment overhead. */
    if (bytes > UINT64_MAX - sizeof(block) - 7 ||
        sizeof(block) + ((bytes + 7) & ~UINT64_C(7)) > context->text.capacity) return status;
    /* Private helper roots are visible only to this collection, not logical stack
     * tracing. Values include every borrowed input and intermediate needed after
     * allocation; their slots remain live on this synchronous C call's stack. */
    neoclr_probe_storage slots[16];
    for (uint32_t i = 0; i < count; i++) slots[i] = (neoclr_probe_storage){&values[i], 8, 0};
    neoclr_probe_frame helper = {.previous = (neoclr_probe_frame *)boundary,
        .context = context, .storage = slots, .storage_count = count};
    status = GC_REQUEST(context, count ? &helper : boundary, NEOCLR_GC_TRIGGER_PRESSURE);
    if (status) return status;
    return neoclr_gc_allocate_v1(&context->text, bytes, kind, output);
}

int32_t neoclr_gc_allocate_rooted_v1(neoclr_aot_context *context, const neoclr_probe_frame *boundary,
    uint64_t bytes, uint32_t kind, void **output) {
    return neoclr_gc_allocate_rooted_values_v1(context, boundary, NULL, 0, bytes, kind, output);
}

/* Sparse byte-range index rebuilt from validated spans for each collection.
 * Small heaps use 2 KiB; dense heaps temporarily use another 32 KiB.
 * No allocation, retained addresses or heap ABI change.
 * A bucket points to the block containing its first byte, including free spans.
 * Interior/tagged candidates still require the exact allocated payload bounds. */
enum { INTERN_SEED_LIMIT = 32 };
typedef struct {
    block **start, **interns;
    unsigned capacity, shift, intern_count;
    uint64_t blocks, atomic_marks;
    int reset_required;
} block_index;
/* Record candidates without mutating heap state. Overflow retains the original
 * full seed walk; these pointers live only through this synchronous collection. */
static void index_seed(block_index *index, block *b) {
    index->reset_required |= b->state > ALLOCATED;
    if (b->state && b->kind == NEOCLR_GC_INTERN && index->intern_count <= INTERN_SEED_LIMIT) {
        if (index->intern_count < INTERN_SEED_LIMIT)
            index->interns[index->intern_count] = b;
        index->intern_count++;
    }
}
static int build_index(neoclr_aot_text_arena *a, block_index *index) {
    if (!valid(a)) return 0;
    uint64_t blocks = 0;
    index->shift = 6;
    while (a->used && ((a->used - 1) >> index->shift) >= index->capacity) index->shift++;
    unsigned bucket = 0;
    uint64_t next_free = a == owned_heap.arena ? owned_heap.free_head : 0;
    for (uint64_t at = 0; at < a->used;) {
        LOOKUP_COUNT(index_build_spans);
        if (!block_valid(a, at)) return 0;
        block *b = (void *)(a->data + at);
        if (a == owned_heap.arena && !b->state) {
            if (next_free != at + 1) return 0;
            next_free = b->bytes;
        }
        blocks++;
        index_seed(index, b);
        uint64_t end = at + b->span;
        while (bucket < index->capacity && ((uint64_t)bucket << index->shift) < end)
            index->start[bucket++] = b;
        at = end;
    }
    index->blocks = blocks;
    return !next_free;
}
/* Index lookup preserves exact payload-base validation for host owners/values.
 * Only use after blocks_valid and before sweep changes block spans. */
static block *indexed_block(neoclr_aot_text_arena *a, const block_index *index, uint64_t word) {
    LOOKUP_COUNT(index_queries);
    uintptr_t base = (uintptr_t)a->data;
    if (word < base || word - base >= a->used) {
        LOOKUP_COUNT(index_outside);
        return NULL;
    }
    uint64_t offset = word - base;
    block *first = index->start[offset >> index->shift];
    for (uint64_t at = (uintptr_t)first - base; at < a->used;) {
        LOOKUP_COUNT(index_probes);
        block *b = (void *)(a->data + at);
        if (offset < at + b->span) return b;
        at += b->span;
    }
    return NULL;
}
static int indexed_live_base(neoclr_aot_text_arena *a, const block_index *index, const void *value) {
    if (!value) return 1;
    block *b = indexed_block(a, index, (uintptr_t)value);
    return b && (b->state & ALLOCATED) && value == (void *)(b + 1);
}
static void mark(neoclr_aot_text_arena *a, block_index *index, uint64_t word, block **pending) {
    LOOKUP_COUNT(mark_candidates);
    block *b = indexed_block(a, index, word);
#ifdef NEOCLR_GC_PROFILE
    if (b && b->state && word >= (uintptr_t)(b + 1) &&
        word - (uintptr_t)(b + 1) < b->bytes)
        LOOKUP_COUNT(payload_matches);
#endif
    if (b && b->state && word >= (uintptr_t)(b + 1) &&
        word - (uintptr_t)(b + 1) < b->bytes && !(b->state & MARKED)) {
        LOOKUP_COUNT(newly_marked);
        /* Atomic payloads have no children: retain them without worklist traffic.
         * Count newly marked leaves so dependent/parked owners discovered late
         * still drive the fixed point even when no tracing work was enqueued. */
        if (b->kind == NEOCLR_GC_TEXT || b->kind == NEOCLR_GC_BYTES) {
            b->state = ALLOCATED | MARKED | SCANNED;
            index->atomic_marks++;
        } else {
            b->state = (uint64_t)(uintptr_t)*pending | ALLOCATED | MARKED;
            *pending = b;
        }
    }
}
static void mark_slots(neoclr_aot_text_arena *a, block_index *index, const neoclr_probe_storage *slots, uint32_t count, block **pending) {
    for (uint32_t i = 0; i < count; i++) {
        if (slots[i].read_bytes != 8) continue; /* 32-bit discriminators are not pointers. */
        uint64_t word; memcpy(&word, slots[i].address, 8); mark(a, index, word, pending);
    }
}
static void mark_frames(neoclr_aot_context *context, block_index *index,
    const neoclr_probe_frame *head, block **pending) {
    for (const neoclr_probe_frame *f = head; f; f = f->previous) {
        if (f->context != context) continue;
        mark_slots(&context->text, index, f->storage, f->storage_count, pending);
        mark_slots(&context->text, index, f->transient, f->transient_count, pending);
        for (uint32_t i = 0; i < f->lane_count; i++)
            mark(&context->text, index, f->lanes[i], pending);
    }
}
#ifdef NEOCLR_WORKER_GC
_Thread_local neoclr_gc_worker_collector neoclr_gc_worker_collect_hook;
static _Thread_local const neoclr_gc_participant *worker_participants;
static _Thread_local unsigned worker_participant_count;
int32_t neoclr_gc_collect_participants_v1(neoclr_aot_context *context, const neoclr_probe_frame *head,
    const neoclr_gc_participant *participants, unsigned count) {
    if (worker_participants || !participants || count > 17) return 3;
    worker_participants = participants; worker_participant_count = count;
    int32_t status = neoclr_gc_collect_conditional_v1(context, head, NULL, 0);
    worker_participants = NULL; worker_participant_count = 0;
    return status;
}
int32_t neoclr_gc_worker_roots_check_v1(neoclr_aot_context *context, uint64_t handle) {
    unsigned found = 0;
    if (neoclr_roots_parked_v1()) return 3;
    for (neoclr_gc_resource *r = resource_head; r; r = r->next) if (r->context == context) return 3;
    for (host_root *r = host_head; r; r = r->next) if (r->context == context) {
        if (r->handle != handle || r->conditional) return 3;
        found++;
    }
    return found == 1 ? 0 : 3;
}
#endif
#ifdef NEOCLR_GC_PROFILE
static int32_t collect_dispatch(neoclr_aot_context *context, const neoclr_probe_frame *head) {
#else
int32_t neoclr_gc_collect_v1(neoclr_aot_context *context, const neoclr_probe_frame *head) {
#endif
#ifdef NEOCLR_WORKER_GC
    if (neoclr_gc_worker_collect_hook) return neoclr_gc_worker_collect_hook(context, head);
#endif
    return neoclr_gc_collect_conditional_v1(context, head, NULL, 0);
}
#ifdef NEOCLR_GC_PROFILE
static int32_t collect_requested(neoclr_aot_context *context, const neoclr_probe_frame *head, unsigned reason) {
    trigger_profile.requests[reason]++;
    int32_t status = collect_dispatch(context, head);
    trigger_profile.failures[reason] += status != 0;
    return status;
}
int32_t neoclr_gc_collect_v1(neoclr_aot_context *context, const neoclr_probe_frame *head) {
    return collect_requested(context, head, NEOCLR_GC_TRIGGER_DIRECT);
}
#endif
/* Diagnostic-only immutable capture. Included into a generated native-gc.c.
 * The worker owns copies, never mutator TLS, frame addresses or live payloads.
 * Synchronous GC remains solely responsible for cleanup and reclamation. */
#include <pthread.h>
#include <stdlib.h>
#include <time.h>
typedef struct { uint64_t owner, value; } shadow_edge;
typedef struct {
    uintptr_t base;
    unsigned char *data, *marked, *expected;
    uint64_t used, *offsets, *pending;
    block *headers;
    mutation_gate *gate;
    uint64_t epoch, payload_read, barrier_words;
#ifdef NEOCLR_LIVE_BATCH
    unsigned read_held, read_bytes, read_calls;
    uint64_t read_acquisitions, max_read_bytes, max_read_calls;
    uint64_t hold_start, hold_max, hold_total;
#endif
#ifdef NEOCLR_SHADOW_SPARSE_INDEX
    size_t *starts;
    unsigned index_capacity, index_shift;
#endif
    size_t count, pending_count, edge_count, edge_capacity;
    shadow_edge *edges;
    int reference_valid, valid;
    uint64_t cpu_ns;
} shadow_snapshot;
typedef struct {
    pthread_t thread;
    pthread_mutex_t mutex;
    pthread_cond_t condition;
    shadow_snapshot *job;
    int ready, done, stop;
} shadow_worker;
#ifdef NEOCLR_SHADOW_TEST
#include <sched.h>
static _Atomic int shadow_test_gate;
void experiment_gc_shadow_gate(int closed) { atomic_store(&shadow_test_gate, closed); }
#endif
static _Thread_local shadow_worker *shadow_owner;
static _Thread_local uint64_t live_counts[5], live_batch_counts[5], live_time_counts[5];
static _Thread_local uint64_t shadow_stats[5]; /* compared, copied bytes, capture ns, worker CPU ns, invalid */
static uint64_t shadow_clock(clockid_t clock) {
    struct timespec t;
    if (clock_gettime(clock, &t)) abort();
    return (uint64_t)t.tv_sec * UINT64_C(1000000000) + t.tv_nsec;
}
static void *shadow_alloc(size_t count, size_t bytes) {
    if (bytes && count > SIZE_MAX / bytes) abort();
    void *value = calloc(count ? count : 1, bytes);
    if (!value) abort();
    return value;
}
static size_t shadow_find(const shadow_snapshot *s, uint64_t word) {
    if (word < s->base || word - s->base >= s->used) return SIZE_MAX;
    uint64_t offset = word - s->base;
#ifdef NEOCLR_SHADOW_SPARSE_INDEX
    size_t i = s->starts[offset >> s->index_shift];
    while (i + 1 < s->count && s->offsets[i + 1] <= offset) i++;
#else
    size_t low = 0, high = s->count;
    while (low < high) {
        size_t mid = low + (high - low) / 2;
        if (s->offsets[mid] <= offset) low = mid + 1;
        else high = mid;
    }
    if (!low) return SIZE_MAX;
    size_t i = low - 1;
#endif
    const block *b = &s->headers[i];
    uint64_t payload = s->offsets[i] + sizeof(block);
    return (b->state & ALLOCATED) && offset >= payload && offset - payload < b->bytes ? i : SIZE_MAX;
}
static void shadow_mark(shadow_snapshot *s, uint64_t word) {
    size_t i = shadow_find(s, word);
    if (i != SIZE_MAX && !s->marked[i]) {
        s->marked[i] = 1;
        s->pending[s->pending_count++] = i;
    }
}
static void shadow_edge_add(shadow_snapshot *s, uint64_t owner, uint64_t value) {
    if (s->edge_count == s->edge_capacity) {
        size_t next = s->edge_capacity ? s->edge_capacity * 2 : 64;
        if (next < s->edge_capacity || next > SIZE_MAX / sizeof(shadow_edge)) abort();
        void *edges = realloc(s->edges, next * sizeof(shadow_edge));
        if (!edges) abort();
        s->edges = edges;
        s->edge_capacity = next;
    }
    s->edges[s->edge_count++] = (shadow_edge){owner, value};
}
static void shadow_slots(shadow_snapshot *s, uint64_t owner,
    const neoclr_probe_storage *slots, uint32_t count) {
    for (uint32_t i = 0; i < count; i++) {
        if (slots[i].read_bytes != 8) continue;
        uint64_t value;
        memcpy(&value, slots[i].address, 8);
        shadow_edge_add(s, owner, value);
    }
}
#ifdef NEOCLR_LIVE_BATCH
/* One heap gate, held for bounded work. No callbacks or allocations here. */
static void live_batch_leave(shadow_snapshot *s) {
    if (!s->read_held) return;
    if (s->read_bytes > s->max_read_bytes) s->max_read_bytes=s->read_bytes;
    if (s->read_calls > s->max_read_calls) s->max_read_calls=s->read_calls;
#ifdef NEOCLR_LIVE_GATE_PROFILE
    uint64_t elapsed=shadow_clock(CLOCK_MONOTONIC)-s->hold_start;
    s->hold_total+=elapsed;
    if (elapsed>s->hold_max) s->hold_max=elapsed;
#endif
    s->read_held=0;
    if (pthread_mutex_unlock(&s->gate->mutex)) abort();
}
static int live_batch_enter(shadow_snapshot *s) {
    if (s->read_held) return 1;
    if (pthread_mutex_lock(&s->gate->mutex)) abort();
    s->read_held=1;
    s->read_bytes=s->read_calls=0;
    s->read_acquisitions++;
#ifdef NEOCLR_LIVE_GATE_PROFILE
    s->hold_start=shadow_clock(CLOCK_MONOTONIC);
#endif
    if (!s->gate->active || s->gate->epoch!=s->epoch || s->gate->cancelled) {
        live_batch_leave(s);
        return 0;
    }
    return 1;
}
static int live_batch_drain(shadow_snapshot *s) {
    uint64_t words[GATE_WORDS]; size_t count;
    if (gate_drain(s->gate,s->epoch,words,GATE_WORDS,&count)) return 0;
    s->barrier_words+=count;
    for (size_t i=0;i<count;i++) shadow_mark(s,words[i]);
    return 1;
}
#endif

/* Generated scanner below shares the production payload semantics. */
static int shadow_scan(shadow_snapshot *s, const block *b);
static void *shadow_run(void *argument) {
    shadow_worker *w = argument;
    if (pthread_mutex_lock(&w->mutex)) abort();
    for (;;) {
        while (!w->ready && !w->stop)
            if (pthread_cond_wait(&w->condition, &w->mutex)) abort();
        if (w->stop) break;
        shadow_snapshot *s = w->job;
        w->ready = 0;
        if (pthread_mutex_unlock(&w->mutex)) abort();
        #ifdef NEOCLR_SHADOW_TEST
        while (atomic_load(&shadow_test_gate)) sched_yield();
#endif
        uint64_t start = shadow_clock(CLOCK_THREAD_CPUTIME_ID);
        /* Validity persists across worker passes. */
        for (;;) {
            while (s->pending_count) {
#ifdef NEOCLR_LIVE_BATCH
                unsigned objects=0;
                while (s->pending_count && objects++<32) {
#endif
                    size_t i = s->pending[--s->pending_count];
                    if (!shadow_scan(s, &s->headers[i])) {
                        s->valid = 0;
                        break;
                    }
#ifdef NEOCLR_LIVE_BATCH
                }
                live_batch_leave(s);
                if (!s->valid || !live_batch_drain(s)) { s->valid=0; break; }
#endif
            }
            if (!s->valid) break;
            for (size_t i = 0; i < s->edge_count; i++) {
                size_t owner = shadow_find(s, s->edges[i].owner);
                if (owner != SIZE_MAX && s->marked[owner]) shadow_mark(s, s->edges[i].value);
            }
            uint64_t words[GATE_WORDS]; size_t count;
            if (gate_drain(s->gate,s->epoch,words,GATE_WORDS,&count)) { s->valid=0; break; }
            s->barrier_words += count;
            for (size_t i=0;i<count;i++) shadow_mark(s,words[i]);
            if (!s->pending_count) break;
        }
        s->cpu_ns += shadow_clock(CLOCK_THREAD_CPUTIME_ID) - start;
        if (pthread_mutex_lock(&w->mutex)) abort();
        w->done = 1;
        if (pthread_cond_broadcast(&w->condition)) abort();
    }
    if (pthread_mutex_unlock(&w->mutex)) abort();
    return NULL;
}
static void shadow_drain(void) {
    shadow_worker *w = shadow_owner;
    if (!w || !w->job) return;
    if (pthread_mutex_lock(&w->mutex)) abort();
    while (!w->done)
        if (pthread_cond_wait(&w->condition, &w->mutex)) abort();
    shadow_snapshot *s = w->job;
    w->job = NULL;
    if (pthread_mutex_unlock(&w->mutex)) abort();
    if (s->reference_valid) {
        if (!s->valid || memcmp(s->marked, s->expected, s->count)) abort();
        shadow_stats[0]++;
    } else shadow_stats[4]++;
    shadow_stats[3] += s->cpu_ns;
#ifdef NEOCLR_SHADOW_SPARSE_INDEX
    free(s->starts);
#endif
    gate_stop(s->gate);
    if (gate_destroy(s->gate)) abort();
#ifdef NEOCLR_LIVE_BATCH
    live_batch_counts[0]+=s->read_acquisitions;
    if (s->max_read_bytes>live_batch_counts[1]) live_batch_counts[1]=s->max_read_bytes;
    if (s->max_read_calls>live_batch_counts[2]) live_batch_counts[2]=s->max_read_calls;
    if (s->hold_max>live_batch_counts[3]) live_batch_counts[3]=s->hold_max;
    live_batch_counts[4]+=s->hold_total;
#endif
    live_time_counts[0] += s->cpu_ns;
    live_counts[0] += s->count * sizeof(block);
    live_counts[1] += s->payload_read;
    live_counts[2] += s->barrier_words;
    live_counts[3] += !!s->valid;
    live_counts[4] += !s->valid;
    free(s->gate); free(s->headers);
    free(s->edges); free(s->pending); free(s->offsets);
    free(s->expected); free(s->marked); free(s->data); free(s);
}
static void shadow_stop(void) {
    shadow_worker *w = shadow_owner;
    if (!w) return;
    shadow_drain();
    if (pthread_mutex_lock(&w->mutex)) abort();
    w->stop = 1;
    if (pthread_cond_broadcast(&w->condition) || pthread_mutex_unlock(&w->mutex)) abort();
    if (pthread_join(w->thread, NULL)) abort();
    if (pthread_cond_destroy(&w->condition) || pthread_mutex_destroy(&w->mutex)) abort();
    free(w);
    shadow_owner = NULL;
}
void experiment_gc_shadow(uint64_t *output) {
    if (candidate_active) abort();
    shadow_stop();
    memcpy(output, shadow_stats, sizeof(shadow_stats));
}
static void shadow_begin(neoclr_aot_context *context,
    const neoclr_gc_conditional_root *conditional, uint32_t count) {
    shadow_drain();
    uint64_t start = shadow_clock(CLOCK_MONOTONIC);
    shadow_snapshot *s = shadow_alloc(1, sizeof(*s));
    s->valid = 1;
    s->base = (uintptr_t)context->text.data;
    s->used = context->text.used;
    s->gate = shadow_alloc(1, sizeof(*s->gate));
    if (gate_init(s->gate) || gate_begin(s->gate, &s->epoch)) abort();
    for (uint64_t at = 0; at < s->used;) {
        const block *b = (const void *)(context->text.data + at);
        s->count++;
        at += b->span;
    }
    s->headers = shadow_alloc(s->count, sizeof(block));
    s->offsets = shadow_alloc(s->count, sizeof(uint64_t));
    s->pending = shadow_alloc(s->count, sizeof(uint64_t));
    s->marked = shadow_alloc(s->count, 1);
    s->expected = shadow_alloc(s->count, 1);
    size_t n = 0;
    for (uint64_t at = 0; at < s->used;) {
        const block *b = (const void *)(context->text.data + at);
        s->headers[n] = *b;
        s->offsets[n++] = at;
        at += b->span;
    }
#ifdef NEOCLR_SHADOW_SPARSE_INDEX
    /* Same population threshold and minimum bucket width as the live collector.
     * Buckets hold detached block ordinals, never addresses in the live arena. */
    s->index_capacity = s->count > 2048 ? 4096 : 256;
    s->index_shift = 6;
    while (s->used && ((s->used - 1) >> s->index_shift) >= s->index_capacity)
        s->index_shift++;
    s->starts = shadow_alloc(s->index_capacity, sizeof(size_t));
    unsigned bucket = 0;
    for (size_t i = 0; i < s->count; i++) {
        const block *b = &s->headers[i];
        uint64_t end = s->offsets[i] + b->span;
        while (bucket < s->index_capacity && ((uint64_t)bucket << s->index_shift) < end)
            s->starts[bucket++] = i;
    }
#endif
    /* Production has seeded every strong root and intern before this capture.
     * Copy the seed bits, not queue links into the original arena. */
    for (size_t i = 0; i < s->count; i++) {
        const block *b = &s->headers[i];
        if (b->state & MARKED) shadow_mark(s, s->base + s->offsets[i] + sizeof(block));
    }
    for (uint32_t i = 0; i < count; i++)
        shadow_edge_add(s, (uintptr_t)conditional[i].owner, (uintptr_t)conditional[i].value);
    for (host_root *r = host_head; r; r = r->next)
        if (r->context == context && r->conditional && !r->expired)
            shadow_edge_add(s, (uintptr_t)r->owner, (uintptr_t)r->value);
    for (const neoclr_parked_roots *p = neoclr_roots_parked_v1(); p; p = p->next) {
        if (p->owner_context != context || p->expired) continue;
        for (const neoclr_probe_frame *f = p->head; f; f = f->previous) {
            if (f->context != context) continue;
            shadow_slots(s, (uintptr_t)p->owner, f->storage, f->storage_count);
            shadow_slots(s, (uintptr_t)p->owner, f->transient, f->transient_count);
            for (uint32_t i = 0; i < f->lane_count; i++)
                shadow_edge_add(s, (uintptr_t)p->owner, f->lanes[i]);
        }
    }
    if (!shadow_owner) {
        shadow_owner = shadow_alloc(1, sizeof(*shadow_owner));
        if (pthread_mutex_init(&shadow_owner->mutex, NULL) ||
            pthread_cond_init(&shadow_owner->condition, NULL) ||
            pthread_create(&shadow_owner->thread, NULL, shadow_run, shadow_owner)) abort();
    }
    shadow_worker *w = shadow_owner;
    if (pthread_mutex_lock(&w->mutex)) abort();
    w->job = s;
    w->done = 0;
    w->ready = 1;
    if (pthread_cond_broadcast(&w->condition) || pthread_mutex_unlock(&w->mutex)) abort();
    shadow_stats[1] += s->count * sizeof(block);
    shadow_stats[2] += shadow_clock(CLOCK_MONOTONIC) - start;
}
__attribute__((unused)) static void shadow_reference(neoclr_aot_context *context) {
    shadow_snapshot *s = shadow_owner->job;
    for (size_t i = 0; i < s->count; i++) {
        const block *b = (const void *)(context->text.data + s->offsets[i]);
        s->expected[i] = !!(b->state & MARKED);
    }
    s->reference_valid = 1;
}

/* Reads only through the mutation gate; allocation headers are detached. */
static int live_read(shadow_snapshot *s, const block *b, uint64_t offset, void *out, size_t bytes) {
    size_t i = (size_t)(b - s->headers);
#ifdef NEOCLR_LIVE_BATCH
    if (bytes>GATE_SCRATCH || offset>b->bytes || bytes>b->bytes-offset) return 0;
    if (s->read_held && (s->read_bytes+bytes>4096 || s->read_calls==64))
        live_batch_leave(s);
    if (!live_batch_enter(s)) return 0;
    memcpy(out,(void *)(s->base+s->offsets[i]+sizeof(block)+offset),bytes);
    s->read_bytes+=(unsigned)bytes;
    s->read_calls++;
    return 1;
#else
    return !gate_read(s->gate, s->epoch,
        (void *)(s->base + s->offsets[i] + sizeof(block)), b->bytes, offset, out, bytes);
#endif
}
static int live_words(shadow_snapshot *s, const block *b, uint64_t start, uint64_t end) {
    uint64_t scratch[GATE_SCRATCH / 8];
    while (start < end) {
        size_t bytes = end - start > sizeof(scratch) ? sizeof(scratch) : (size_t)(end-start);
        if (!live_read(s,b,start,scratch,bytes)) return 0;
        s->payload_read += bytes;
        for (size_t i = 0; i < bytes / 8; i++) shadow_mark(s,scratch[i]);
        start += bytes;
    }
    return 1;
}
static int shadow_scan(shadow_snapshot *s, const block *b) {
    if (b->kind == NEOCLR_GC_INTERN)
        return b->bytes == 8 && live_words(s,b,0,8);
    if (b->kind == NEOCLR_GC_OBJECT)
        return live_words(s,b,8,b->bytes & ~UINT64_C(7));
    if (b->kind == NEOCLR_GC_RECORDS) {
        uint64_t header[3];
        if (b->bytes < 24 || !live_read(s,b,0,header,24)) return 0;
        uint64_t kind=header[0], length=header[1], lanes=header[2];
        if ((kind & UINT64_C(0xffffffff)) != UINT64_C(0x80000005) ||
            (kind >> 32) > NEOCLR_NATIVE_TYPE_LIMIT || ((kind >> 32) && lanes != 1) ||
            !lanes || lanes > NEOCLR_NATIVE_LAYOUT_LANES || length > 65536 ||
            length > (b->bytes-24)/(lanes*8+1)) return 0;
        uint64_t markers=24+length*lanes*8;
        for (uint64_t i=0;i<length;i++) {
            unsigned char initialized;
            if (!live_read(s,b,markers+i,&initialized,1)) return 0;
            if (initialized && !live_words(s,b,24+i*lanes*8,24+(i+1)*lanes*8)) return 0;
        }
    } else if (b->kind == NEOCLR_GC_STRINGS) {
        uint64_t header[2];
        if (b->bytes < 16 || !live_read(s,b,0,header,16)) return 0;
        uint64_t kind=header[0]&UINT64_C(0xffffffff), length=header[1];
        int reserved=kind==UINT64_C(0x80000004);
        if ((!reserved && kind!=UINT64_C(0x80000003)) ||
            length>(b->bytes-16)/(reserved?9:8)) return 0;
        if (!reserved) return live_words(s,b,16,16+length*8);
        for (uint64_t i=0;i<length;i++) {
            unsigned char initialized;
            if (!live_read(s,b,16+length*8+i,&initialized,1)) return 0;
            if (initialized && !live_words(s,b,16+i*8,24+i*8)) return 0;
        }
    }
    return 1;
}

/* Explicit experimental lifecycle; owner-thread use only. Published collection completes the epoch; arena
 * release remains forbidden until completion. Allocation/mutation is allowed.
 * A failed finish discards the snapshot and leaves synchronous recovery available. */
static _Thread_local int candidate_phase;

static void candidate_wait(void) {
    shadow_worker *w = shadow_owner;
    if (!w || !w->job) abort();
    if (pthread_mutex_lock(&w->mutex)) abort();
    while (!w->done)
        if (pthread_cond_wait(&w->condition, &w->mutex)) abort();
    if (pthread_mutex_unlock(&w->mutex)) abort();
}
static void candidate_dispose(void) {
    candidate_wait();
    shadow_worker *w = shadow_owner;
    if (pthread_mutex_lock(&w->mutex)) abort();
    shadow_snapshot *s = w->job;
    w->job = NULL;
    if (pthread_mutex_unlock(&w->mutex)) abort();
#ifdef NEOCLR_SHADOW_SPARSE_INDEX
    free(s->starts);
#endif
    gate_stop(s->gate);
    if (gate_destroy(s->gate)) abort();
#ifdef NEOCLR_LIVE_BATCH
    live_batch_counts[0]+=s->read_acquisitions;
    if (s->max_read_bytes>live_batch_counts[1]) live_batch_counts[1]=s->max_read_bytes;
    if (s->max_read_calls>live_batch_counts[2]) live_batch_counts[2]=s->max_read_calls;
    if (s->hold_max>live_batch_counts[3]) live_batch_counts[3]=s->hold_max;
    live_batch_counts[4]+=s->hold_total;
#endif
    live_time_counts[0] += s->cpu_ns;
    live_counts[0] += s->count * sizeof(block);
    live_counts[1] += s->payload_read;
    live_counts[2] += s->barrier_words;
    live_counts[3] += !!s->valid;
    live_counts[4] += !s->valid;
    free(s->gate); free(s->headers);
    free(s->edges); free(s->pending); free(s->offsets);
    free(s->expected); free(s->marked); free(s->data); free(s);
}
static int candidate_seed(neoclr_aot_context *context, block_index *index, block **pending) {
    shadow_snapshot *s = shadow_owner->job;
    neoclr_aot_text_arena *a = &context->text;
    if (!s->valid || (uintptr_t)a->data != s->base || a->used < s->used) return 3;
    /* Old allocated blocks cannot move, split or disappear before remark.
     * Validate that proof before introducing any snapshot-derived mark. */
    for (size_t i = 0; i < s->count; i++) {
        const block *old = &s->headers[i];
        if (!(old->state & ALLOCATED)) continue;
        block *now = indexed_block(a, index, s->base + s->offsets[i]);
        if (!now || (unsigned char *)now != a->data + s->offsets[i] ||
            !(now->state & ALLOCATED) || now->span != old->span ||
            now->bytes != old->bytes || now->kind != old->kind) return 3;
    }
    size_t previous = 0;
    for (uint64_t at = 0; at < a->used;) {
        block *b = (void *)(a->data + at);
        while (previous < s->count && s->offsets[previous] < at) previous++;
        const block *old = previous < s->count && s->offsets[previous] == at
            ? &s->headers[previous] : NULL;
        if (b->state & ALLOCATED) {
            int existed = old && (old->state & ALLOCATED);
            if (!existed) {
                /* New allocations are not in the detached index. Trace their
                 * completed current payloads on the owner at remark. */
                mark(a,index,(uintptr_t)(b+1),pending);
            } else if (s->marked[previous] && !(b->state & MARKED)) {
                b->state=ALLOCATED|MARKED|SCANNED;
            }
        }
        at += b->span;
    }
    return 0;
}

static int32_t collect_indexed(neoclr_aot_context *context,
    const neoclr_probe_frame *head, neoclr_gc_conditional_root *conditional, uint32_t conditional_count,
    block_index index) {
    neoclr_aot_text_arena *a = &context->text;
    if (conditional_count > NEOCLR_GC_HOST_ROOT_LIMIT || (conditional_count && !conditional))
        return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    for (neoclr_gc_resource *r = resource_head; r; r = r->next)
        if (r->context == context && (!r->owner || !indexed_live_base(a, &index, r->owner)))
            return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    for (uint32_t i = 0; i < conditional_count; i++)
        if ((!conditional[i].owner && conditional[i].value) ||
            !indexed_live_base(a, &index, conditional[i].owner) || !indexed_live_base(a, &index, conditional[i].value))
            return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    for (host_root *root = host_head; root; root = root->next)
        if (root->context == context && (!indexed_live_base(a, &index, root->value) ||
            (root->conditional && !root->expired &&
                (!root->owner || !indexed_live_base(a, &index, root->owner))))) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    for (const neoclr_parked_roots *p = neoclr_roots_parked_v1(); p; p = p->next)
        if (p->owner_context == context && !p->expired &&
            (!p->owner || !indexed_live_base(a, &index, p->owner))) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    neoclr_probe_storage fault[65];
    int32_t count = neoclr_probe_fault_roots_v1(context, fault, 65);
    if (count < 0) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    for (neoclr_parked_roots *p = (neoclr_parked_roots *)neoclr_roots_parked_v1(); p; p = p->next)
        if (p->owner_context == context) p->traced = 0;
    block *pending = NULL;
    /* Header validation recorded a bounded list of intern seeds. Clean marks
     * need no reset walk. Stale marks or overflow retain the original full walk,
     * where mark() only enqueues the current block until the worklist runs. */
    if (index.reset_required || index.intern_count > INTERN_SEED_LIMIT) {
        for (uint64_t at = 0; at < a->used;) {
            block *b = (void *)(a->data + at);
            b->state &= ALLOCATED;
            if ((b->state & ALLOCATED) && b->kind == NEOCLR_GC_INTERN)
                mark(a, &index, (uintptr_t)(b + 1), &pending);
            at += b->span;
        }
    } else {
        for (unsigned i = 0; i < index.intern_count; i++)
            mark(a, &index, (uintptr_t)(index.interns[i] + 1), &pending);
    }
    mark_slots(a, &index, fault, (uint32_t)count, &pending);
    for (host_root *root = host_head; root; root = root->next)
        if (root->context == context && !root->conditional)
            mark(a, &index, (uintptr_t)root->value, &pending);
    mark(a, &index, (uintptr_t)context->static_storage, &pending);
    mark_frames(context, &index, head, &pending);
#ifdef NEOCLR_WORKER_GC
    for (unsigned n = 0; n < worker_participant_count; n++) {
        const neoclr_gc_participant *part = &worker_participants[n];
        neoclr_probe_storage diagnostics[65];
        int32_t slots = neoclr_probe_fault_roots_v1(part->context, diagnostics, 65);
        if (slots < 0) return 3;
        mark_slots(a, &index, diagnostics, (uint32_t)slots, &pending);
        for (const neoclr_probe_frame *f = part->frames; f; f = f->previous) {
            if (f->context != part->context) return 3;
            mark_slots(a, &index, f->storage, f->storage_count, &pending);
            mark_slots(a, &index, f->transient, f->transient_count, &pending);
            for (uint32_t i = 0; i < f->lane_count; i++) mark(a, &index, f->lanes[i], &pending);
        }
    }
#endif

    for (const neoclr_parked_roots *p = neoclr_roots_parked_v1(); p; p = p->next)
        if (!p->owner_context) mark_frames(context, &index, p->head, &pending);
    if (candidate_phase == 1) {
        shadow_begin(context, conditional, conditional_count);
        for (uint64_t at = 0; at < a->used;) {
            block *b = (void *)(a->data + at);
            b->state &= ALLOCATED;
            at += b->span;
        }
        return 0;
    }
    if (candidate_phase == 2 && candidate_seed(context, &index, &pending))
        goto invalid_descriptor;
    /* Each newly marked reference-bearing allocation enters the worklist once.
     * The sparse index bounds address searches to a bucket plus its crossing block. */
    for (;;) {
        uint64_t atomic_before = index.atomic_marks;
        while (pending) {
            block *b = pending;
            pending = (block *)(uintptr_t)(b->state & ~UINT64_C(7));
            b->state = ALLOCATED | MARKED | SCANNED;
            const unsigned char *data = (const void *)(b + 1);
            if (b->kind == NEOCLR_GC_INTERN) {
                if (b->bytes != 8) goto invalid_descriptor;
                uint64_t owner; memcpy(&owner, data, 8);
                mark(a, &index, owner, &pending);
            } else if (b->kind == NEOCLR_GC_OBJECT) {
                for (uint64_t offset = 8; offset + 8 <= b->bytes; offset += 8) {
                    LOOKUP_COUNT(object_words);
                    uint64_t word; memcpy(&word, data + offset, 8); mark(a, &index, word, &pending);
                }
            } else if (b->kind == NEOCLR_GC_RECORDS) {
                uint64_t kind, length, lanes;
                if (b->bytes < 24) goto invalid_descriptor;
                memcpy(&kind, data, 8); memcpy(&length, data + 8, 8); memcpy(&lanes, data + 16, 8);
                if ((kind & UINT64_C(0xffffffff)) != UINT64_C(0x80000005) ||
                    (kind >> 32) > NEOCLR_NATIVE_TYPE_LIMIT || ((kind >> 32) && lanes != 1) || !lanes || lanes > NEOCLR_NATIVE_LAYOUT_LANES ||
                    length > 65536 || length > (b->bytes - 24) / (lanes * 8 + 1)) goto invalid_descriptor;
                uint64_t markers = 24 + length * lanes * 8;
                for (uint64_t i = 0; i < length; i++) {
                    if (!data[markers + i]) continue;
                    for (uint64_t lane = 0; lane < lanes; lane++) {
                        uint64_t word; memcpy(&word, data + 24 + (i * lanes + lane) * 8, 8);
                        mark(a, &index, word, &pending);
                    }
                }
            } else if (b->kind == NEOCLR_GC_STRINGS) {
                uint64_t kind, length;
                if (b->bytes < 16) goto invalid_descriptor;
                memcpy(&kind, data, 8); memcpy(&length, data + 8, 8);
                kind &= UINT64_C(0xffffffff);
                int reserved = kind == UINT64_C(0x80000004);
                if ((!reserved && kind != UINT64_C(0x80000003)) ||
                    length > (b->bytes - 16) / (reserved ? 9 : 8)) goto invalid_descriptor;
                for (uint64_t i = 0; i < length; i++) {
                    if (reserved && !data[16 + 8 * length + i]) continue;
                    uint64_t word; memcpy(&word, data + 16 + 8 * i, 8); mark(a, &index, word, &pending);
                }
            }
        }
        // Values can reveal further owners. Reach a fixed point independent of
        // entry order; an unrooted cycle never supplies its own first mark.
        for (uint32_t i = 0; i < conditional_count; i++) {
            const void *owner = conditional[i].owner;
            if (owner && (((const block *)owner - 1)->state & MARKED))
                mark(a, &index, (uintptr_t)conditional[i].value, &pending);
        }
        for (host_root *root = host_head; root; root = root->next)
            if (root->context == context && root->conditional && !root->expired &&
                (((const block *)root->owner - 1)->state & MARKED))
                mark(a, &index, (uintptr_t)root->value, &pending);
        /* Parked frame contents are immutable during collection. Once their
         * owner is marked, scan this registration only once; newly discovered
         * owners still activate other registrations on subsequent passes. */
        for (neoclr_parked_roots *p = (neoclr_parked_roots *)neoclr_roots_parked_v1(); p; p = p->next)
            if (p->owner_context == context && !p->expired && !p->traced &&
                (((const block *)p->owner - 1)->state & MARKED)) {
                p->traced = 1;
                mark_frames(context, &index, p->head, &pending);
            }
        if (!pending && atomic_before == index.atomic_marks) break;
    }

    for (neoclr_gc_resource **link = &resource_head; *link;) {
        neoclr_gc_resource *r = *link;
        if (r->context == context && !(((const block *)r->owner - 1)->state & MARKED))
            resource_cleanup(link);
        else
            link = &r->next;
    }
    for (host_root *root = host_head; root; root = root->next)
        if (root->context == context && root->conditional && !root->expired &&
            !(((const block *)root->owner - 1)->state & MARKED)) {
            root->owner = root->value = NULL;
            root->expired = 1;
        }
    for (neoclr_parked_roots *p = (neoclr_parked_roots *)neoclr_roots_parked_v1(); p; p = p->next)
        if (p->owner_context == context && !p->expired &&
            !(((const block *)p->owner - 1)->state & MARKED)) {
            p->head = NULL;
            p->owner = NULL;
            p->expired = 1;
        }
    for (uint32_t i = 0; i < conditional_count; i++) {
        void *owner = conditional[i].owner;
        conditional[i].retained = owner && (((const block *)owner - 1)->state & MARKED);
        if (!conditional[i].retained)
            conditional[i].owner = conditional[i].value = NULL;
    }
#ifdef NEOCLR_GC_PROFILE
    uint64_t live_bytes = 0, live_blocks = 0;
#endif
    /* Sweep and coalesce in one forward walk. Preserve the original span before
     * extending a preceding free run; no later lookup uses the marking index. */
    block *free_run = NULL, *last_free = NULL;
    uint64_t free_at = 0, free_head = 0;
    for (uint64_t at = 0; at < a->used;) {
        block *b = (void *)(a->data + at);
        uint64_t span = b->span;
        if (b->state && !(b->state & MARKED)) {
            gc_state.statistics.reclaimed_allocations++; gc_state.statistics.reclaimed_bytes += b->bytes;
            /* Keep positive proofs for survivors. Revoke a reclaimed exact base
             * before its descriptor/payload can be reused or coalesced. */
            if (a == owned_heap.arena) {
#ifdef NEOCLR_LIVE_ALLOCATION_INDEX
                owned_index_clear((unsigned char *)(b+1)-a->data);
#endif
                unsigned slot = base_slot(b + 1);
                if (owned_heap.bases[slot] == (void *)(b + 1)) owned_heap.bases[slot] = NULL;
            }
            /* Poison reclaimed contents so stale reads fail functional stress tests. */
            memset(b + 1, 0xdd, (size_t)(span - sizeof(block)));
            b->state = 0; b->bytes = 0; b->kind = 0;
        } else b->state &= ALLOCATED;
#ifdef NEOCLR_GC_PROFILE
        if (b->state) { live_bytes += b->bytes; live_blocks++; }
#endif
        if (b->state) {
            if (free_run && a == owned_heap.arena) {
                if (last_free) last_free->bytes = free_at + 1;
                else free_head = free_at + 1;
                last_free = free_run;
            }
            free_run = NULL;
        } else if (free_run) {
            free_run->span += span;
        } else {
            free_run = b;
            free_at = at;
            if (a == owned_heap.arena) b->bytes = 0;
        }
        at += span;
    }
    if (free_run) a->used = free_at;
    if (a == owned_heap.arena) {
        owned_heap.used = a->used;
        owned_heap.free_head = free_head;
    }
    gc_state.statistics.collections++;
#ifdef NEOCLR_GC_PROFILE
    profile.live_bytes = live_bytes; profile.live_blocks = live_blocks;
    if (live_bytes > profile.peak_live_bytes) profile.peak_live_bytes = live_bytes;
#endif
    return 0;
invalid_descriptor:
    /* Do not leave private queue links in public quiescent heap state on failure.
     * Nothing has been swept; a repaired descriptor can be collected again. */
    for (uint64_t at = 0; at < a->used;) {
        block *b = (void *)(a->data + at); b->state &= ALLOCATED; at += b->span;
    }
    return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
}
/* Keep the larger stack reservation off the common small-heap path, including
 * compilers that would otherwise inline the helper and reserve it unconditionally. */
#ifdef _MSC_VER
__declspec(noinline)
#else
__attribute__((noinline))
#endif
static int32_t collect_dense(neoclr_aot_context *context,
    const neoclr_probe_frame *head, neoclr_gc_conditional_root *conditional, uint32_t count) {
    block *starts[4096], *interns[INTERN_SEED_LIMIT];
    block_index index = {.start = starts, .interns = interns, .capacity = 4096};
    /* The caller has validated every span in this synchronous collection.
     * No guest code, cleanup callback or heap mutation runs between the walks.
     * Rebuild only bucket starts; do not repeat validation or population counting. */
    neoclr_aot_text_arena *a = &context->text;
    index.shift = 6;
    while (a->used && ((a->used - 1) >> index.shift) >= index.capacity) index.shift++;
    unsigned bucket = 0;
    for (uint64_t at = 0; at < a->used;) {
        block *b = (void *)(a->data + at);
        index_seed(&index, b);
        uint64_t end = at + b->span;
        while (bucket < index.capacity && ((uint64_t)bucket << index.shift) < end)
            index.start[bucket++] = b;
        at = end;
    }
    return collect_indexed(context, head, conditional, count, index);
}
int32_t experiment_gc_finish(neoclr_aot_context *, const neoclr_probe_frame *, neoclr_gc_conditional_root *, uint32_t);
static int32_t collect_conditional(neoclr_aot_context *context,
    const neoclr_probe_frame *head, neoclr_gc_conditional_root *conditional, uint32_t count) {
    if (!context || gc_state.cleanup_active || (candidate_context &&
        (!candidate_phase || candidate_context != context))) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    block *starts[256], *interns[INTERN_SEED_LIMIT];
    block_index index = {.start = starts, .interns = interns, .capacity = 256};
    if (!build_index(&context->text, &index)) return NEOCLR_AOT_FAULT_RUNTIME_ERROR;
    /* Population, not arena size: a few large atomic buffers do not warrant a
     * denser table. Rebuild only before any marks or cleanup state are changed. */
    if (index.blocks > 2048) return collect_dense(context, head, conditional, count);
    return collect_indexed(context, head, conditional, count, index);
}
int32_t experiment_gc_begin(neoclr_aot_context *, const neoclr_probe_frame *, neoclr_gc_conditional_root *, uint32_t);
int32_t experiment_gc_finish(neoclr_aot_context *, const neoclr_probe_frame *, neoclr_gc_conditional_root *, uint32_t);
static void candidate_cancel(void) {
    candidate_dispose();
    candidate_counts[2]++;
    candidate_context = NULL;
    candidate_active = 0;
}
int32_t neoclr_gc_collect_conditional_v1(neoclr_aot_context *context,
    const neoclr_probe_frame *head, neoclr_gc_conditional_root *conditional, uint32_t count) {
    if (native_scope_depth) {
        if (context != native_scope_context) return 3;
        native_scope_counts[2]++;
    }
    if (!candidate_phase) {
        if (candidate_autostart && !native_scope_depth && context && owned_heap.arena == &context->text) {
            if (candidate_active && candidate_context == context)
                return experiment_gc_finish(context, head, conditional, count);
            if (candidate_active) candidate_cancel();
            return experiment_gc_begin(context, head, conditional, count);
        }
        if (candidate_active) {
            if (candidate_context == context) {
                int32_t status = experiment_gc_finish(context, head, conditional, count);
                if (status) return status;
                candidate_counts[3]++;
            } else candidate_cancel();
        }
    }


#ifdef NEOCLR_GC_PROFILE
#ifdef _WIN32
    static _Thread_local LARGE_INTEGER frequency;
    LARGE_INTEGER before, after;
    if (!frequency.QuadPart &&
        (!QueryPerformanceFrequency(&frequency) || frequency.QuadPart <= 0)) abort();
    if (!QueryPerformanceCounter(&before)) abort();
#else
    struct timespec before, after;
    if (clock_gettime(CLOCK_MONOTONIC, &before)) abort();
#endif
#endif
    int32_t status = collect_conditional(context, head, conditional, count);
#ifdef NEOCLR_GC_PROFILE
#ifdef _WIN32
    if (!QueryPerformanceCounter(&after) || after.QuadPart < before.QuadPart) abort();
    uint64_t ticks = (uint64_t)(after.QuadPart - before.QuadPart);
    uint64_t hz = (uint64_t)frequency.QuadPart;
    /* Split whole seconds before scaling to avoid overflowing ticks * 1e9. */
    uint64_t ns = (ticks / hz) * UINT64_C(1000000000) +
        (uint64_t)((double)(ticks % hz) * 1000000000.0 / (double)hz);
#else
    if (clock_gettime(CLOCK_MONOTONIC, &after)) abort();
    uint64_t ns = (uint64_t)((int64_t)(after.tv_sec - before.tv_sec) * INT64_C(1000000000)
                           + after.tv_nsec - before.tv_nsec);
#endif
    unsigned bucket = 0;
    for (uint64_t remaining = ns; remaining > 1; remaining >>= 1) bucket++;
    profile.pause_buckets[bucket]++;
    profile.attempts++;
    profile.failures += status != 0;
    profile.nanoseconds += ns;
    if (ns > profile.maximum_nanoseconds) profile.maximum_nanoseconds = ns;
#endif
#ifdef NEOCLR_DIAGNOSTICS
    neoclr_diagnostics_publish_v1();
#endif
    return status;
}
/* Opt-in generated-boundary pacing; private per-owner-thread state, not ABI.
 * Unexpected global collection epochs force a sweep instead of indefinitely
 * postponing cleanup across contexts. Rooted admission handles actual pressure.
 * The bounded 256-allocation / 4096-publication budget amortizes tracing on the
 * plain HTTP path; see benchmarks/http-server/primitive-comparison/pacing.
 * This is a publication budget, not a wall-clock finalization guarantee. */
#ifdef NEOCLR_GC_PROFILE
static int32_t collect_idle(neoclr_aot_context *context, const neoclr_probe_frame *boundary, unsigned reason) {
    /* Owned allocation/publication budgets toggle asynchronous epochs.
     * Other requests recheck synchronously, or cancel on context change. */
    candidate_autostart = reason == NEOCLR_GC_TRIGGER_PUBLICATION || reason == NEOCLR_GC_TRIGGER_ALLOCATION;
    int32_t status = collect_requested(context, boundary, reason);
    candidate_autostart = 0;
#ifdef NEOCLR_GC_PACED
    /* Preserve idle cleanup, then capture survivors for the next interval. */
    if (!status && !native_scope_depth && reason == NEOCLR_GC_TRIGGER_IDLE && owned_heap.arena == &context->text) {
        status = experiment_gc_begin(context, boundary, NULL, 0);
        if (!status) candidate_counts[4]++;
    }
#endif

#else
int32_t neoclr_gc_idle_v1(neoclr_aot_context *context, const neoclr_probe_frame *boundary) {
    int32_t status = neoclr_gc_collect_v1(context, boundary);
#endif
    if (!status) {
        gc_state.pacing.context = context;
        gc_state.pacing.allocations = gc_state.statistics.allocations;
        gc_state.pacing.collections = gc_state.statistics.collections;
        gc_state.pacing.boundaries = 0;
    }
    return status;
}
#ifdef NEOCLR_GC_PROFILE
int32_t neoclr_gc_idle_v1(neoclr_aot_context *context, const neoclr_probe_frame *boundary) {
    return collect_idle(context, boundary, NEOCLR_GC_TRIGGER_IDLE);
}
int32_t neoclr_gc_paced_collect_v1(neoclr_aot_context *context, const neoclr_probe_frame *boundary) {
    unsigned reason = gc_state.pacing.context != context ? NEOCLR_GC_TRIGGER_CONTEXT :
        gc_state.statistics.collections != gc_state.pacing.collections ? NEOCLR_GC_TRIGGER_EPOCH :
        gc_state.statistics.allocations - gc_state.pacing.allocations >= 256 ? NEOCLR_GC_TRIGGER_ALLOCATION :
        NEOCLR_GC_TRIGGER_PUBLICATION;
    return collect_idle(context, boundary, reason);
}
#endif
int32_t neoclr_gc_boundary_v1(neoclr_aot_context *context, const neoclr_probe_frame *boundary) {
    if (!context || gc_state.cleanup_active || boundary != neoclr_root_probe_head_v1() ||
        (boundary && boundary->context != context)) return 3;
    return neoclr_paced_boundary(&neoclr_execution_state_v1, context, boundary);
}
/* Only root publication may reuse its just-established current-head proof.
 * No guest execution, callback mutation or collection may intervene. Keep the
 * cleanup/context checks here and the general native entry fully checked. */
int32_t neoclr_gc_published_boundary_v1(neoclr_aot_context *context, const neoclr_probe_frame *boundary) {
    return neoclr_published_boundary(&neoclr_execution_state_v1, context, boundary);
}
neoclr_gc_statistics neoclr_gc_statistics_v1(void) { return gc_state.statistics; }

static int32_t string_intern(const neoclr_aot_text *text, neoclr_aot_text_arena *arena,
                               const neoclr_aot_text **output, int rooted) {
    if (!text || !output || !blocks_valid(arena)) return 3;
    uint64_t count = 0, bytes = 0;
    for (uint64_t at = 0; at < arena->used;) {
        const block *b = (const void *)(arena->data + at);
        if ((b->state & ALLOCATED) && b->kind == NEOCLR_GC_INTERN) {
            if (b->bytes != 8) return 3;
            const neoclr_aot_text *owner;
            memcpy(&owner, b + 1, 8);
            if (!owner || owner->length > UINT64_C(1048576) - bytes) return 3;
            if (owner->length == text->length && !memcmp(owner->bytes,text->bytes,(size_t)text->length)) {
                *output = owner;
                return 0;
            }
            bytes += owner->length; count++;
        }
        at += b->span;
    }
    if (count >= 4096 || text->length > UINT64_C(1048576) - bytes) return 10;
    void *entry;
    int32_t status;
    if (rooted) {
        const neoclr_probe_frame *head = neoclr_root_probe_head_v1();
        neoclr_aot_context *context = head ? (neoclr_aot_context *)head->context : NULL;
        if (!context || &context->text != arena) return 3;
        const void *owner = text;
        status = neoclr_gc_allocate_rooted_values_v1(context, head, &owner, 1, 8, NEOCLR_GC_INTERN, &entry);
    } else {
        status = neoclr_gc_allocate_v1(arena,8,NEOCLR_GC_INTERN,&entry);
    }
    if (status) return status;
    memcpy(entry,&text,8);
    *output = text;
    return 0;
}

int32_t neoclr_string_intern_v1(const neoclr_aot_text *text, neoclr_aot_text_arena *arena,
    const neoclr_aot_text **output) { return string_intern(text, arena, output, 0); }
int32_t neoclr_string_intern_rooted_v1(const neoclr_aot_text *text, neoclr_aot_text_arena *arena,
    const neoclr_aot_text **output) { return string_intern(text, arena, output, 1); }

/* Managed GC.Collect is available independently of runtime suspension. */
int32_t neoclr_gc_collect_managed_v1(neoclr_aot_context *c, void *out) {
    (void)out;
    return GC_REQUEST(c, neoclr_root_probe_head_v1(), NEOCLR_GC_TRIGGER_MANAGED);
}

int32_t experiment_gc_begin(neoclr_aot_context *context, const neoclr_probe_frame *head,
    neoclr_gc_conditional_root *conditional, uint32_t count) {
    if (!context || native_scope_depth || candidate_active || gc_state.cleanup_active) return 3;
    candidate_context = context;
    candidate_phase = 1;
    int32_t status = neoclr_gc_collect_conditional_v1(context, head, conditional, count);
    candidate_phase = 0;
    if (status) candidate_context = NULL;
    else {
        candidate_active = 1; candidate_counts[0]++;
        gc_state.pacing.context=context;
        gc_state.pacing.allocations=gc_state.statistics.allocations;
        gc_state.pacing.collections=gc_state.statistics.collections;
        gc_state.pacing.boundaries=0;
    }
    return status;
}
int32_t experiment_gc_finish(neoclr_aot_context *context, const neoclr_probe_frame *head,
    neoclr_gc_conditional_root *conditional, uint32_t count) {
    if (!candidate_active || context != candidate_context || gc_state.cleanup_active) return 3;
    candidate_wait();
    shadow_worker *w=shadow_owner;
    shadow_snapshot *s=w->job;
    uint64_t words[GATE_WORDS]; size_t barrier_count=0;
    if (gate_drain(s->gate,s->epoch,words,GATE_WORDS,&barrier_count)) s->valid=0;
    else {
        s->barrier_words += barrier_count;
        for (size_t i=0;i<barrier_count;i++) shadow_mark(s,words[i]);
    }
    if (s->valid && s->pending_count) {
        if (pthread_mutex_lock(&w->mutex)) abort();
        w->done=0; w->ready=1;
        if (pthread_cond_broadcast(&w->condition) || pthread_mutex_unlock(&w->mutex)) abort();
        candidate_wait();
    }
    candidate_phase = 2;
    int32_t status = neoclr_gc_collect_conditional_v1(context, head, conditional, count);
    candidate_phase = 0;
    candidate_context = NULL;
    candidate_active = 0;
    candidate_dispose();
    if (!status) candidate_counts[1]++;
    return status;
}

void experiment_gc_time_counts(uint64_t *out) { memcpy(out,live_time_counts,sizeof(live_time_counts)); }
void experiment_gc_batch_counts(uint64_t *out) { memcpy(out,live_batch_counts,sizeof(live_batch_counts)); }
void experiment_gc_live_counts(uint64_t *out) { memcpy(out,live_counts,sizeof(live_counts)); }
void experiment_gc_live_wait(void) { if (!candidate_active) abort(); candidate_wait(); }
/* Raw native caller must admit every mutation through this adapter. This is not
 * sufficient admission for generated code, providers, or shared heaps. */
static int live_write_known(void *payload, uint64_t bytes, uint32_t kind,
    const mutation_patch *patches, size_t count) {
    shadow_snapshot *s=shadow_owner->job;
    /* Published array shape is immutable. Markers and payload use grouped patches. */
    size_t header=kind==NEOCLR_GC_RECORDS?24:kind==NEOCLR_GC_STRINGS?16:0;
    if (count && !patches) return GATE_INVALID;
    if (count > GATE_PATCHES) return GATE_INVALID;
    for (size_t i=0;i<count;i++)
        if (patches[i].length && patches[i].offset < header) return GATE_INVALID;
#ifdef NEOCLR_LIVE_GATE_PROFILE
    uint64_t start=shadow_clock(CLOCK_MONOTONIC), cpu=shadow_clock(CLOCK_THREAD_CPUTIME_ID);
#endif
    int result=gate_write(s->gate,payload,bytes,kind==NEOCLR_GC_OBJECT?8:0,patches,count);
#ifdef NEOCLR_LIVE_GATE_PROFILE
    live_time_counts[4]+=shadow_clock(CLOCK_THREAD_CPUTIME_ID)-cpu;
    uint64_t elapsed=shadow_clock(CLOCK_MONOTONIC)-start;
    live_time_counts[1]+=elapsed;
    if (elapsed>live_time_counts[2]) live_time_counts[2]=elapsed;
    live_time_counts[3]++;
#endif
    return result;
}
int experiment_gc_write(neoclr_aot_context *context, void *payload,
    const mutation_patch *patches, size_t count) {
    if (!candidate_active || context != candidate_context) return GATE_INVALID;
    uint64_t bytes; uint32_t kind;
    if (neoclr_gc_allocation_info_v1(context,payload,&bytes,&kind)) return GATE_INVALID;
    return live_write_known(payload,bytes,kind,patches,count);
}

int experiment_gc_live_active(neoclr_aot_context *context) { return candidate_active && candidate_context==context; }

/* Prototype compiler-facing scalar-store adapter. It never collects. The caller
 * supplies a valid native destination; out-of-arena storage is trusted stack or
 * host storage, not permission to mutate a different managed heap. */
/* These private hints/counters share storage, not lifetimes or admission.
 * The explicit split control preserves the former TLS layout. */
#if defined(NEOCLR_LIVE_SPLIT_TLS) || defined(NEOCLR_LIVE_SPLIT_STORE_TLS)
#if !defined(NEOCLR_LIVE_NO_STORE_CACHE) && !defined(NEOCLR_LIVE_LINEAR_STORE)
#ifndef NEOCLR_LIVE_HEADER_PROOF
static _Thread_local const void *live_store_last_payload;
#else
static _Thread_local struct {
    const void *payload;
    uint64_t span, bytes, kind;
} live_store_last_header;
#define live_store_last_payload (live_store_last_header.payload)
#endif
#ifndef NEOCLR_LIVE_STORE_RANGES
#define NEOCLR_LIVE_STORE_RANGES 4
#endif
#if NEOCLR_LIVE_STORE_RANGES < 1 || NEOCLR_LIVE_STORE_RANGES > 16
#error "store range count must be between 1 and 16"
#endif
#if NEOCLR_LIVE_STORE_RANGES > 1
static _Thread_local const void *live_store_recent[NEOCLR_LIVE_STORE_RANGES-1];
static _Thread_local unsigned live_store_recent_next;
#endif
#endif
#ifdef NEOCLR_LIVE_WALK_PROFILE
static _Thread_local uint64_t live_store_walk_counts[3]; /* headers visited, max per walk, free headers */
#endif
static _Thread_local uint64_t live_store_lookup_counts[2]; /* proved range/base, checked walks */
#else
#define live_store_lookup_counts (live_owner.store.lookups)
#ifdef NEOCLR_LIVE_WALK_PROFILE
#define live_store_walk_counts (live_owner.store.walks)
#endif
#if !defined(NEOCLR_LIVE_NO_STORE_CACHE) && !defined(NEOCLR_LIVE_LINEAR_STORE)
#ifdef NEOCLR_LIVE_HEADER_PROOF
#define live_store_last_header (live_owner.store.header)
#define live_store_last_payload (live_owner.store.header.payload)
#else
#define live_store_last_payload (live_owner.store.payload)
#endif
#if NEOCLR_LIVE_STORE_RANGES > 1
#define live_store_recent (live_owner.store.recent)
#define live_store_recent_next (live_owner.store.next)
#endif
#endif
#endif
#ifdef NEOCLR_LIVE_WALK_PROFILE
void experiment_gc_store_walk_counts(uint64_t *out) {
    memcpy(out,live_store_walk_counts,sizeof(live_store_walk_counts));
}
#endif
static void live_store_cancel_epoch(void) {
        candidate_dispose();
        candidate_context=NULL;
        candidate_active=0; candidate_counts[2]++;
        live_store_counts[3]++;
}
/* Width was validated by the adapter. Constant-size memcpy keeps unaligned
 * destinations legal and preserves native integer truncation/byte order without
 * a second dynamic-size copy. This does not authorize or synchronize a store. */
static inline void live_store_bits(void *destination, uint64_t bits, uint32_t width) {
#ifdef NEOCLR_LIVE_SERIALIZED_STORE
    unsigned char value[8];
    if (width==1) { uint8_t v=(uint8_t)bits; memcpy(value,&v,1); }
    else if (width==2) { uint16_t v=(uint16_t)bits; memcpy(value,&v,2); }
    else if (width==4) { uint32_t v=(uint32_t)bits; memcpy(value,&v,4); }
    else memcpy(value,&bits,8);
    memcpy(destination,value,width);
#else
    if (width==1) { uint8_t v=(uint8_t)bits; memcpy(destination,&v,1); }
    else if (width==2) { uint16_t v=(uint16_t)bits; memcpy(destination,&v,2); }
    else if (width==4) { uint32_t v=(uint32_t)bits; memcpy(destination,&v,4); }
    else memcpy(destination,&bits,8);
#endif
}
int experiment_gc_store(neoclr_aot_context *context, void *destination,
                       uint64_t bits, uint32_t width) {
    if (!context || owned_heap.arena != &context->text || !valid(&context->text) ||
        !destination || (width!=1 && width!=2 && width!=4 && width!=8) ||
        (candidate_active && candidate_context!=context)) goto rejected;
    uintptr_t address=(uintptr_t)destination, base=(uintptr_t)context->text.data;
    if (address>UINTPTR_MAX-width || base>UINTPTR_MAX-context->text.capacity) goto rejected;
    uintptr_t end=base+context->text.capacity;
    if (address>=end || address+width<=base) {
        live_store_counts[0]++;
        live_store_bits(destination,bits,width);
        return 0;
    }
    if (address<base || address-base>=context->text.used) goto rejected;
    neoclr_aot_text_arena *a=&context->text;
    block *b=NULL;
    uint64_t walk_start=0;
#if !defined(NEOCLR_LIVE_LINEAR_STORE) && !defined(NEOCLR_LIVE_REPEAT_SNAPSHOT_LOOKUP)
    int snapshot_allocation=0;
#endif
#if !defined(NEOCLR_LIVE_NO_STORE_CACHE) && !defined(NEOCLR_LIVE_LINEAR_STORE) && defined(NEOCLR_LIVE_HEADER_PROOF)
    int reused_header=0;
#endif
#ifndef NEOCLR_LIVE_LINEAR_STORE
    if (candidate_active) {
        shadow_snapshot *snapshot=shadow_owner->job;
        size_t index=shadow_find(snapshot,address);
        if (index!=SIZE_MAX) {
#ifndef NEOCLR_LIVE_REPEAT_SNAPSHOT_LOOKUP
            snapshot_allocation=1;
#endif
            uint64_t at=snapshot->offsets[index];
            const block *saved=&snapshot->headers[index];
            if (!block_valid(a,at)) goto rejected;
            b=(void *)(a->data+at);
            /* Old allocations cannot move, retire or be reclaimed during this
             * epoch. Validate the identity before trusting detached lookup. */
            if (!(b->state&ALLOCATED) || b->span!=saved->span ||
                b->bytes!=saved->bytes || b->kind!=saved->kind) goto rejected;
            goto located;
        }
    }
#endif
#if !defined(NEOCLR_LIVE_NO_STORE_CACHE) && !defined(NEOCLR_LIVE_LINEAR_STORE)
    /* The owned exact-base cache revokes proofs on reclamation/reset/release.
     * Never dereference a remembered range unless that current proof survives.
     * Snapshot identity validation above still owns old-epoch allocations. */
    if (live_store_last_payload && known_base(live_store_last_payload)) {
        uintptr_t previous=(uintptr_t)live_store_last_payload;
        if (previous>=base && previous-base>=sizeof(block) && previous-base<a->used && address>=previous) {
            uint64_t at=previous-base-sizeof(block);
            block *cached=(void *)(a->data+at);
#ifdef NEOCLR_LIVE_HEADER_PROOF
            /* The tuple was validated when this hint was installed. Current
             * owned-base admission above protects its address; matching fields
             * preserve the immutable constraints. State and extent stay live.
             * A legitimate metadata transition is revalidated, never assumed. */
            int same_header=cached->span==live_store_last_header.span &&
                cached->bytes==live_store_last_header.bytes &&
                cached->kind==live_store_last_header.kind;
            if (same_header) {
                if (!(cached->state&ALLOCATED) || cached->state>7 ||
                    cached->span>a->used-at) goto rejected;
            } else if (!block_valid(a,at)) goto rejected;
#else
            if (!block_valid(a,at)) goto rejected;
#endif
            if ((cached->state&ALLOCATED) && address-previous<cached->bytes) {
#ifdef NEOCLR_LIVE_HEADER_PROOF
                reused_header=same_header;
#endif
                b=cached;
                live_store_lookup_counts[0]++;
                goto located;
            }
#ifndef NEOCLR_LIVE_FULL_STORE_WALK
            if (cached->state&ALLOCATED) walk_start=at;
#endif
        }
    }
    /* Allocation-base writes can use the existing current owned proof directly.
     * This also seeds the last range for subsequent field initialization. Never
     * derive a header from an unproved destination or skip snapshot checks. */
#ifndef NEOCLR_LIVE_NO_EXACT_STORE
    if (address-base>=sizeof(block) && known_base(destination)) {
        uint64_t at=address-base-sizeof(block);
        if (!block_valid(a,at)) goto rejected;
        b=(void *)(a->data+at);
        if (!(b->state&ALLOCATED)) goto rejected;
        live_store_lookup_counts[0]++;
        goto located;
    }
#endif
#if NEOCLR_LIVE_STORE_RANGES > 1
    for (unsigned i=0;i<NEOCLR_LIVE_STORE_RANGES-1;i++) {
        const void *recent=live_store_recent[i];
        uintptr_t previous=(uintptr_t)recent;
        /* A stale hint is never a proof. Do not inspect its header until the
         * current owned exact-base cache authorizes it. */
        if (!recent || previous<base || previous-base<sizeof(block) ||
            previous-base>=a->used || address<previous || !known_base(recent)) continue;
        uint64_t at=previous-base-sizeof(block);
        if (!block_valid(a,at)) goto rejected;
        block *cached=(void *)(a->data+at);
        if ((cached->state&ALLOCATED) && address-previous<cached->bytes) {
            b=cached;
            live_store_lookup_counts[0]++;
            goto located;
        }
#ifndef NEOCLR_LIVE_FULL_STORE_WALK
        if ((cached->state&ALLOCATED) && at>walk_start) walk_start=at;
#endif
    }
#endif
#endif
    /* An admitted, validated allocation below the destination is also a safe
     * walk anchor. Current ownership revoked stale hints before header access;
     * retain checked span traversal from this boundary, never from user bytes. */
    live_store_lookup_counts[1]++;
#ifdef NEOCLR_LIVE_WALK_PROFILE
    uint64_t walk_steps=0;
#endif
#ifdef NEOCLR_LIVE_ALLOCATION_INDEX
    (void)walk_start;
    uint64_t indexed=owned_index_before(address-base);
    if (indexed==UINT64_MAX || indexed<sizeof(block) || indexed>=a->used) goto rejected;
#ifdef NEOCLR_LIVE_WALK_PROFILE
    live_store_walk_counts[0]++;
    if (!live_store_walk_counts[1]) live_store_walk_counts[1]=1;
    (void)walk_steps;
#endif
    uint64_t at=indexed-sizeof(block);
    if (!block_valid(a,at)) goto rejected;
    b=(void *)(a->data+at);
    if (!(b->state&ALLOCATED) || address-base-indexed>=b->bytes) goto rejected;
    goto located;
#else
    for (uint64_t at=walk_start;at<a->used;) {
#ifdef NEOCLR_LIVE_WALK_PROFILE
        live_store_walk_counts[0]++;
        if (++walk_steps>live_store_walk_counts[1]) live_store_walk_counts[1]=walk_steps;
#endif
        if (!block_valid(a,at)) goto rejected;
        b=(void *)(a->data+at);
#ifdef NEOCLR_LIVE_WALK_PROFILE
        live_store_walk_counts[2]+=!(b->state&ALLOCATED);
#endif
        uintptr_t payload=(uintptr_t)(b+1);
        if (address>=payload && address-payload<b->bytes && (b->state&ALLOCATED))
            goto located;
        at+=b->span;
    }
    goto rejected;
#endif
located:;
    uintptr_t payload=(uintptr_t)(b+1);
    uint64_t offset=address-payload;
    if (width>b->bytes-offset) goto rejected;
#if !defined(NEOCLR_LIVE_NO_STORE_CACHE) && !defined(NEOCLR_LIVE_LINEAR_STORE)
    remember_base((void *)payload);
#if NEOCLR_LIVE_STORE_RANGES > 1
    if (live_store_last_payload!=(void *)payload) {
        live_store_recent[live_store_recent_next]=live_store_last_payload;
        live_store_recent_next=(live_store_recent_next+1)%(NEOCLR_LIVE_STORE_RANGES-1);
    }
#endif
#ifdef NEOCLR_LIVE_HEADER_PROOF
    if (!reused_header) {
        live_store_last_header.span=b->span;
        live_store_last_header.bytes=b->bytes;
        live_store_last_header.kind=b->kind;
    }
#endif
    live_store_last_payload=(void *)payload;
#endif
    /* No callback, allocation or epoch transition occurs between lookup and
     * this store. Reuse its result; the marker cannot change snapshot identity.
     * Linear lookup and the measurement control retain the original search. */
#if defined(NEOCLR_LIVE_LINEAR_STORE) || defined(NEOCLR_LIVE_REPEAT_SNAPSHOT_LOOKUP)
    int new_allocation=!candidate_active || shadow_find(shadow_owner->job,address)==SIZE_MAX;
#else
    int new_allocation=!snapshot_allocation;
#endif
    if (new_allocation) {
        /* New allocations are excluded from marker reads and are all
         * traced at remark. No publication exemption for old objects. */
        live_store_counts[1]++;
        live_store_bits(destination,bits,width);
        return 0;
    }
    unsigned char value[8];
    live_store_bits(value,bits,width);
    mutation_patch patch={offset,width,value};
#ifdef NEOCLR_LIVE_LINEAR_STORE
    int status=experiment_gc_write(context,(void *)payload,&patch,1);
#else
    int status=live_write_known((void *)payload,b->bytes,b->kind,&patch,1);
#endif
    if (status==GATE_CANCELLED) {
        /* No root walk, sweep, cleanup or managed callback here. Discard
         * detached work before writing; future collection needs a normal
         * root-published boundary. Temporaries may be unpublished now. */
        live_store_cancel_epoch();
        live_store_bits(destination,bits,width);
        return 0;
    }
    if (status) goto rejected;
    live_store_counts[2]++;
    return 0;
rejected:
    live_store_counts[4]++;
    return 3;
}
void experiment_gc_store_lookup_counts(uint64_t *out) {
    memcpy(out,live_store_lookup_counts,sizeof(live_store_lookup_counts));
}
void experiment_gc_store_counts(uint64_t *out) {
    memcpy(out,live_store_counts,sizeof(live_store_counts));
}

/* Trusted generated source is a compiler-owned stack snapshot, never an alias
 * into the destination. Publish payload and initialization marker together. */
int experiment_gc_store_record(neoclr_aot_context *context, void *array,
    uint32_t index, const void *source, uint32_t width) {
    if (!context || owned_heap.arena!=&context->text || !array || !source ||
        (candidate_active && candidate_context!=context)) return 3;
    uint64_t bytes; uint32_t kind;
    if (neoclr_gc_allocation_info_v1(context,array,&bytes,&kind) ||
        kind!=NEOCLR_GC_RECORDS || bytes<24) return 3;
    uint64_t header[3]; memcpy(header,array,24);
    uint64_t length=header[1],lanes=header[2];
    if ((uint32_t)header[0]!=UINT32_C(0x80000005) ||
        (header[0]>>32)>NEOCLR_NATIVE_TYPE_LIMIT ||
        ((header[0]>>32) && lanes!=1) || !lanes || lanes>NEOCLR_NATIVE_LAYOUT_LANES ||
        width!=lanes || length>65536 || index>=length ||
        length>(bytes-24)/(lanes*8+1)) return 3;
    unsigned char initialized=1;
    mutation_patch patches[2]={{24+index*lanes*8,lanes*8,source},
        {24+length*lanes*8+index,1,&initialized}};
    if (candidate_active && shadow_find(shadow_owner->job,(uintptr_t)array)!=SIZE_MAX) {
        int status=live_write_known(array,bytes,kind,patches,2);
        if (status==GATE_CANCELLED) live_store_cancel_epoch();
        else if (status) return 3;
        else { live_store_counts[2]++; return 0; }
    }
    for (unsigned i=0;i<2;i++)
        memcpy((unsigned char *)array+patches[i].offset,patches[i].source,patches[i].length);
    live_store_counts[1]++;
    return 0;
}

/* Text, character and callable-descriptor arrays share traced pointer storage. */
int experiment_gc_store_text(neoclr_aot_context *context, void *array,
    uint32_t index, uint64_t value) {
    if (!context || owned_heap.arena!=&context->text || !array ||
        (candidate_active && candidate_context!=context)) return 3;
    uint64_t bytes; uint32_t kind;
    if (neoclr_gc_allocation_info_v1(context,array,&bytes,&kind) ||
        kind!=NEOCLR_GC_STRINGS || bytes<16) return 3;
    uint64_t header[2]; memcpy(header,array,16);
    uint32_t tag=(uint32_t)header[0];
    unsigned reserved=tag==UINT32_C(0x80000004);
    uint64_t length=header[1];
    if ((!reserved && tag!=UINT32_C(0x80000003)) || index>=length ||
        length>(bytes-16)/(reserved?9:8)) return 3;
    unsigned char initialized=1;
    mutation_patch patches[2]={{16+(uint64_t)index*8,8,&value},
        {16+length*8+index,1,&initialized}};
    unsigned count=reserved?2:1;
    if (candidate_active && shadow_find(shadow_owner->job,(uintptr_t)array)!=SIZE_MAX) {
        int status=live_write_known(array,bytes,kind,patches,count);
        if (status==GATE_CANCELLED) live_store_cancel_epoch();
        else if (status) return 3;
        else { live_store_counts[2]++; return 0; }
    }
    for (unsigned i=0;i<count;i++)
        memcpy((unsigned char *)array+patches[i].offset,patches[i].source,patches[i].length);
    live_store_counts[1]++;
    return 0;
}

/* Private live-GC host query. Not a public hosting API or shared-heap promise.
 * Querying must not allocate, collect, mutate roots or start a worker. Unknown
 * versions return zero. Hosts own and must qualify the implementations behind
 * these declarations; this handshake is compatibility checking, not isolation. */
#define NEOCLR_LIVE_HOST_VERSION UINT32_C(1)
#define NEOCLR_LIVE_NONCOLLECTING_STORE UINT64_C(1)
#define NEOCLR_LIVE_OLD_NEW_LOGGING UINT64_C(2)
#define NEOCLR_LIVE_OWNED_NONMOVING UINT64_C(4)
#define NEOCLR_LIVE_BOUNDARY_FINISH UINT64_C(8)
#define NEOCLR_LIVE_REQUIRED (NEOCLR_LIVE_NONCOLLECTING_STORE | NEOCLR_LIVE_OLD_NEW_LOGGING | NEOCLR_LIVE_OWNED_NONMOVING)
uint64_t experiment_gc_live_capabilities_v1(uint32_t version) {
    return version==NEOCLR_LIVE_HOST_VERSION ? (NEOCLR_LIVE_REQUIRED | NEOCLR_LIVE_BOUNDARY_FINISH | UINT64_C(16)) : 0;
}

void experiment_gc_candidate_counts(uint64_t *out) { memcpy(out, candidate_counts, sizeof(candidate_counts)); out[5] = candidate_active; }

/* Internal live-entry transition. Admission rejects all outstanding ownership;
 * the successful check joins the marker before any storage is invalidated. */
int32_t experiment_gc_prepare_entry_v1(neoclr_aot_context *context) {
    if (!context || owned_heap.arena != &context->text || gc_state.cleanup_active ||
        candidate_phase || !blocks_valid(&context->text)) return 3;
    int32_t status = neoclr_gc_entry_check_v1(context);
    if (status) return status;
    context->static_storage = NULL;
    context->text.used = 0;
    owned_heap.used = owned_heap.free_head = 0;
    memset(owned_heap.bases, 0, sizeof(owned_heap.bases));
#ifdef NEOCLR_LIVE_ALLOCATION_INDEX
    owned_index_reset();
#endif
    /* Keep aggregate statistics and unrelated root state; force fresh pacing. */
    gc_state.pacing.context = NULL;
    return 0;
}

/* Entry cancels without collection: native inputs/results may be unpublished.
 * Collection explicitly requested inside a scope uses existing synchronous roots.
 * Leave never collects or starts an epoch before the caller publishes its result. */
int32_t experiment_gc_native_enter_v1(neoclr_aot_context *context, uint64_t *token) {
    const neoclr_probe_frame *head = neoclr_root_probe_head_v1();
    if (!context || !token || !head || head->context != context ||
        owned_heap.arena != &context->text || gc_state.cleanup_active || candidate_phase || native_scope_depth == 64 ||
        native_scope_serial == UINT64_MAX ||
        (native_scope_depth && native_scope_context != context)) return 3;
    if (candidate_active) {
        candidate_cancel();
        native_scope_counts[1]++;
    }
    native_scope_context = context;
    uint64_t next = ++native_scope_serial;
    native_scope_tokens[native_scope_depth++] = next;
    if (native_scope_depth > native_scope_counts[3]) native_scope_counts[3] = native_scope_depth;
    native_scope_counts[0]++;
    *token = next;
    return 0;
}
int32_t experiment_gc_native_leave_v1(neoclr_aot_context *context, uint64_t token) {
    if (!native_scope_depth || context != native_scope_context ||
        owned_heap.arena != &context->text || !token ||
        native_scope_tokens[native_scope_depth-1] != token) return 3;
    native_scope_tokens[--native_scope_depth] = 0;
    if (!native_scope_depth) native_scope_context = NULL;
    return 0;
}
void experiment_gc_native_scope_counts(uint64_t *out) {
    memcpy(out,native_scope_counts,sizeof(native_scope_counts));
    out[4] = native_scope_depth;
}

/* Exact synchronous leaf adapter; never use this to wrap an async pump.
 * The generated caller supplies stack result storage and publishes after return. */
int32_t experiment_gc_string_slice_utf8_rooted_v1(const neoclr_aot_text *text,
    int32_t start, int32_t length, neoclr_aot_text_arena *arena, void *output) {
    const neoclr_probe_frame *head = neoclr_root_probe_head_v1();
    if (!head || !head->context || !output) return 3;
    neoclr_aot_context *context = (neoclr_aot_context *)head->context;
    if (&context->text != arena) return 3;
    uint64_t token;
    int32_t status = experiment_gc_native_enter_v1(context, &token);
    if (status) return status;
    status = neoclr_string_slice_utf8_rooted_v1(text, start, length, arena, output);
    int32_t leave_status = experiment_gc_native_leave_v1(context, token);
    return leave_status ? leave_status : status;
}
