from pathlib import Path
import json,os,subprocess,hashlib,shutil
root=Path('/Users/robert/Projects/neoclr');target=root/'target/concurrent-workloads';runner=target/'test-runner-conditional-borrow'
for kind in ['ordinary','http']:
 old=target/('borrowed-managed-'+kind+'-build');out=target/('conditional-borrow-'+kind+'-build');out.mkdir(exist_ok=False)
 prior=json.loads((old/'results.json').read_text());result=dict(passed=False,commands=[],inputs={},scope='Conditional borrowed acquisition in mutually exclusive acyclic store regions')
 if kind=='ordinary':result.update(iterations=prior['iterations'],optimizationLevel=prior['optimizationLevel'],cases=[])
 try:
  for sample in (['tasks','collections','arrays'] if kind=='ordinary' else ['plain','json']):
   ordinary=kind=='ordinary'
   case=next(c for c in prior['cases'] if c['sample']==sample) if ordinary else None
   c=next(n for n in case['native'] if n['mode']=='live') if ordinary else next(c for c in prior['commands'] if c['sample']==sample)
   command=c['selectionCommand'].copy();oldobj=Path(command[4]);destination=out/sample/'live.o' if ordinary else out/(sample+'.o');destination.parent.mkdir(exist_ok=True)
   command[4]=str(destination);path=out/(sample+'-command.json');path.write_text(json.dumps(command));audit=out/(sample+'-audit.json')
   env=dict(os.environ,NEOCLR_TEST_OPT_LEVEL='speed',NEOCLR_LIVE_BORROW_STORES='1',NEOCLR_LIVE_CONDITIONAL_BORROW='1',NEOCLR_LIVE_ELIDE_STACK_ARGUMENTS='1',NEOCLR_LIVE_SELECTION_COMMAND=str(path),NEOCLR_LIVE_SELECTION_MODE='live',NEOCLR_LIVE_STACK_ARGUMENT_AUDIT=str(audit))
   invoke=[str(runner),'mutation_store::tests::full_http_selection_compiles_with_live_gc','--exact','--ignored','--nocapture'];x=subprocess.run(invoke,env=env,capture_output=True,text=True,timeout=300)
   row=dict(sample=sample,mode='live',command=invoke,selectionCommand=command,environment={k:v for k,v in env.items() if k.startswith('NEOCLR_')},exitCode=x.returncode,stdout=x.stdout,stderr=x.stderr);result['commands'].append(row);x.check_returncode()
   row['byteIdentical']=oldobj.read_bytes()==destination.read_bytes()
   if ordinary:
    sync=out/sample/'sync.o';shutil.copy2(old/sample/'sync.o',sync)
    result['cases'].append(dict(sample=sample,expectedPerIteration=case['expectedPerIteration'],native=[dict(mode='sync',exitCode=0,reusedFrom=str(old/sample/'sync.o')),row]))
   for p in [oldobj,destination,audit,runner,root/'runtime/codegen/src/mutation_store.rs',root/'runtime/codegen/src/mutation_store_tests.rs']:result['inputs'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
   print(sample,row['byteIdentical'],flush=True)
  result['passed']=True
 finally:(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
