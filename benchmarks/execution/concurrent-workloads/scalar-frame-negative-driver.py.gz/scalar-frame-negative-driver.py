import json,subprocess,tempfile
from pathlib import Path
root=Path('target/concurrent-workloads');results=[]
for fault in ['none','missing-flag','flag-on-control','different-object','missing-trial']:
 with tempfile.TemporaryDirectory() as tmp:
  for suffix in ['ordinary-measure','http-plain','http-json']:
   d=json.loads((root/('scalar-frame-'+suffix)/'results.json').read_text())
   if suffix=='http-plain':
    def command(mode):return next(c['command'] for c in d['commands'] if '-o' in c['command'] and Path(c['command'][c['command'].index('-o')+1]).name==mode)
    if fault=='missing-flag':command('live-inline-index').remove('-DNEOCLR_GC_SCALAR_STORAGE_VALIDATION')
    if fault=='flag-on-control':command('live-previous-inline-index').append('-DNEOCLR_GC_SCALAR_STORAGE_VALIDATION')
    if fault=='different-object':
     c=command('live-inline-index');i=next(i for i,x in enumerate(c) if x.endswith('.o'));c[i]='different.o'
    if fault=='missing-trial':d['trials'].pop(0)
   path=Path(tmp)/('scalar-frame-'+suffix)/'results.json';path.parent.mkdir();path.write_text(json.dumps(d))
  c=['python3','benchmarks/execution/concurrent-workloads/summarize-stack-arguments.py','--root',tmp,'--prefix','scalar-frame','--scalar-validation','--output',str(Path(tmp)/'out.json')]
  x=subprocess.run(c,capture_output=True,text=True);assert (x.returncode==0)==(fault=='none'),(fault,x.stderr)
  results.append(dict(case=fault,exitCode=x.returncode,expectedResult=True))
(root/'scalar-frame-negative.json').write_text(json.dumps(dict(passed=True,cases=results),indent=2)+'\n')
