import json,subprocess
from pathlib import Path
root=Path('/Users/robert/Projects/neoclr');target=root/'target/concurrent-workloads'
prior=json.loads((target/'forward-elision-measure-commands.json').read_text());r=dict(passed=False,commands=[])
try:
 for row in prior['commands']:
  command=row['command'].copy();i=command.index('--output')+1;command[i]=command[i].replace('forward-elision-','scalar-frame-')
  for flag in ['--previous-build','--previous-inline-object']:
   if flag in command:
    i=command.index(flag)+1;command[i]=command[i].replace('stack-elision-','forward-elision-')
  command+=['--compare-scalar-validation']
  x=subprocess.run(command,cwd=root,capture_output=True,text=True,timeout=600)
  r['commands'].append(dict(command=command,exitCode=x.returncode,stdout=x.stdout,stderr=x.stderr));x.check_returncode();print(command[command.index('--output')+1],0,flush=True)
 r['passed']=True
finally:(target/'scalar-frame-measure-commands.json').write_text(json.dumps(r,indent=2)+'\n')
