import json,gzip,os,subprocess,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent
ordinary=json.loads(Path('target/concurrent-workloads/forward-elision-ordinary-build/results.json').read_text())
http=json.loads(gzip.decompress(Path('benchmarks/execution/concurrent-workloads/forward-elision-http-build.json.gz').read_bytes()))
recipes=[c['native'][1] for c in ordinary['cases']]+http['commands']
r={'passed':False,'commands':[]}
try:
 for old in recipes:
  name=old['sample'];command=old['selectionCommand'].copy();previous=Path(command[4]);command[4]=str(out/(name+'.o'));selection=out/(name+'-command.json');selection.write_text(json.dumps(command))
  env=dict(os.environ,**old['environment']);env['NEOCLR_LIVE_SELECTION_COMMAND']=str(selection);env['NEOCLR_LIVE_STACK_ARGUMENT_AUDIT']=str(out/(name+'-audit.json'))
  invoke=old['command'].copy();invoke[0]=str(Path('target/release/deps/neoclr_codegen-12f33f26d2ff4df0').resolve())
  x=subprocess.run(invoke,env=env,capture_output=True,text=True,timeout=300)
  row=dict(sample=name,command=invoke,selectionCommand=command,environment={k:v for k,v in env.items() if k.startswith('NEOCLR_')},exitCode=x.returncode,stdout=x.stdout,stderr=x.stderr);r['commands'].append(row);x.check_returncode()
  row['byteIdentical']=previous.read_bytes()==Path(command[4]).read_bytes();row['previousSha256']=hashlib.sha256(previous.read_bytes()).hexdigest();row['currentSha256']=hashlib.sha256(Path(command[4]).read_bytes()).hexdigest()
  print(name,row['byteIdentical'],flush=True)
 r['passed']=True
finally:(out/'build.json').write_text(json.dumps(r,indent=2)+'\n')
