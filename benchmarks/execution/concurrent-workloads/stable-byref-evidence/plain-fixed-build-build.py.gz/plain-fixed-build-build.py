import json,os,subprocess,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent
original=json.loads(Path('target/concurrent-workloads/forward-elision-http-build/results.json').read_text())
source=next(c for c in original['commands'] if c['sample']=='plain')
r={'passed':False,'commands':[],'inputs':{}}
try:
 for enabled in [False,True]:
  name='on' if enabled else 'off';command=source['selectionCommand'].copy();command[4]=str(out/(name+'.o'));recipe=out/(name+'.json');recipe.write_text(json.dumps(command))
  env={k:v for k,v in os.environ.items() if not k.startswith('NEOCLR_')};env.update(NEOCLR_TEST_OPT_LEVEL='speed',NEOCLR_LIVE_SELECTION_MODE='live',NEOCLR_LIVE_SELECTION_COMMAND=str(recipe),NEOCLR_LIVE_FORWARD_STACK_ARGUMENTS='1',NEOCLR_LIVE_ELIDE_STACK_ARGUMENTS='1',NEOCLR_LIVE_ELIDE_FORWARDED_STACK_ARGUMENTS='1',NEOCLR_LIVE_STACK_ARGUMENT_AUDIT=str(out/(name+'-audit.json')))
  if enabled:env['NEOCLR_LIVE_SSA_BYREF_ARGUMENTS']='1'
  cmd=source['command'].copy();cmd[0]=str(Path('target/release/deps/neoclr_codegen-12f33f26d2ff4df0').resolve())
  x=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=300);r['commands'].append(dict(enabled=enabled,command=cmd,selectionCommand=command,environment={k:v for k,v in env.items() if k.startswith('NEOCLR_')},exitCode=x.returncode,stdout=x.stdout,stderr=x.stderr));x.check_returncode()
  for item in [*command,cmd[0],str(recipe),__file__]:
   p=Path(item)
   if p.is_file():r['inputs'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 old=Path(source['selectionCommand'][4]);r['controlByteIdentical']=(out/'off.o').read_bytes()==old.read_bytes();assert r['controlByteIdentical']
 r['passed']=True
finally:(out/'results.json').write_text(json.dumps(r,indent=2)+'\n')
