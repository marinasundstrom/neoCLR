from pathlib import Path
import json,subprocess,os,hashlib,gzip
out=Path(__file__).resolve().parent;r={'passed':False,'commands':[]}
runner=str(Path('target/release/deps/neoclr_codegen-12f33f26d2ff4df0').resolve());env=dict(os.environ,NEOCLR_LIVE_SSA_BYREF_ARGUMENTS='1')
try:
 for filter in ['stable_byref_tests','mutation_store::']:
  cmd=[runner,filter];x=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=30);r['commands'].append(dict(command=cmd,exitCode=x.returncode,stdout=x.stdout,stderr=x.stderr));x.check_returncode()
 previous=json.loads((out/'results.json').read_text())['commands'][0]
 env=dict(os.environ,**previous['environment']);selection=json.loads((out/'selection.json').read_text());selection[4]=str(out/'final.o');(out/'final-selection.json').write_text(json.dumps(selection))
 env.update(NEOCLR_LIVE_SELECTION_COMMAND=str(out/'final-selection.json'),NEOCLR_LIVE_STACK_ARGUMENT_AUDIT=str(out/'final-audit.json'),NEOCLR_LIVE_STORE_IR_OUTPUT=str(out/'final.clif'))
 x=subprocess.run(previous['command'],env=env,capture_output=True,text=True,timeout=180);r['commands'].append(dict(command=previous['command'],exitCode=x.returncode,stdout=x.stdout,stderr=x.stderr));x.check_returncode()
 r['byteIdentical']=Path(selection[4]).read_bytes()==(out/'live.o').read_bytes();assert r['byteIdentical'];r['sourceSha256']=hashlib.sha256(Path('runtime/codegen/src/values.rs').read_bytes()).hexdigest();r['passed']=True
finally:(out/'final-check.json').write_text(json.dumps(r,indent=2)+'\n')
print(r['passed'],r['byteIdentical'])
