import gzip,json,subprocess,os,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent
old=json.loads(gzip.decompress(Path('benchmarks/execution/concurrent-workloads/scalar-frame-ordinary-jit.json.gz').read_bytes()))
build=json.loads(Path('target/concurrent-workloads/forward-elision-ordinary-build/results.json').read_text());expected={c['sample']:c['expectedPerIteration']*build['iterations'] for c in build['cases']}
r={'passed':False,'trials':[],'inputs':{}}
try:
 for t in old['trials']:
  recipe=out/(t['sample']+'-jit.json');recipe.write_text(json.dumps(t['selectionCommand']))
  env=dict(os.environ,NEOCLR_TEST_OPT_LEVEL='speed',NEOCLR_LIVE_SELECTION_COMMAND=str(recipe),NEOCLR_LIVE_SELECTION_MODE='live',NEOCLR_LIVE_SSA_BYREF_ARGUMENTS='1')
  for k in ['NEOCLR_LIVE_ELIDE_STACK_ARGUMENTS','NEOCLR_LIVE_ELIDE_FORWARDED_STACK_ARGUMENTS','NEOCLR_LIVE_FORWARD_STACK_ARGUMENTS']:
   env.pop(k,None)
   if t['elision']:env[k]='1'
  cmd=t['command'].copy();cmd[0]=str(Path('target/release/deps/neoclr_codegen-12f33f26d2ff4df0').resolve())
  x=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);row=dict(sample=t['sample'],elision=t['elision'],command=cmd,exitCode=x.returncode,stdout=x.stdout,stderr=x.stderr);r['trials'].append(row);x.check_returncode()
  assert expected[t['sample']] in x.stdout
  def numbers(label):return list(map(int,next(l.split()[1:] for l in x.stderr.splitlines() if l.startswith(label+' '))))
  counts=numbers('CANDIDATE');index=numbers('INDEX_METADATA');assert counts[0]==counts[1]+counts[2] and counts[1]>0 and counts[5]==0 and index[1]==0
  result=json.loads(next(l[11:] for l in x.stderr.splitlines() if l.startswith('JIT_RESULT ')));assert result['guestExitCode']==0
  row.update(candidateCounts=counts,indexMetadata=index)
  for item in [*t['selectionCommand'],cmd[0],str(recipe)]:
   p=Path(item)
   if p.is_file():r['inputs'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
  print(t['sample'],t['elision'],counts[1],flush=True)
 r['passed']=True
finally:(out/'jit-results.json').write_text(json.dumps(r,indent=2)+'\n')
