import json,subprocess,os,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent;origin=Path('target/http-result-origin');r={'passed':False,'sample':'plain','stableByrefs':True,'commands':[],'inputs':{}}
try:
 previous=json.loads((origin/'result.json').read_text());selection=json.loads((origin/'selection.json').read_text());selection[4]=str(out/'live.o');(out/'selection.json').write_text(json.dumps(selection))
 env=dict(os.environ,**previous['environment']);env.update(NEOCLR_LIVE_SELECTION_COMMAND=str(out/'selection.json'),NEOCLR_LIVE_STACK_ARGUMENT_AUDIT=str(out/'audit.json'),NEOCLR_LIVE_STORE_IR_OUTPUT=str(out/'855.clif'),NEOCLR_LIVE_SSA_BYREF_ARGUMENTS='1')
 cmd=previous['command'];x=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180);r['commands'].append(dict(command=cmd,environment={k:v for k,v in env.items() if k.startswith('NEOCLR_')},exitCode=x.returncode,stdout=x.stdout,stderr=x.stderr));x.check_returncode()
 base=Path('target/http-owner-forwarded').resolve();build=json.loads((base/'results.json').read_text());cmd=next(c['command'].copy() for c in build['commands'] if '-o' in c['command'] and Path(c['command'][c['command'].index('-o')+1]).name=='live-1')
 cmd=[str(out/'live.o') if x==str(base/'live.o') else x for x in cmd];cmd[cmd.index('-o')+1]=str(out/'live-1')
 x=subprocess.run(cmd,capture_output=True,text=True,timeout=60);r['commands'].append(dict(command=cmd,exitCode=x.returncode,stdout=x.stdout,stderr=x.stderr));x.check_returncode()
 for item in cmd:
  p=Path(item)
  if p.is_file():r['inputs'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 r['passed']=True
finally:(out/'results.json').write_text(json.dumps(r,indent=2)+'\n')
