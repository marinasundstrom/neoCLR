from pathlib import Path
import urllib.request,json,hashlib,subprocess,datetime
run=json.loads(subprocess.check_output(['gh','run','view','41141936054','--json','status,conclusion,headSha,url']))
assert run['status']=='completed' and run['conclusion']=='success',run
p=Path('docs/validation/release-20261030/publication.json');d=json.loads(p.read_text());d['websiteDeployment']=run
checks=[]
for path,needles in [('', ['v0.1.0-preview.19']),('try/',['neoclr-preview19-osx-arm64.tar.gz','neoclr-preview19-win-x64.tar.gz','PostgreSQL']),('benchmarks/http/',['Preview 19','31 October 2026']),('benchmarks/execution/',['Preview 19','31 October 2026'])]:
 url='https://marinasundstrom.github.io/neoCLR/'+path
 req=urllib.request.Request(url,headers={'Cache-Control':'no-cache'})
 with urllib.request.urlopen(req) as r:body=r.read();status=r.status
 text=body.decode();assert status==200 and all(x in text for x in needles),(url,needles)
 checks.append(dict(url=url,status=status,contains=needles,sha256=hashlib.sha256(body).hexdigest()))
d['liveWebsiteChecks']=checks;d['websiteVerifiedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(d,indent=2)+'\n');print('PASS: website deployed; four live pages show Preview 19')
