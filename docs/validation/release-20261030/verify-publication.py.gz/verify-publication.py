from pathlib import Path
import json,hashlib,subprocess,datetime,urllib.request
assets=Path('target/releases/preview19-20261030')
r=json.loads(subprocess.check_output(['gh','api','repos/marinasundstrom/neoCLR/releases/429565706']))
files={p.name:p for p in assets.iterdir()};assert len(r['assets'])==len(files)==12
for a in r['assets']:
 p=files[a['name']]
 with p.open('rb') as f: h=hashlib.file_digest(f,'sha256').hexdigest()
 assert a['state']=='uploaded' and a['size']==p.stat().st_size and a['digest']=='sha256:'+h,a['name']
print('All 12 remote asset hashes and sizes match; draft=',r['draft'])
if not r['draft']:
 a=next(a for a in r['assets'] if a['name']=='SHA256SUMS')
 assert urllib.request.urlopen(a['browser_download_url']).read()==(assets/'SHA256SUMS').read_bytes()
 report={'verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'releaseUrl':r['html_url'],'tag':r['tag_name'],'commit':r['target_commitish'],'publishedAt':r['published_at'],'prerelease':r['prerelease'],'allAssetHashesAndSizesMatch':True,'publicChecksumDownloadMatches':True,'assets':[{'name':a['name'],'size':a['size'],'digest':a['digest'],'url':a['browser_download_url']} for a in r['assets']]}
 Path('docs/validation/release-20261030/publication.json').write_text(json.dumps(report,indent=2)+'\n')
 print('Public checksum download verified')
