from pathlib import Path
import subprocess, os, json, hashlib, xml.etree.ElementTree as ET
import socket, importlib.util
root=Path.cwd()
bundle=root/'target/http-header-noop/inputs/bundle'
out=root/'target/composite-testing-negative-ordinal-20261101'
out.mkdir(exist_ok=False)
project=root/'docs/experiments/composite-formatting/Main.rvnproj'
source=project.parent/'Main.rvn'
original=source.read_text()
old='"retained:tag"' 
assert original.count(old)==1
negative=out/'Main.rvn'
negative.write_text(original.replace(old, '"wrong"' ))
tree=ET.parse(project)
for item in tree.iter('Compile'):
 path=(project.parent/item.attrib['Include']).resolve()
 item.set('Include',str(negative if path==source else path))
negative_project=out/'Negative.rvnproj'
tree.write(negative_project)
compile_command=['dotnet',str(bundle/'sdk/tools/rvnc/rvnc.dll'),'neoclr','--project',str(negative_project)]
built=subprocess.run(compile_command,env=dict(os.environ,NeoClrBundleRoot=str(bundle)),capture_output=True,text=True,timeout=180)
(out/'compile.stdout.log').write_text(built.stdout)
(out/'compile.stderr.log').write_text(built.stderr)
assert built.returncode==0,built.stderr
image=next(Path(line.removeprefix('Native build output: ')) for line in built.stdout.splitlines() if line.startswith('Native build output: '))
lib=bundle/'lib';catalog=json.loads((lib/'bundle.json').read_text())
command=[str(bundle/'bin/neoclr'),'run',str(image),'--system',str(lib/catalog['runtimeSeed'])]
for name in catalog['assemblyNames']:command+=['--module',str(lib/(name+'.dll'))]
command+=['--object-root',str(lib/'System.Runtime.dll'),'--instructions','2000000000','--execution','interpreter']
result=subprocess.run(command,capture_output=True,text=True,timeout=120)
expected=("FAIL Composite formatting preserves text dispatch retained values and console output: Expected 'wrong', actual 'retained:tag'\n"
          "Tests: 1, passed: 0, failed: 1, skipped: 0\n")
passed=result.returncode==1 and result.stdout==expected and not result.stderr
report=dict(passed=bool(passed),mutation='Expected retained payload text retained:tag -> wrong in isolated copy',command=command,compileCommand=compile_command,exitCode=result.returncode,stdout=result.stdout,stderr=result.stderr,sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,negative,project]})
(out/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(result.stdout);assert passed,report
