from pathlib import Path
import subprocess, os, json, hashlib, xml.etree.ElementTree as ET
import socket, importlib.util
root=Path.cwd()
bundle=root/'target/http-header-noop/inputs/bundle'
out=root/'target/http-reason-testing-negative-fixed-20261101'
out.mkdir(exist_ok=False)
project=root/'docs/experiments/http-message-metadata/ReasonPhrase.rvnproj'
source=project.parent/'ReasonPhrase.rvn'
original=source.read_text()
old='Assert.Equal("x", text)' 
assert original.count(old)==1
negative=out/'ReasonPhrase.rvn'
negative.write_text(original.replace(old, 'Assert.Equal("y", text)' ))
tree=ET.parse(project)
for item in tree.iter('Compile'):
 path=(project.parent/item.attrib['Include']).resolve()
 item.set('Include',str(negative if path==source else path))
negative_project=out/'Negative.rvnproj'
tree.write(negative_project)
compile_command=['dotnet',str(bundle/'sdk/tools/rvnc/rvnc.dll'),'neoclr','--project',str(negative_project)]
built=subprocess.run(compile_command,env=dict(os.environ,NeoClrBundleRoot=str(bundle)),capture_output=True,text=True,timeout=180)
(out/'compile.stdout.log').write_text(built.stdout)
(out/'compile.stderr.log').write_text(built.stderr)
assert built.returncode==0,built.stderr
image=next(Path(line.removeprefix('Native build output: ')) for line in built.stdout.splitlines() if line.startswith('Native build output: '))
lib=bundle/'lib';catalog=json.loads((lib/'bundle.json').read_text())
command=[str(bundle/'bin/neoclr'),'run',str(image),'--system',str(lib/catalog['runtimeSeed'])]
for name in catalog['assemblyNames']:command+=['--module',str(lib/(name+'.dll'))]
command+=['--object-root',str(lib/'System.Runtime.dll'),'--instructions','2000000000','--execution','interpreter']
validator=project.parent/'validate_reason.py'
code=validator.read_text().replace('PASS HTTP response metadata preserves status version and reason phrases', "FAIL HTTP response metadata preserves status version and reason phrases: Expected \\'y\\', actual \\'x\\'").replace('Tests: 1, passed: 1, failed: 0, skipped: 0','Tests: 1, passed: 0, failed: 1, skipped: 0')
namespace={'__file__':str(validator),'__name__':'negative_control'}
exec(compile(code,str(validator),'exec'),namespace)
BaseGuest=namespace['Guest']
class FailureGuest(BaseGuest):
 def finish(self,allowed_stderr=(b'',)):
  status=self.process.wait(timeout=self.timeout)
  self.reader.join(timeout=5)
  stderr=self.errors()
  assert status==1 and not stderr and not self.reader.is_alive(),(status,stderr)
  return stderr
namespace['Guest']=FailureGuest
command+=['--']
receipt=namespace['run'](command,'interpreter')
report=dict(passed=True,mutation='Expected final streamed body x -> y in isolated copy; all seven peer exchanges retained',command=command,compileCommand=compile_command,receipt=receipt,sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,negative,project.parent/'Main.rvn',validator]})
(out/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
