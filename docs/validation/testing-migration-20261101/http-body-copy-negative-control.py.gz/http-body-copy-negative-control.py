from pathlib import Path
import subprocess, os, json, hashlib, xml.etree.ElementTree as ET
import socket, importlib.util
root=Path.cwd()
bundle=root/'target/http-header-noop/inputs/bundle'
out=root/'target/http-body-copy-testing-negative-20261101'
out.mkdir(exist_ok=False)
project=root/'docs/experiments/http-content-copy/Probe.rvnproj'
source=project.parent/'Tests.rvn'
original=source.read_text()
old='destination.GetLength() is Ok(2049L)'
assert original.count(old)==1
negative=out/'Tests.rvn'
negative.write_text(original.replace(old,'destination.GetLength() is Ok(2050L)'))
tree=ET.parse(project)
for item in tree.iter('Compile'):
 path=(project.parent/item.attrib['Include']).resolve()
 item.set('Include',str(negative if path==source else path))
negative_project=out/'Negative.rvnproj'
tree.write(negative_project)
compile_command=['dotnet',str(bundle/'sdk/tools/rvnc/rvnc.dll'),'neoclr','--project',str(negative_project)]
built=subprocess.run(compile_command,env=dict(os.environ,NeoClrBundleRoot=str(bundle)),capture_output=True,text=True,timeout=180)
(out/'compile.stdout.log').write_text(built.stdout)
(out/'compile.stderr.log').write_text(built.stderr)
assert built.returncode==0,built.stderr
image=next(Path(line.removeprefix('Native build output: ')) for line in built.stdout.splitlines() if line.startswith('Native build output: '))
lib=bundle/'lib';catalog=json.loads((lib/'bundle.json').read_text())
command=[str(bundle/'bin/neoclr'),'run',str(image),'--system',str(lib/catalog['runtimeSeed'])]
for name in catalog['assemblyNames']:command+=['--module',str(lib/(name+'.dll'))]
command+=['--object-root',str(lib/'System.Runtime.dll'),'--instructions','2000000000','--execution','interpreter']
import sys
sys.path.insert(0,str(root/'benchmarks/framework'))
from process import Guest
peer={}
with socket.socket() as listener:
 listener.bind(('127.0.0.1',0));listener.listen(1);listener.settimeout(180)
 url='http://127.0.0.1:'+str(listener.getsockname()[1])+'/'
 command+=['--',url]
 guest=Guest(command,timeout=240)
 try:
  with listener.accept()[0] as connection:
   connection.settimeout(180);request=b''
   while b'\r\n\r\n' not in request:
    part=connection.recv(4096)
    assert part, 'Early request EOF'
    request+=part
   assert request.startswith(b'GET / HTTP/1.1\r\n')
   connection.sendall(b'HTTP/1.1 200 OK\r\nContent-Length: 2049\r\nConnection: close\r\n\r\n')
   guest.line(b'HEADERS')
   peer['headersBeforeBody']=True
   connection.sendall(b'x'*2049)
   peer['closed']=connection.recv(1)==b''
  guest.line(b'FAIL Incoming HTTP body copy preserves framing bytes and single consumption: Copied body length is 2049 bytes')
  guest.line(b'Tests: 1, passed: 0, failed: 1, skipped: 0')
  code=guest.process.wait(timeout=240)
  guest.reader.join(timeout=5)
  stderr=guest.errors()
  stdout=b''.join(guest.output).decode()
 finally:guest.close()
expected=('HEADERS\nFAIL Incoming HTTP body copy preserves framing bytes and single consumption: Copied body length is 2049 bytes\n'
          'Tests: 1, passed: 0, failed: 1, skipped: 0\n')
passed=code==1 and stdout==expected and not stderr and peer.get('closed')
report=dict(passed=bool(passed),mutation='Expected copied length 2049 -> 2050 in isolated copy; stops after first delivered body',command=command,compileCommand=compile_command,exitCode=code,stdout=stdout,stderr=stderr.decode(),peer=peer,sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,negative,project.parent/'Main.rvn']})
(out/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(stdout);assert passed,report
