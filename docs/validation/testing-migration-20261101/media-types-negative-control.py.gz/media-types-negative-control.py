from pathlib import Path
import subprocess, os, json, hashlib, xml.etree.ElementTree as ET
import socket, importlib.util
root=Path.cwd()
bundle=root/'target/http-header-noop/inputs/bundle'
out=root/'target/media-types-testing-negative-20261101'
out.mkdir(exist_ok=False)
project=root/'docs/experiments/media-types/Server.rvnproj'
source=project.parent/'Server.rvn'
original=source.read_text()
old='Assert.Equal("AbC; 123", boundary)'
assert original.count(old)==1
negative=out/'Server.rvn'
negative.write_text(original.replace(old,'Assert.Equal("abc; 123", boundary)'))
tree=ET.parse(project)
for item in tree.iter('Compile'):
 path=(project.parent/item.attrib['Include']).resolve()
 item.set('Include',str(negative if path==source else path))
negative_project=out/'Negative.rvnproj'
tree.write(negative_project)
compile_command=['dotnet',str(bundle/'sdk/tools/rvnc/rvnc.dll'),'neoclr','--project',str(negative_project)]
built=subprocess.run(compile_command,env=dict(os.environ,NeoClrBundleRoot=str(bundle)),capture_output=True,text=True,timeout=180)
(out/'compile.stdout.log').write_text(built.stdout)
(out/'compile.stderr.log').write_text(built.stderr)
assert built.returncode==0,built.stderr
image=next(Path(line.removeprefix('Native build output: ')) for line in built.stdout.splitlines() if line.startswith('Native build output: '))
lib=bundle/'lib';catalog=json.loads((lib/'bundle.json').read_text())
command=[str(bundle/'bin/neoclr'),'run',str(image),'--system',str(lib/catalog['runtimeSeed'])]
for name in catalog['assemblyNames']:command+=['--module',str(lib/(name+'.dll'))]
command+=['--object-root',str(lib/'System.Runtime.dll'),'--instructions','100000000','--execution','interpreter']
spec=importlib.util.spec_from_file_location('http_json',root/'scripts/verify-native-http-json.py')
http_json=importlib.util.module_from_spec(spec);spec.loader.exec_module(http_json)
process=http_json.start_process(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
try:
 port=int(http_json.read_port(process.stdout,timeout=30))
 with socket.create_connection(('127.0.0.1',port),timeout=10) as connection:
  connection.sendall(f'POST /items HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nContent-Type: multipart/form-data; boundary="AbC; 123"\r\nContent-Length: 0\r\n\r\n'.encode())
  response=b''
  while True:
   part=connection.recv(4096)
   if not part:break
   response+=part
 stdout,stderr=process.communicate(timeout=20)
 wire_ok=b'Content-Type: application/problem+json\r\n' in response and response.endswith(b'\r\n\r\n{}')
 expected=("FAIL Media type server preserves quoted boundary case and value: Expected 'abc; 123', actual 'AbC; 123'\n"
           'Tests: 1, passed: 0, failed: 1, skipped: 0\n')
 passed=process.returncode==1 and stdout.decode()==expected and not stderr and wire_ok
 report=dict(passed=passed,mutation='Expected boundary case AbC; 123 -> abc; 123 in isolated copy',command=command,compileCommand=compile_command,exitCode=process.returncode,stdout=stdout.decode(),stderr=stderr.decode(),responseHex=response.hex(),wireValidated=wire_ok,sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,negative,project.parent/'Reporting.rvn']})
 (out/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
 print(stdout.decode());assert passed,report
finally:http_json.stop_process(process)
