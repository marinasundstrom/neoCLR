from pathlib import Path
import subprocess, os, json, hashlib, xml.etree.ElementTree as ET
import socket, importlib.util
root=Path.cwd()
bundle=root/'target/http-header-noop/inputs/bundle'
out=root/'target/http-timeout-network-testing-negative-20261101'
out.mkdir(exist_ok=False)
project=root/'docs/experiments/http-timeout/Network.rvnproj'
source=project.parent/'Network.rvn'
original=source.read_text()
old='Assert.Equal(200, (int)response.StatusCode)'
assert original.count(old)==1
negative=out/'Network.rvn'
negative.write_text(original.replace(old,'Assert.Equal(201, (int)response.StatusCode)'))
tree=ET.parse(project)
for item in tree.iter('Compile'):
 path=(project.parent/item.attrib['Include']).resolve()
 item.set('Include',str(negative if path==source else path))
negative_project=out/'Negative.rvnproj'
tree.write(negative_project)
compile_command=['dotnet',str(bundle/'sdk/tools/rvnc/rvnc.dll'),'neoclr','--project',str(negative_project)]
built=subprocess.run(compile_command,env=dict(os.environ,NeoClrBundleRoot=str(bundle)),capture_output=True,text=True,timeout=180)
(out/'compile.stdout.log').write_text(built.stdout)
(out/'compile.stderr.log').write_text(built.stderr)
assert built.returncode==0,built.stderr
image=next(Path(line.removeprefix('Native build output: ')) for line in built.stdout.splitlines() if line.startswith('Native build output: '))
lib=bundle/'lib';catalog=json.loads((lib/'bundle.json').read_text())
command=[str(bundle/'bin/neoclr'),'run',str(image),'--system',str(lib/catalog['runtimeSeed'])]
for name in catalog['assemblyNames']:command+=['--module',str(lib/(name+'.dll'))]
command+=['--object-root',str(lib/'System.Runtime.dll'),'--instructions','100000000','--execution','interpreter']
import threading, time
peer={}
with socket.socket() as listener:
 listener.bind(('127.0.0.1',0));listener.listen(1);listener.settimeout(20)
 url='http://127.0.0.1:'+str(listener.getsockname()[1])+'/'
 def serve():
  try:
   with listener.accept()[0] as connection:
    connection.settimeout(5);request=b''
    while b'\r\n\r\n' not in request:
     part=connection.recv(4096)
     if not part:raise RuntimeError('Client closed before request headers')
     request+=part
    peer['requestBytes']=len(request)
    time.sleep(.35)
    connection.sendall(b'HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\n{}')
    peer['closed']=connection.recv(1)==b''
  except Exception as error:peer['error']=str(error)
 worker=threading.Thread(target=serve,daemon=True);worker.start()
 command+=['--',url,'success']
 result=subprocess.run(command,capture_output=True,text=True,timeout=30)
 worker.join(timeout=6)
expected=('FAIL Disabled timeout permits a delayed network response: Expected 201, actual 200\n'
          'Tests: 1, passed: 0, failed: 1, skipped: 0\n')
passed=result.returncode==1 and result.stdout==expected and not result.stderr and peer.get('closed') and not peer.get('error')
report=dict(passed=bool(passed),mutation='Expected delayed response status 200 -> 201 in isolated copy',command=command,compileCommand=compile_command,exitCode=result.returncode,stdout=result.stdout,stderr=result.stderr,peer=peer,sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,negative,project.parent/'NetworkMain.rvn']})
(out/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(result.stdout);assert passed,report
