from pathlib import Path
import subprocess, os, json, hashlib, xml.etree.ElementTree as ET
import importlib.util, inspect
root=Path.cwd();bundle=root/'target/http-header-noop/inputs/bundle'
out=root/'target/filewatch-testing-negative-20261101';out.mkdir(exist_ok=False)
project=root/'runtime/System.Runtime/test/FileSystemWatcherTests/FileSystemWatcherTests.rvnproj'
source=project.parent/'NeoClr/RuntimeTests/Tests.rvn';original=source.read_text()
old='Assert.True(!watcher.EnableRaisingEvents, "Starts disabled")';assert original.count(old)==1
negative=out/'Tests.rvn';negative.write_text(original.replace(old,'Assert.True(watcher.EnableRaisingEvents, "Starts disabled")'))
tree=ET.parse(project)
for group in tree.iter('ItemGroup'):
 for item in list(group):
  if item.tag!='Compile':continue
  pattern=item.attrib['Include'];group.remove(item)
  for path in sorted(project.parent.glob(pattern)):
   ET.SubElement(group,'Compile',Include=str(negative if path.resolve()==source else path.resolve()))
negative_project=out/'Negative.rvnproj';tree.write(negative_project)
compile_command=['dotnet',str(bundle/'sdk/tools/rvnc/rvnc.dll'),'neoclr','--project',str(negative_project)]
built=subprocess.run(compile_command,env=dict(os.environ,NeoClrBundleRoot=str(bundle)),capture_output=True,text=True,timeout=180)
(out/'compile.stdout.log').write_text(built.stdout);(out/'compile.stderr.log').write_text(built.stderr)
assert built.returncode==0,built.stderr
image=next(Path(line.removeprefix('Native build output: ')) for line in built.stdout.splitlines() if line.startswith('Native build output: '))
lib=bundle/'lib';catalog=json.loads((lib/'bundle.json').read_text())
command=[str(bundle/'bin/neoclr'),'run',str(image),'--system',str(lib/catalog['runtimeSeed'])]
for name in catalog['assemblyNames']:command+=['--module',str(lib/(name+'.dll'))]
command+=['--object-root',str(lib/'System.Runtime.dll'),'--instructions','100000000','--execution','interpreter','--']
validator=root/'scripts/validate-filewatch.py'
spec=importlib.util.spec_from_file_location('filewatch',validator);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
# Reuse the real filesystem driver, changing only the expected failure transcript
# and exit status in this isolated in-memory copy; the validator file is unchanged.
check=inspect.getsource(module.execute)
old_line='PASS Watchers start disabled and disposal permanently closes them'
assert check.count(old_line)==1 and check.count('code != 0')==1
check=check.replace(old_line,'FAIL Watchers start disabled and disposal permanently closes them: Starts disabled').replace('Tests: 3, passed: 3, failed: 0, skipped: 0','Tests: 3, passed: 2, failed: 1, skipped: 0').replace('code != 0','code != 1')
exec(compile(check,'<isolated-negative-driver>','exec'),module.__dict__)
result=module.execute(command,out/'files',dict(os.environ),'interpreter')
report=dict(passed=True,mutation='Require initially enabled watcher in isolated copy',command=command,compileCommand=compile_command,**result,sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,negative,validator,source.with_name('Main.rvn')]})
(out/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
