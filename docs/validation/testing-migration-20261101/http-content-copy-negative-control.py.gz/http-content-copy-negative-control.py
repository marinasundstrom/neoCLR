from pathlib import Path
import subprocess, os, json, hashlib, xml.etree.ElementTree as ET
root = Path.cwd()
bundle = root / 'target/http-message-surfaces/inputs9/bundle'
out = root / 'target/http-content-copy-testing-negative-20261101'
out.mkdir(exist_ok=False)
project = root / 'runtime/System.Web/test/HttpContentCopyTests/HttpContentCopyTests.rvnproj'
source = project.parent / 'NeoClr/RuntimeTests/Tests.rvn'
original = source.read_text()
old = '_ = Assert.Equal(2500, output.Count)?'
assert original.count(old) == 1
negative = out / 'Tests.rvn'
negative.write_text(original.replace(old, '_ = Assert.Equal(2501, output.Count)?'))
tree = ET.parse(project)
for item in tree.iter('Compile'):
    path = (project.parent / item.attrib['Include']).resolve()
    item.set('Include', str(negative if path == source else path))
negative_project = out / 'Negative.rvnproj'
tree.write(negative_project)
compile_command = ['dotnet', str(bundle / 'sdk/tools/rvnc/rvnc.dll'), 'neoclr', '--project', str(negative_project)]
built = subprocess.run(compile_command, env=dict(os.environ, NeoClrBundleRoot=str(bundle)), capture_output=True, text=True, timeout=180)
(out / 'compile.stdout.log').write_text(built.stdout)
(out / 'compile.stderr.log').write_text(built.stderr)
assert built.returncode == 0, built.stderr
image = next(Path(line.removeprefix('Native build output: ')) for line in built.stdout.splitlines() if line.startswith('Native build output: '))
lib = bundle / 'lib'
catalog = json.loads((lib / 'bundle.json').read_text())
command = [str(bundle / 'bin/neoclr'), 'run', str(image), '--system', str(lib / catalog['runtimeSeed'])]
for name in catalog['assemblyNames']:
    command += ['--module', str(lib / (name + '.dll'))]
command += ['--object-root', str(lib / 'System.Runtime.dll'), '--jit-host', str(bundle / 'bin/neoclr-jit-host.dylib'), '--jit-compiler', str(bundle / 'bin/neoclr-codegen')]
result = subprocess.run(command, capture_output=True, text=True, timeout=180)
passed = (result.returncode == 1 and result.stderr in ('', 'warning: DAM2004: dynamic-dispatch implementation bodies are not analyzed; reflection inside them may require explicit retention\n') and result.stdout.startswith('FAIL HTTP content copy awaits writes before reading more and preserves ownership: ') and result.stdout.count('\nPASS ') == 7 and result.stdout.endswith('Tests: 8, passed: 7, failed: 1, skipped: 0\n'))
report = dict(passed=passed, mutation='Expected copied count 2500 -> 2501 in isolated copy; all lifecycles still execute', command=command, compileCommand=compile_command, exitCode=result.returncode, stdout=result.stdout, stderr=result.stderr, sources={str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [source, negative, project.parent / 'NeoClr/RuntimeTests/Main.rvn']})
(out / 'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(result.stdout)
assert passed, report
