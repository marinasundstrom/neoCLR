//! Explicit closed-world direct-call selection for reference-free applications.
//! This is bounded code selection, not a general reflection-aware trimmer.
use neoclr::metadata::{FunctionRef, Instruction as Op, MemberId, Type, TypeDefId};
use serde_json::{Value, json};
use std::collections::BTreeSet;
type Error = Box<dyn std::error::Error>;

/// Pointer-free, single-lane elements in the private scalar-array layout.
/// Byte retains its existing compact storage and native I/O contract.
pub(crate) fn scalar_array_element(t: &Type) -> bool {
    matches!(
        t,
        Type::Single
            | Type::Double
            | Type::Int32
            | Type::UInt32
            | Type::Int64
            | Type::UInt64
            | Type::SByte
            | Type::Int16
            | Type::UInt16
            | Type::Boolean
            | Type::Void
            | Type::IntPtr
            | Type::UIntPtr
    )
}

/// Metadata-only owner of static methods; never an executable reference value.
pub(crate) fn static_owner(t: &neoclr::metadata::TypeDef) -> bool {
    t.is_reference_type
        && t.is_abstract
        && t.is_sealed
        && t.representation == neoclr::metadata::Representation::Record
        && t.fields.is_empty()
        && t.base.is_none()
        && t.enum_info.is_none()
        && t.generic_parameters.is_empty()
        && t.generic_constraints.is_empty()
        && t.packing.is_none()
        && t.minimum_size.is_none()
}

/// Shared preparation for native emission and read-only admission inspection.
pub fn prepare(input: &neoclr::Module, root: &str) -> Result<(neoclr::Module, Value), Error> {
    validate_source(input, true)?;
    if input
        .functions
        .iter()
        .any(|f| object_dispatch_contract(f) || class_contract(input, f))
    {
        neoclr::LoadedProgram::new(input)
            .and_then(|p| p.verify())
            .map_err(|e| e.to_string())?;
    }
    let mut execution = input.clone();
    neoclr::value_defaults::materialize(&mut execution).map_err(|e| e.to_string())?;
    let input = &execution;
    if input.types.iter().any(|t| !t.generic_parameters.is_empty())
        || input
            .functions
            .iter()
            .any(|f| !f.generic_parameters.is_empty())
    {
        let (expanded, specialization) = super::specialization::expand(input, root)?;
        if input.types.iter().any(|t| {
            (t.is_reference_type || t.representation == neoclr::metadata::Representation::Interface)
                && !t.generic_parameters.is_empty()
        }) || specialization["methods"]
            .as_array()
            .unwrap()
            .iter()
            .any(|m| !m["arguments"].as_array().unwrap().is_empty())
            || specialization["types"]
                .as_array()
                .unwrap()
                .iter()
                .any(|t| t["expandedIndex"].as_u64().unwrap() as usize >= input.types.len())
        {
            // Cloning assigns private origin tokens. Verify originals first so this
            // cannot repair invalid source metadata or bypass generic contracts.
            neoclr::LoadedProgram::new(input)
                .and_then(|p| p.verify())
                .map_err(|e| e.to_string())?;
        }
        let backings = reference_array_backings(&specialization);
        let (selected, mut report) =
            select_inventory_with_host_roots(&expanded, root, true, &[], &backings)?;
        super::specialization::restore_methods(&mut report, &specialization);
        report["specialization"] = specialization;
        Ok((selected, report))
    } else {
        select(input, root)
    }
}

pub(super) fn callable_invoke(target: &FunctionRef) -> Option<&neoclr::metadata::FunctionType> {
    match target.owner.as_ref() {
        Some(Type::Function(shape)) if target.name == "$Function.Invoke" && target.instance => {
            Some(shape)
        }
        _ => None,
    }
}

pub(super) fn resolve(input: &neoclr::Module, target: &FunctionRef) -> Result<usize, Error> {
    if !target.generic_arguments.is_empty() {
        return Err("closed-world selection does not support generic calls".into());
    }
    let mut candidates = input.functions.iter().enumerate().filter(|(_, f)| {
        f.name == target.name
            && f.owner == target.owner
            && f.instance == target.instance
            && f.parameters == target.parameters
            && target
                .definition
                .as_ref()
                .is_none_or(|id| Some(id) == f.definition.as_ref())
    });
    let (index, _) = candidates.next().ok_or_else(|| {
        format!("closed-world call is external or has an invalid identity/signature: {target:?}")
    })?;
    if candidates.next().is_some() {
        return Err("ambiguous closed-world call".into());
    }
    Ok(index)
}

pub(super) fn interface_contract(input: &neoclr::Module, f: &neoclr::metadata::Function) -> bool {
    f.owner
        .as_ref()
        .and_then(|t| input.type_definition(t))
        .is_some_and(|t| t.representation == neoclr::metadata::Representation::Interface)
}

/// Sealing is descriptive metadata today: also check the complete loaded type set.
/// Keep callvirt for its null check; only the private native projection loses slots.
pub(super) fn class_contract(input: &neoclr::Module, f: &neoclr::metadata::Function) -> bool {
    f.instance
        && !f.receiver_byref
        && f.is_virtual
        && f.generic_parameters.is_empty()
        && !object_dispatch_contract(f)
        && !inherited_object_member(input, f)
        && f.owner
            .as_ref()
            .and_then(|t| input.type_definition(t))
            .is_some_and(|t| {
                t.is_reference_type && t.representation == neoclr::metadata::Representation::Record
            })
}

pub(super) fn virtual_base_contracts(
    input: &neoclr::Module,
    f: &neoclr::metadata::Function,
) -> Vec<usize> {
    if !class_contract(input, f) || !f.is_override {
        return vec![];
    }
    let mut parent = f
        .owner
        .as_ref()
        .and_then(|t| input.type_definition(t))
        .and_then(|t| t.base.as_ref());
    for _ in 0..64 {
        let Some(owner) = parent else {
            break;
        };
        if let Some((index, _)) = input.functions.iter().enumerate().find(|(_, candidate)| {
            candidate.owner.as_ref() == Some(owner)
                && candidate.instance
                && candidate.is_virtual
                && candidate.name.rsplit('.').next() == f.name.rsplit('.').next()
                && candidate.parameters == f.parameters
        }) {
            return vec![index];
        }
        parent = input.type_definition(owner).and_then(|t| t.base.as_ref());
    }
    vec![]
}

pub(super) fn class_implementation(
    input: &neoclr::Module,
    concrete: &Type,
    contract: &neoclr::metadata::Function,
) -> Result<(usize, FunctionRef), Error> {
    let method = neoclr::native_metadata::class_implementation(input, concrete, contract)
        .map_err(|e| e.to_string())?;
    let index = input
        .functions
        .iter()
        .position(|f| f.definition == method.definition && f.name == method.name)
        .ok_or("missing class virtual target")?;
    Ok((
        index,
        FunctionRef {
            definition: method.definition,
            name: method.name,
            owner: method.owner,
            instance: method.instance,
            generic_arguments: vec![],
            parameters: method.parameters,
        },
    ))
}

pub(super) fn sealed_member(input: &neoclr::Module, f: &neoclr::metadata::Function) -> bool {
    f.instance
        && !f.is_abstract
        && !f.receiver_byref
        && f.impl_flags == 0
        && f.owner
            .as_ref()
            .and_then(|t| input.type_definition(t))
            .is_some_and(|t| {
                (t.is_reference_type || f.owner.as_ref() == Some(&Type::String))
                    && t.is_sealed
                    && t.representation != neoclr::metadata::Representation::Interface
                    && !input.types.iter().any(|candidate| {
                        candidate.base.as_ref().and_then(Type::definition_name)
                            == Some(t.name.as_str())
                    })
            })
}

/// In a complete closed load set, an inherited Object override needs no runtime
/// choice when every descendant retains that implementation. Reject any same-name
/// descendant member conservatively, including new-slot and generic candidates.
pub(super) fn inherited_object_member(
    input: &neoclr::Module,
    f: &neoclr::metadata::Function,
) -> bool {
    if !f.instance
        || f.receiver_byref
        || !f.is_virtual
        || !f.is_override
        || f.is_abstract
        || f.impl_flags != 0
        || f.no_result
        || !f.generic_parameters.is_empty()
        || !f.generic_arguments.is_empty()
        || !object_slot_shape(f)
    {
        return false;
    }
    let Some(owner) = f.owner.as_ref().and_then(|t| input.type_definition(t)) else {
        return false;
    };
    if !owner.is_reference_type || !owner.generic_parameters.is_empty() {
        return false;
    }
    for candidate in &input.types {
        if candidate.name == owner.name {
            continue;
        }
        let mut base = candidate.base.as_ref();
        for _ in 0..input.types.len() {
            let Some(ty) = base.and_then(|t| input.type_definition(t)) else {
                break;
            };
            if ty.name == owner.name {
                if !candidate.generic_parameters.is_empty()
                    || input.functions.iter().any(|method| {
                        method.owner.as_ref().and_then(Type::definition_name)
                            == Some(candidate.name.as_str())
                            && method.instance
                            && method.name.rsplit('.').next() == f.name.rsplit('.').next()
                    })
                {
                    return false;
                }
                break;
            }
            base = ty.base.as_ref();
        }
    }
    true
}

pub(super) fn object_slot_shape(f: &neoclr::metadata::Function) -> bool {
    match f.name.rsplit('.').next() {
        Some("ToString") => f.parameters.is_empty() && f.returns == Type::String,
        Some("GetHashCode") => f.parameters.is_empty() && f.returns == Type::Int32,
        Some("Equals") => {
            f.parameters == [Type::Named("System.Object".into())] && f.returns == Type::Boolean
        }
        _ => false,
    }
}

pub(super) fn object_value_contract(f: &neoclr::metadata::Function) -> bool {
    f.owner == Some(Type::Named("System.Object".into()))
        && matches!(
            f.name.as_str(),
            "System.Object.Equals" | "System.Object.GetHashCode"
        )
        && object_slot_shape(f)
        && f.instance
        && f.is_virtual
        && !f.is_override
        && !f.is_abstract
        && !f.receiver_byref
        && !f.receiver_readonly
        && !f.no_result
        && f.impl_flags == 0
        && f.generic_parameters.is_empty()
        && f.generic_arguments.is_empty()
        && f.generic_constraints.is_empty()
}

pub(super) fn object_dispatch_contract(f: &neoclr::metadata::Function) -> bool {
    object_display_contract(f) || object_value_contract(f)
}

pub(super) fn object_placeholder(f: &neoclr::metadata::Function) -> Vec<Op> {
    vec![
        match f.returns {
            Type::Boolean => Op::Bool(false),
            Type::Int32 => Op::Int(0),
            _ => Op::String(String::new()),
        },
        Op::Return,
    ]
}

/// Return a verified most-derived Object value override, or use identity semantics.
pub(super) fn object_value_override(
    input: &neoclr::Module,
    concrete: &Type,
    contract: &neoclr::metadata::Function,
) -> Result<Option<(usize, FunctionRef)>, Error> {
    let mut current = concrete.clone();
    for _ in 0..=input.types.len() {
        if current == Type::Named("System.Object".into()) {
            return Ok(None);
        }
        let definition = input
            .type_definition(&current)
            .ok_or("Object value dispatch requires a local class")?;
        let value_receiver = !definition.is_reference_type
            && object_dispatch_contract(contract)
            && definition.representation == neoclr::metadata::Representation::Record;
        if !definition.is_reference_type && !value_receiver {
            return Err(
                "Object value dispatch requires a class receiver or verified value override".into(),
            );
        }
        let arguments = match &current {
            Type::Constructed { arguments, .. } | Type::Scoped { arguments, .. } => {
                arguments.as_slice()
            }
            _ => &[],
        };
        let mut candidates = vec![];
        for (index, method) in input.functions.iter().enumerate() {
            if method.owner.as_ref().and_then(Type::definition_name) != current.definition_name()
                || !method.instance
                || !(neoclr::value_defaults::implements_contract(method, contract)
                    || (method.is_override
                        && method.name.rsplit('.').next() == contract.name.rsplit('.').next()))
            {
                continue;
            }
            let method = closed_signature(method, arguments)
                .map_err(|e| format!("Object override {} on {current:?}: {e}", method.name))?;
            if method.parameters != contract.parameters || !method.generic_parameters.is_empty() {
                continue;
            }
            // New-slot and ordinary hiding members do not replace the Object slot.
            if !method.is_override
                && !neoclr::value_defaults::implements_contract(&method, contract)
            {
                continue;
            }
            if method.is_abstract
                || method.receiver_byref != value_receiver
                || method.returns != contract.returns
                || method.no_result
            {
                return Err("Object value dispatch requires a verified concrete override".into());
            }
            candidates.push((
                index,
                FunctionRef {
                    definition: method.definition.clone(),
                    name: method.name.clone(),
                    owner: method.owner.clone(),
                    instance: true,
                    generic_arguments: vec![],
                    parameters: method.parameters.clone(),
                },
            ));
        }
        if candidates.len() > 1 {
            return Err("ambiguous Object value override".into());
        }
        if let Some(found) = candidates.pop() {
            return Ok(Some(found));
        }
        let Some(base) = &definition.base else {
            return Ok(None);
        };
        current = base
            .substitute_type_parameters(arguments)
            .map_err(|e| e.to_string())?;
    }
    Err("cyclic Object value hierarchy".into())
}

/// Narrow class-virtual slice used by Console.WriteLine(Object). Original load-set
/// verification supplies slot ancestry; a same-named ordinary member is never enough.
pub(super) fn object_display_contract(f: &neoclr::metadata::Function) -> bool {
    f.name == "System.Object.ToString"
        && f.owner == Some(Type::Named("System.Object".into()))
        && f.instance
        && f.is_virtual
        && !f.is_override
        && !f.is_abstract
        && !f.receiver_byref
        && !f.receiver_readonly
        && f.parameters.is_empty()
        && f.returns == Type::String
        && !f.no_result
        && f.impl_flags == 0
        && f.generic_parameters.is_empty()
        && f.generic_constraints.is_empty()
}

/// Traverse verified class/interface inheritance with closed owner arguments.
pub(super) fn implements_interface(input: &neoclr::Module, concrete: &Type, target: &Type) -> bool {
    if input
        .type_definition(target)
        .is_some_and(|d| d.representation == neoclr::metadata::Representation::Interface)
    {
        return neoclr::native_metadata::assignable(input, concrete, target).unwrap_or(false);
    }
    let mut pending = vec![concrete.clone()];
    let mut seen = vec![];
    while let Some(current) = pending.pop() {
        if &current == target {
            return true;
        }
        if seen.contains(&current) {
            continue;
        }
        if seen.len() >= 1024 {
            return false;
        }
        seen.push(current.clone());
        let Some(definition) = input.type_definition(&current) else {
            continue;
        };
        let arguments = match &current {
            Type::Constructed { arguments, .. } => arguments.as_slice(),
            _ => &[],
        };
        for interface in definition.base.iter().chain(&definition.implements) {
            if let Ok(closed) = interface.substitute_type_parameters(arguments) {
                pending.push(closed);
            }
        }
    }
    false
}

pub(super) fn closed_signature(
    function: &neoclr::metadata::Function,
    arguments: &[Type],
) -> Result<neoclr::metadata::Function, Error> {
    let mut result = function.clone();
    result.owner = function
        .owner
        .as_ref()
        .map(|ty| ty.substitute_type_parameters(arguments))
        .transpose()
        .map_err(|e| e.to_string())?;
    result.parameters = function
        .parameters
        .iter()
        .map(|ty| ty.substitute_type_parameters(arguments))
        .collect::<Result<_, _>>()
        .map_err(|e| e.to_string())?;
    result.returns = function
        .returns
        .substitute_type_parameters(arguments)
        .map_err(|e| e.to_string())?;
    Ok(result)
}

pub(super) fn implicit_implementation(
    input: &neoclr::Module,
    concrete: &Type,
    contract: &neoclr::metadata::Function,
) -> Result<(usize, FunctionRef), Error> {
    if contract
        .owner
        .as_ref()
        .is_some_and(|owner| neoclr::native_metadata::interface_has_variance(input, owner))
        || input.type_definition(concrete).is_some_and(|t| {
            t.base
                .as_ref()
                .is_some_and(|b| b.definition_name() != Some("System.Object"))
        })
    {
        let method = neoclr::native_metadata::interface_implementation(input, concrete, contract)
            .map_err(|e| e.to_string())?;
        let index = input
            .functions
            .iter()
            .position(|f| f.definition == method.definition && f.name == method.name)
            .ok_or("missing inherited interface target")?;
        return Ok((
            index,
            FunctionRef {
                definition: method.definition,
                name: method.name,
                owner: method.owner,
                instance: method.instance,
                generic_arguments: vec![],
                parameters: method.parameters,
            },
        ));
    }
    let arguments = match concrete {
        Type::Constructed { arguments, .. } => arguments.as_slice(),
        _ => &[],
    };
    let member_name = |m: &neoclr::metadata::Function| {
        m.origin
            .as_ref()
            .map(|o| o.name.clone())
            .unwrap_or_else(|| m.name.rsplit('.').next().unwrap().to_owned())
    };
    let name = member_name(contract);
    let mut candidates = vec![];
    let mut explicit = vec![];
    for (index, method) in input.functions.iter().enumerate() {
        if method.owner.as_ref().and_then(Type::definition_name) != concrete.definition_name() {
            continue;
        }
        let maps_contract = method.interface_implementations.iter().any(|target| {
            target
                .owner
                .as_ref()
                .and_then(|t| t.substitute_type_parameters(arguments).ok())
                == contract.owner
                && target.instance == contract.instance
                && target
                    .parameters
                    .iter()
                    .map(|t| t.substitute_type_parameters(arguments))
                    .collect::<Result<Vec<_>, _>>()
                    .ok()
                    .as_ref()
                    == Some(&contract.parameters)
                && (target
                    .definition
                    .as_ref()
                    .is_some_and(|id| Some(id) == contract.definition.as_ref())
                    || target.definition.is_none() && target.name == contract.name)
        });
        if !maps_contract && member_name(method) != name {
            continue;
        }
        // The first private shape reuses its template's definition name.
        // Unselected overloads still have an open owner; they are not methods
        // of the lowered nongeneric shape and cannot be closed with no arguments.
        if matches!(concrete, Type::Named(_))
            && matches!(method.owner, Some(Type::Constructed { .. }))
        {
            continue;
        }
        let method = closed_signature(method, arguments)?;
        if method.owner.as_ref() == Some(concrete)
            && method.instance == contract.instance
            && method.parameters == contract.parameters
            && method.returns == contract.returns
            && method.no_result == contract.no_result
            && method.out_parameters == contract.out_parameters
            && method.generic_parameters.is_empty()
        {
            let target = (
                index,
                FunctionRef {
                    definition: method.definition.clone(),
                    name: method.name.clone(),
                    owner: method.owner.clone(),
                    instance: method.instance,
                    generic_arguments: vec![],
                    parameters: method.parameters.clone(),
                },
            );
            if maps_contract {
                explicit.push(target);
            } else if member_name(&method) == name
                && method.visibility == neoclr::metadata::Visibility::Public
                && method.interface_implementations.is_empty()
            {
                candidates.push(target);
            }
        }
    }
    if !explicit.is_empty() {
        candidates = explicit;
    }
    let [target] = candidates.as_slice() else {
        return Err(format!(
            "interface implementation is missing or ambiguous: {} on {concrete:?}",
            contract.name
        )
        .into());
    };
    Ok(target.clone())
}

/// The load set's verified nominal backing, closed over this profile's byte element.
/// Specialization relocates the private backing identity to the exact Byte shape.
pub(super) fn byte_array_owner(input: &neoclr::Module) -> Option<Type> {
    array_owner(input, &Type::Byte)
}

pub(super) fn array_owner(input: &neoclr::Module, element: &Type) -> Option<Type> {
    let id = input
        .assemblies
        .iter()
        .find_map(|a| a.array_backing.as_ref())?;
    let t = input
        .types
        .iter()
        .find(|t| t.definition.as_ref() == Some(id))?;
    match t.generic_parameters.len() {
        1 => Some(Type::Constructed {
            definition: t.name.clone(),
            arguments: vec![element.clone()],
        }),
        0 => Some(Type::Named(t.name.clone())),
        _ => None,
    }
}

/// Exact intrinsic Object overrides, after original-load-set validation.
pub(super) fn text_object_override(f: &neoclr::metadata::Function) -> bool {
    matches!(f.owner, Some(Type::String | Type::Char))
        && f.instance
        && f.is_override
        && f.is_virtual
        && !f.is_abstract
        && !f.no_result
        && object_slot_shape(f)
}

fn char_dispatch_target(input: &neoclr::Module, contract: usize) -> Option<usize> {
    let f = &input.functions[contract];
    if !object_dispatch_contract(f) {
        return None;
    }
    input.functions.iter().position(|method| {
        method.owner == Some(Type::Char)
            && text_object_override(method)
            && method.name.rsplit('.').next() == f.name.rsplit('.').next()
            && method.parameters == f.parameters
            && method.returns == f.returns
    })
}

/// Intrinsic String dispatch uses verified conformance, not a nominal object tag.
fn string_dispatch_target(input: &neoclr::Module, contract: usize) -> Result<Option<usize>, Error> {
    let f = &input.functions[contract];
    if object_dispatch_contract(f) {
        let target = input.functions.iter().enumerate().find(|(_, method)| {
            method.owner.as_ref() == Some(&Type::String)
                && method.is_override
                && !method.is_abstract
                && method.name.rsplit('.').next() == f.name.rsplit('.').next()
                && method.parameters == f.parameters
                && method.returns == f.returns
                && method.no_result == f.no_result
        });
        return Ok(target.map(|(index, _)| index));
    }
    if !interface_contract(input, f)
        || !implements_interface(input, &Type::String, f.owner.as_ref().unwrap())
    {
        return Ok(None);
    }
    Ok(Some(implicit_implementation(input, &Type::String, f)?.0))
}

/// Scalar value owners share the same borrowed-receiver and boxed-interface contract.
pub(super) const SCALAR_PRIMITIVES: &[Type] = &[
    Type::SByte,
    Type::Byte,
    Type::Int16,
    Type::UInt16,
    Type::Int32,
    Type::UInt32,
    Type::Int64,
    Type::UInt64,
    Type::IntPtr,
    Type::UIntPtr,
    Type::Single,
    Type::Double,
    Type::Boolean,
    Type::Char,
];

pub(super) fn projected_primitive(ty: &Type) -> bool {
    SCALAR_PRIMITIVES.contains(ty)
}

fn scalar_interface_targets(
    input: &neoclr::Module,
    contract: usize,
    reached: &BTreeSet<usize>,
) -> Result<Vec<(Type, usize)>, Error> {
    let f = &input.functions[contract];
    if !interface_contract(input, f) {
        return Ok(vec![]);
    }
    let mut primitives = vec![];
    for &index in reached {
        for op in &input.functions[index].body {
            if let Op::BoxValue(ty) = op
                && projected_primitive(ty)
                && !primitives.contains(ty)
                && implements_interface(input, ty, f.owner.as_ref().unwrap())
            {
                primitives.push(ty.clone());
            }
        }
    }
    primitives
        .into_iter()
        .map(|ty| {
            let target = implicit_implementation(input, &ty, f)?.0;
            Ok((ty, target))
        })
        .collect()
}

// Cache only immutable type relationships, never the growing set of reachable
// receivers or selected method targets. The borrow prevents reuse after mutation.
pub(super) struct DispatchRelations<'a> {
    input: &'a neoclr::Module,
    owners: std::collections::HashMap<Type, std::collections::HashMap<usize, bool>>,
}

impl<'a> DispatchRelations<'a> {
    pub(super) fn new(input: &'a neoclr::Module) -> Self {
        Self {
            input,
            owners: Default::default(),
        }
    }

    fn implements(&mut self, concrete: usize, target: &Type) -> bool {
        if let Some(result) = self
            .owners
            .get(target)
            .and_then(|owners| owners.get(&concrete))
        {
            return *result;
        }
        let result = implements_interface(
            self.input,
            &Type::Named(self.input.types[concrete].name.clone()),
            target,
        );
        self.owners
            .entry(target.clone())
            .or_default()
            .insert(concrete, result);
        result
    }
}

/// Exact implicit implementations for classes constructed by the reachable program.
/// Optional conformance types add verification-only roots; omit them for dispatch tables.
/// Original conformance is verified before private projection; this is not a binder.
pub(super) fn dispatch_targets_with_array(
    relations: &mut DispatchRelations<'_>,
    contract: usize,
    reached: &BTreeSet<usize>,
    array_backing: Option<usize>,
    reference_backings: &[usize],
    conformance_types: Option<&BTreeSet<usize>>,
) -> Result<Vec<(usize, usize)>, Error> {
    let input = relations.input;
    let f = &input.functions[contract];
    let display = object_dispatch_contract(f);
    let class = class_contract(input, f);
    if !interface_contract(input, f) && !display && !class {
        return Ok(vec![]);
    }
    if !f.instance
        || f.receiver_byref
        || (!display && !class && !f.body.is_empty())
        || !f.generic_parameters.is_empty()
    {
        return Err("interface dispatch requires a bodyless nongeneric instance contract".into());
    }
    let mut constructed = BTreeSet::new();
    let mut boxed_values = BTreeSet::new();
    if !display {
        for &index in conformance_types.into_iter().flatten() {
            let ty = &input.types[index];
            if ty.is_reference_type
                && ty.representation == neoclr::metadata::Representation::Record
                && !ty.is_abstract
            {
                constructed.insert(ty.name.as_str());
            }
        }
    }
    let array_owner = array_backing
        .map(|i| Type::Named(input.types[i].name.clone()))
        .or_else(|| byte_array_owner(input));
    for &i in reached {
        if input.functions[i].returns == Type::ArrayRef(Box::new(Type::Byte))
            && let Some(Type::Named(name)) = &array_owner
        {
            constructed.insert(name.as_str());
        }
        for &index in reference_backings {
            if input.types[index]
                .fields
                .first()
                .is_some_and(|f| f.ty == input.functions[i].returns)
            {
                constructed.insert(input.types[index].name.as_str());
            }
        }
        for (pc, op) in input.functions[i].body.iter().enumerate() {
            if let Op::BoxValue(ty) = op {
                // Nominal value boxes retain interface identity as well as Object
                // overrides. Scalar boxes still use their explicit projections.
                if object_display_contract(f)
                    || matches!(ty, Type::Named(_) | Type::Constructed { .. })
                {
                    if let Some(t) = input.type_definition(ty) {
                        if !t.is_reference_type
                            && t.representation == neoclr::metadata::Representation::Record
                        {
                            constructed.insert(t.name.as_str());
                            boxed_values.insert(t.name.as_str());
                        }
                    } else if !matches!(
                        ty,
                        Type::Int32 | Type::Int64 | Type::Boolean | Type::String
                    ) && !input.is_object_reference_type(ty)
                    {
                        return Err(format!("Object display does not support boxed type {ty:?} in {} at instruction {pc}", input.functions[i].name).into());
                    }
                }
            }
            if matches!(op, Op::NewArray(Type::Byte) | Op::ReserveArray(Type::Byte))
                && let Some(Type::Named(name)) = &array_owner
            {
                constructed.insert(name.as_str());
            }
            if let Op::NewArray(element) | Op::ReserveArray(element) = op {
                for &index in reference_backings {
                    let ty = &input.types[index];
                    if ty
                        .fields
                        .first()
                        .is_some_and(|f| f.ty == Type::ArrayRef(Box::new(element.clone())))
                    {
                        constructed.insert(ty.name.as_str());
                    }
                }
            }
            if let Op::Construct(target) = op
                && let Some(Type::Named(name)) = &target.owner
            {
                constructed.insert(name.as_str());
            }
        }
    }
    let mut targets = vec![];
    for (ti, t) in input.types.iter().enumerate() {
        if !constructed.contains(t.name.as_str())
            || (!display && !relations.implements(ti, f.owner.as_ref().unwrap()))
        {
            continue;
        }
        // A value constructor alone cannot contribute a reference dispatch target.
        // Only reachable boxes contribute value-type interface dispatch targets.
        if display && !t.is_reference_type && !boxed_values.contains(t.name.as_str()) {
            continue;
        }
        if (!t.is_reference_type && !boxed_values.contains(t.name.as_str()))
            || !t.generic_parameters.is_empty()
            || t.representation != neoclr::metadata::Representation::Record
        {
            return Err("interface dispatch requires nongeneric constructed classes".into());
        }
        let (target, _) = if object_dispatch_contract(f) {
            let Some(target) = object_value_override(input, &Type::Named(t.name.clone()), f)?
            else {
                continue;
            };
            target
        } else if class {
            class_implementation(input, &Type::Named(t.name.clone()), f)?
        } else {
            implicit_implementation(input, &Type::Named(t.name.clone()), f)?
        };
        targets.push((ti, target));
    }
    Ok(targets)
}

pub(super) fn validate_source(input: &neoclr::Module, single_assembly: bool) -> Result<(), Error> {
    if input.functions.len() > crate::limits::INPUT_FUNCTIONS
        || input.types.len() > crate::limits::INPUT_TYPES
    {
        return Err(format!("closed-world input inventory exceeds bounds: {} functions (limit {}), {} types (limit {})", input.functions.len(), crate::limits::INPUT_FUNCTIONS, input.types.len(), crate::limits::INPUT_TYPES).into());
    }
    if single_assembly && input.assemblies.len() > 1 {
        return Err("closed-world selection requires one source assembly".into());
    }
    for origin in input
        .functions
        .iter()
        .filter_map(|f| f.origin.as_ref())
        .chain(input.types.iter().filter_map(|t| t.origin.as_ref()))
    {
        if !input
            .assemblies
            .iter()
            .any(|a| a.full_name == origin.assembly && a.modules.contains(&origin.module))
        {
            return Err("closed-world origin must belong to the source assembly".into());
        }
    }
    // Never let projection repair a malformed supplied identity.
    for (i, f) in input.functions.iter().enumerate() {
        let expected = MemberId {
            module: input.name.clone(),
            revision: input.revision.clone(),
            index: i as u32,
        };
        if f.definition.as_ref().is_some_and(|id| *id != expected) {
            return Err("noncanonical source function identity".into());
        }
    }
    for (i, t) in input.types.iter().enumerate() {
        let expected = TypeDefId {
            module: input.name.clone(),
            revision: input.revision.clone(),
            index: i as u32,
        };
        if t.definition.as_ref().is_some_and(|id| *id != expected) {
            return Err("noncanonical source type identity".into());
        }
    }
    Ok(())
}

// Signature/storage-only classes still need implementations of retained interface
// contracts in the private verification projection, even without a constructor.
fn retained_types(
    input: &neoclr::Module,
    functions: &BTreeSet<usize>,
    reference_backings: &[usize],
) -> Result<BTreeSet<usize>, Error> {
    let mut types = BTreeSet::new();
    let mut pending_types = reference_backings
        .iter()
        .map(|i| Type::Named(input.types[*i].name.clone()))
        .collect::<Vec<_>>();
    for &i in functions {
        let f = &input.functions[i];
        pending_types.extend(f.owner.iter().cloned());
        pending_types.extend(f.parameters.iter().chain(&f.locals).cloned());
        pending_types.push(f.returns.clone());
        for (pc, op) in f.body.iter().enumerate() {
            if let Op::StaticField { owner, .. } | Op::SetStaticField { owner, .. } = op {
                pending_types.push(owner.clone());
            }
            if matches!(op, Op::BoxValue(_) | Op::UnboxAny(_))
                || matches!(op, Op::IsInstance(t) if (crate::scalar_unions::tag(t).is_some() || crate::scalar_unions::bank_scalar(t) || crate::scalar_unions::record(input, t)) && crate::scalar_unions::query(input, f, pc))
            {
                // The VM verification view of scalar tests returns Object even
                // when this native union never allocates a boxed payload.
                pending_types.push(Type::Named("System.Object".into()));
            }
            if let Op::BindFunction { function_type, .. } = op {
                pending_types.push(function_type.clone());
            }
            if let Op::New(t)
            | Op::InitializeObject(t)
            | Op::LoadObject(t)
            | Op::StoreObject(t)
            | Op::PackValue(t)
            | Op::IsValue(t)
            | Op::LoadTypeToken(t)
            | Op::UnpackValue(t)
            | Op::BoxValue(t)
            | Op::IsInstance(t)
            | Op::CastClass(t)
            | Op::NewArray(t)
            | Op::ReserveArray(t)
            | Op::ArrayElement(t)
            | Op::StoreArrayElement(t)
            | Op::ArrayAddress(t) = op
            {
                pending_types.push(t.clone());
            }
        }
    }
    while let Some(ty) = pending_types.pop() {
        match ty {
            Type::Tuple(parts) => pending_types.extend(parts.iter().cloned()),
            Type::Intersection(parts) => pending_types.extend(parts),
            Type::Union(parts) => pending_types.extend(parts),
            Type::Named(name) => {
                let candidates: Vec<_> = input
                    .types
                    .iter()
                    .enumerate()
                    .filter(|(_, t)| t.name == name)
                    .map(|(i, _)| i)
                    .collect();
                let [i] = candidates.as_slice() else {
                    return Err(
                        "closed-world type must resolve uniquely inside the input module".into(),
                    );
                };
                if !types.insert(*i) {
                    continue;
                }
                if types.len() > crate::limits::TYPES {
                    return Err("selected types exceed the value profile limit".into());
                }
                let t = &input.types[*i];
                if t.memory_view.is_some() && !crate::memory_views::byte_memory(t) {
                    return Err("memory views require interpreter execution; native ABI and GC lowering are not implemented".into());
                }
                pending_types.extend(t.fields.iter().map(|f| f.ty.clone()));
                pending_types.extend(t.static_fields.iter().map(|f| f.ty.clone()));
                pending_types.extend(t.base.iter().chain(&t.implements).cloned());
                pending_types.extend(
                    neoclr::native_metadata::interface_shape_arguments(t)
                        .iter()
                        .cloned(),
                );
                if let Some(owner) = &t.declaring_type {
                    if owner.module != input.name || owner.revision != input.revision {
                        return Err("external lexical owner is unsupported".into());
                    }
                    pending_types.push(Type::Named(
                        input
                            .types
                            .get(owner.index as usize)
                            .ok_or("invalid lexical owner")?
                            .name
                            .clone(),
                    ));
                }
            }
            Type::Function(shape) => {
                pending_types.extend(shape.parameters);
                pending_types.push(shape.returns);
            }
            Type::ByRef(t) => pending_types.push(*t),
            Type::Array(t) if matches!(*t, Type::Byte | Type::Char) => (),
            Type::ArrayRef(t)
                if matches!(*t, Type::String | Type::Char) || scalar_array_element(&t) => {}
            Type::ArrayRef(t)
                if matches!(
                    *t,
                    Type::Function(_)
                        | Type::ArrayRef(_)
                        | Type::Named(_)
                        | Type::Tuple(_)
                        | Type::Union(_)
                        | Type::Intersection(_)
                ) =>
            {
                pending_types.push(*t)
            }
            Type::ArrayRef(t) if *t == Type::Byte => {
                if let Some(owner) = byte_array_owner(input) {
                    pending_types.push(owner);
                }
            }
            Type::Single
            | Type::Double
            | Type::Int32
            | Type::Byte
            | Type::SByte
            | Type::Int16
            | Type::UInt16
            | Type::Boolean
            | Type::Void
            | Type::Value
            | Type::String
            | Type::Char
            | Type::UInt32
            | Type::Int64
            | Type::UInt64
            | Type::IntPtr
            | Type::UIntPtr
            | Type::RuntimeTypeHandle => (),
            _ => {
                return Err(
                    "closed-world selection requires reference-free nongeneric value signatures"
                        .into(),
                );
            }
        }
    }
    Ok(types)
}

pub fn select(input: &neoclr::Module, root: &str) -> Result<(neoclr::Module, Value), Error> {
    select_inventory(input, root, true)
}

pub(super) fn select_inventory(
    input: &neoclr::Module,
    root: &str,
    single_assembly: bool,
) -> Result<(neoclr::Module, Value), Error> {
    select_inventory_with_host_roots(input, root, single_assembly, &[], &[])
}
pub(super) fn select_inventory_with_host_roots(
    input: &neoclr::Module,
    root: &str,
    single_assembly: bool,
    host_roots: &[usize],
    reference_backings: &[usize],
) -> Result<(neoclr::Module, Value), Error> {
    validate_source(input, single_assembly)?;
    if host_roots.iter().any(|i| *i >= input.functions.len()) {
        return Err("host root index out of range".into());
    }
    let roots: Vec<_> = input
        .functions
        .iter()
        .enumerate()
        .filter(|(_, f)| f.name == root)
        .map(|(i, _)| i)
        .collect();
    let [root_index] = roots.as_slice() else {
        return Err("closed-world root must have one exact name match".into());
    };
    let mut relations = DispatchRelations::new(input);
    let mut functions = BTreeSet::new();
    let mut pending = vec![*root_index];
    pending.extend_from_slice(host_roots);
    loop {
        while let Some(i) = pending.pop() {
            if !functions.insert(i) {
                continue;
            }
            if functions.len() > crate::limits::FUNCTIONS {
                return Err("selected functions exceed the value profile limit".into());
            }
            pending.extend(virtual_base_contracts(input, &input.functions[i]));
            pending.extend(neoclr::native_metadata::interface_slot_peers(
                input,
                &input.functions[i],
            ));
            if object_dispatch_contract(&input.functions[i]) {
                continue;
            }
            for op in &input.functions[i].body {
                match op {
                    Op::Call(target)
                    | Op::CallVirtual(target)
                    | Op::Construct(target)
                    | Op::BindFunction { target, .. } => {
                        if callable_invoke(target).is_some() {
                            continue;
                        }
                        let callee = resolve(input, target)
                            .map_err(|e| format!("in {}: {e}", input.functions[i].name))?;
                        let f = &input.functions[callee];
                        if matches!(op, Op::CallVirtual(_))
                            && !interface_contract(input, f)
                            && !class_contract(input, f)
                            && !object_dispatch_contract(f)
                            && !sealed_member(input, f)
                            && !inherited_object_member(input, f)
                            && (f.is_virtual || f.is_abstract || f.is_override)
                        {
                            return Err(
                                "virtual calls requiring dispatch need a later selection profile"
                                    .into(),
                            );
                        }
                        if matches!(op, Op::Call(_)) && object_dispatch_contract(f) {
                            return Err("direct Object.ToString/Equals/GetHashCode calls require base-call lowering".into());
                        }
                        pending.push(callee);
                    }
                    _ => (), // Unsupported selected opcodes still fail ordinary AOT admission.
                }
            }
        }
        let conformance_types = retained_types(input, &functions, reference_backings)?;
        for &ty in &conformance_types {
            if let Some(initializer) = crate::type_initialization::initializer(
                input,
                &crate::type_initialization::owner_type(&input.types[ty]),
            ) && !functions.contains(&initializer)
            {
                pending.push(initializer);
            }
        }
        for &contract in &functions {
            for (_, target) in scalar_interface_targets(input, contract, &functions)? {
                if !functions.contains(&target) {
                    pending.push(target);
                }
            }
            if let Some(target) = string_dispatch_target(input, contract)?
                && !functions.contains(&target)
            {
                pending.push(target);
            }
            if functions.iter().any(|i| {
                input.functions[*i]
                    .body
                    .iter()
                    .any(|op| matches!(op, Op::BoxValue(Type::Char)))
            }) && let Some(target) = char_dispatch_target(input, contract)
                && !functions.contains(&target)
            {
                pending.push(target);
            }
            for (_, target) in dispatch_targets_with_array(
                &mut relations,
                contract,
                &functions,
                None,
                reference_backings,
                Some(&conformance_types),
            )? {
                if !functions.contains(&target) {
                    pending.push(target);
                }
            }
        }
        if pending.is_empty() {
            break;
        }
    }
    let types = retained_types(input, &functions, reference_backings)?;
    let rows: Vec<_> = functions.iter().copied().collect();
    let type_rows: Vec<_> = types.iter().copied().collect();
    let mut projected = input.clone();
    projected.functions = rows.iter().map(|i| input.functions[*i].clone()).collect();
    projected.types = type_rows.iter().map(|i| input.types[*i].clone()).collect();
    // Compile a private, canonical verification projection. Semantic names, visibility,
    // signatures, storage and instruction bodies remain; non-executable descriptions
    // stay in the original artifact. Report the original-to-projection row map.
    for assembly in &mut projected.assemblies {
        // Original access was checked before selection. Attribute constructors are
        // descriptive metadata, not executable roots in this private projection.
        assembly.custom_attributes.clear();
        assembly.references.clear();
        assembly.value_type_references.clear();
        assembly.native_module_bindings.clear();
        assembly.native_type_bindings.clear();
        assembly.array_backing = None;
    }
    projected.references = None;
    projected.entry = if input.functions[*root_index].parameters.is_empty() {
        root.to_owned()
    } else {
        String::new()
    };
    for (i, f) in projected.functions.iter_mut().enumerate() {
        if object_dispatch_contract(f) {
            f.body = object_placeholder(f);
            f.locals.clear();
            f.local_names.clear();
        }
        f.custom_attributes.clear();
        f.definition = Some(MemberId {
            module: input.name.clone(),
            revision: input.revision.clone(),
            index: i as u32,
        });
        // Mapping references use the same selected identity space as call targets.
        // Unreached contracts have no executable dispatch in this closed world.
        let mut mappings = vec![];
        for mut target in std::mem::take(&mut f.interface_implementations) {
            let old = resolve(input, &target)?;
            if let Ok(new) = rows.binary_search(&old) {
                target.definition = Some(MemberId {
                    module: input.name.clone(),
                    revision: input.revision.clone(),
                    index: new as u32,
                });
                mappings.push(target);
            }
        }
        f.interface_implementations = mappings;
        for op in &mut f.body {
            if let Op::Call(target)
            | Op::CallVirtual(target)
            | Op::Construct(target)
            | Op::BindFunction { target, .. } = op
            {
                if callable_invoke(target).is_some() {
                    continue;
                }
                let old = resolve(input, target).map_err(|e| format!("in {}: {e}", f.name))?;
                let new = rows.binary_search(&old).expect("selected call");
                target.definition = Some(MemberId {
                    module: input.name.clone(),
                    revision: input.revision.clone(),
                    index: new as u32,
                });
            }
        }
    }
    for (i, t) in projected.types.iter_mut().enumerate() {
        // Init associations are executable readonly-write authority, not merely
        // descriptions. Preserve only setters already reached through calls.
        let mut retained = vec![];
        let mut property_tokens = vec![];
        for (index, property) in t.properties.iter().enumerate().filter(|(_, p)| p.init_only) {
            let setter = property
                .setter
                .as_ref()
                .ok_or("init property lacks setter")?;
            let old = resolve(input, setter)?;
            let Ok(new) = rows.binary_search(&old) else {
                continue;
            };
            let mut property = property.clone();
            property.getter = None;
            property.setter.as_mut().unwrap().definition = Some(MemberId {
                module: input.name.clone(),
                revision: input.revision.clone(),
                index: new as u32,
            });
            retained.push(property);
            if let Some(origin) = &t.origin {
                property_tokens.push(origin.property_tokens[index]);
            }
        }
        if let Some(origin) = &mut t.origin {
            origin.property_tokens = property_tokens;
        }
        t.custom_attributes.clear();
        t.properties = retained;
        t.definition = Some(TypeDefId {
            module: input.name.clone(),
            revision: input.revision.clone(),
            index: i as u32,
        });
        if let Some(owner) = &mut t.declaring_type {
            owner.index = type_rows
                .binary_search(&(owner.index as usize))
                .expect("selected lexical owner") as u32;
        }
    }
    let mut dispatch = vec![];
    let mut object_dispatch = vec![];
    let mut class_dispatch = vec![];
    let mut string_dispatch = vec![];
    let mut char_dispatch = vec![];
    let mut scalar_dispatch = vec![];
    for (compiled, source) in rows.iter().enumerate() {
        for (primitive, target) in scalar_interface_targets(input, *source, &functions)? {
            scalar_dispatch.push(json!({"contractCompiledIndex":compiled,"primitive":primitive,"functionCompiledIndex":rows.binary_search(&target).unwrap()}));
        }
        if let Some(target) = string_dispatch_target(input, *source)? {
            string_dispatch.push(json!({"contractCompiledIndex":compiled,"functionCompiledIndex":rows.binary_search(&target).unwrap()}));
        }
        if let Some(target) = char_dispatch_target(input, *source)
            && let Ok(target) = rows.binary_search(&target)
        {
            char_dispatch
                .push(json!({"contractCompiledIndex":compiled,"functionCompiledIndex":target}));
        }
        let display = object_dispatch_contract(&input.functions[*source]);
        let class = class_contract(input, &input.functions[*source]);
        if interface_contract(input, &input.functions[*source]) || display || class {
            let targets = dispatch_targets_with_array(
                &mut relations,
                *source,
                &functions,
                None,
                reference_backings,
                None,
            )?;
            let inventory = if display {
                &mut object_dispatch
            } else if class {
                &mut class_dispatch
            } else {
                &mut dispatch
            };
            inventory.push(json!({"contractCompiledIndex":compiled,"contractSourceIndex":source, "kind":input.functions[*source].name.rsplit('.').next(),
                "targets":targets.iter().map(|(ty, method)| json!({"typeCompiledIndex":type_rows.binary_search(ty).unwrap(),"functionCompiledIndex":rows.binary_search(method).unwrap()})).collect::<Vec<_>>() }));
        }
    }
    let array_backing = byte_array_owner(input).and_then(|owner| input.types.iter().position(|t| owner == Type::Named(t.name.clone())))
        .and_then(|source| type_rows.binary_search(&source).ok().map(|compiled| json!({"sourceIndex":source,"compiledIndex":compiled,
            "policy":"verified nominal byte-array backing; identity-preserving views and intrinsic storage field"})));
    let report = json!({"schema":"neoclr-aot-selection-v1", "module":input.name, "root":root,
        "entryArguments": matches!(input.functions[*root_index].parameters.as_slice(), [Type::ArrayRef(t)] if **t == Type::String),
        "hostRoots": host_roots.iter().map(|i| json!({"sourceIndex":i,"compiledIndex":rows.binary_search(i).unwrap(),"name":input.functions[*i].name,"reason":"explicit runtime adapter"})).collect::<Vec<_>>(),
        "policy":"explicit closed world with constructed-class implicit interface dispatch; ordinary selected bodies retained; verified Object-slot dispatch replaces private slot bodies; bounded class virtual dispatch; no dynamic loading",
        "scalarInterfaceDispatch":scalar_dispatch, "charObjectDispatch":char_dispatch, "stringInterfaceDispatch":string_dispatch, "interfaceDispatch":dispatch, "objectDisplayDispatch":object_dispatch, "classVirtualDispatch":class_dispatch, "arrayBackingProjection":array_backing,
        "referenceArrayBackingProjections": reference_backings.iter().filter_map(|source| type_rows.binary_search(source).ok().map(|compiled| json!({"sourceIndex":source,"compiledIndex":compiled}))).collect::<Vec<_>>(),
        "metadataPolicy":"original artifact unchanged; private verification projection omits attributes/property descriptors, relocates definition rows; source origins retain access and readonly facts; external assembly bindings omitted",
        "functions": rows.iter().enumerate().map(|(new, old)| json!({"sourceIndex":old,"compiledIndex":new,"definition":input.functions[*old].definition,"name":input.functions[*old].name})).collect::<Vec<_>>(),
        "types": type_rows.iter().enumerate().map(|(new, old)| json!({"sourceIndex":old,"compiledIndex":new,"definition":input.types[*old].definition,"name":input.types[*old].name})).collect::<Vec<_>>(),
        "excludedFunctions": input.functions.iter().enumerate().filter(|(i,_)| !functions.contains(i)).map(|(i,f)| json!({"sourceIndex":i,"definition":f.definition,"name":f.name})).collect::<Vec<_>>(),
        "excludedTypes": input.types.iter().enumerate().filter(|(i,_)| !types.contains(i)).map(|(i,t)| json!({"sourceIndex":i,"definition":t.definition,"name":t.name})).collect::<Vec<_>>()});
    Ok((projected, report))
}

/// Private verified specialization evidence, never inferred from names or field shapes.
pub(super) fn reference_array_backings(report: &Value) -> Vec<usize> {
    report["referenceArrayBackings"]
        .as_array()
        .into_iter()
        .flatten()
        .filter_map(|r| r.as_u64().map(|i| i as usize))
        .collect()
}

#[cfg(test)]
mod composition_admission_tests {
    use super::*;

    #[test]
    fn explicit_mapping_identity_follows_selected_rows() {
        let module = neoclr::assemble(
            r#"
.module SelectedExplicit
.function Unused() -> Int32
ldc.i4 0
ret
.end
.interface Readable
.method instance Read() -> Int32
.end
.end
.type class Cell
.implements Readable
.method instance .ctor() -> void
ret
.end
.method private instance Hidden() -> Int32
.override instance Readable::Read()
ldc.i4 42
ret
.end
.end
.function Main() -> Int32
newobj instance Cell::.ctor()
callvirt instance Readable::Read()
ret
.end
"#,
        )
        .unwrap();
        let (selected, _) = select(&module, "Main").unwrap();
        let contract = selected
            .functions
            .iter()
            .position(|f| f.name == "Readable.Read")
            .unwrap();
        let method = selected
            .functions
            .iter()
            .find(|f| f.name == "Cell.Hidden")
            .unwrap();
        assert_eq!(
            method.interface_implementations[0]
                .definition
                .as_ref()
                .unwrap()
                .index as usize,
            contract
        );
        neoclr::LoadedProgram::new(&selected)
            .unwrap()
            .verify()
            .unwrap();
    }

    #[test]
    fn dispatch_relationship_cache_preserves_closed_types_and_module_changes() {
        let mut module = neoclr::assemble(
            ".module Relations\n.interface Read<T>\n.end\n.type class Cell\n.implements Read<Int32>\n.end\n"
        ).unwrap();
        let cell = module.types.iter().position(|t| t.name == "Cell").unwrap();
        let integer = neoclr::assembler::parse_type("Read<Int32>").unwrap();
        let text = neoclr::assembler::parse_type("Read<String>").unwrap();
        {
            let mut relations = DispatchRelations::new(&module);
            for _ in 0..3 {
                assert!(relations.implements(cell, &integer));
                assert!(!relations.implements(cell, &text));
            }
            assert_eq!(relations.owners.len(), 2);
        }
        module.types[cell].implements = vec![text.clone()];
        let mut relations = DispatchRelations::new(&module);
        assert!(!relations.implements(cell, &integer));
        assert!(relations.implements(cell, &text));
    }

    #[test]
    #[ignore = "manual dispatch relationship timing probe"]
    fn dispatch_relationship_cache_timing() {
        let mut source = String::from(".module Relations\n.interface Read\n.end\n");
        for index in 0..128 {
            source += &format!(".type class Cell{index}\n.implements Read\n.end\n");
        }
        let module = neoclr::assemble(&source).unwrap();
        let target = Type::Named("Read".into());
        let mut relations = DispatchRelations::new(&module);
        for round in 0..5 {
            for cached in [false, true] {
                let start = std::time::Instant::now();
                for _ in 0..32 {
                    for concrete in 1..module.types.len() {
                        assert!(if cached {
                            relations.implements(concrete, std::hint::black_box(&target))
                        } else {
                            implements_interface(
                                &module,
                                &Type::Named(module.types[concrete].name.clone()),
                                std::hint::black_box(&target),
                            )
                        });
                    }
                }
                println!(
                    "dispatch_cached={cached} round={round} seconds={:.9}",
                    start.elapsed().as_secs_f64()
                );
            }
        }
    }

    #[test]
    fn boxed_value_interface_targets_are_retained_without_a_constructor() {
        let module = neoclr::assemble(
            ".module BoxedInterface\n.type class System.Object\n.end\n.interface Format\n.method instance Render() -> Int32\n.end\n.end\n.type Payload\n.implements Format\n.method instance byref Render() -> Int32\nldc.i4 42\nret\n.end\n.end\n.function Main() -> Int32\n.local Payload value\nldloca value\ninitobj Payload\nldloc value\nbox Payload\npop\nldc.i4 0\nret\n.end",
        ).unwrap();
        let contract = module
            .functions
            .iter()
            .position(|f| f.name == "Format.Render")
            .unwrap();
        let main = module
            .functions
            .iter()
            .position(|f| f.name == "Main")
            .unwrap();
        let method = module
            .functions
            .iter()
            .position(|f| f.name == "Payload.Render")
            .unwrap();
        let value = module
            .types
            .iter()
            .position(|t| t.name == "Payload")
            .unwrap();
        let targets = dispatch_targets_with_array(
            &mut DispatchRelations::new(&module),
            contract,
            &BTreeSet::from([main]),
            None,
            &[],
            None,
        )
        .unwrap();
        let mut relations = DispatchRelations::new(&module);
        for reached in [BTreeSet::new(), BTreeSet::from([main]), BTreeSet::new()] {
            let cached =
                dispatch_targets_with_array(&mut relations, contract, &reached, None, &[], None)
                    .unwrap();
            assert_eq!(
                cached,
                if reached.is_empty() {
                    vec![]
                } else {
                    vec![(value, method)]
                }
            );
        }
        assert_eq!(targets, vec![(value, method)]);
        assert!(
            dispatch_targets_with_array(
                &mut DispatchRelations::new(&module),
                contract,
                &BTreeSet::new(),
                None,
                &[],
                None
            )
            .unwrap()
            .is_empty()
        );
    }

    #[test]
    fn structural_tuple_storage_is_selected_without_nominal_carriers() {
        let mut module = neoclr::assemble(
            ".module TupleNative\n.entry Main\n.function Main() -> Int32\nldc.i4 42\nret\n.end",
        )
        .unwrap();
        module.functions[0]
            .locals
            .push(Type::Tuple(vec![Type::Int32, Type::String].into()));
        prepare(&module, "Main").unwrap();
    }

    #[test]
    fn structural_union_signatures_are_selected_without_nominal_carriers() {
        let mut module = neoclr::assemble(
            ".module CompoundNative\n.entry Main\n.interface Left\n.end\n.interface Right\n.end\n.function Main() -> Int32\nldc.i4 42\nret\n.end",
        ).unwrap();
        let main = module
            .functions
            .iter_mut()
            .find(|f| f.name == "Main")
            .unwrap();
        main.locals.push(Type::Union(vec![
            Type::from_name("Left"),
            Type::from_name("Right"),
        ]));
        prepare(&module, "Main").unwrap();
    }
}
