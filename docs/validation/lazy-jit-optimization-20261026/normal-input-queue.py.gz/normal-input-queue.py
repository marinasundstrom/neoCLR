from pathlib import Path
import subprocess,json,time,hashlib
root=Path('/Users/robert/Projects/neoclr');out=root/'target/lazy-jit-normal-input-cases';out.mkdir(exist_ok=False)
steps=[]
for case,build,rates,dependency in [('complex','target/lazy-jit-default-complex-build',[150,600],0),('service','target/lazy-jit-default-service-build',[100,400],20)]:
 command=['python3','benchmarks/gc-suite/matrix/lazy-load.py','--build',build,'--output',str(out/case),'--rates',*map(str,rates),'--apps','1','--duration','15','--rounds','2','--concurrency','32','--header-gap-ms','0','--dependency-ms',str(dependency),'--reuse-processes','--modes','arena-control-sync-jit','arena-control-live-jit']
 steps.append((case,command))
 steps.append((case+'-summary',['python3','benchmarks/gc-suite/matrix/summarize-lazy-load.py','--measurement',str(out/case/'results.json'),'--output',str(out/case/'summary.json')]))
r=dict(completed=False,scope='Sequential unfragmented-request lazy sync/concurrent comparison after the initial production-default queue; two rounds, production codegen, same arena, one app.',steps=[])
for name,command in steps:
 print('START',name,flush=True);began=time.time()
 with (out/(name+'.log')).open('w') as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 r['steps'].append(dict(name=name,command=command,exitCode=result.returncode,elapsedSeconds=time.time()-began))
 (out/'queue.json').write_text(json.dumps(r,indent=2)+'\n');print('END',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
r['completed']=True;r['queueSourceSha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();(out/'queue.json').write_text(json.dumps(r,indent=2)+'\n')
