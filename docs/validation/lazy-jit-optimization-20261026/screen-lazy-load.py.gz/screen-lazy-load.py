"""Paced complex HTTP load across one or more isolated server processes.

Reuses the checked open-loop arrival scheduler: misses remain offered arrivals,
there is no hidden client queue, and latency includes dispatch delay. Processes
share the host CPU/memory; handler concurrency is bounded, not a hard CPU quota.
"""
import argparse
import asyncio
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import queue
import socket
import subprocess
import threading
import time

ROOT = Path(__file__).resolve().parents[3]
loader = ROOT/'benchmarks/http-server/load/run.py'
spec = importlib.util.spec_from_file_location('http_load', loader)
load = importlib.util.module_from_spec(spec)
spec.loader.exec_module(load)


async def exchange(port, path, size, timeout, timings=None, header_gap=0.02):
    writer = None
    try:
        async def request():
            nonlocal writer
            reader, writer = await asyncio.open_connection('127.0.0.1', port)
            writer.write(f'GET {path} HTTP/1.1\r\n'.encode())
            await writer.drain()
            await asyncio.sleep(header_gap)
            writer.write(b'Host: localhost\r\nConnection: close\r\n\r\n')
            await writer.drain()
            header = await reader.readuntil(b'\r\n\r\n')
            lines = header[:-4].split(b'\r\n')
            if lines[0] != b'HTTP/1.1 200 OK':
                return 'unexpected_status'
            fields = {}
            for line in lines[1:]:
                key, value = line.split(b':', 1)
                key = key.lower()
                if key in fields:
                    return 'duplicate_header'
                fields[key] = value.strip()
            length = int(fields[b'content-length'])
            if not 0 < length <= 256 or fields.get(b'connection') != b'close':
                return 'invalid_framing'
            if fields.get(b'content-type', b'').split(b';')[0] != b'application/json':
                return 'invalid_content_type'
            body = await reader.readexactly(length)
            if await reader.read(1):
                return 'trailing_bytes'
            return 'ok' if json.loads(body) == {'id': 42, 'name': 'Café team', 'active': True} else 'invalid_body'
        return await asyncio.wait_for(request(), timeout)
    except asyncio.TimeoutError:
        return 'timeout'
    except (OSError, ValueError, KeyError, asyncio.IncompleteReadError, asyncio.LimitOverrunError) as error:
        return type(error).__name__
    finally:
        if writer is not None:
            writer.close()
            try:
                await writer.wait_closed()
            except OSError:
                pass


class Server:
    def __init__(self, recipe):
        env = {k: v for k, v in os.environ.items() if not k.startswith('NEOCLR_')}
        env.update(recipe['env'])
        self.started = time.perf_counter()
        self.process = subprocess.Popen(recipe['command'], env=env, cwd=ROOT,
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        self.stdout, self.stderr, self.lines, self.readers = [], [], queue.Queue(), []
        def drain(stream, output, notify):
            for line in stream:
                output.append(line)
                if notify:
                    self.lines.put((line, time.perf_counter()))
            if notify:
                self.lines.put((None, time.perf_counter()))
        for stream, output, notify in [(self.process.stdout, self.stdout, True),
                                       (self.process.stderr, self.stderr, False)]:
            thread = threading.Thread(target=drain, args=(stream, output, notify))
            thread.start()
            self.readers.append(thread)

    def ready(self):
        while True:
            line, at = self.lines.get(timeout=120)
            assert line is not None, ''.join(self.stderr)
            if line.strip() == 'READY':
                break
        self.port = int(self.lines.get(timeout=10)[0])
        self.control = int(self.lines.get(timeout=10)[0])
        return at-self.started

    def stop(self):
        with socket.create_connection(('127.0.0.1', self.control), timeout=10):
            pass
        self.process.wait(timeout=45)
        for reader in self.readers:
            reader.join(timeout=5)
        assert self.process.returncode == 0, ''.join(self.stderr)
        done = next(line for line in self.stdout if line.startswith('DONE '))
        return list(map(int, done.split()[1:]))

    def close(self):
        if self.process.poll() is None:
            self.process.kill()
            self.process.wait(timeout=10)
        for reader in self.readers:
            reader.join(timeout=5)
        self.process.stdout.close()
        self.process.stderr.close()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--rates', type=float, nargs='+', default=[50, 150, 400])
    p.add_argument('--apps', type=int, nargs='+', default=[1, 2])
    p.add_argument('--modes', nargs='+', default=['arena-eager-sync-jit', 'arena-control-sync-jit',
                                               'arena-eager-live-jit', 'arena-control-live-jit'])
    p.add_argument('--duration', type=float, default=15)
    p.add_argument('--rounds', type=int, default=2)
    p.add_argument('--concurrency', type=int, default=16)
    p.add_argument('--timeout', type=float, default=3)
    p.add_argument('--header-gap-ms', type=float, default=20)
    p.add_argument('--p99-target-ms', type=float, default=100)
    a = p.parse_args()
    assert min(a.rates) > 0 and min(a.apps) > 0 and a.duration > 0 and a.rounds > 0
    assert a.concurrency > 0 and a.timeout > 0 and a.header_gap_ms >= 0
    source = a.build.resolve()/'build.json'
    build = json.loads(source.read_text())
    assert build['passed'] and all(mode in build['recipes'] for mode in a.modes)
    for path, digest in build['inputs'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
    out = a.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    report = dict(completed=False, scope=__doc__, platform=platform.platform(),
                  logicalCpuCount=os.cpu_count(), workload=build.get('workload'),
                  durationSeconds=a.duration, headerGapMs=a.header_gap_ms,
                  perAppClientInflightLimit=a.concurrency, rounds=a.rounds,
                  target=dict(p99Milliseconds=a.p99_target_ms, successfulOfferedFraction=1,
                              dispatchLagP99Milliseconds=5), trials=[], inputs={})
    for path in [source, Path(__file__).resolve(), loader]:
        report['inputs'][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()

    async def checked(*args):
        return await exchange(*args, header_gap=a.header_gap_ms/1000)

    async def warm(servers):
        async def one(server):
            began = time.perf_counter()
            outcomes = []
            for _ in range(16):
                outcomes.append(await checked(server.port, '/json', 256, 30))
            assert outcomes == ['ok']*16, outcomes
            return time.perf_counter()-began
        return await asyncio.gather(*(one(server) for server in servers))

    async def windows(servers, rate):
        return await asyncio.gather(*(load.window(server.port, '/json', 256, rate/len(servers),
            a.duration, a.concurrency, a.timeout, request_fn=checked) for server in servers))

    try:
        points = [(apps, rate, mode) for apps in a.apps for rate in a.rates for mode in a.modes]
        for repetition in range(a.rounds):
            for apps, rate, mode in points if repetition % 2 == 0 else reversed(points):
                row = dict(round=repetition, apps=apps, aggregateOfferedRate=rate, mode=mode, servers=[])
                report['trials'].append(row)
                servers = []
                try:
                    for _ in range(apps):
                        servers.append(Server(build['recipes'][mode]))
                    ready = [server.ready() for server in servers]
                    cold = asyncio.run(warm(servers))
                    before = [load.resource_sample(server.process.pid) for server in servers]
                    measurements = asyncio.run(windows(servers, rate))
                    after = [load.resource_sample(server.process.pid) for server in servers]
                    for index, (server, measurement) in enumerate(zip(servers, measurements)):
                        totals = server.stop()
                        admitted = measurement['admitted']
                        successes = measurement['outcomes'].get('ok', 0)
                        if successes == admitted:
                            assert totals == [16+successes, 0], totals
                        measurement['meetsTarget'] = (successes == measurement['offered'] and
                            measurement['offeredLatencySeconds']['p99'] is not None and
                            measurement['offeredLatencySeconds']['p99'] <= a.p99_target_ms/1000 and
                            measurement['dispatchLagSeconds']['p99'] <= .005)
                        row['servers'].append(dict(readySeconds=ready[index], coldWarmupSeconds=cold[index],
                            measurement=measurement, serverTotals=totals,
                            cpuSecondsDuringTrafficAndDrain=after[index]['cpuSeconds']-before[index]['cpuSeconds'],
                            rssBeforeKiB=before[index]['rssKiB'], rssAfterKiB=after[index]['rssKiB'],
                            stdout=''.join(server.stdout), stderr=''.join(server.stderr)))
                    row['cleanShutdown'] = True
                    print(repetition, apps, rate, mode,
                          [m['outcomes'] for m in measurements], flush=True)
                except Exception as error:
                    row['error'] = repr(error)
                    row['failureOutputs'] = [dict(stdout=''.join(s.stdout), stderr=''.join(s.stderr)) for s in servers]
                    raise
                finally:
                    for server in servers:
                        server.close()
                    (out/'results.json').write_text(json.dumps(report, indent=2)+'\n')
        report['completed'] = True
    finally:
        (out/'results.json').write_text(json.dumps(report, indent=2)+'\n')


if __name__ == '__main__':
    main()
