from pathlib import Path
import subprocess,json,time,hashlib
root=Path('/Users/robert/Projects/neoclr');out=root/'target/lazy-jit-production-default-cases';out.mkdir(exist_ok=False)
base=['python3'];matrix='benchmarks/gc-suite/matrix/'
def cmd(name,*args):return base+[matrix+name]+list(map(str,args))
steps=[
('service-qualification',cmd('lazy-load.py','--build','target/lazy-jit-default-service-build','--output',out/'service-qualification','--modes','arena-eager-live-jit','arena-control-live-jit','arena-eager-sync-jit','arena-control-sync-jit','--rates',25,50,'--apps',1,'--duration',2,'--rounds',1,'--dependency-ms',20,'--reuse-processes')),
('recursion',cmd('validate-lazy-jit-recursion.py','--build','target/lazy-jit-default-build','--output',out/'recursion')),
('failure',cmd('validate-lazy-jit-failure.py','--build','target/lazy-jit-default-build','--output',out/'failure.json')),
('http',cmd('http.py','--build','target/lazy-jit-default-comparison-build','--output',out/'http','--modes','eager-sync-jit','lazy-sync-jit','eager-live-jit','lazy-live-jit','system-control-sync-jit','system-control-live-jit','--samples','plain','json','--protocols','pipeline','--requests',4096,'--rounds',3)),
('placement-summary',cmd('summarize-lazy-profile.py','--measurement',out/'http/results.json','--output',out/'placement-summary.json')),
('samples',cmd('lazy-samples.py','--phase','measure','--build','target/lazy-jit-default-samples-build','--output',out/'samples','--rounds',3)),
('default-summary',cmd('summarize-lazy-jit.py','--http',out/'http/results.json','--samples',out/'samples/results.json','--output',out/'default-summary.json')),
('complex-load',cmd('lazy-load.py','--build','target/lazy-jit-default-complex-build','--output',out/'complex-load','--rates',150,300,600,'--apps',1,2,'--duration',10,'--rounds',2,'--concurrency',32,'--reuse-processes')),
('complex-summary',cmd('summarize-lazy-load.py','--measurement',out/'complex-load/results.json','--output',out/'complex-load/summary.json')),
('service-load',cmd('lazy-load.py','--build','target/lazy-jit-default-service-build','--output',out/'service-load','--rates',100,200,400,'--apps',1,2,'--duration',10,'--rounds',2,'--concurrency',32,'--dependency-ms',20,'--reuse-processes')),
('service-summary',cmd('summarize-lazy-load.py','--measurement',out/'service-load/results.json','--output',out/'service-load/summary.json')),
('cold-load',cmd('lazy-load.py','--build','target/lazy-jit-default-complex-build','--output',out/'cold-load','--rates',150,'--apps',1,'--duration',15,'--rounds',2,'--concurrency',32,'--warmup-requests',0)),
('cold-summary',cmd('summarize-lazy-load.py','--measurement',out/'cold-load/results.json','--output',out/'cold-load/summary.json')),
('uneven-load',cmd('lazy-load.py','--build','target/lazy-jit-default-complex-build','--output',out/'uneven-load','--rates',300,600,'--apps',2,'--shares',.9,.1,'--duration',10,'--rounds',2,'--concurrency',32,'--reuse-processes')),
('uneven-summary',cmd('summarize-lazy-load.py','--measurement',out/'uneven-load/results.json','--output',out/'uneven-load/summary.json')),
]
r=dict(completed=False,scope='Sequential production-default codegen qualification and uninstrumented production-shaped load cohorts; explicit arena controls remain labelled. No builds/profilers overlap timing.',steps=[
('service-qualification',cmd('lazy-load.py','--build','target/lazy-jit-default-service-build','--output',out/'service-qualification','--modes','arena-eager-live-jit','arena-control-live-jit','arena-eager-sync-jit','arena-control-sync-jit','--rates',25,50,'--apps',1,'--duration',2,'--rounds',1,'--dependency-ms',20,'--reuse-processes')),])
for name,command in steps:
 print('START',name,flush=True); began=time.time()
 with (out/(name+'.log')).open('w') as log:
  result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 r['steps'].append(dict(name=name,command=command,exitCode=result.returncode,elapsedSeconds=time.time()-began))
 (out/'queue.json').write_text(json.dumps(r,indent=2)+'\n')
 print('END',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
r['completed']=True;r['queueSourceSha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();(out/'queue.json').write_text(json.dumps(r,indent=2)+'\n')
