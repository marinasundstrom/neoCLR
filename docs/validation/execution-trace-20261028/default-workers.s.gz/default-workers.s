	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 26, 2	sdk_version 26, 2
	.globl	_neoclr_workers_create          ; -- Begin function neoclr_workers_create
	.p2align	2
_neoclr_workers_create:                 ; @neoclr_workers_create
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, #0                         ; =0x0
	tst	x2, #0x7
	b.ne	LBB0_15
; %bb.1:
	mov	x21, x2
	cmp	x2, #256
	b.lo	LBB0_15
; %bb.2:
	sub	w8, w0, #1
	cmp	w8, #3
	b.hi	LBB0_15
; %bb.3:
	mov	x20, x1
	sub	w8, w1, #1
	cmp	w8, #15
	b.hi	LBB0_15
; %bb.4:
	mov	x22, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #21184                      ; =0x52c0
	bl	_calloc
	mov	x19, x0
	cbz	x0, LBB0_15
; %bb.5:
	mov	w0, #1                          ; =0x1
	mov	x1, x21
	bl	_calloc
	str	x0, [x19, #1304]
	cbz	x0, LBB0_13
; %bb.6:
Lloh0:
	adrp	x8, _next_identity@PAGE
Lloh1:
	add	x8, x8, _next_identity@PAGEOFF
	str	x21, [x19, #1312]
	mov	w9, #1                          ; =0x1
	ldaddal	x9, x8, [x8]
	str	x8, [x19]
	add	x8, x8, #1
	cmp	x8, #1
	b.ls	LBB0_30
; %bb.7:
	bl	_pthread_self
	str	x0, [x19, #24]
	str	w20, [x19, #228]
	add	x0, x19, #64
	mov	x1, #0                          ; =0x0
	bl	_pthread_mutex_init
	cbnz	w0, LBB0_12
; %bb.8:
	add	x0, x19, #128
	mov	x1, #0                          ; =0x0
	bl	_pthread_cond_init
	cbnz	w0, LBB0_11
; %bb.9:
	add	x0, x19, #176
	mov	x1, #0                          ; =0x0
	bl	_pthread_cond_init
	cbz	w0, LBB0_16
; %bb.10:
	add	x0, x19, #128
	bl	_pthread_cond_destroy
LBB0_11:
	add	x0, x19, #64
	bl	_pthread_mutex_destroy
LBB0_12:
	ldr	x0, [x19, #1304]
	bl	_free
LBB0_13:
	mov	x0, x19
	bl	_free
LBB0_14:
	mov	x19, #0                         ; =0x0
LBB0_15:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB0_16:
	mov	w9, w20
	cmp	w20, #3
	b.hi	LBB0_18
; %bb.17:
	mov	x10, #0                         ; =0x0
	mov	x8, x22
	b	LBB0_23
LBB0_18:
	and	x10, x9, #0x1c
	str	x19, [x19, #1344]
	str	x19, [x19, #2552]
	str	x19, [x19, #3760]
	str	x19, [x19, #4968]
	cmp	x10, #4
	mov	x8, x22
	b.eq	LBB0_22
; %bb.19:
	str	x19, [x19, #6176]
	str	x19, [x19, #7384]
	str	x19, [x19, #8592]
	str	x19, [x19, #9800]
	cmp	x10, #8
	b.eq	LBB0_22
; %bb.20:
	str	x19, [x19, #11008]
	str	x19, [x19, #12216]
	str	x19, [x19, #13424]
	str	x19, [x19, #14632]
	cmp	x10, #12
	b.eq	LBB0_22
; %bb.21:
	str	x19, [x19, #15840]
	str	x19, [x19, #17048]
	str	x19, [x19, #18256]
	str	x19, [x19, #19464]
LBB0_22:
	cmp	x10, x9
	b.eq	LBB0_25
LBB0_23:
	mov	w11, #1208                      ; =0x4b8
	umull	x11, w10, w11
	add	x11, x11, #1344
	sub	x9, x9, x10
LBB0_24:                                ; =>This Inner Loop Header: Depth=1
	str	x19, [x19, x11]
	add	x11, x11, #1208
	subs	x9, x9, #1
	b.ne	LBB0_24
LBB0_25:
	ldr	w9, [x19, #224]
	cmp	w9, w8
	b.hs	LBB0_15
; %bb.26:
	add	x21, x19, #32
Lloh2:
	adrp	x20, _run@PAGE
Lloh3:
	add	x20, x20, _run@PAGEOFF
LBB0_27:                                ; =>This Inner Loop Header: Depth=1
	add	x0, x21, w9, uxtw #3
	mov	x1, #0                          ; =0x0
	mov	x2, x20
	mov	x3, x19
	bl	_pthread_create
	cbnz	w0, LBB0_29
; %bb.28:                               ;   in Loop: Header=BB0_27 Depth=1
	ldr	w8, [x19, #224]
	add	w9, w8, #1
	str	w9, [x19, #224]
	cmp	w9, w22
	b.lo	LBB0_27
	b	LBB0_15
LBB0_29:
	mov	x0, x19
	bl	_neoclr_workers_close
	mov	x0, x19
	bl	_neoclr_workers_destroy
	b	LBB0_14
LBB0_30:
	bl	_abort
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function run
_run:                                   ; @run
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
Lloh4:
	adrp	x0, _entered@TLVPPAGE
Lloh5:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x9, x0
Lloh6:
	adrp	x0, _reading@TLVPPAGE
Lloh7:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x10, x0
Lloh8:
	adrp	x0, _mutating@TLVPPAGE
Lloh9:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x11, x0
Lloh10:
	adrp	x0, _executing@TLVPPAGE
Lloh11:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	mov	w8, #9800                       ; =0x2648
	add	x8, x19, x8
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
	mov	w8, #8592                       ; =0x2190
	add	x8, x19, x8
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	mov	w8, #7384                       ; =0x1cd8
	add	x8, x19, x8
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	mov	w8, #6176                       ; =0x1820
	add	x12, x19, x8
	mov	w8, #4968                       ; =0x1368
	add	x8, x19, x8
	add	x13, x19, #1344
	str	x13, [sp, #88]                  ; 8-byte Folded Spill
	mov	w22, #9664                      ; =0x25c0
	mov	w21, #29160                     ; =0x71e8
	mov	w25, #27952                     ; =0x6d30
	mov	w26, #26744                     ; =0x6878
	mov	w27, #25536                     ; =0x63c0
	mov	w28, #24328                     ; =0x5f08
	mov	w23, #23120                     ; =0x5a50
	mov	w20, #21912                     ; =0x5598
	stp	x10, x9, [sp, #24]              ; 16-byte Folded Spill
	str	x11, [sp, #16]                  ; 8-byte Folded Spill
	stp	x8, x12, [sp, #48]              ; 16-byte Folded Spill
LBB1_1:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_5 Depth 2
                                        ;       Child Loop BB1_19 Depth 3
                                        ;       Child Loop BB1_13 Depth 3
	ldr	x8, [x9]
	ldr	x9, [x10]
	ldr	x10, [x11]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB1_65
; %bb.2:                                ;   in Loop: Header=BB1_1 Depth=1
	add	x0, x19, #64
	bl	_pthread_mutex_lock
	cbz	w0, LBB1_5
	b	LBB1_65
LBB1_3:                                 ;   in Loop: Header=BB1_5 Depth=2
	cbnz	x24, LBB1_50
LBB1_4:                                 ;   in Loop: Header=BB1_5 Depth=2
	add	x0, x19, #128
	add	x1, x19, #64
	bl	_pthread_cond_wait
	cbnz	w0, LBB1_65
LBB1_5:                                 ;   Parent Loop BB1_1 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_19 Depth 3
                                        ;       Child Loop BB1_13 Depth 3
	ldr	w8, [x19, #244]
	cbnz	w8, LBB1_63
; %bb.6:                                ;   in Loop: Header=BB1_5 Depth=2
	ldr	w8, [x19, #228]
	cbz	w8, LBB1_4
; %bb.7:                                ;   in Loop: Header=BB1_5 Depth=2
	cmp	w8, #8
	b.hs	LBB1_16
; %bb.8:                                ;   in Loop: Header=BB1_5 Depth=2
	mov	x9, #0                          ; =0x0
	mov	x24, #0                         ; =0x0
LBB1_9:                                 ;   in Loop: Header=BB1_5 Depth=2
	and	x8, x8, #0x7
	cbz	x8, LBB1_3
; %bb.10:                               ;   in Loop: Header=BB1_5 Depth=2
	ldr	x10, [sp, #88]                  ; 8-byte Folded Reload
	mov	w11, #1208                      ; =0x4b8
	madd	x9, x9, x11, x10
	b	LBB1_13
LBB1_11:                                ;   in Loop: Header=BB1_13 Depth=3
	mov	x24, x9
LBB1_12:                                ;   in Loop: Header=BB1_13 Depth=3
	add	x9, x9, #1208
	subs	x8, x8, #1
	b.eq	LBB1_3
LBB1_13:                                ;   Parent Loop BB1_1 Depth=1
                                        ;     Parent Loop BB1_5 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x9, #32]
	cmp	w10, #1
	b.ne	LBB1_12
; %bb.14:                               ;   in Loop: Header=BB1_13 Depth=3
	cbz	x24, LBB1_11
; %bb.15:                               ;   in Loop: Header=BB1_13 Depth=3
	ldr	x10, [x9, #16]
	ldr	x11, [x24, #16]
	cmp	x10, x11
	b.lo	LBB1_11
	b	LBB1_12
LBB1_16:                                ;   in Loop: Header=BB1_5 Depth=2
	mov	x10, #0                         ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x24, #0                         ; =0x0
	lsr	x11, x8, #3
	umull	x11, w11, w22
	ldp	x17, x16, [sp, #72]             ; 16-byte Folded Reload
	ldp	x1, x0, [sp, #56]               ; 16-byte Folded Reload
	ldr	x2, [sp, #48]                   ; 8-byte Folded Reload
	b	LBB1_19
LBB1_17:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x24, x16, x10
LBB1_18:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x9, x9, #8
	add	x10, x10, x22
	cmp	x11, x10
	b.eq	LBB1_9
LBB1_19:                                ;   Parent Loop BB1_1 Depth=1
                                        ;     Parent Loop BB1_5 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x12, x19, x10
	prfm	pldl1keep, [x12, #20704]
	ldr	w13, [x12, #1376]
	cmp	w13, #1
	b.ne	LBB1_23
; %bb.20:                               ;   in Loop: Header=BB1_19 Depth=3
	cbz	x24, LBB1_22
; %bb.21:                               ;   in Loop: Header=BB1_19 Depth=3
	add	x13, x19, x10
	ldr	x13, [x13, #1360]
	ldr	x14, [x24, #16]
	cmp	x13, x14
	b.hs	LBB1_23
LBB1_22:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x24, x12, #1344
LBB1_23:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x13, x12, x20
	prfm	pldl1keep, [x13]
	ldr	w13, [x12, #2584]
	cmp	w13, #1
	b.ne	LBB1_27
; %bb.24:                               ;   in Loop: Header=BB1_19 Depth=3
	cbz	x24, LBB1_26
; %bb.25:                               ;   in Loop: Header=BB1_19 Depth=3
	add	x13, x19, x10
	ldr	x13, [x13, #2568]
	ldr	x14, [x24, #16]
	cmp	x13, x14
	b.hs	LBB1_27
LBB1_26:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x24, x12, #2552
LBB1_27:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x14, x12, x23
	add	x13, x19, x10
	prfm	pldl1keep, [x14]
	ldr	w14, [x13, #3792]
	cmp	w14, #1
	b.ne	LBB1_31
; %bb.28:                               ;   in Loop: Header=BB1_19 Depth=3
	cbz	x24, LBB1_30
; %bb.29:                               ;   in Loop: Header=BB1_19 Depth=3
	add	x14, x19, x10
	ldr	x14, [x14, #3776]
	ldr	x15, [x24, #16]
	cmp	x14, x15
	b.hs	LBB1_31
LBB1_30:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x24, x13, #3760
LBB1_31:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x14, x12, x28
	prfm	pldl1keep, [x14]
	ldr	w13, [x13, #5000]
	cmp	w13, #1
	b.ne	LBB1_35
; %bb.32:                               ;   in Loop: Header=BB1_19 Depth=3
	cbz	x24, LBB1_34
; %bb.33:                               ;   in Loop: Header=BB1_19 Depth=3
	add	x13, x19, x10
	ldr	x13, [x13, #4984]
	ldr	x14, [x24, #16]
	cmp	x13, x14
	b.hs	LBB1_35
LBB1_34:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x24, x2, x10
LBB1_35:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x14, x12, x27
	add	x13, x19, x10
	prfm	pldl1keep, [x14]
	ldr	w14, [x13, #6208]
	cmp	w14, #1
	b.ne	LBB1_39
; %bb.36:                               ;   in Loop: Header=BB1_19 Depth=3
	cbz	x24, LBB1_38
; %bb.37:                               ;   in Loop: Header=BB1_19 Depth=3
	add	x14, x19, x10
	ldr	x14, [x14, #6192]
	ldr	x15, [x24, #16]
	cmp	x14, x15
	b.hs	LBB1_39
LBB1_38:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x24, x1, x10
LBB1_39:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x14, x12, x26
	prfm	pldl1keep, [x14]
	ldr	w13, [x13, #7416]
	cmp	w13, #1
	b.ne	LBB1_43
; %bb.40:                               ;   in Loop: Header=BB1_19 Depth=3
	cbz	x24, LBB1_42
; %bb.41:                               ;   in Loop: Header=BB1_19 Depth=3
	add	x13, x19, x10
	ldr	x13, [x13, #7400]
	ldr	x14, [x24, #16]
	cmp	x13, x14
	b.hs	LBB1_43
LBB1_42:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x24, x0, x10
LBB1_43:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x14, x12, x25
	add	x13, x19, x10
	prfm	pldl1keep, [x14]
	ldr	w14, [x13, #8624]
	cmp	w14, #1
	b.ne	LBB1_47
; %bb.44:                               ;   in Loop: Header=BB1_19 Depth=3
	cbz	x24, LBB1_46
; %bb.45:                               ;   in Loop: Header=BB1_19 Depth=3
	add	x14, x19, x10
	ldr	x14, [x14, #8608]
	ldr	x15, [x24, #16]
	cmp	x14, x15
	b.hs	LBB1_47
LBB1_46:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x24, x17, x10
LBB1_47:                                ;   in Loop: Header=BB1_19 Depth=3
	add	x12, x12, x21
	prfm	pldl1keep, [x12]
	ldr	w12, [x13, #9832]
	cmp	w12, #1
	b.ne	LBB1_18
; %bb.48:                               ;   in Loop: Header=BB1_19 Depth=3
	cbz	x24, LBB1_17
; %bb.49:                               ;   in Loop: Header=BB1_19 Depth=3
	add	x12, x19, x10
	ldr	x12, [x12, #9816]
	ldr	x13, [x24, #16]
	cmp	x12, x13
	b.lo	LBB1_17
	b	LBB1_18
LBB1_50:                                ;   in Loop: Header=BB1_1 Depth=1
	mov	w8, #2                          ; =0x2
	str	w8, [x24, #32]
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB1_65
; %bb.51:                               ;   in Loop: Header=BB1_1 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	str	x24, [x8]
	ldr	x8, [x24, #1192]
	ldr	x1, [x24, #1200]
	mov	x0, x24
	blr	x8
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	ldp	x8, x9, [sp, #32]               ; 16-byte Folded Reload
	str	xzr, [x9]
	ldr	x8, [x8]
	cbnz	x8, LBB1_65
; %bb.52:                               ;   in Loop: Header=BB1_1 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB1_65
; %bb.53:                               ;   in Loop: Header=BB1_1 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB1_65
; %bb.54:                               ;   in Loop: Header=BB1_1 Depth=1
	add	x0, x19, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB1_65
; %bb.55:                               ;   in Loop: Header=BB1_1 Depth=1
	ldr	w8, [x24, #36]
	cbz	w8, LBB1_57
; %bb.56:                               ;   in Loop: Header=BB1_1 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [x24, #40]
	stp	xzr, xzr, [x24, #128]
	str	xzr, [x24, #120]
	add	x0, x24, #144
	mov	w1, #1048                       ; =0x418
	bl	_bzero
	b	LBB1_60
LBB1_57:                                ;   in Loop: Header=BB1_1 Depth=1
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	cbnz	w8, LBB1_59
; %bb.58:                               ;   in Loop: Header=BB1_1 Depth=1
	ldr	w8, [x24, #144]
	cbz	w8, LBB1_62
LBB1_59:                                ;   in Loop: Header=BB1_1 Depth=1
	mov	w8, #2                          ; =0x2
	str	w8, [x24, #40]
	stp	xzr, xzr, [x24, #128]
	str	xzr, [x24, #120]
LBB1_60:                                ;   in Loop: Header=BB1_1 Depth=1
	str	xzr, [x24, #48]
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #56]
	stur	q0, [x24, #72]
	stur	q0, [x24, #88]
	stur	q0, [x24, #104]
	ldr	x8, [x24]
	ldr	x9, [x8, #16]
	cmn	x9, #1
	b.eq	LBB1_65
; %bb.61:                               ;   in Loop: Header=BB1_1 Depth=1
	add	x9, x9, #1
	str	x9, [x8, #16]
	str	x9, [x24, #24]
	mov	w9, #3                          ; =0x3
	str	w9, [x24, #32]
	add	x0, x8, #176
	bl	_pthread_cond_broadcast
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	ldp	x10, x9, [sp, #24]              ; 16-byte Folded Reload
	ldr	x11, [sp, #16]                  ; 8-byte Folded Reload
	cbz	w0, LBB1_1
	b	LBB1_65
LBB1_62:                                ;   in Loop: Header=BB1_1 Depth=1
	str	wzr, [x24, #40]
	b	LBB1_60
LBB1_63:
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB1_65
; %bb.64:
	mov	x0, #0                          ; =0x0
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB1_65:
	bl	_abort
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_close           ; -- Begin function neoclr_workers_close
	.p2align	2
_neoclr_workers_close:                  ; @neoclr_workers_close
	.cfi_startproc
; %bb.0:
	stp	d9, d8, [sp, #-80]!             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	mov	x19, x0
	ldr	x20, [x0, #24]
	bl	_pthread_self
	mov	x1, x0
	mov	x0, x20
	bl	_pthread_equal
	mov	x8, x0
Lloh12:
	adrp	x0, _entered@TLVPPAGE
Lloh13:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	w8, #0
	ccmp	x9, #0, #0, ne
	b.eq	LBB2_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	b	LBB2_21
LBB2_2:
Lloh14:
	adrp	x0, _reading@TLVPPAGE
Lloh15:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh16:
	adrp	x0, _mutating@TLVPPAGE
Lloh17:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	orr	x8, x8, x9
	cbnz	x8, LBB2_22
; %bb.3:
	add	x0, x19, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB2_22
; %bb.4:
	ldr	w8, [x19, #248]
	cbz	w8, LBB2_7
; %bb.5:
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB2_22
; %bb.6:
	mov	w0, #1                          ; =0x1
	b	LBB2_21
LBB2_7:
	mov	w20, #1                         ; =0x1
	str	w20, [x19, #244]
	ldr	w8, [x19, #228]
	cbz	w8, LBB2_15
; %bb.8:
	mov	x21, #0                         ; =0x0
	add	x22, x19, #1392
	movi.2s	v8, #1
	mov	w23, #3                         ; =0x3
	b	LBB2_10
LBB2_9:                                 ;   in Loop: Header=BB2_10 Depth=1
	add	x21, x21, #1
	add	x22, x22, #1208
	cmp	x21, x8
	b.hs	LBB2_15
LBB2_10:                                ; =>This Inner Loop Header: Depth=1
	ldur	w9, [x22, #-16]
	cmp	w9, #1
	b.eq	LBB2_13
; %bb.11:                               ;   in Loop: Header=BB2_10 Depth=1
	cmp	w9, #2
	b.ne	LBB2_9
; %bb.12:                               ;   in Loop: Header=BB2_10 Depth=1
	stur	w20, [x22, #-12]
	b	LBB2_9
LBB2_13:                                ;   in Loop: Header=BB2_10 Depth=1
	str	xzr, [x22]
	stur	d8, [x22, #-12]
	ldur	x8, [x22, #-48]
	ldr	x9, [x8, #16]
	cmn	x9, #1
	b.eq	LBB2_22
; %bb.14:                               ;   in Loop: Header=BB2_10 Depth=1
	add	x9, x9, #1
	str	x9, [x8, #16]
	stur	x9, [x22, #-24]
	stur	w23, [x22, #-16]
	add	x0, x8, #176
	bl	_pthread_cond_broadcast
	ldr	w8, [x19, #228]
	b	LBB2_9
LBB2_15:
	add	x0, x19, #128
	bl	_pthread_cond_broadcast
	add	x0, x19, #176
	bl	_pthread_cond_broadcast
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB2_22
; %bb.16:
	ldr	w8, [x19, #224]
	cbz	w8, LBB2_20
; %bb.17:
	mov	x20, #0                         ; =0x0
	add	x21, x19, #32
LBB2_18:                                ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x21, x20, lsl #3]
	mov	x1, #0                          ; =0x0
	bl	_pthread_join
	cbnz	w0, LBB2_22
; %bb.19:                               ;   in Loop: Header=BB2_18 Depth=1
	add	x20, x20, #1
	ldr	w8, [x19, #224]
	cmp	x20, x8
	b.lo	LBB2_18
LBB2_20:
	mov	w0, #1                          ; =0x1
	str	w0, [x19, #248]
LBB2_21:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #80               ; 16-byte Folded Reload
	ret
LBB2_22:
	bl	_abort
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_destroy         ; -- Begin function neoclr_workers_destroy
	.p2align	2
_neoclr_workers_destroy:                ; @neoclr_workers_destroy
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	ldr	x20, [x0, #24]
	bl	_pthread_self
	mov	x1, x0
	mov	x0, x20
	bl	_pthread_equal
	cbz	w0, LBB3_5
; %bb.1:
	ldr	w9, [x19, #248]
Lloh18:
	adrp	x0, _entered@TLVPPAGE
Lloh19:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w9, LBB3_5
; %bb.2:
	ldr	x8, [x8]
	cbnz	x8, LBB3_5
; %bb.3:
	ldr	w8, [x19, #252]
	cbz	w8, LBB3_6
LBB3_4:
	mov	w0, #0                          ; =0x0
LBB3_5:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB3_6:
	ldr	w8, [x19, #228]
	cbz	w8, LBB3_10
; %bb.7:
	add	x9, x19, #1376
LBB3_8:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w10, [x9]
	cbnz	w10, LBB3_4
; %bb.9:                                ;   in Loop: Header=BB3_8 Depth=1
	add	x9, x9, #1208
	subs	x8, x8, #1
	b.ne	LBB3_8
LBB3_10:
	mov	x8, #-512                       ; =0xfffffffffffffe00
LBB3_11:                                ; =>This Inner Loop Header: Depth=1
	add	x9, x19, x8
	ldr	x9, [x9, #21192]
	cbnz	x9, LBB3_4
; %bb.12:                               ;   in Loop: Header=BB3_11 Depth=1
	adds	x8, x8, #16
	b.ne	LBB3_11
; %bb.13:
	ldr	x8, [x19, #1336]
	cbz	x8, LBB3_16
; %bb.14:
	add	x0, x19, #256
	bl	_neoclr_gc_complete_invocation_v1
	cbnz	w0, LBB3_4
; %bb.15:
	add	x0, x19, #256
	mov	w1, #1048                       ; =0x418
	bl	_bzero
LBB3_16:
	add	x1, sp, #8
	mov	x0, x19
	bl	_neoclr_workers_collect
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB3_5
; %bb.17:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB3_5
; %bb.18:
	add	x0, x19, #176
	bl	_pthread_cond_destroy
	add	x0, x19, #128
	bl	_pthread_cond_destroy
	add	x0, x19, #64
	bl	_pthread_mutex_destroy
	ldr	x0, [x19, #1304]
	bl	_free
	mov	x0, x19
	bl	_free
	mov	w0, #1                          ; =0x1
	b	LBB3_5
	.loh AdrpLdr	Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_bootstrap       ; -- Begin function neoclr_workers_bootstrap
	.p2align	2
_neoclr_workers_bootstrap:              ; @neoclr_workers_bootstrap
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x21, x4
	mov	x22, x3
	mov	x20, x2
	mov	x23, x1
	mov	x19, x0
	ldr	x24, [x0, #24]
	bl	_pthread_self
	mov	x1, x0
	mov	x0, x24
	bl	_pthread_equal
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x21, LBB4_11
; %bb.1:
	cbz	x20, LBB4_11
; %bb.2:
	cbz	x23, LBB4_11
; %bb.3:
	cbz	w8, LBB4_11
; %bb.4:
	mov	x0, x19
	bl	_heap_lock
	ldr	w8, [x19, #244]
	cbnz	w8, LBB4_9
; %bb.5:
	ldr	x8, [x19, #1336]
	cbnz	x8, LBB4_9
; %bb.6:
	ldr	x8, [x19, #1320]
	cbnz	x8, LBB4_9
; %bb.7:
	bl	_neoclr_root_probe_head_v1
	cbnz	x0, LBB4_9
; %bb.8:
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB4_12
LBB4_9:
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB4_20
; %bb.10:
	mov	w0, #3                          ; =0x3
LBB4_11:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB4_12:
	str	xzr, [sp, #8]
	add	x24, sp, #8
	add	x1, sp, #8
	add	x2, x19, #256
	mov	x0, x22
	blr	x23
	mov	x22, x0
	ldr	x8, [sp, #8]
	cmp	x8, #0
	csel	x1, x24, xzr, ne
	cset	w2, ne
	add	x0, x19, #256
	bl	_neoclr_gc_owned_roots_check_v1
	cbnz	w0, LBB4_20
; %bb.13:
	cbnz	w22, LBB4_16
; %bb.14:
	str	xzr, [sp]
	ldr	x1, [sp, #8]
	add	x0, x19, #256
	mov	x2, sp
	bl	_neoclr_gc_callback_read_v1
	mov	x22, x0
	cbnz	w0, LBB4_16
; %bb.15:
	ldr	x1, [sp]
	mov	x0, x19
	mov	x2, x21
	bl	_adopt
	mov	w8, #5                          ; =0x5
	cmp	w0, #0
	csel	w22, w8, wzr, eq
LBB4_16:
	ldr	x1, [sp, #8]
	cbz	x1, LBB4_18
; %bb.17:
	add	x0, x19, #256
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB4_20
LBB4_18:
	str	x20, [x19, #1336]
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB4_20
; %bb.19:
	mov	x0, x22
	b	LBB4_11
LBB4_20:
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function heap_lock
_heap_lock:                             ; @heap_lock
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh20:
	adrp	x0, _entered@TLVPPAGE
Lloh21:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh22:
	adrp	x0, _reading@TLVPPAGE
Lloh23:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh24:
	adrp	x0, _mutating@TLVPPAGE
Lloh25:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB5_7
; %bb.1:
	add	x0, x19, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB5_7
; %bb.2:
	ldr	w8, [x19, #240]
	add	w8, w8, #1
	str	w8, [x19, #240]
	b	LBB5_4
LBB5_3:                                 ;   in Loop: Header=BB5_4 Depth=1
	add	x0, x19, #176
	add	x1, x19, #64
	bl	_pthread_cond_wait
	cbnz	w0, LBB5_7
LBB5_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x19, #232]
	cbnz	w8, LBB5_3
; %bb.5:                                ;   in Loop: Header=BB5_4 Depth=1
	ldr	w8, [x19, #236]
	cbnz	w8, LBB5_3
; %bb.6:
	ldr	w8, [x19, #240]
	sub	w8, w8, #1
	str	w8, [x19, #240]
	add	x0, x19, #176
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_pthread_cond_broadcast
LBB5_7:
	bl	_abort
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh20, Lloh21
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function adopt
_adopt:                                 ; @adopt
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB6_7
; %bb.1:
	mov	x8, #0                          ; =0x0
	mov	w9, #20680                      ; =0x50c8
	add	x10, x0, x9
	mov	w9, #1                          ; =0x1
	b	LBB6_3
LBB6_2:                                 ;   in Loop: Header=BB6_3 Depth=1
	cmp	x8, #31
	add	x11, x8, #1
	cset	w9, lo
	add	x10, x10, #16
	mov	x8, x11
	cmp	x11, #32
	b.eq	LBB6_6
LBB6_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x10]
	cbnz	x11, LBB6_2
; %bb.4:                                ;   in Loop: Header=BB6_3 Depth=1
	ldur	x11, [x10, #-8]
	cmn	x11, #1
	b.eq	LBB6_2
; %bb.5:
	add	x11, x11, #1
	stp	x11, x1, [x10, #-8]
	ldr	x10, [x0]
	stp	x10, x11, [x2]
	mov	w10, #1                         ; =0x1
	stp	w8, w10, [x2, #16]
	and	w0, w9, #0x1
	ret
LBB6_6:
	mov	w0, #0                          ; =0x0
	ret
LBB6_7:
	stp	xzr, xzr, [x2]
	mov	w0, #1                          ; =0x1
	str	xzr, [x2, #16]
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_invoke_capture   ; -- Begin function neoclr_worker_invoke_capture
	.p2align	2
_neoclr_worker_invoke_capture:          ; @neoclr_worker_invoke_capture
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #20960                      ; =0x51e0
Lloh26:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh27:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #5, lsl #12             ; =20480
	sub	sp, sp, #480
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
Lloh28:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh29:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh30:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
Lloh31:
	adrp	x0, _executing@TLVPPAGE
Lloh32:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x8, x19
	b.ne	LBB7_26
; %bb.1:
	ldr	x20, [x19]
	mov	x0, x20
	bl	_heap_lock
Lloh33:
	adrp	x0, _entered@TLVPPAGE
Lloh34:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	x19, [x0]
	ldr	x8, [x20, #1336]
	cbz	x8, LBB7_6
; %bb.2:
	mov	x21, x19
	ldr	w8, [x21, #144]!
	cbnz	w8, LBB7_6
; %bb.3:
	ldr	w8, [x20, #256]
	cbnz	w8, LBB7_6
; %bb.4:
	mov	x22, x0
	bl	_neoclr_root_probe_head_v1
	mov	x8, x0
	mov	x0, x22
	cbnz	x8, LBB7_6
; %bb.5:
	bl	_neoclr_roots_parked_v1
	mov	x8, x0
	mov	x0, x22
	cbz	x8, LBB7_11
LBB7_6:
	ldr	x8, [x0]
	cmp	x8, x19
	b.ne	LBB7_26
; %bb.7:
	str	xzr, [x0]
	ldr	x8, [x19]
	add	x0, x8, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB7_26
; %bb.8:
	mov	w0, #3                          ; =0x3
LBB7_9:
	ldur	x8, [x29, #-88]
Lloh35:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh36:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh37:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB7_27
; %bb.10:
	add	sp, sp, #5, lsl #12             ; =20480
	add	sp, sp, #480
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB7_11:
	add	x22, sp, #160
	add	x0, sp, #160
	mov	w1, #1048                       ; =0x418
	bl	_bzero
	add	x23, x22, #1048
	add	x24, x20, #1304
	ldr	q0, [x24]
	str	q0, [x23]
	ldr	x8, [x24, #16]
	str	x8, [sp, #1224]
	ldr	x8, [x20, #1328]
	str	x8, [sp, #1232]
	ldr	x26, [sp, #1208]
	ldr	x25, [sp, #1216]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24]
	str	xzr, [sp, #152]
	ldr	x1, [x19, #48]
	add	x0, sp, #160
	add	x2, sp, #152
	bl	_neoclr_gc_host_root_create_v1
	mov	x22, x0
	cbnz	w0, LBB7_16
; %bb.12:
	add	x1, sp, #1240
	mov	x0, x20
	bl	_pool_slots
	mov	x4, x0
	str	xzr, [sp, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
Lloh38:
	adrp	x5, l_.str@PAGE
Lloh39:
	add	x5, x5, l_.str@PAGEOFF
	add	x0, sp, #48
	add	x1, sp, #160
	add	x3, sp, #1240
	mov	w2, #0                          ; =0x0
	mov	w6, #2                          ; =0x2
	bl	_neoclr_gc_enter_v1
	mov	x27, sp
	mov	x0, sp
	bl	_neoclr_roots_park_v1
	ldr	x8, [x20, #1336]
	ldr	x0, [sp, #152]
	add	x1, sp, #160
	blr	x8
	mov	x22, x0
	bl	_neoclr_root_probe_head_v1
	cbnz	x0, LBB7_26
; %bb.13:
	bl	_neoclr_roots_parked_v1
	cmp	x0, x27
	b.ne	LBB7_26
; %bb.14:
	mov	x0, sp
	bl	_neoclr_roots_resume_v1
	add	x0, sp, #48
	bl	_neoclr_gc_leave_v1
	add	x0, sp, #160
	add	x1, sp, #152
	mov	w2, #1                          ; =0x1
	bl	_neoclr_gc_owned_roots_check_v1
	cbnz	w0, LBB7_26
; %bb.15:
	ldr	x1, [sp, #152]
	add	x0, sp, #160
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB7_26
LBB7_16:
	ldr	x8, [sp, #1208]
	cmp	x8, x26
	b.ne	LBB7_26
; %bb.17:
	ldr	x8, [sp, #1216]
	cmp	x8, x25
	b.ne	LBB7_26
; %bb.18:
	ldr	x8, [sp, #1224]
	cmp	x8, x25
	b.hi	LBB7_26
; %bb.19:
	ldr	x8, [x24]
	cbnz	x8, LBB7_26
; %bb.20:
	ldr	x8, [x20, #1312]
	cbnz	x8, LBB7_26
; %bb.21:
	ldr	x8, [x20, #1320]
	cbnz	x8, LBB7_26
; %bb.22:
	ldr	x8, [x20, #1328]
	cbnz	x8, LBB7_26
; %bb.23:
	ldr	q0, [x23]
	str	q0, [x24]
	ldr	x8, [x23, #16]
	str	x8, [x24, #16]
	ldr	x8, [sp, #1232]
	str	x8, [x20, #1328]
	ldr	w8, [sp, #160]
	cbz	w8, LBB7_25
; %bb.24:
	add	x1, sp, #160
	mov	x0, x21
	mov	w2, #1048                       ; =0x418
	bl	_memcpy
LBB7_25:
	add	x0, sp, #160
	mov	w1, #1080                       ; =0x438
	bl	_bzero
	mov	x0, x19
	bl	_neoclr_worker_leave
	mov	x0, x22
	b	LBB7_9
LBB7_26:
	bl	_abort
LBB7_27:
	bl	___stack_chk_fail
	.loh AdrpLdr	Lloh31, Lloh32
	.loh AdrpLdrGotLdr	Lloh28, Lloh29, Lloh30
	.loh AdrpLdr	Lloh33, Lloh34
	.loh AdrpLdrGotLdr	Lloh35, Lloh36, Lloh37
	.loh AdrpAdd	Lloh38, Lloh39
	.loh AdrpLdrGot	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_enter            ; -- Begin function neoclr_worker_enter
	.p2align	2
_neoclr_worker_enter:                   ; @neoclr_worker_enter
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh40:
	adrp	x0, _executing@TLVPPAGE
Lloh41:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x8, x19
	b.ne	LBB8_2
; %bb.1:
	ldr	x0, [x19]
	bl	_heap_lock
Lloh42:
	adrp	x0, _entered@TLVPPAGE
Lloh43:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	x19, [x0]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB8_2:
	bl	_abort
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpLdr	Lloh42, Lloh43
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_leave            ; -- Begin function neoclr_worker_leave
	.p2align	2
_neoclr_worker_leave:                   ; @neoclr_worker_leave
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh44:
	adrp	x0, _entered@TLVPPAGE
Lloh45:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	x9, x8
	b.ne	LBB9_3
; %bb.1:
	str	xzr, [x0]
	ldr	x8, [x8]
	add	x0, x8, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB9_3
; %bb.2:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB9_3:
	bl	_abort
	.loh AdrpLdr	Lloh44, Lloh45
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function pool_slots
lCPI10_0:
	.long	8                               ; 0x8
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_pool_slots:                            ; @pool_slots
	.cfi_startproc
; %bb.0:
	mov	w8, #20680                      ; =0x50c8
	add	x8, x0, x8
	str	x8, [x1]
	mov	w8, #20696                      ; =0x50d8
	add	x8, x0, x8
	str	x8, [x1, #16]
	mov	w8, #20712                      ; =0x50e8
	add	x8, x0, x8
	str	x8, [x1, #32]
	mov	w8, #20728                      ; =0x50f8
	add	x8, x0, x8
	str	x8, [x1, #48]
Lloh46:
	adrp	x8, lCPI10_0@PAGE
Lloh47:
	ldr	d0, [x8, lCPI10_0@PAGEOFF]
	str	d0, [x1, #8]
	str	d0, [x1, #24]
	str	d0, [x1, #40]
	str	d0, [x1, #56]
	mov	w8, #20744                      ; =0x5108
	add	x8, x0, x8
	mov	w9, #20760                      ; =0x5118
	add	x9, x0, x9
	mov	w10, #20776                     ; =0x5128
	add	x10, x0, x10
	mov	w11, #20792                     ; =0x5138
	add	x11, x0, x11
	str	x8, [x1, #64]
	str	x9, [x1, #80]
	str	x10, [x1, #96]
	str	x11, [x1, #112]
	str	d0, [x1, #72]
	str	d0, [x1, #88]
	str	d0, [x1, #104]
	str	d0, [x1, #120]
	mov	w8, #20808                      ; =0x5148
	add	x8, x0, x8
	mov	w9, #20824                      ; =0x5158
	add	x9, x0, x9
	mov	w10, #20840                     ; =0x5168
	add	x10, x0, x10
	mov	w11, #20856                     ; =0x5178
	add	x11, x0, x11
	str	x8, [x1, #128]
	str	x9, [x1, #144]
	str	x10, [x1, #160]
	str	x11, [x1, #176]
	str	d0, [x1, #136]
	str	d0, [x1, #152]
	str	d0, [x1, #168]
	str	d0, [x1, #184]
	mov	w8, #20872                      ; =0x5188
	add	x8, x0, x8
	mov	w9, #20888                      ; =0x5198
	add	x9, x0, x9
	mov	w10, #20904                     ; =0x51a8
	add	x10, x0, x10
	mov	w11, #20920                     ; =0x51b8
	add	x11, x0, x11
	str	x8, [x1, #192]
	str	x9, [x1, #208]
	str	x10, [x1, #224]
	str	x11, [x1, #240]
	str	d0, [x1, #200]
	str	d0, [x1, #216]
	str	d0, [x1, #232]
	str	d0, [x1, #248]
	mov	w8, #20936                      ; =0x51c8
	add	x8, x0, x8
	mov	w9, #20952                      ; =0x51d8
	add	x9, x0, x9
	mov	w10, #20968                     ; =0x51e8
	add	x10, x0, x10
	mov	w11, #20984                     ; =0x51f8
	add	x11, x0, x11
	str	x8, [x1, #256]
	str	x9, [x1, #272]
	str	x10, [x1, #288]
	str	x11, [x1, #304]
	str	d0, [x1, #264]
	str	d0, [x1, #280]
	str	d0, [x1, #296]
	str	d0, [x1, #312]
	mov	w8, #21000                      ; =0x5208
	add	x8, x0, x8
	mov	w9, #21016                      ; =0x5218
	add	x9, x0, x9
	mov	w10, #21032                     ; =0x5228
	add	x10, x0, x10
	mov	w11, #21048                     ; =0x5238
	add	x11, x0, x11
	str	x8, [x1, #320]
	str	x9, [x1, #336]
	str	x10, [x1, #352]
	str	x11, [x1, #368]
	str	d0, [x1, #328]
	str	d0, [x1, #344]
	str	d0, [x1, #360]
	str	d0, [x1, #376]
	mov	w8, #21064                      ; =0x5248
	add	x8, x0, x8
	mov	w9, #21080                      ; =0x5258
	add	x9, x0, x9
	mov	w10, #21096                     ; =0x5268
	add	x10, x0, x10
	mov	w11, #21112                     ; =0x5278
	add	x11, x0, x11
	str	x8, [x1, #384]
	str	x9, [x1, #400]
	str	x10, [x1, #416]
	str	x11, [x1, #432]
	str	d0, [x1, #392]
	str	d0, [x1, #408]
	str	d0, [x1, #424]
	str	d0, [x1, #440]
	mov	w8, #21128                      ; =0x5288
	add	x8, x0, x8
	mov	w9, #21144                      ; =0x5298
	add	x9, x0, x9
	mov	w10, #21160                     ; =0x52a8
	add	x10, x0, x10
	mov	w11, #21176                     ; =0x52b8
	add	x11, x0, x11
	str	x8, [x1, #448]
	str	x9, [x1, #464]
	str	x10, [x1, #480]
	str	x11, [x1, #496]
	str	d0, [x1, #456]
	str	d0, [x1, #472]
	str	d0, [x1, #488]
	str	d0, [x1, #504]
	ldr	w8, [x0, #228]
	cbz	w8, LBB10_10
; %bb.1:
	mov	x9, #0                          ; =0x0
	add	x10, x0, #1344
	add	x11, x0, #1512
	mov	w8, #32                         ; =0x20
	mov	w12, #1208                      ; =0x4b8
	b	LBB10_4
LBB10_2:                                ;   in Loop: Header=BB10_4 Depth=1
	mov	x14, x8
LBB10_3:                                ;   in Loop: Header=BB10_4 Depth=1
	add	x8, x13, #56
	add	w15, w14, #1
	add	x16, x1, w14, uxtw #4
	str	x8, [x16]
	str	d0, [x16, #8]
	add	w8, w14, #2
	add	x15, x1, w15, uxtw #4
	add	x16, x13, #64
	str	x16, [x15]
	str	d0, [x15, #8]
	add	w15, w14, #3
	add	x8, x1, w8, uxtw #4
	add	x16, x13, #72
	str	x16, [x8]
	str	d0, [x8, #8]
	add	w8, w14, #4
	add	x15, x1, w15, uxtw #4
	add	x16, x13, #80
	str	x16, [x15]
	str	d0, [x15, #8]
	add	w15, w14, #5
	add	x8, x1, w8, uxtw #4
	add	x16, x13, #88
	str	x16, [x8]
	str	d0, [x8, #8]
	add	w8, w14, #6
	add	x15, x1, w15, uxtw #4
	add	x16, x13, #96
	str	x16, [x15]
	str	d0, [x15, #8]
	add	w15, w14, #7
	add	x8, x1, w8, uxtw #4
	add	x16, x13, #104
	str	x16, [x8]
	str	d0, [x8, #8]
	add	w8, w14, #8
	add	x14, x1, w15, uxtw #4
	add	x13, x13, #112
	str	x13, [x14]
	str	d0, [x14, #8]
	add	x9, x9, #1
	ldr	w13, [x0, #228]
	add	x11, x11, #1208
	cmp	x9, x13
	b.hs	LBB10_11
LBB10_4:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB10_8 Depth 2
	add	w15, w8, #1
	add	x14, x1, w8, uxtw #4
	madd	x13, x9, x12, x10
	add	x16, x13, #48
	str	x16, [x14]
	str	d0, [x14, #8]
	add	w14, w8, #2
	add	x15, x1, w15, uxtw #4
	add	x16, x13, #136
	str	x16, [x15]
	str	d0, [x15, #8]
	ldr	w15, [x13, #144]
	cbz	w15, LBB10_3
; %bb.5:                                ;   in Loop: Header=BB10_4 Depth=1
	ldr	w15, [x13, #148]
	cmp	w15, #65
	b.hs	LBB10_12
; %bb.6:                                ;   in Loop: Header=BB10_4 Depth=1
	add	w8, w8, #3
	add	x14, x1, w14, uxtw #4
	add	x15, x13, #152
	str	x15, [x14]
	str	d0, [x14, #8]
	ldr	w14, [x13, #148]
	cbz	w14, LBB10_2
; %bb.7:                                ;   in Loop: Header=BB10_4 Depth=1
	mov	x14, #0                         ; =0x0
	mov	x15, x11
LBB10_8:                                ;   Parent Loop BB10_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	w16, w8, w14
	add	x16, x1, w16, uxtw #4
	str	x15, [x16]
	str	d0, [x16, #8]
	add	x14, x14, #1
	ldr	w16, [x13, #148]
	add	x15, x15, #16
	cmp	x14, x16
	b.lo	LBB10_8
; %bb.9:                                ;   in Loop: Header=BB10_4 Depth=1
	add	w14, w8, w14
	b	LBB10_3
LBB10_10:
	mov	w8, #32                         ; =0x20
LBB10_11:
	mov	x0, x8
	ret
LBB10_12:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_abort
	.loh AdrpLdr	Lloh46, Lloh47
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_root_new        ; -- Begin function neoclr_workers_root_new
	.p2align	2
_neoclr_workers_root_new:               ; @neoclr_workers_root_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x21, x1
	mov	x19, x0
	bl	_heap_lock
	mov	w8, #0                          ; =0x0
	mov	x9, #-512                       ; =0xfffffffffffffe00
	b	LBB11_3
LBB11_1:                                ;   in Loop: Header=BB11_3 Depth=1
	ldr	x10, [x10, #21184]
	cmn	x10, #1
	cset	w10, ne
LBB11_2:                                ;   in Loop: Header=BB11_3 Depth=1
	orr	w8, w10, w8
	adds	x9, x9, #16
	b.eq	LBB11_5
LBB11_3:                                ; =>This Inner Loop Header: Depth=1
	add	x10, x19, x9
	ldr	x11, [x10, #21192]
	cbz	x11, LBB11_1
; %bb.4:                                ;   in Loop: Header=BB11_3 Depth=1
	mov	w10, #0                         ; =0x0
	b	LBB11_2
LBB11_5:
	str	xzr, [sp, #8]
	ldr	w9, [x19, #244]
	cmp	w9, #0
	ccmp	w8, #0, #4, eq
	b.eq	LBB11_7
; %bb.6:
	add	x0, x19, #1304
	add	x3, sp, #8
	mov	w1, #8                          ; =0x8
	mov	w2, #3                          ; =0x3
	bl	_neoclr_gc_allocate_v1
	cbz	w0, LBB11_10
LBB11_7:
	mov	w21, #0                         ; =0x0
LBB11_8:
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB11_17
; %bb.9:
	mov	x0, x21
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB11_10:
	ldr	x8, [sp, #8]
	str	x21, [x8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB11_16
; %bb.11:
	mov	x9, #0                          ; =0x0
	mov	w10, #20680                     ; =0x50c8
	add	x11, x19, x10
	mov	w10, #1                         ; =0x1
	b	LBB11_13
LBB11_12:                               ;   in Loop: Header=BB11_13 Depth=1
	cmp	x9, #31
	add	x12, x9, #1
	cset	w10, lo
	add	x11, x11, #16
	mov	x9, x12
	cmp	x12, #32
	b.eq	LBB11_7
LBB11_13:                               ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x11]
	cbnz	x12, LBB11_12
; %bb.14:                               ;   in Loop: Header=BB11_13 Depth=1
	ldur	x12, [x11, #-8]
	cmn	x12, #1
	b.eq	LBB11_12
; %bb.15:
	add	x12, x12, #1
	stp	x12, x8, [x11, #-8]
	ldr	x8, [x19]
	stp	x8, x12, [x20]
	mov	w8, #1                          ; =0x1
	stp	w9, w8, [x20, #16]
	and	w21, w10, #0x1
	b	LBB11_8
LBB11_16:
	stp	xzr, xzr, [x20]
	mov	w21, #1                         ; =0x1
	str	xzr, [x20, #16]
	b	LBB11_8
LBB11_17:
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_root_read       ; -- Begin function neoclr_workers_root_read
	.p2align	2
_neoclr_workers_root_read:              ; @neoclr_workers_root_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x21, x1
	mov	x19, x0
	bl	_heap_lock
	ldr	w8, [x21, #20]
	cmp	w8, #1
	b.ne	LBB12_6
; %bb.1:
	ldr	w8, [x21, #16]
	ldr	x9, [x21]
	ldr	x10, [x19]
	cmp	x9, x10
	ccmp	w8, #31, #2, eq
	b.hi	LBB12_6
; %bb.2:
	add	x8, x19, x8, lsl #4
	ldr	x1, [x8, #20680]
	cbz	x1, LBB12_6
; %bb.3:
	ldr	x9, [x21, #8]
	mov	w10, #20672                     ; =0x50c0
	add	x22, x8, x10
	ldr	x8, [x22]
	cmp	x8, x9
	b.ne	LBB12_6
; %bb.4:
	str	xzr, [sp, #8]
	str	wzr, [sp, #4]
	add	x0, x19, #256
	add	x2, sp, #8
	add	x3, sp, #4
	bl	_neoclr_gc_allocation_info_v1
	mov	w21, #0                         ; =0x0
	ldr	x8, [sp, #8]
	cmp	w0, #0
	ccmp	x8, #8, #0, eq
	b.lo	LBB12_7
; %bb.5:
	ldr	x8, [x22, #8]
	ldr	x8, [x8]
	str	x8, [x20]
	mov	w21, #1                         ; =0x1
	b	LBB12_7
LBB12_6:
	mov	w21, #0                         ; =0x0
	str	xzr, [sp, #8]
	str	wzr, [sp, #4]
LBB12_7:
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB12_9
; %bb.8:
	mov	x0, x21
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB12_9:
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_root_release    ; -- Begin function neoclr_workers_root_release
	.p2align	2
_neoclr_workers_root_release:           ; @neoclr_workers_root_release
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x0
Lloh48:
	adrp	x0, _entered@TLVPPAGE
Lloh49:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh50:
	adrp	x0, _reading@TLVPPAGE
Lloh51:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh52:
	adrp	x0, _mutating@TLVPPAGE
Lloh53:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB13_11
; %bb.1:
	add	x0, x19, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB13_11
; %bb.2:
	ldr	w8, [x20, #20]
	cmp	w8, #1
	b.ne	LBB13_8
; %bb.3:
	mov	w21, #0                         ; =0x0
	ldr	x8, [x20]
	ldr	x9, [x19]
	cmp	x8, x9
	b.ne	LBB13_9
; %bb.4:
	ldr	w8, [x20, #16]
	cmp	w8, #31
	b.hi	LBB13_9
; %bb.5:
	add	x8, x19, x8, lsl #4
	ldr	x9, [x8, #20680]
	cbz	x9, LBB13_8
; %bb.6:
	ldr	x9, [x20, #8]
	mov	w10, #20672                     ; =0x50c0
	add	x8, x8, x10
	ldr	x10, [x8]
	cmp	x10, x9
	b.ne	LBB13_8
; %bb.7:
	str	xzr, [x8, #8]
	mov	w21, #1                         ; =0x1
	b	LBB13_9
LBB13_8:
	mov	w21, #0                         ; =0x0
LBB13_9:
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB13_11
; %bb.10:
	mov	x0, x21
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB13_11:
	bl	_abort
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh48, Lloh49
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_workers_submit
lCPI14_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_workers_submit
	.p2align	2
_neoclr_workers_submit:                 ; @neoclr_workers_submit
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x4
	mov	x21, x3
	mov	x22, x2
	mov	x24, x1
	mov	x19, x0
Lloh54:
	adrp	x0, _entered@TLVPPAGE
Lloh55:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh56:
	adrp	x0, _reading@TLVPPAGE
Lloh57:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh58:
	adrp	x0, _mutating@TLVPPAGE
Lloh59:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB14_19
; %bb.1:
	add	x0, x19, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB14_19
; %bb.2:
	ldr	w8, [x24, #20]
	cmp	w8, #1
	b.ne	LBB14_16
; %bb.3:
	mov	w23, #0                         ; =0x0
	ldr	x8, [x24]
	ldr	x9, [x19]
	cmp	x8, x9
	b.ne	LBB14_17
; %bb.4:
	ldr	w9, [x24, #16]
	cmp	w9, #31
	b.hi	LBB14_17
; %bb.5:
	add	x9, x19, x9, lsl #4
	ldr	x10, [x9, #20680]
	cbz	x10, LBB14_16
; %bb.6:
	mov	w23, #0                         ; =0x0
	ldr	x10, [x24, #8]
	mov	w11, #20672                     ; =0x50c0
	add	x9, x9, x11
	ldr	x11, [x9]
	cmp	x11, x10
	csel	x9, x9, xzr, eq
	cbz	x22, LBB14_17
; %bb.7:
	ldr	w12, [x19, #244]
	cbnz	w12, LBB14_17
; %bb.8:
	cmp	x11, x10
	b.ne	LBB14_17
; %bb.9:
	ldr	x11, [x19, #8]
	cmn	x11, #1
	b.eq	LBB14_16
; %bb.10:
	ldr	w13, [x19, #228]
	cbz	w13, LBB14_16
; %bb.11:
	mov	x12, #0                         ; =0x0
	mov	w10, #0                         ; =0x0
	mov	w14, #1208                      ; =0x4b8
	umull	x13, w13, w14
	b	LBB14_13
LBB14_12:                               ;   in Loop: Header=BB14_13 Depth=1
	mov	w23, #0                         ; =0x0
	add	w10, w10, #1
	add	x12, x12, #1208
	cmp	x13, x12
	b.eq	LBB14_17
LBB14_13:                               ; =>This Inner Loop Header: Depth=1
	add	x14, x19, x12
	ldr	w15, [x14, #1376]
	cbnz	w15, LBB14_12
; %bb.14:                               ;   in Loop: Header=BB14_13 Depth=1
	ldr	x14, [x14, #1352]
	cmn	x14, #1
	b.eq	LBB14_12
; %bb.15:
	add	x11, x11, #1
	str	x11, [x19, #8]
	add	x12, x19, x12
	str	x11, [x12, #1360]
	add	x11, x14, #1
	str	x11, [x12, #1352]
	ldr	x9, [x9, #8]
	str	x9, [x12, #1392]
	str	x22, [x12, #2536]
	str	x21, [x12, #2544]
	str	wzr, [x12, #1388]
	str	xzr, [x12, #1464]
	str	xzr, [x12, #1480]
	str	xzr, [x12, #1472]
Lloh60:
	adrp	x9, lCPI14_0@PAGE
Lloh61:
	ldr	d0, [x9, lCPI14_0@PAGEOFF]
	str	d0, [x12, #1376]
	stp	x8, x11, [x20]
	mov	w8, #2                          ; =0x2
	stp	w10, w8, [x20, #16]
	add	x0, x19, #128
	bl	_pthread_cond_signal
	mov	w23, #1                         ; =0x1
	b	LBB14_17
LBB14_16:
	mov	w23, #0                         ; =0x0
LBB14_17:
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB14_19
; %bb.18:
	mov	x0, x23
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB14_19:
	bl	_abort
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh60, Lloh61
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_cancel          ; -- Begin function neoclr_workers_cancel
	.p2align	2
_neoclr_workers_cancel:                 ; @neoclr_workers_cancel
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x1
	mov	x19, x0
Lloh62:
	adrp	x0, _entered@TLVPPAGE
Lloh63:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh64:
	adrp	x0, _reading@TLVPPAGE
Lloh65:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh66:
	adrp	x0, _mutating@TLVPPAGE
Lloh67:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB15_15
; %bb.1:
	add	x0, x19, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB15_15
; %bb.2:
	ldr	w8, [x20, #20]
	cmp	w8, #2
	b.ne	LBB15_8
; %bb.3:
	ldr	x8, [x20]
	ldr	x9, [x19]
	cmp	x8, x9
	b.ne	LBB15_8
; %bb.4:
	ldr	w8, [x20, #16]
	ldr	w9, [x19, #228]
	cmp	w8, w9
	b.hs	LBB15_8
; %bb.5:
	mov	w9, #1208                       ; =0x4b8
	umaddl	x8, w8, w9, x19
	ldr	w9, [x8, #1376]
	cbz	w9, LBB15_8
; %bb.6:
	ldr	x10, [x20, #8]
	add	x8, x8, #1344
	ldr	x11, [x8, #8]
	cmp	x11, x10
	ccmp	w9, #3, #4, eq
	b.eq	LBB15_8
; %bb.7:
	ldr	w10, [x8, #36]
	cbz	w10, LBB15_11
LBB15_8:
	mov	w20, #0                         ; =0x0
LBB15_9:
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB15_15
; %bb.10:
	mov	x0, x20
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB15_11:
	mov	w10, #1                         ; =0x1
	str	w10, [x8, #36]
	cmp	w9, #1
	b.ne	LBB15_14
; %bb.12:
	str	xzr, [x8, #48]
	str	w10, [x8, #40]
	ldr	x9, [x8]
	ldr	x10, [x9, #16]
	cmn	x10, #1
	b.eq	LBB15_15
; %bb.13:
	add	x10, x10, #1
	str	x10, [x9, #16]
	str	x10, [x8, #24]
	mov	w10, #3                         ; =0x3
	str	w10, [x8, #32]
	add	x0, x9, #176
	bl	_pthread_cond_broadcast
LBB15_14:
	add	x0, x19, #176
	bl	_pthread_cond_broadcast
	mov	w20, #1                         ; =0x1
	b	LBB15_9
LBB15_15:
	bl	_abort
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpLdr	Lloh62, Lloh63
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_cancelled        ; -- Begin function neoclr_worker_cancelled
	.p2align	2
_neoclr_worker_cancelled:               ; @neoclr_worker_cancelled
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh68:
	adrp	x0, _entered@TLVPPAGE
Lloh69:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh70:
	adrp	x0, _reading@TLVPPAGE
Lloh71:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh72:
	adrp	x0, _mutating@TLVPPAGE
Lloh73:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB16_4
; %bb.1:
	ldr	x8, [x19]
	add	x0, x8, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB16_4
; %bb.2:
	ldr	w20, [x19, #36]
	ldr	x8, [x19]
	add	x0, x8, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB16_4
; %bb.3:
	mov	x0, x20
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB16_4:
	bl	_abort
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpLdr	Lloh68, Lloh69
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_read_begin       ; -- Begin function neoclr_worker_read_begin
	.p2align	2
_neoclr_worker_read_begin:              ; @neoclr_worker_read_begin
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh74:
	adrp	x0, _executing@TLVPPAGE
Lloh75:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x8, x19
	b.ne	LBB17_8
; %bb.1:
	ldr	x21, [x19]
Lloh76:
	adrp	x0, _entered@TLVPPAGE
Lloh77:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh78:
	adrp	x0, _reading@TLVPPAGE
Lloh79:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x20, x0
	ldr	x9, [x0]
Lloh80:
	adrp	x0, _mutating@TLVPPAGE
Lloh81:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB17_8
; %bb.2:
	add	x0, x21, #64
	bl	_pthread_mutex_lock
	cbz	w0, LBB17_4
	b	LBB17_8
LBB17_3:                                ;   in Loop: Header=BB17_4 Depth=1
	add	x0, x21, #176
	add	x1, x21, #64
	bl	_pthread_cond_wait
	cbnz	w0, LBB17_8
LBB17_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x21, #240]
	cbnz	w8, LBB17_3
; %bb.5:                                ;   in Loop: Header=BB17_4 Depth=1
	ldr	w8, [x21, #236]
	cbnz	w8, LBB17_3
; %bb.6:
	ldr	w8, [x21, #232]
	add	w8, w8, #1
	str	w8, [x21, #232]
	str	x19, [x20]
	ldr	x19, [x19, #48]
	add	x0, x21, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB17_8
; %bb.7:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB17_8:
	bl	_abort
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpLdr	Lloh76, Lloh77
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_read_end         ; -- Begin function neoclr_worker_read_end
	.p2align	2
_neoclr_worker_read_end:                ; @neoclr_worker_read_end
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh82:
	adrp	x0, _reading@TLVPPAGE
Lloh83:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x19, x0
	ldr	x9, [x0]
Lloh84:
	adrp	x0, _executing@TLVPPAGE
Lloh85:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x9, x8
	ccmp	x10, x8, #0, eq
	b.ne	LBB18_7
; %bb.1:
	ldr	x20, [x8]
	add	x0, x20, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB18_7
; %bb.2:
	ldr	w8, [x20, #232]
	cbz	w8, LBB18_7
; %bb.3:
	str	xzr, [x19]
	subs	w8, w8, #1
	str	w8, [x20, #232]
	b.ne	LBB18_5
; %bb.4:
	add	x0, x20, #176
	bl	_pthread_cond_broadcast
LBB18_5:
	add	x0, x20, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB18_7
; %bb.6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB18_7:
	bl	_abort
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpLdr	Lloh82, Lloh83
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_mutate_begin     ; -- Begin function neoclr_worker_mutate_begin
	.p2align	2
_neoclr_worker_mutate_begin:            ; @neoclr_worker_mutate_begin
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh86:
	adrp	x0, _executing@TLVPPAGE
Lloh87:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x8, x19
	b.ne	LBB19_8
; %bb.1:
	ldr	x21, [x19]
Lloh88:
	adrp	x0, _entered@TLVPPAGE
Lloh89:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh90:
	adrp	x0, _reading@TLVPPAGE
Lloh91:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh92:
	adrp	x0, _mutating@TLVPPAGE
Lloh93:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB19_8
; %bb.2:
	mov	x20, x0
	add	x0, x21, #64
	bl	_pthread_mutex_lock
	cbz	w0, LBB19_4
	b	LBB19_8
LBB19_3:                                ;   in Loop: Header=BB19_4 Depth=1
	add	x0, x21, #176
	add	x1, x21, #64
	bl	_pthread_cond_wait
	cbnz	w0, LBB19_8
LBB19_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x21, #240]
	cbnz	w8, LBB19_3
; %bb.5:                                ;   in Loop: Header=BB19_4 Depth=1
	ldr	w8, [x21, #232]
	cbnz	w8, LBB19_3
; %bb.6:
	ldr	w8, [x21, #236]
	add	w8, w8, #1
	str	w8, [x21, #236]
	str	x19, [x20]
	ldr	x19, [x19, #48]
	add	x0, x21, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB19_8
; %bb.7:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB19_8:
	bl	_abort
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh88, Lloh89
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_mutate_end       ; -- Begin function neoclr_worker_mutate_end
	.p2align	2
_neoclr_worker_mutate_end:              ; @neoclr_worker_mutate_end
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh94:
	adrp	x0, _mutating@TLVPPAGE
Lloh95:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x19, x0
	ldr	x9, [x0]
Lloh96:
	adrp	x0, _executing@TLVPPAGE
Lloh97:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x9, x8
	ccmp	x10, x8, #0, eq
	b.ne	LBB20_7
; %bb.1:
	ldr	x20, [x8]
	add	x0, x20, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB20_7
; %bb.2:
	ldr	w8, [x20, #236]
	cbz	w8, LBB20_7
; %bb.3:
	str	xzr, [x19]
	subs	w8, w8, #1
	str	w8, [x20, #236]
	b.ne	LBB20_5
; %bb.4:
	add	x0, x20, #176
	bl	_pthread_cond_broadcast
LBB20_5:
	add	x0, x20, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB20_7
; %bb.6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB20_7:
	bl	_abort
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpLdr	Lloh94, Lloh95
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_mutate_poll      ; -- Begin function neoclr_worker_mutate_poll
	.p2align	2
_neoclr_worker_mutate_poll:             ; @neoclr_worker_mutate_poll
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_neoclr_worker_mutate_end
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_neoclr_worker_mutate_begin
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_capture          ; -- Begin function neoclr_worker_capture
	.p2align	2
_neoclr_worker_capture:                 ; @neoclr_worker_capture
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh98:
	adrp	x0, _entered@TLVPPAGE
Lloh99:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	x9, x8
	b.ne	LBB22_2
; %bb.1:
	ldr	x0, [x8, #48]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB22_2:
	bl	_abort
	.loh AdrpLdr	Lloh98, Lloh99
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_allocate         ; -- Begin function neoclr_worker_allocate
	.p2align	2
_neoclr_worker_allocate:                ; @neoclr_worker_allocate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh100:
	adrp	x0, _entered@TLVPPAGE
Lloh101:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	x9, x8
	b.ne	LBB23_2
; %bb.1:
	str	xzr, [sp, #8]
	ldr	x8, [x8]
	add	x0, x8, #1304
	add	x3, sp, #8
	bl	_neoclr_gc_allocate_v1
	ldr	x8, [sp, #8]
	cmp	w0, #0
	csel	x0, x8, xzr, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
LBB23_2:
	bl	_abort
	.loh AdrpLdr	Lloh100, Lloh101
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_result           ; -- Begin function neoclr_worker_result
	.p2align	2
_neoclr_worker_result:                  ; @neoclr_worker_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x1
	mov	x19, x0
Lloh102:
	adrp	x0, _entered@TLVPPAGE
Lloh103:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x8, x19
	b.ne	LBB24_4
; %bb.1:
	ldr	x1, [x20, #16]
	cbz	x1, LBB24_3
; %bb.2:
	ldr	x8, [x19]
	add	x0, x8, #256
	add	x2, sp, #8
	add	x3, sp, #4
	bl	_neoclr_gc_allocation_info_v1
	cbnz	w0, LBB24_4
LBB24_3:
	ldr	q0, [x20]
	ldr	x8, [x20, #16]
	str	x8, [x19, #136]
	stur	q0, [x19, #120]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB24_4:
	bl	_abort
	.loh AdrpLdr	Lloh102, Lloh103
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_local_store      ; -- Begin function neoclr_worker_local_store
	.p2align	2
_neoclr_worker_local_store:             ; @neoclr_worker_local_store
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x2
	mov	x22, x1
	mov	x19, x0
Lloh104:
	adrp	x0, _entered@TLVPPAGE
Lloh105:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x9, [x0]
Lloh106:
	adrp	x0, _mutating@TLVPPAGE
Lloh107:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x9, x19
	ccmp	x8, x19, #4, ne
	b.ne	LBB25_11
; %bb.1:
	mov	x20, x0
	cmp	x8, x19
	b.ne	LBB25_3
; %bb.2:
	ldr	x8, [x19]
	add	x0, x8, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB25_11
LBB25_3:
	cmp	w22, #7
	b.hi	LBB25_6
; %bb.4:
	cbz	x21, LBB25_7
; %bb.5:
	ldr	x8, [x19]
	add	x0, x8, #256
	add	x2, sp, #8
	add	x3, sp, #4
	mov	x1, x21
	bl	_neoclr_gc_allocation_info_v1
	cbz	w0, LBB25_7
LBB25_6:
	mov	w21, #0                         ; =0x0
	b	LBB25_8
LBB25_7:
	add	x8, x19, w22, uxtw #3
	str	x21, [x8, #56]
	mov	w21, #1                         ; =0x1
LBB25_8:
	ldr	x8, [x20]
	cmp	x8, x19
	b.ne	LBB25_10
; %bb.9:
	ldr	x8, [x19]
	add	x0, x8, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB25_11
LBB25_10:
	mov	x0, x21
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB25_11:
	bl	_abort
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpLdr	Lloh104, Lloh105
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_local_load       ; -- Begin function neoclr_worker_local_load
	.p2align	2
_neoclr_worker_local_load:              ; @neoclr_worker_local_load
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh108:
	adrp	x0, _entered@TLVPPAGE
Lloh109:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh110:
	adrp	x0, _mutating@TLVPPAGE
Lloh111:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x9, x8
	ccmp	x10, x8, #4, ne
	b.ne	LBB26_4
; %bb.1:
	cmp	w1, #7
	b.hi	LBB26_3
; %bb.2:
	add	x8, x8, w1, uxtw #3
	ldr	x0, [x8, #56]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB26_3:
	mov	x0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB26_4:
	bl	_abort
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpLdr	Lloh108, Lloh109
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_wait            ; -- Begin function neoclr_workers_wait
	.p2align	2
_neoclr_workers_wait:                   ; @neoclr_workers_wait
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x0
Lloh112:
	adrp	x0, _executing@TLVPPAGE
Lloh113:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB27_3
; %bb.1:
	mov	w0, #-1                         ; =0xffffffff
	mov	w9, #60000                      ; =0xea60
	cmp	w2, w9
	b.hi	LBB27_27
; %bb.2:
	ldr	x8, [x8]
	cmp	x8, x19
	b.ne	LBB27_4
	b	LBB27_27
LBB27_3:
	mov	w8, #60000                      ; =0xea60
	cmp	w2, w8
	b.hi	LBB27_5
LBB27_4:
	mov	x21, x2
	mov	x1, sp
	mov	w0, #0                          ; =0x0
	bl	_clock_gettime
	cbz	w0, LBB27_6
LBB27_5:
	mov	w0, #-1                         ; =0xffffffff
	b	LBB27_27
LBB27_6:
	ubfx	w8, w21, #3, #13
	mov	w9, #8389                       ; =0x20c5
	mul	w8, w8, w9
	lsr	w8, w8, #20
	mov	w9, #1000                       ; =0x3e8
	msub	w9, w8, w9, w21
	ldp	x10, x11, [sp]
	add	x8, x10, x8
	and	x9, x9, #0xffff
	mov	w10, #16960                     ; =0x4240
	movk	w10, #15, lsl #16
	umaddl	x9, w9, w10, x11
	stp	x8, x9, [sp]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	cmp	x9, x10
	b.lt	LBB27_8
; %bb.7:
	add	x8, x8, #1
	mov	x10, #-51712                    ; =0xffffffffffff3600
	movk	x10, #50277, lsl #16
	add	x9, x9, x10
	stp	x8, x9, [sp]
LBB27_8:
Lloh114:
	adrp	x0, _entered@TLVPPAGE
Lloh115:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh116:
	adrp	x0, _reading@TLVPPAGE
Lloh117:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh118:
	adrp	x0, _mutating@TLVPPAGE
Lloh119:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB27_29
; %bb.9:
	add	x0, x19, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB27_29
; %bb.10:
	add	x21, x19, #1344
	mov	w22, #1208                      ; =0x4b8
LBB27_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x20, #20]
	cmp	w8, #2
	b.ne	LBB27_25
; %bb.12:                               ;   in Loop: Header=BB27_11 Depth=1
	ldr	x8, [x20]
	ldr	x9, [x19]
	cmp	x8, x9
	b.ne	LBB27_25
; %bb.13:                               ;   in Loop: Header=BB27_11 Depth=1
	ldr	w8, [x20, #16]
	ldr	w9, [x19, #228]
	cmp	w8, w9
	b.hs	LBB27_25
; %bb.14:                               ;   in Loop: Header=BB27_11 Depth=1
	umaddl	x9, w8, w22, x21
	ldr	w8, [x9, #32]
	cbz	w8, LBB27_25
; %bb.15:                               ;   in Loop: Header=BB27_11 Depth=1
	ldr	x10, [x20, #8]
	ldr	x9, [x9, #8]
	cmp	x9, x10
	b.ne	LBB27_25
; %bb.16:                               ;   in Loop: Header=BB27_11 Depth=1
	cmp	w8, #3
	b.eq	LBB27_28
; %bb.17:                               ;   in Loop: Header=BB27_11 Depth=1
	add	x0, x19, #176
	add	x1, x19, #64
	mov	x2, sp
	bl	_pthread_cond_timedwait
	cbz	w0, LBB27_11
; %bb.18:
	cmp	w0, #60
	b.ne	LBB27_25
; %bb.19:
	ldr	w8, [x20, #20]
	cmp	w8, #2
	b.ne	LBB27_25
; %bb.20:
	ldr	x8, [x20]
	ldr	x9, [x19]
	cmp	x8, x9
	b.ne	LBB27_25
; %bb.21:
	ldr	w8, [x20, #16]
	ldr	w9, [x19, #228]
	cmp	w8, w9
	b.hs	LBB27_25
; %bb.22:
	mov	w9, #1208                       ; =0x4b8
	umaddl	x9, w8, w9, x21
	ldr	w8, [x9, #32]
	cbz	w8, LBB27_25
; %bb.23:
	ldr	x10, [x20, #8]
	ldr	x9, [x9, #8]
	cmp	x9, x10
	b.ne	LBB27_25
; %bb.24:
	cmp	w8, #3
	cset	w20, eq
	b	LBB27_26
LBB27_25:
	mov	w20, #-1                        ; =0xffffffff
LBB27_26:
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	mov	x8, x0
	mov	x0, x20
	cbnz	w8, LBB27_29
LBB27_27:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB27_28:
	mov	w20, #1                         ; =0x1
	b	LBB27_26
LBB27_29:
	bl	_abort
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpLdr	Lloh114, Lloh115
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_dispatch        ; -- Begin function neoclr_workers_dispatch
	.p2align	2
_neoclr_workers_dispatch:               ; @neoclr_workers_dispatch
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	stp	x3, x2, [sp, #56]               ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	ldr	x23, [x0, #24]
	bl	_pthread_self
	mov	x1, x0
	mov	x0, x23
	bl	_pthread_equal
	mov	x8, x0
	mov	w0, #-1                         ; =0xffffffff
	cmp	w19, #16
	b.hi	LBB28_71
; %bb.1:
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	cbz	x9, LBB28_71
; %bb.2:
	cbz	w8, LBB28_71
; %bb.3:
Lloh120:
	adrp	x0, _entered@TLVPPAGE
Lloh121:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	ldr	x8, [x0]
Lloh122:
	adrp	x0, _reading@TLVPPAGE
Lloh123:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	ldr	x9, [x0]
Lloh124:
	adrp	x0, _mutating@TLVPPAGE
Lloh125:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB28_72
; %bb.4:
	add	x0, x20, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB28_72
; %bb.5:
	ldr	w8, [x20, #252]
	cbz	w8, LBB28_8
; %bb.6:
	add	x0, x20, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB28_72
; %bb.7:
	mov	w0, #-1                         ; =0xffffffff
	b	LBB28_71
LBB28_8:
	mov	w27, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	str	w8, [x20, #252]
	mov	w8, #9800                       ; =0x2648
	add	x21, x20, x8
	mov	w8, #8592                       ; =0x2190
	add	x23, x20, x8
	mov	w8, #7384                       ; =0x1cd8
	add	x24, x20, x8
	mov	w8, #6176                       ; =0x1820
	add	x22, x20, x8
	mov	w8, #4968                       ; =0x1368
	add	x26, x20, x8
	add	x8, x20, #1344
	stp	x8, x24, [sp, #8]               ; 16-byte Folded Spill
	mov	w28, #9664                      ; =0x25c0
	str	x26, [sp, #24]                  ; 8-byte Folded Spill
LBB28_9:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB28_30 Depth 2
                                        ;     Child Loop BB28_17 Depth 2
	cmp	w27, w19
	b.eq	LBB28_70
; %bb.10:                               ;   in Loop: Header=BB28_9 Depth=1
	ldr	w10, [x20, #228]
	cbz	w10, LBB28_69
; %bb.11:                               ;   in Loop: Header=BB28_9 Depth=1
	cmp	w10, #8
	b.hs	LBB28_27
; %bb.12:                               ;   in Loop: Header=BB28_9 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	w25, #0                         ; =0x0
LBB28_13:                               ;   in Loop: Header=BB28_9 Depth=1
	and	x10, x10, #0x7
	cbz	x10, LBB28_21
; %bb.14:                               ;   in Loop: Header=BB28_9 Depth=1
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
	mov	w12, #1208                      ; =0x4b8
	madd	x11, x8, x12, x11
	b	LBB28_17
LBB28_15:                               ;   in Loop: Header=BB28_17 Depth=2
	mov	x25, x8
	mov	x9, x11
LBB28_16:                               ;   in Loop: Header=BB28_17 Depth=2
	add	w8, w8, #1
	add	x11, x11, #1208
	subs	x10, x10, #1
	b.eq	LBB28_21
LBB28_17:                               ;   Parent Loop BB28_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w12, [x11, #32]
	cmp	w12, #3
	b.ne	LBB28_16
; %bb.18:                               ;   in Loop: Header=BB28_17 Depth=2
	ldr	w12, [x11, #44]
	cbnz	w12, LBB28_16
; %bb.19:                               ;   in Loop: Header=BB28_17 Depth=2
	cbz	x9, LBB28_15
; %bb.20:                               ;   in Loop: Header=BB28_17 Depth=2
	ldr	x12, [x11, #24]
	ldr	x13, [x9, #24]
	cmp	x12, x13
	b.lo	LBB28_15
	b	LBB28_16
LBB28_21:                               ;   in Loop: Header=BB28_9 Depth=1
	cbz	x9, LBB28_69
; %bb.22:                               ;   in Loop: Header=BB28_9 Depth=1
	mov	x26, x22
	mov	x24, x23
	mov	x23, x21
	mov	x21, x27
	ldr	x27, [sp, #64]                  ; 8-byte Folded Reload
	mov	x28, x19
	ldr	x22, [x20]
	ldr	x19, [x9, #8]
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #44]
	add	x0, x20, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB28_72
; %bb.23:                               ;   in Loop: Header=BB28_9 Depth=1
	stp	x22, x19, [sp, #72]
	mov	w8, #2                          ; =0x2
	stp	w25, w8, [sp, #88]
	add	x1, sp, #72
	mov	x0, x20
	ldr	x2, [sp, #56]                   ; 8-byte Folded Reload
	blr	x27
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	mov	x19, x28
	mov	x27, x21
	mov	x21, x23
	mov	x23, x24
	mov	x22, x26
	ldp	x24, x26, [sp, #16]             ; 16-byte Folded Reload
	mov	w28, #9664                      ; =0x25c0
	cbnz	x8, LBB28_72
; %bb.24:                               ;   in Loop: Header=BB28_9 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB28_72
; %bb.25:                               ;   in Loop: Header=BB28_9 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB28_72
; %bb.26:                               ;   in Loop: Header=BB28_9 Depth=1
	add	w27, w27, #1
	add	x0, x20, #64
	bl	_pthread_mutex_lock
	cbz	w0, LBB28_9
	b	LBB28_72
LBB28_27:                               ;   in Loop: Header=BB28_9 Depth=1
	mov	x11, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	w25, #0                         ; =0x0
	lsr	x12, x10, #3
	umull	x12, w12, w28
	mov	w17, #29160                     ; =0x71e8
	mov	w0, #27952                      ; =0x6d30
	mov	w1, #26744                      ; =0x6878
	mov	w2, #25536                      ; =0x63c0
	mov	w3, #24328                      ; =0x5f08
	mov	w4, #23120                      ; =0x5a50
	mov	w5, #21912                      ; =0x5598
	b	LBB28_30
LBB28_28:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x9, x21, x11
	add	w25, w8, #7
LBB28_29:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x8, x8, #8
	add	x11, x11, x28
	cmp	x12, x11
	b.eq	LBB28_13
LBB28_30:                               ;   Parent Loop BB28_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x13, x20, x11
	prfm	pldl1keep, [x13, #20704]
	ldr	w14, [x13, #1376]
	cmp	w14, #3
	b.ne	LBB28_35
; %bb.31:                               ;   in Loop: Header=BB28_30 Depth=2
	ldr	w14, [x13, #1388]
	cbnz	w14, LBB28_35
; %bb.32:                               ;   in Loop: Header=BB28_30 Depth=2
	cbz	x9, LBB28_34
; %bb.33:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x14, x20, x11
	ldr	x14, [x14, #1368]
	ldr	x15, [x9, #24]
	cmp	x14, x15
	b.hs	LBB28_35
LBB28_34:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x9, x13, #1344
	mov	x25, x8
LBB28_35:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x14, x13, x5
	prfm	pldl1keep, [x14]
	ldr	w14, [x13, #2584]
	cmp	w14, #3
	b.ne	LBB28_40
; %bb.36:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x14, x20, x11
	ldr	w14, [x14, #2596]
	cbnz	w14, LBB28_40
; %bb.37:                               ;   in Loop: Header=BB28_30 Depth=2
	cbz	x9, LBB28_39
; %bb.38:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x14, x20, x11
	ldr	x14, [x14, #2576]
	ldr	x15, [x9, #24]
	cmp	x14, x15
	b.hs	LBB28_40
LBB28_39:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x9, x13, #2552
	add	w25, w8, #1
LBB28_40:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x15, x13, x4
	add	x14, x20, x11
	prfm	pldl1keep, [x15]
	ldr	w15, [x14, #3792]
	cmp	w15, #3
	b.ne	LBB28_45
; %bb.41:                               ;   in Loop: Header=BB28_30 Depth=2
	ldr	w15, [x14, #3804]
	cbnz	w15, LBB28_45
; %bb.42:                               ;   in Loop: Header=BB28_30 Depth=2
	cbz	x9, LBB28_44
; %bb.43:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x15, x20, x11
	ldr	x15, [x15, #3784]
	ldr	x16, [x9, #24]
	cmp	x15, x16
	b.hs	LBB28_45
LBB28_44:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x9, x14, #3760
	add	w25, w8, #2
LBB28_45:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x15, x13, x3
	prfm	pldl1keep, [x15]
	ldr	w14, [x14, #5000]
	cmp	w14, #3
	b.ne	LBB28_50
; %bb.46:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x14, x20, x11
	ldr	w14, [x14, #5012]
	cbnz	w14, LBB28_50
; %bb.47:                               ;   in Loop: Header=BB28_30 Depth=2
	cbz	x9, LBB28_49
; %bb.48:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x14, x20, x11
	ldr	x14, [x14, #4992]
	ldr	x15, [x9, #24]
	cmp	x14, x15
	b.hs	LBB28_50
LBB28_49:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x9, x26, x11
	add	w25, w8, #3
LBB28_50:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x15, x13, x2
	add	x14, x20, x11
	prfm	pldl1keep, [x15]
	ldr	w15, [x14, #6208]
	cmp	w15, #3
	b.ne	LBB28_55
; %bb.51:                               ;   in Loop: Header=BB28_30 Depth=2
	ldr	w15, [x14, #6220]
	cbnz	w15, LBB28_55
; %bb.52:                               ;   in Loop: Header=BB28_30 Depth=2
	cbz	x9, LBB28_54
; %bb.53:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x15, x20, x11
	ldr	x15, [x15, #6200]
	ldr	x16, [x9, #24]
	cmp	x15, x16
	b.hs	LBB28_55
LBB28_54:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x9, x22, x11
	add	w25, w8, #4
LBB28_55:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x15, x13, x1
	prfm	pldl1keep, [x15]
	ldr	w14, [x14, #7416]
	cmp	w14, #3
	b.ne	LBB28_60
; %bb.56:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x14, x20, x11
	ldr	w14, [x14, #7428]
	cbnz	w14, LBB28_60
; %bb.57:                               ;   in Loop: Header=BB28_30 Depth=2
	cbz	x9, LBB28_59
; %bb.58:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x14, x20, x11
	ldr	x14, [x14, #7408]
	ldr	x15, [x9, #24]
	cmp	x14, x15
	b.hs	LBB28_60
LBB28_59:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x9, x24, x11
	add	w25, w8, #5
LBB28_60:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x15, x13, x0
	add	x14, x20, x11
	prfm	pldl1keep, [x15]
	ldr	w15, [x14, #8624]
	cmp	w15, #3
	b.ne	LBB28_65
; %bb.61:                               ;   in Loop: Header=BB28_30 Depth=2
	ldr	w15, [x14, #8636]
	cbnz	w15, LBB28_65
; %bb.62:                               ;   in Loop: Header=BB28_30 Depth=2
	cbz	x9, LBB28_64
; %bb.63:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x15, x20, x11
	ldr	x15, [x15, #8616]
	ldr	x16, [x9, #24]
	cmp	x15, x16
	b.hs	LBB28_65
LBB28_64:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x9, x23, x11
	add	w25, w8, #6
LBB28_65:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x13, x13, x17
	prfm	pldl1keep, [x13]
	ldr	w13, [x14, #9832]
	cmp	w13, #3
	b.ne	LBB28_29
; %bb.66:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x13, x20, x11
	ldr	w13, [x13, #9844]
	cbnz	w13, LBB28_29
; %bb.67:                               ;   in Loop: Header=BB28_30 Depth=2
	cbz	x9, LBB28_28
; %bb.68:                               ;   in Loop: Header=BB28_30 Depth=2
	add	x13, x20, x11
	ldr	x13, [x13, #9824]
	ldr	x14, [x9, #24]
	cmp	x13, x14
	b.lo	LBB28_28
	b	LBB28_29
LBB28_69:
	mov	x19, x27
LBB28_70:
	str	wzr, [x20, #252]
	add	x0, x20, #64
	bl	_pthread_mutex_unlock
	mov	x8, x0
	mov	x0, x19
	cbnz	w8, LBB28_72
LBB28_71:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB28_72:
	bl	_abort
	.loh AdrpLdr	Lloh124, Lloh125
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpLdr	Lloh120, Lloh121
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_fault_copy      ; -- Begin function neoclr_workers_fault_copy
	.p2align	2
_neoclr_workers_fault_copy:             ; @neoclr_workers_fault_copy
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbz	x2, LBB29_3
; %bb.1:
	cbnz	x3, LBB29_4
; %bb.2:
	cbz	x4, LBB29_4
LBB29_3:
	mov	w0, #-1                         ; =0xffffffff
	b	LBB29_16
LBB29_4:
	mov	x23, x4
	mov	x19, x3
	mov	x21, x2
	mov	x22, x0
	mov	x20, x1
	bl	_heap_lock
	ldr	w8, [x20, #20]
	cmp	w8, #2
	b.ne	LBB29_13
; %bb.5:
	mov	x9, x20
	ldr	x10, [x20]
	mov	x8, x22
	ldr	x11, [x22]
	cmp	x10, x11
	b.ne	LBB29_14
; %bb.6:
	ldr	w10, [x9, #16]
	ldr	w11, [x8, #228]
	cmp	w10, w11
	b.hs	LBB29_14
; %bb.7:
	mov	w11, #1208                      ; =0x4b8
	umaddl	x11, w10, w11, x8
	ldr	w10, [x11, #1376]
	cbz	w10, LBB29_14
; %bb.8:
	ldr	x9, [x9, #8]
	add	x24, x11, #1344
	ldr	x11, [x24, #8]
	cmp	x11, x9
	b.ne	LBB29_14
; %bb.9:
	cmp	w10, #3
	b.ne	LBB29_17
; %bb.10:
	ldr	x10, [x24, #152]
	cbz	x10, LBB29_18
; %bb.11:
	ldr	x20, [x10]
	cmp	x20, x23
	b.ls	LBB29_19
; %bb.12:
	mov	w19, #-2                        ; =0xfffffffe
	b	LBB29_15
LBB29_13:
	mov	w19, #-1                        ; =0xffffffff
	mov	x8, x22
	b	LBB29_15
LBB29_14:
	mov	w19, #-1                        ; =0xffffffff
LBB29_15:
	add	x0, x8, #64
	bl	_pthread_mutex_unlock
	mov	x8, x0
	mov	x0, x19
	cbnz	w8, LBB29_23
LBB29_16:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB29_17:
	mov	w19, #0                         ; =0x0
	b	LBB29_15
LBB29_18:
	mov	x20, #0                         ; =0x0
	b	LBB29_21
LBB29_19:
	cbz	x20, LBB29_21
; %bb.20:
	add	x1, x10, #8
	mov	x0, x19
	mov	x2, x20
	bl	_memcpy
	mov	x9, x21
	mov	x8, x22
	b	LBB29_22
LBB29_21:
	mov	x9, x21
LBB29_22:
	ldr	d0, [x24, #144]
	str	d0, [x9]
	str	x20, [x9, #8]
	mov	w19, #1                         ; =0x1
	b	LBB29_15
LBB29_23:
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_take            ; -- Begin function neoclr_workers_take
	.p2align	2
_neoclr_workers_take:                   ; @neoclr_workers_take
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x22, x4
	mov	x20, x3
	mov	x21, x2
	mov	x23, x1
	mov	x19, x0
Lloh126:
	adrp	x0, _entered@TLVPPAGE
Lloh127:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh128:
	adrp	x0, _reading@TLVPPAGE
Lloh129:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh130:
	adrp	x0, _mutating@TLVPPAGE
Lloh131:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB30_20
; %bb.1:
	add	x0, x19, #64
	bl	_pthread_mutex_lock
	cbnz	w0, LBB30_20
; %bb.2:
	ldr	w8, [x23, #20]
	cmp	w8, #2
	b.ne	LBB30_10
; %bb.3:
	ldr	x8, [x23]
	ldr	x9, [x19]
	cmp	x8, x9
	b.ne	LBB30_10
; %bb.4:
	ldr	w9, [x23, #16]
	ldr	w10, [x19, #228]
	cmp	w9, w10
	b.hs	LBB30_10
; %bb.5:
	mov	w10, #1208                      ; =0x4b8
	umaddl	x10, w9, w10, x19
	ldr	w9, [x10, #1376]
	cbz	w9, LBB30_10
; %bb.6:
	ldr	x11, [x23, #8]
	add	x24, x10, #1344
	ldr	x10, [x24, #8]
	cmp	x10, x11
	b.ne	LBB30_10
; %bb.7:
	cmp	w9, #3
	b.ne	LBB30_17
; %bb.8:
	ldr	x9, [x24, #136]
	cbz	x9, LBB30_18
; %bb.9:
	mov	x10, #0                         ; =0x0
	mov	w11, #20680                     ; =0x50c8
	add	x12, x19, x11
	mov	w11, #1                         ; =0x1
	b	LBB30_14
LBB30_10:
	mov	w23, #-1                        ; =0xffffffff
LBB30_11:
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB30_20
; %bb.12:
	mov	x0, x23
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB30_13:                               ;   in Loop: Header=BB30_14 Depth=1
	mov	w23, #0                         ; =0x0
	cmp	x10, #31
	add	x13, x10, #1
	cset	w11, lo
	add	x12, x12, #16
	mov	x10, x13
	cmp	x13, #32
	b.eq	LBB30_11
LBB30_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x12]
	cbnz	x13, LBB30_13
; %bb.15:                               ;   in Loop: Header=BB30_14 Depth=1
	ldur	x13, [x12, #-8]
	cmn	x13, #1
	b.eq	LBB30_13
; %bb.16:
	add	x13, x13, #1
	stp	x13, x9, [x12, #-8]
	stp	x8, x13, [x22]
	mov	w8, #1                          ; =0x1
	stp	w10, w8, [x22, #16]
	tbnz	w11, #0, LBB30_19
LBB30_17:
	mov	w23, #0                         ; =0x0
	b	LBB30_11
LBB30_18:
	stp	xzr, xzr, [x22]
	str	xzr, [x22, #16]
LBB30_19:
	ldr	w8, [x24, #40]
	str	w8, [x21]
	ldur	q0, [x24, #120]
	str	q0, [x20]
	str	xzr, [x20, #16]
	add	x0, x24, #144
	mov	w1, #1048                       ; =0x418
	bl	_bzero
	stp	xzr, xzr, [x24, #120]
	str	xzr, [x24, #136]
	add	x8, x24, #1192
	str	wzr, [x24, #32]
	movi.2d	v0, #0000000000000000
	str	q0, [x8]
	mov	w23, #1                         ; =0x1
	b	LBB30_11
LBB30_20:
	bl	_abort
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpLdr	Lloh126, Lloh127
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_collect         ; -- Begin function neoclr_workers_collect
	.p2align	2
_neoclr_workers_collect:                ; @neoclr_workers_collect
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	mov	w9, #19824                      ; =0x4d70
Lloh132:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh133:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #4, lsl #12             ; =16384
	sub	sp, sp, #3440
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x0
Lloh134:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh135:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh136:
	ldr	x8, [x8]
	stur	x8, [x29, #-40]
	ldr	x21, [x0, #24]
	bl	_pthread_self
	mov	x1, x0
	mov	x0, x21
	bl	_pthread_equal
	cbz	w0, LBB31_5
; %bb.1:
	mov	x0, x19
	bl	_heap_lock
	add	x21, sp, #104
	add	x1, sp, #104
	mov	x0, x19
	bl	_pool_slots
	str	xzr, [sp, #96]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #32]
	stp	q0, q0, [sp]
	add	x8, x19, #256
	str	x8, [sp, #8]
	str	x21, [sp, #48]
	str	w0, [sp, #64]
	mov	x1, sp
	mov	x0, x8
	bl	_neoclr_gc_collect_v1
	cmp	w0, #0
	cset	w21, eq
	cbnz	w0, LBB31_3
; %bb.2:
	ldr	x8, [x19, #1320]
	str	x8, [x20]
LBB31_3:
	add	x0, x19, #64
	bl	_pthread_mutex_unlock
	cbz	w0, LBB31_6
; %bb.4:
	bl	_abort
LBB31_5:
	mov	w21, #0                         ; =0x0
LBB31_6:
	ldur	x8, [x29, #-40]
Lloh137:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh138:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh139:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB31_8
; %bb.7:
	mov	x0, x21
	add	sp, sp, #4, lsl #12             ; =16384
	add	sp, sp, #3440
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB31_8:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh134, Lloh135, Lloh136
	.loh AdrpLdrGotLdr	Lloh137, Lloh138, Lloh139
	.loh AdrpLdrGot	Lloh132, Lloh133
	.cfi_endproc
                                        ; -- End function
	.section	__DATA,__data
	.p2align	3, 0x0                          ; @next_identity
_next_identity:
	.quad	1                               ; 0x1

.tbss _executing$tlv$init, 8, 3         ; @executing

	.section	__DATA,__thread_vars,thread_local_variables
_executing:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_executing$tlv$init

	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"[]"

.tbss _entered$tlv$init, 8, 3           ; @entered

	.section	__DATA,__thread_vars,thread_local_variables
_entered:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_entered$tlv$init

.tbss _reading$tlv$init, 8, 3           ; @reading

_reading:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_reading$tlv$init

.tbss _mutating$tlv$init, 8, 3          ; @mutating

_mutating:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_mutating$tlv$init

.subsections_via_symbols
