//! Explicit borrowed interface dispatch. No boxing, ownership or receiver writeback.
use crate::{
    Fault, Module,
    metadata::{Function, FunctionRef, Representation, Type, TypeDef, Visibility},
};

pub(crate) fn interface_definition<'a>(
    module: &'a Module,
    interface: &Type,
) -> Result<&'a TypeDef, Fault> {
    module
        .type_definition(interface)
        .filter(|d| d.representation == Representation::Interface)
        .ok_or_else(|| Fault::new("expected interface type"))
}

pub(crate) fn is_contract(module: &Module, function: &Function) -> bool {
    function
        .owner
        .as_ref()
        .and_then(|owner| module.type_definition(owner))
        .is_some_and(|d| d.representation == Representation::Interface)
}

pub(crate) fn is_bodyless(module: &Module, function: &Function) -> bool {
    function.is_abstract || (is_contract(module, function) && function.body.is_empty())
}

// Helpers have no implementation obligation and are called directly.
pub(crate) fn is_helper(function: &Function) -> bool {
    function.interface_implementations.is_empty()
        && (function.visibility == Visibility::Private
            || (!function.instance && !function.body.is_empty()))
}

pub(crate) fn validate_contract(function: &Function) -> Result<(), Fault> {
    let explicit = !function.interface_implementations.is_empty();
    let helper = is_helper(function);
    if (!function.instance
        && (function.receiver_byref
            || function.receiver_readonly
            || explicit
            || (!function.body.is_empty() && function.is_virtual)))
        || (helper
            && (function.instance
                || function.is_abstract
                || function.is_virtual
                || function.body.is_empty()))
        || function.visibility
            != if explicit || (helper && function.visibility == Visibility::Private) {
                Visibility::Private
            } else {
                Visibility::Public
            }
        || function.name.ends_with(".ctor")
        || function.impl_flags != 0
        || function.pinvoke.is_some()
        || function.is_override
        || (function.body.is_empty() && !function.locals.is_empty())
        || (function.is_abstract && !function.body.is_empty())
    {
        return Err(Fault::new(
            "invalid interface declaration, default body or explicit replacement",
        ));
    }
    Ok(())
}

fn arguments(ty: &Type) -> &[Type] {
    ty.generic_arguments()
}

/// Transitive, substituted interface identities, with diamonds deduplicated.
pub(crate) fn closure(module: &Module, ty: &Type) -> Result<Vec<Type>, Fault> {
    if let Some(views) = crate::runtime_lookup::interface_closure(module, ty) {
        return Ok(views.to_vec());
    }
    let views = closure_uncached(module, ty)?;
    crate::runtime_lookup::remember_interface_closure(module, ty, &views);
    Ok(views)
}

fn closure_uncached(module: &Module, ty: &Type) -> Result<Vec<Type>, Fault> {
    if let Some(nominal) = module.array_nominal(ty) {
        return closure(module, &nominal);
    }
    fn visit(
        module: &Module,
        ty: &Type,
        path: &mut Vec<String>,
        result: &mut Vec<Type>,
        implementing_type: &Type,
    ) -> Result<(), Fault> {
        let definition = module
            .type_definition(ty)
            .ok_or_else(|| Fault::new("interface receiver requires a known implementing type"))?;
        let name = ty
            .definition_name()
            .ok_or_else(|| Fault::new("invalid interface owner"))?
            .to_string();
        if path.contains(&name) || path.len() >= 256 {
            return Err(Fault::new(
                "cyclic or excessively deep interface inheritance",
            ));
        }
        if definition.representation == Representation::Interface {
            if result.contains(ty) {
                return Ok(());
            }
            result.push(ty.clone());
        }
        path.push(name);
        for base in &definition.implements {
            let base = base
                .substitute_type_parameters(arguments(ty))?
                .substitute_self(implementing_type)?;
            interface_definition(module, &base)?;
            visit(module, &base, path, result, implementing_type)?;
        }
        if definition.representation == Representation::Record {
            if let Some(base) = crate::inheritance::base(module, ty)? {
                visit(module, &base, path, result, &base)?;
            }
        }
        path.pop();
        Ok(())
    }
    if let Type::ArrayRef(element) = ty {
        if module.type_definition(ty).is_none() {
            let interface = Type::Constructed {
                definition: "System.Collections.Iterable".into(),
                arguments: vec![(**element).clone()],
            };
            return if interface_definition(module, &interface).is_ok() {
                closure(module, &interface)
            } else {
                Ok(vec![])
            };
        }
    }
    let mut result = Vec::new();
    let implementing_type = if interface_definition(module, ty).is_ok() {
        &Type::SelfType
    } else {
        ty
    };
    visit(module, ty, &mut Vec::new(), &mut result, implementing_type)?;
    Ok(result)
}

fn declared(module: &Module, concrete: &Type, interface: &Type) -> Result<(), Fault> {
    interface_definition(module, interface)?;
    if !closure(module, concrete)?.contains(interface) {
        return Err(Fault::new(
            "type must declare exactly one matching interface implementation (directly or transitively)",
        ));
    }
    Ok(())
}

fn conformance_owner(module: &Module, concrete: &Type, interface: &Type) -> Result<Type, Fault> {
    // An inherited mapping is anchored at the class that declares conformance.
    // A repeated declaration remaps from that class, including inherited members.
    let chain = if module
        .type_definition(concrete)
        .is_some_and(|d| d.representation == Representation::Record)
    {
        crate::inheritance::lineage(module, concrete)?
    } else {
        vec![concrete.clone()]
    };
    let mut anchor = None;
    for (index, owner) in chain.iter().enumerate() {
        let definition = module
            .type_definition(owner)
            .ok_or_else(|| Fault::new("unknown implementation owner"))?;
        for declared in &definition.implements {
            let declared = declared.substitute_type_parameters(arguments(owner))?;
            if closure(module, &declared)?
                .iter()
                .any(|ty| ty.substitute_self(owner).is_ok_and(|ty| &ty == interface))
            {
                anchor = Some(index);
                break;
            }
        }
        if anchor.is_some() {
            break;
        }
    }
    anchor
        .map(|index| chain[index].clone())
        .ok_or_else(|| Fault::new("missing interface mapping declaration"))
}

/// An inherited nominal interface does not promise Self = the derived type.
pub(crate) fn satisfies_self_bound(
    module: &Module,
    concrete: &Type,
    interface: &Type,
) -> Result<bool, Fault> {
    Ok(!has_self_contract(module, interface)?
        || conformance_owner(module, concrete, interface)? == *concrete)
}

fn has_self_contract(module: &Module, interface: &Type) -> Result<bool, Fault> {
    let interfaces = closure(module, interface)?;
    Ok(interfaces.iter().any(Type::contains_self)
        || interfaces.iter().any(|interface| {
            let Some(definition) = module.type_definition(interface) else {
                return false;
            };
            crate::runtime_lookup::functions_for_owner(module, definition).any(|method| {
                crate::self_types::signature_has_self(method)
                    && method
                        .owner
                        .as_ref()
                        .and_then(|owner| module.type_definition(owner))
                        .is_some_and(|owner| std::ptr::eq(owner, definition))
            })
        }))
}

fn member(
    module: &Module,
    concrete: &Type,
    contract: &Function,
) -> Result<Option<Function>, Fault> {
    let owner = conformance_owner(
        module,
        concrete,
        contract
            .owner
            .as_ref()
            .ok_or_else(|| Fault::new("interface contract requires owner"))?,
    )?;
    let specialized = contract.map_types(|ty| ty.substitute_self(&owner))?;
    let contract = &specialized;
    let chain = if module
        .type_definition(concrete)
        .is_some_and(|d| d.representation == Representation::Record)
    {
        crate::inheritance::lineage(module, concrete)?
    } else {
        vec![concrete.clone()]
    };
    let anchor = chain.iter().position(|ty| ty == &owner).unwrap();
    let name = contract
        .name
        .rsplit('.')
        .next()
        .ok_or_else(|| Fault::new("invalid interface member"))?;
    let mut selected = None;
    let mut explicit = false;
    for owner in &chain[anchor..] {
        for method in &module.functions {
            if method.interface_implementations.is_empty()
                || !method
                    .owner
                    .as_ref()
                    .and_then(|t| module.type_definition(t))
                    .zip(module.type_definition(owner))
                    .is_some_and(|(a, b)| std::ptr::eq(a, b))
            {
                continue;
            }
            let body = method.map_types(|ty| ty.substitute_type_parameters(arguments(owner)))?;
            for target in &body.interface_implementations {
                // Unrelated contracts cannot select this member. Native projections
                // may retain their unselected source templates until final trimming.
                if target.owner != contract.owner {
                    continue;
                }
                let declaration = crate::vm::resolve(module, target)?;
                if declaration.definition == contract.definition
                    && declaration.owner == contract.owner
                {
                    if explicit {
                        return Err(Fault::new(
                            "ambiguous explicit interface mapping after substitution",
                        ));
                    }
                    selected = Some(body.clone());
                    explicit = true;
                }
            }
        }
        if explicit {
            break;
        }
        let target = FunctionRef {
            definition: None,
            name: format!("{}.{name}", owner.definition_name().unwrap()),
            owner: Some(owner.clone()),
            instance: contract.instance,
            generic_arguments: vec![],
            parameters: contract.parameters.clone(),
        };
        let resolved = crate::vm::resolve(module, &target).or_else(|original| {
            // Metadata contracts can use encoded executable names while virtual
            // class slots retain the runtime member spelling. Both carry a
            // validated origin; resolve the same member and exact signature.
            if let Some(origin) = &contract.origin {
                let mut canonical = target.clone();
                canonical.name = format!("{}.{}", owner.definition_name().unwrap(), origin.name);
                return crate::vm::resolve(module, &canonical);
            }
            Err(original)
        });
        if let Ok(function) = resolved {
            if function.interface_implementations.is_empty()
                && function.visibility == Visibility::Public
            {
                selected = Some(function);
                break;
            }
        }
    }
    if let Some(implementation) = &selected {
        check_signature(module, implementation, contract, explicit)?;
    }
    Ok(selected)
}

fn check_signature(
    module: &Module,
    implementation: &Function,
    contract: &Function,
    explicit: bool,
) -> Result<(), Fault> {
    // Nominal interfaces receive an object; value methods receive its boxed payload.
    let boxed_receiver = !contract.receiver_byref
        && implementation.receiver_byref
        && implementation
            .owner
            .as_ref()
            .is_some_and(|owner| !module.is_reference_type(owner));
    if implementation.instance != contract.instance
        || implementation.parameters != contract.parameters
    {
        return Err(Fault::new(
            "interface implementation requires exact parameter types",
        ));
    }
    if implementation
        .out_when_true
        .iter()
        .collect::<std::collections::BTreeSet<_>>()
        != contract
            .out_when_true
            .iter()
            .collect::<std::collections::BTreeSet<_>>()
        || implementation
            .readonly_parameters
            .iter()
            .collect::<std::collections::BTreeSet<_>>()
            != contract
                .readonly_parameters
                .iter()
                .collect::<std::collections::BTreeSet<_>>()
        || (!boxed_receiver
            && (implementation.receiver_byref != contract.receiver_byref
                || implementation.receiver_readonly != contract.receiver_readonly))
        || implementation
            .out_parameters
            .iter()
            .collect::<std::collections::BTreeSet<_>>()
            != contract
                .out_parameters
                .iter()
                .collect::<std::collections::BTreeSet<_>>()
        || implementation.returns != contract.returns
        || implementation.no_result != contract.no_result
        || (!explicit && implementation.visibility != Visibility::Public)
        || implementation.is_internal_call()
        || implementation.pinvoke.is_some()
    {
        return Err(Fault::new(
            "interface implementation requires matching IL receiver, parameter and return contracts",
        ));
    }
    Ok(())
}

pub(crate) fn ensure_implementation(
    module: &Module,
    concrete: &Type,
    interface: &Type,
) -> Result<(), Fault> {
    let nominal = module.array_nominal(concrete);
    let concrete = nominal.as_ref().unwrap_or(concrete);
    declared(module, concrete, interface)?;
    ensure_members(module, concrete, interface)
}

// Both callers have already established the exact declared interface view.
fn ensure_members(module: &Module, concrete: &Type, interface: &Type) -> Result<(), Fault> {
    if interface_definition(module, concrete).is_ok() {
        return Ok(());
    }
    let owner = if has_self_contract(module, interface)? {
        conformance_owner(module, concrete, interface)?
    } else {
        concrete.clone()
    };
    for inherited in closure(module, interface)? {
        let inherited = inherited.substitute_self(&owner)?;
        let definition = interface_definition(module, &inherited)?;
        for method in crate::runtime_lookup::functions_for_owner(module, definition) {
            if method
                .owner
                .as_ref()
                .and_then(|ty| module.type_definition(ty))
                .is_some_and(|d| std::ptr::eq(d, definition))
                && method.interface_implementations.is_empty()
                && !is_helper(method)
            {
                let contract =
                    method.map_types(|ty| ty.substitute_type_parameters(arguments(&inherited)))?;
                let implementation = select(module, concrete, &contract)?;
                if !module
                    .type_definition(concrete)
                    .is_some_and(|d| d.is_abstract)
                    && implementation.is_virtual
                    && !is_contract(module, &implementation)
                {
                    crate::inheritance::dispatch(module, concrete, &implementation)?;
                }
            }
        }
    }
    Ok(())
}

/// Reference views may widen only a verified, explicitly implemented interface.
pub(crate) fn ensure_reference_implementation(
    module: &Module,
    concrete: &Type,
    interface: &Type,
) -> Result<(), Fault> {
    let nominal = module.array_nominal(concrete);
    let concrete = nominal.as_ref().unwrap_or(concrete);
    let view = crate::variance::implemented_view(module, concrete, interface)?;
    ensure_members(module, concrete, &view)
}

pub(crate) fn implementation(
    module: &Module,
    concrete: &Type,
    interface: &Type,
    contract: &Function,
) -> Result<Function, Fault> {
    let nominal = module.array_nominal(concrete);
    let concrete = nominal.as_ref().unwrap_or(concrete);
    let view = crate::variance::implemented_view(module, concrete, interface)?;
    if !is_contract(module, contract)
        || contract.owner.as_ref() != Some(interface)
        || !contract.interface_implementations.is_empty()
    {
        return Err(Fault::new("callvirt requires an interface member"));
    }
    let adapted;
    let contract = if view != *interface && contract.native_interface_slot.is_some() {
        adapted = module
            .functions
            .iter()
            .find(|method| {
                method.owner.as_ref() == Some(&view)
                    && method.native_interface_slot == contract.native_interface_slot
            })
            .ok_or_else(|| Fault::new("missing specialized variant interface slot"))?
            .clone();
        &adapted
    } else if view != *interface {
        let template = module
            .functions
            .iter()
            .find(|method| {
                method.name == contract.name
                    && method.definition == contract.definition
                    && method
                        .owner
                        .as_ref()
                        .and_then(|o| module.type_definition(o))
                        .zip(module.type_definition(interface))
                        .is_some_and(|(a, b)| std::ptr::eq(a, b))
                    && method
                        .map_types(|t| t.substitute_type_parameters(arguments(interface)))
                        .is_ok_and(|m| {
                            m.parameters == contract.parameters && m.returns == contract.returns
                        })
            })
            .ok_or_else(|| Fault::new("missing variant interface contract template"))?;
        adapted = template.map_types(|t| t.substitute_type_parameters(arguments(&view)))?;
        &adapted
    } else {
        contract
    };
    let mapped = select(module, concrete, contract)?;
    if is_bodyless(module, &mapped) && is_contract(module, &mapped) {
        return Err(Fault::new(
            "interface member has no concrete implementation",
        ));
    }
    if mapped.is_virtual && !is_contract(module, &mapped) {
        crate::inheritance::dispatch(module, concrete, &mapped)
    } else {
        Ok(mapped)
    }
}

fn array_implementation(
    module: &Module,
    element: &Type,
    contract: &Function,
) -> Result<Function, Fault> {
    let iterable = Type::Constructed {
        definition: "System.Collections.Iterable".into(),
        arguments: vec![element.clone()],
    };
    let iterator = Type::Constructed {
        definition: "System.Collections.Iterator".into(),
        arguments: vec![element.clone()],
    };
    if contract.owner.as_ref() != Some(&iterable)
        || contract.name != "System.Collections.Iterable.GetIterator"
        || !contract.instance
        || contract.receiver_byref
        || !contract.parameters.is_empty()
        || contract.returns != iterator
        || !contract.generic_parameters.is_empty()
    {
        return Err(Fault::new("unsupported array iteration contract"));
    }
    let array = Type::ArrayRef(Box::new(element.clone()));
    let body = crate::vm::resolve(
        module,
        &FunctionRef {
            definition: None,
            name: "System.Collections.ArrayEnumerable.GetIterator".into(),
            owner: Some(Type::Named("System.Collections.ArrayEnumerable".into())),
            instance: false,
            generic_arguments: vec![element.clone()],
            parameters: vec![array.clone()],
        },
    )?;
    if body.instance
        || body.parameters != vec![array]
        || body.returns != iterator
        || is_bodyless(module, &body)
    {
        return Err(Fault::new("invalid array iteration implementation"));
    }
    Ok(body)
}

fn select(module: &Module, concrete: &Type, contract: &Function) -> Result<Function, Fault> {
    if let Type::ArrayRef(element) = concrete {
        if contract.name == "System.Collections.Iterable.GetIterator" {
            return array_implementation(module, element, contract);
        }
    }
    if let Some(body) = member(module, concrete, contract)? {
        return Ok(body);
    }
    let mut candidates = vec![contract.clone()];
    for interface in closure(module, concrete)? {
        for method in &module.functions {
            if !method
                .owner
                .as_ref()
                .and_then(|t| module.type_definition(t))
                .zip(module.type_definition(&interface))
                .is_some_and(|(a, b)| std::ptr::eq(a, b))
            {
                continue;
            }
            let body = method.map_types(|t| t.substitute_type_parameters(arguments(&interface)))?;
            for target in &body.interface_implementations {
                // Unrelated contracts cannot select this member. Native projections
                // may retain their unselected source templates until final trimming.
                if target.owner != contract.owner {
                    continue;
                }
                let declaration = crate::vm::resolve(module, target)?;
                if declaration.definition == contract.definition
                    && declaration.owner == contract.owner
                    && !candidates
                        .iter()
                        .any(|c| c.definition == body.definition && c.owner == body.owner)
                {
                    candidates.push(body.clone());
                }
            }
        }
    }
    let mut remaining = Vec::new();
    for candidate in &candidates {
        let mut dominated = false;
        for other in &candidates {
            if candidate.owner != other.owner
                && closure(module, other.owner.as_ref().unwrap())?
                    .contains(candidate.owner.as_ref().unwrap())
            {
                dominated = true;
                break;
            }
        }
        if !dominated {
            remaining.push(candidate);
        }
    }
    if remaining.len() != 1 {
        return Err(Fault::new("ambiguous default interface implementation"));
    }
    let selected = remaining[0];
    if is_bodyless(module, selected)
        && !module
            .type_definition(concrete)
            .is_some_and(|d| d.is_abstract)
    {
        return Err(Fault::new(format!(
            "interface implementation member not found or reabstracted: {concrete:?} -> {}",
            contract.name
        )));
    }
    // Existing abstract records must still supply an explicit abstract class contract
    // when no interface default or replacement participates.
    if is_bodyless(module, selected) && candidates.len() == 1 {
        return Err(Fault::new("interface implementation member not found"));
    }
    Ok(selected.clone())
}

fn flags<T: Ord + Copy>(values: &[T]) -> std::collections::BTreeSet<T> {
    values.iter().copied().collect()
}

pub(crate) fn validate(module: &Module) -> Result<(), Fault> {
    let mut mappings = std::collections::HashSet::new();
    for body in &module.functions {
        if body.interface_implementations.is_empty() {
            continue;
        }
        let owner = body
            .owner
            .as_ref()
            .ok_or_else(|| Fault::new("explicit implementation requires a record owner"))?;
        let definition = module
            .type_definition(owner)
            .ok_or_else(|| Fault::new("unknown explicit implementation owner"))?;
        let interface_owner = definition.representation == Representation::Interface;
        // Intrinsic String supplies IL members over immutable text. Reference receivers
        // need no readonly-byref flag; retained byref bodies must be readonly.
        let string_owner = *owner == Type::String
            && definition.representation == Representation::Runtime
            && (!body.receiver_byref || body.receiver_readonly);
        if !matches!(
            definition.representation,
            Representation::Record | Representation::Interface
        ) && !string_owner
            || !body.instance
            || (!body.receiver_byref && !module.is_reference_type(owner) && !string_owner)
            || body.visibility != Visibility::Private
            || (body.is_virtual && !interface_owner)
            || body.is_override
            || (body.is_abstract && !interface_owner)
            || body.name.ends_with(".ctor")
            || body.is_internal_call()
            || body.pinvoke.is_some()
        {
            return Err(Fault::new(
                "explicit implementations require private concrete managed IL value/class or immutable String methods",
            ));
        }
        for target in &body.interface_implementations {
            let contract = crate::vm::resolve(module, target)?;
            if !is_contract(module, &contract) || !contract.interface_implementations.is_empty() {
                return Err(Fault::new(
                    "explicit implementation must map an interface declaration",
                ));
            }
            let interface = contract.owner.as_ref().unwrap();
            let mut declared_here = false;
            for declared in &definition.implements {
                if closure(module, declared)?.contains(interface) {
                    declared_here = true;
                }
            }
            if !declared_here {
                return Err(Fault::new(
                    "explicit implementation requires interface conformance declared on its owner",
                ));
            }
            if !mappings.insert((
                owner.clone(),
                contract.definition.clone(),
                interface.clone(),
            )) {
                return Err(Fault::new("duplicate explicit interface mapping"));
            }
            check_signature(
                module,
                body,
                &contract.map_types(|ty| ty.substitute_self(owner))?,
                true,
            )?;
        }
    }
    for definition in &module.types {
        if definition.representation == Representation::Interface
            && (!definition.fields.is_empty()
                || definition.packing.is_some()
                || definition.minimum_size.is_some())
        {
            return Err(Fault::new("interfaces cannot declare storage or layout"));
        }
        let inherited = closure(module, &definition.open_type())?;
        if definition.representation == Representation::Interface {
            let mut contracts: Vec<Function> = Vec::new();
            for interface in inherited {
                let owner = interface_definition(module, &interface)?;
                for method in &module.functions {
                    if is_helper(method)
                        || !method.interface_implementations.is_empty()
                        || !method
                            .owner
                            .as_ref()
                            .and_then(|ty| module.type_definition(ty))
                            .is_some_and(|d| std::ptr::eq(d, owner))
                    {
                        continue;
                    }
                    let contract = method
                        .map_types(|ty| ty.substitute_type_parameters(arguments(&interface)))?;
                    for previous in &contracts {
                        if previous.name.rsplit('.').next() == contract.name.rsplit('.').next()
                            && previous.parameters == contract.parameters
                            && (previous.returns != contract.returns
                                || previous.no_result != contract.no_result
                                || previous.receiver_byref != contract.receiver_byref
                                || previous.receiver_readonly != contract.receiver_readonly
                                || flags(&previous.out_parameters)
                                    != flags(&contract.out_parameters)
                                || flags(&previous.out_when_true) != flags(&contract.out_when_true)
                                || flags(&previous.readonly_parameters)
                                    != flags(&contract.readonly_parameters))
                        {
                            return Err(Fault::new("incompatible inherited interface contracts"));
                        }
                    }
                    contracts.push(contract);
                }
            }
        }
        let mut seen = std::collections::HashSet::new();
        for interface in &definition.implements {
            let parent = interface_definition(module, interface)?;
            if parent.is_closed_hierarchy
                && !definition
                    .definition
                    .as_ref()
                    .zip(parent.definition.as_ref())
                    .is_some_and(|(child, root)| {
                        child.module == root.module && child.revision == root.revision
                    })
            {
                return Err(Fault::new(
                    "closed interface hierarchy cannot be extended outside its defining assembly",
                ));
            }
            if !seen.insert(interface) {
                return Err(Fault::new("duplicate interface implementation"));
            }
        }
        for interface in closure(module, &definition.open_type())? {
            if interface != definition.open_type() {
                ensure_implementation(module, &definition.open_type(), &interface)?;
            }
        }
    }
    Ok(())
}

/// Conservative targets in the loaded module set. Never silently omit unresolved
/// generic implementations from a graph advertised as closed.
pub(crate) fn dispatch_targets(
    module: &Module,
    contract: &Function,
) -> Result<Vec<Function>, Fault> {
    fn infer(pattern: &Type, actual: &Type, bindings: &mut [Option<Type>]) -> bool {
        match (pattern, actual) {
            (Type::TypeParameter(index), actual) => {
                let Some(slot) = bindings.get_mut(*index as usize) else {
                    return false;
                };
                match slot {
                    Some(bound) => bound == actual,
                    None => {
                        *slot = Some(actual.clone());
                        true
                    }
                }
            }
            (
                Type::Constructed {
                    definition: left,
                    arguments: a,
                },
                Type::Constructed {
                    definition: right,
                    arguments: b,
                },
            ) => {
                left == right
                    && a.len() == b.len()
                    && a.iter().zip(b).all(|(a, b)| infer(a, b, bindings))
            }
            (Type::Ptr(a), Type::Ptr(b))
            | (Type::InterfaceRef(a), Type::InterfaceRef(b))
            | (Type::ByRef(a), Type::ByRef(b))
            | (Type::ReadOnlyByRef(a), Type::ReadOnlyByRef(b))
            | (Type::ArrayRef(a), Type::ArrayRef(b))
            | (Type::Array(a), Type::Array(b)) => infer(a, b, bindings),
            _ => pattern == actual,
        }
    }
    let interface = contract
        .owner
        .as_ref()
        .ok_or_else(|| Fault::new("interface call requires owner"))?;
    let mut targets = vec![];
    if let Type::Constructed {
        definition,
        arguments,
    } = interface
    {
        if definition == "System.Collections.Iterable"
            && arguments.len() == 1
            && module
                .type_definition(&Type::Named("System.Collections.ArrayEnumerable".into()))
                .is_some()
        {
            targets.push(array_implementation(module, &arguments[0], contract)?);
        }
    }
    for definition in &module.types {
        if definition.representation == Representation::Interface || definition.is_abstract {
            continue;
        }
        for implemented in &closure(module, &definition.open_type())? {
            if !definition.generic_parameters.is_empty()
                && implemented.definition_name() == interface.definition_name()
                && interface_definition(module, interface)?
                    .generic_variance
                    .iter()
                    .any(|v| *v != crate::metadata::Variance::Invariant)
            {
                return Err(Fault::new(
                    "closed variant dispatch graph requires nongeneric implementing types",
                ));
            }
            let mut bindings = vec![None; definition.generic_parameters.len()];
            if !(infer(implemented, interface, &mut bindings)
                || definition.generic_parameters.is_empty()
                    && crate::variance::compatible(module, implemented, interface))
            {
                continue;
            }
            let arguments = bindings
                .into_iter()
                .collect::<Option<Vec<_>>>()
                .ok_or_else(|| {
                    Fault::new(
                        "closed interface call graph cannot infer all implementing type arguments",
                    )
                })?;
            let concrete = definition
                .open_type()
                .substitute_type_parameters(&arguments)?;
            let target = implementation(module, &concrete, interface, contract)?;
            if !targets
                .iter()
                .any(|f: &Function| f.definition == target.definition && f.owner == target.owner)
            {
                targets.push(target);
            }
        }
    }
    Ok(targets)
}

#[cfg(test)]
mod self_contract_tests {
    use super::*;

    fn fixture() -> Module {
        crate::assemble(
            ".module SelfLookup\n\
             .interface Plain\n.method instance Read() -> Int32\n.end\n.end\n\
             .interface Related\n.method instance Copy() -> Self\n.end\n.end\n\
             .interface Child\n.implements Related\n.end\n\
             .interface Generic<T>\n.method instance Read() -> T\n.end\n.end\n\
             .interface SelfArgument\n.implements Generic<Self>\n.end\n\
             .type Noise\n.method static Read() -> Int32\nldc.i4 42\nret\n.end\n.end\n",
        )
        .unwrap()
    }

    #[test]
    fn indexed_members_preserve_inherited_contracts_and_rejections() {
        let module = crate::assemble(
            r#"
.module MemberCandidates
.interface Read
.method instance Get() -> Int32
.end
.end
.interface Child
.implements Read
.end
.type class Sample
.implements Child
.method instance Get() -> Int32
ldc.i4 42
ret
.end
.end
"#,
        )
        .unwrap();
        let concrete = Type::from_name("Sample");
        let interface = Type::from_name("Child");
        let check = |module: &Module| {
            let expected =
                ensure_implementation(module, &concrete, &interface).map_err(|fault| fault.message);
            crate::runtime_lookup::with_module(module, || {
                assert_eq!(
                    ensure_implementation(module, &concrete, &interface)
                        .map_err(|fault| fault.message),
                    expected
                );
            });
            expected
        };
        assert!(check(&module).is_ok());
        for variant in 0..4 {
            let mut invalid = module.clone();
            let method = invalid
                .functions
                .iter_mut()
                .find(|f| f.name == "Sample.Get")
                .unwrap();
            match variant {
                0 => method.returns = Type::String,
                1 => method.receiver_readonly = true,
                2 => method.visibility = Visibility::Private,
                _ => method.name = "Sample.Missing".into(),
            }
            assert!(check(&invalid).is_err());
        }
    }

    #[test]
    fn self_contract_lookup_keeps_owner_and_inherited_signature_semantics() {
        let module = fixture();
        let check = || {
            for (name, expected) in [
                ("Plain", false),
                ("Related", true),
                ("Child", true),
                ("Generic<Int32>", false),
                ("SelfArgument", true),
            ] {
                let interface = crate::assembler::parse_type(name).unwrap();
                assert_eq!(has_self_contract(&module, &interface).unwrap(), expected);
            }
        };
        check();
        crate::runtime_lookup::with_module(&module, check);
    }

    #[test]
    #[ignore = "manual interface lookup timing probe"]
    fn self_contract_lookup_timing() {
        let mut module = fixture();
        let noise = module.functions.last().unwrap().clone();
        for index in 0..4096 {
            let mut method = noise.clone();
            method.name = format!("Noise.Read{index}");
            module.functions.push(method);
        }
        let interface = Type::Named("Plain".into());
        crate::runtime_lookup::with_module(&module, || {
            for _ in 0..5 {
                let start = std::time::Instant::now();
                for _ in 0..100 {
                    assert!(
                        !has_self_contract(
                            std::hint::black_box(&module),
                            std::hint::black_box(&interface)
                        )
                        .unwrap()
                    );
                }
                println!(
                    "self_contract_100_seconds={:.9}",
                    start.elapsed().as_secs_f64()
                );
            }
        });
    }
}
