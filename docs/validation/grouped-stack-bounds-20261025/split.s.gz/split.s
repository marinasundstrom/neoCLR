	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 26, 2	sdk_version 26, 2
	.globl	_neoclr_native_stack_bounds_v1  ; -- Begin function neoclr_native_stack_bounds_v1
	.p2align	2
_neoclr_native_stack_bounds_v1:         ; @neoclr_native_stack_bounds_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh0:
	adrp	x0, _retained_lower@TLVPPAGE
Lloh1:
	ldr	x0, [x0, _retained_lower@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	str	x8, [x0]
Lloh2:
	adrp	x0, _retained_upper@TLVPPAGE
Lloh3:
	ldr	x0, [x0, _retained_upper@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	x1, [x0]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_native_stack_check_v1   ; -- Begin function neoclr_native_stack_check_v1
	.p2align	2
_neoclr_native_stack_check_v1:          ; @neoclr_native_stack_check_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	; InlineAsm Start
	mov	x21, sp
	; InlineAsm End
Lloh4:
	adrp	x0, _retained_lower@TLVPPAGE
Lloh5:
	ldr	x0, [x0, _retained_lower@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh6:
	adrp	x0, _retained_upper@TLVPPAGE
Lloh7:
	ldr	x0, [x0, _retained_upper@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	orr	x10, x8, x9
	cbz	x10, LBB1_3
; %bb.1:
	mov	w0, #9                          ; =0x9
	subs	x8, x21, x8
	ccmp	x21, x9, #2, hs
	b.hs	LBB1_6
; %bb.2:
	lsr	x8, x8, #18
	cmp	x8, #0
	csel	w0, wzr, w0, ne
	b	LBB1_6
LBB1_3:
	bl	_pthread_self
	mov	x20, x0
	bl	_pthread_get_stackaddr_np
	mov	x19, x0
	mov	x0, x20
	bl	_pthread_get_stacksize_np
	mov	x8, x0
	mov	w0, #9                          ; =0x9
	cbz	x19, LBB1_6
; %bb.4:
	cbz	x8, LBB1_6
; %bb.5:
	sub	x9, x19, x8
	sub	x10, x21, x9
	tst	x10, #0xfffffffffffc0000
	ccmp	x21, x9, #0, ne
	ccmp	x21, x19, #2, hs
	mov	w9, #9                          ; =0x9
	csel	w9, wzr, w9, lo
	cmp	x8, x19
	csel	w0, w0, w9, hi
LBB1_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
.tbss _retained_lower$tlv$init, 8, 3    ; @retained_lower

	.section	__DATA,__thread_vars,thread_local_variables
_retained_lower:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_retained_lower$tlv$init

.tbss _retained_upper$tlv$init, 8, 3    ; @retained_upper

_retained_upper:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_retained_upper$tlv$init

.subsections_via_symbols
