	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 26, 2	sdk_version 26, 2
	.globl	_neoclr_gc_trigger_profile_v1   ; -- Begin function neoclr_gc_trigger_profile_v1
	.p2align	2
_neoclr_gc_trigger_profile_v1:          ; @neoclr_gc_trigger_profile_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh0:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh1:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0, #64]
	stp	q0, q1, [x8, #64]
	ldp	q0, q1, [x0, #96]
	stp	q0, q1, [x8, #96]
	ldp	q0, q1, [x0]
	stp	q0, q1, [x8]
	ldp	q0, q1, [x0, #32]
	stp	q0, q1, [x8, #32]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_trigger_profile_reset_v1 ; -- Begin function neoclr_gc_trigger_profile_reset_v1
	.p2align	2
_neoclr_gc_trigger_profile_reset_v1:    ; @neoclr_gc_trigger_profile_reset_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh2:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh3:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #96]
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_lookup_profile_v1    ; -- Begin function neoclr_gc_lookup_profile_v1
	.p2align	2
_neoclr_gc_lookup_profile_v1:           ; @neoclr_gc_lookup_profile_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh4:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh5:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0, #32]
	stp	q0, q1, [x8, #32]
	ldp	q0, q1, [x0, #64]
	stp	q0, q1, [x8, #64]
	ldp	q0, q1, [x0]
	stp	q0, q1, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_lookup_profile_reset_v1 ; -- Begin function neoclr_gc_lookup_profile_reset_v1
	.p2align	2
_neoclr_gc_lookup_profile_reset_v1:     ; @neoclr_gc_lookup_profile_reset_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh6:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh7:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_profile_v1           ; -- Begin function neoclr_gc_profile_v1
	.p2align	2
_neoclr_gc_profile_v1:                  ; @neoclr_gc_profile_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh8:
	adrp	x0, _profile@TLVPPAGE
Lloh9:
	ldr	x0, [x0, _profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x1, x0
	mov	x0, x8
	mov	w2, #584                        ; =0x248
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_memcpy
	.loh AdrpLdr	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_profile_reset_v1     ; -- Begin function neoclr_gc_profile_reset_v1
	.p2align	2
_neoclr_gc_profile_reset_v1:            ; @neoclr_gc_profile_reset_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh10:
	adrp	x0, _profile@TLVPPAGE
Lloh11:
	ldr	x0, [x0, _profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w1, #584                        ; =0x248
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_bzero
	.loh AdrpLdr	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_heap_acquire_v1      ; -- Begin function neoclr_gc_heap_acquire_v1
	.p2align	2
_neoclr_gc_heap_acquire_v1:             ; @neoclr_gc_heap_acquire_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x9, x0
Lloh12:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh13:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w8, #3                          ; =0x3
	cbz	x9, LBB6_6
; %bb.1:
	ldr	x10, [x0]
	cbnz	x10, LBB6_6
; %bb.2:
	ldp	x10, x8, [x9, #8]
	and	x11, x8, #0x7
	cmp	x8, x10
	ccmp	x11, #0, #0, ls
	b.ne	LBB6_4
; %bb.3:
	ldr	x11, [x9]
	cmp	x11, #0
	ccmp	x10, #0, #4, eq
	and	x12, x11, #0x7
	orr	x8, x12, x8
	ccmp	x8, #0, #0, eq
	b.eq	LBB6_5
LBB6_4:
	mov	w8, #3                          ; =0x3
	b	LBB6_6
LBB6_5:
	mov	w8, #0                          ; =0x0
	stp	x9, x11, [x0]
	stp	xzr, xzr, [x0, #24]
	str	x10, [x0, #16]
LBB6_6:
	mov	x0, x8
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh12, Lloh13
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_heap_release_v1      ; -- Begin function neoclr_gc_heap_release_v1
	.p2align	2
_neoclr_gc_heap_release_v1:             ; @neoclr_gc_heap_release_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	cbz	x0, LBB7_3
; %bb.1:
	mov	x8, x0
Lloh14:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh15:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	mov	w19, #3                         ; =0x3
	cmp	x9, x8
	b.ne	LBB7_4
; %bb.2:
	mov	x20, x0
	mov	x0, x8
	bl	_blocks_valid
	cmp	w0, #0
	csel	w19, w19, wzr, eq
	mov	x0, x20
	mov	w1, #2088                       ; =0x828
	bl	_bzero
	b	LBB7_4
LBB7_3:
	mov	w19, #3                         ; =0x3
LBB7_4:
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function blocks_valid
_blocks_valid:                          ; @blocks_valid
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB8_12
; %bb.1:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh16:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh17:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x10, [x0]
	cmp	x10, x8
	b.eq	LBB8_7
; %bb.2:
	ldp	x9, x11, [x8, #8]
LBB8_3:
	and	x12, x11, #0x7
	cmp	x11, x9
	ccmp	x12, #0, #0, ls
	b.ne	LBB8_10
; %bb.4:
	ldr	x12, [x8]
	cmp	x12, #0
	ccmp	x9, #0, #4, eq
	and	x9, x12, #0x7
	ccmp	x9, #0, #0, eq
	b.ne	LBB8_10
; %bb.5:
	ldr	x9, [x0, #32]
	cmp	x10, x8
	csel	x9, x9, xzr, eq
	cbz	x11, LBB8_26
; %bb.6:
	mov	x13, #0                         ; =0x0
	b	LBB8_15
LBB8_7:
	ldr	x9, [x8]
	ldr	x11, [x0, #8]
	cmp	x9, x11
	b.ne	LBB8_10
; %bb.8:
	ldr	x9, [x8, #8]
	ldr	x11, [x0, #16]
	cmp	x9, x11
	b.ne	LBB8_10
; %bb.9:
	ldr	x11, [x8, #16]
	ldr	x12, [x0, #24]
	cmp	x11, x12
	b.eq	LBB8_3
LBB8_10:
	mov	w0, #0                          ; =0x0
LBB8_11:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB8_12:
	ret
LBB8_13:                                ;   in Loop: Header=BB8_15 Depth=1
	cmp	x10, x8
	b.eq	LBB8_23
LBB8_14:                                ;   in Loop: Header=BB8_15 Depth=1
	add	x13, x14, x13
	cmp	x13, x11
	b.hs	LBB8_26
LBB8_15:                                ; =>This Inner Loop Header: Depth=1
	sub	x16, x11, x13
	cmp	x16, #32
	b.lo	LBB8_25
; %bb.16:                               ;   in Loop: Header=BB8_15 Depth=1
	add	x15, x12, x13
	ldr	x14, [x15]
	cmp	x14, x16
	b.hi	LBB8_25
; %bb.17:                               ;   in Loop: Header=BB8_15 Depth=1
	and	x16, x14, #0x7
	cmp	x14, #40
	ccmp	x16, #0, #0, hs
	b.ne	LBB8_25
; %bb.18:                               ;   in Loop: Header=BB8_15 Depth=1
	ldr	x16, [x15, #24]
	cmp	x16, #7
	b.hi	LBB8_25
; %bb.19:                               ;   in Loop: Header=BB8_15 Depth=1
	cbz	x16, LBB8_13
; %bb.20:                               ;   in Loop: Header=BB8_15 Depth=1
	tbz	w16, #0, LBB8_25
; %bb.21:                               ;   in Loop: Header=BB8_15 Depth=1
	ldr	x16, [x15, #8]
	sub	x17, x14, #32
	sub	x16, x16, #1
	cmp	x16, x17
	b.hs	LBB8_25
; %bb.22:                               ;   in Loop: Header=BB8_15 Depth=1
	ldr	x15, [x15, #16]
	sub	x15, x15, #7
	cmn	x15, #6
	b.hs	LBB8_14
	b	LBB8_25
LBB8_23:                                ;   in Loop: Header=BB8_15 Depth=1
	orr	x16, x13, #0x1
	cmp	x9, x16
	b.ne	LBB8_25
; %bb.24:                               ;   in Loop: Header=BB8_15 Depth=1
	ldr	x9, [x15, #8]
	b	LBB8_14
LBB8_25:
	mov	w8, #0                          ; =0x0
	b	LBB8_27
LBB8_26:
	mov	w8, #1                          ; =0x1
LBB8_27:
	cmp	x9, #0
	csel	w0, wzr, w8, ne
	b	LBB8_11
	.loh AdrpLdr	Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_allocation_info_v1   ; -- Begin function neoclr_gc_allocation_info_v1
	.p2align	2
_neoclr_gc_allocation_info_v1:          ; @neoclr_gc_allocation_info_v1
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB9_8
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	cbz	x1, LBB9_7
; %bb.2:
	mov	x21, x2
	cbz	x2, LBB9_7
; %bb.3:
	mov	x19, x3
	cbz	x3, LBB9_7
; %bb.4:
	add	x0, x8, #1048
	mov	x1, x20
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB9_6
; %bb.5:
	mov	w0, #0                          ; =0x0
	ldur	x8, [x20, #-24]
	str	x8, [x21]
	ldur	x8, [x20, #-16]
	str	w8, [x19]
	b	LBB9_7
LBB9_6:
	mov	w0, #3                          ; =0x3
LBB9_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB9_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function validated_bases
_validated_bases:                       ; @validated_bases
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh18:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh19:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x10, [x0]
	add	x10, x10, #1
	str	x10, [x0]
	cbz	x8, LBB10_25
; %bb.1:
	mov	x9, x0
Lloh20:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh21:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x11, [x0]
	cmp	x11, x8
	b.eq	LBB10_22
; %bb.2:
	ldp	x14, x12, [x8, #8]
LBB10_3:
	mov	w10, #0                         ; =0x0
	cmp	x12, x14
	b.hi	LBB10_26
; %bb.4:
	and	x13, x12, #0x7
	cbnz	x13, LBB10_26
; %bb.5:
	mov	w10, #0                         ; =0x0
	ldr	x13, [x8]
	cmp	x13, #0
	ccmp	x14, #0, #4, eq
	b.ne	LBB10_26
; %bb.6:
	and	x14, x13, #0x7
	cbnz	x14, LBB10_26
; %bb.7:
	cmp	x11, x8
	b.eq	LBB10_27
LBB10_8:
	ldr	x10, [x9, #16]
	add	x10, x10, #1
	str	x10, [x9, #16]
	cmp	x1, #0
	cset	w10, eq
	cmp	x2, #0
	cset	w15, eq
	mov	x14, #0                         ; =0x0
	cbz	x12, LBB10_33
; %bb.9:
	cmp	x2, #0
	cset	w15, eq
	cmp	x1, #0
	cset	w16, eq
	ldr	x10, [x9, #24]
	add	x17, x10, #1
	b	LBB10_11
LBB10_10:                               ;   in Loop: Header=BB10_11 Depth=1
	add	x17, x17, #1
	add	x14, x3, x14
	cmp	x14, x12
	b.hs	LBB10_32
LBB10_11:                               ; =>This Inner Loop Header: Depth=1
	cbz	w16, LBB10_13
; %bb.12:                               ;   in Loop: Header=BB10_11 Depth=1
	cbnz	w15, LBB10_32
LBB10_13:                               ;   in Loop: Header=BB10_11 Depth=1
	str	x17, [x9, #24]
	sub	x5, x12, x14
	cmp	x5, #32
	b.lo	LBB10_25
; %bb.14:                               ;   in Loop: Header=BB10_11 Depth=1
	mov	w10, #0                         ; =0x0
	add	x4, x13, x14
	ldr	x3, [x4]
	cmp	x3, x5
	b.hi	LBB10_26
; %bb.15:                               ;   in Loop: Header=BB10_11 Depth=1
	and	x5, x3, #0x7
	cmp	x3, #40
	ccmp	x5, #0, #0, hs
	b.ne	LBB10_26
; %bb.16:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x10, [x4, #24]
	cmp	x10, #7
	b.hi	LBB10_25
; %bb.17:                               ;   in Loop: Header=BB10_11 Depth=1
	cbz	x10, LBB10_10
; %bb.18:                               ;   in Loop: Header=BB10_11 Depth=1
	tbz	w10, #0, LBB10_25
; %bb.19:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x10, [x4, #8]
	sub	x5, x3, #32
	sub	x10, x10, #1
	cmp	x10, x5
	b.hs	LBB10_25
; %bb.20:                               ;   in Loop: Header=BB10_11 Depth=1
	ldr	x10, [x4, #16]
	sub	x10, x10, #7
	cmn	x10, #6
	b.lo	LBB10_25
; %bb.21:                               ;   in Loop: Header=BB10_11 Depth=1
	add	x10, x4, #32
	cmp	x10, x1
	cset	w4, eq
	orr	w16, w16, w4
	cmp	x10, x2
	cset	w10, eq
	orr	w15, w15, w10
	b	LBB10_10
LBB10_22:
	ldr	x10, [x8]
	ldr	x12, [x0, #8]
	cmp	x10, x12
	b.ne	LBB10_25
; %bb.23:
	ldr	x14, [x8, #8]
	ldr	x10, [x0, #16]
	cmp	x14, x10
	b.ne	LBB10_25
; %bb.24:
	ldr	x12, [x8, #16]
	ldr	x10, [x0, #24]
	cmp	x12, x10
	b.eq	LBB10_3
LBB10_25:
	mov	w10, #0                         ; =0x0
LBB10_26:
	mov	x0, x10
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB10_27:
	cbz	x1, LBB10_29
; %bb.28:
	ubfx	x10, x1, #3, #29
	eor	w10, w10, w1, lsr #9
	add	x10, x0, w10, uxtb #3
	ldr	x10, [x10, #40]
	cmp	x10, x1
	b.ne	LBB10_8
LBB10_29:
	cbz	x2, LBB10_31
; %bb.30:
	ubfx	x10, x2, #3, #29
	eor	w10, w10, w2, lsr #9
	add	x10, x0, w10, uxtb #3
	ldr	x10, [x10, #40]
	cmp	x10, x2
	b.ne	LBB10_8
LBB10_31:
	ldr	x8, [x9, #8]
	add	x8, x8, #1
	str	x8, [x9, #8]
	mov	w10, #1                         ; =0x1
	b	LBB10_26
LBB10_32:
	cmp	w16, #0
	cset	w10, ne
	cmp	w15, #0
	cset	w15, ne
LBB10_33:
	cmp	x14, x12
	b.hs	LBB10_46
; %bb.34:
	ldr	x16, [x9, #24]
	b	LBB10_36
LBB10_35:                               ;   in Loop: Header=BB10_36 Depth=1
	add	x16, x16, #1
	add	x14, x17, x14
	cmp	x14, x12
	b.hs	LBB10_45
LBB10_36:                               ; =>This Inner Loop Header: Depth=1
	sub	x4, x12, x14
	cmp	x4, #32
	b.lo	LBB10_44
; %bb.37:                               ;   in Loop: Header=BB10_36 Depth=1
	add	x3, x13, x14
	ldr	x17, [x3]
	cmp	x17, x4
	b.hi	LBB10_44
; %bb.38:                               ;   in Loop: Header=BB10_36 Depth=1
	and	x4, x17, #0x7
	cmp	x17, #40
	ccmp	x4, #0, #0, hs
	b.ne	LBB10_44
; %bb.39:                               ;   in Loop: Header=BB10_36 Depth=1
	ldr	x4, [x3, #24]
	cmp	x4, #7
	b.hi	LBB10_44
; %bb.40:                               ;   in Loop: Header=BB10_36 Depth=1
	cbz	x4, LBB10_35
; %bb.41:                               ;   in Loop: Header=BB10_36 Depth=1
	tbz	w4, #0, LBB10_44
; %bb.42:                               ;   in Loop: Header=BB10_36 Depth=1
	ldr	x4, [x3, #8]
	sub	x5, x17, #32
	sub	x4, x4, #1
	cmp	x4, x5
	b.hs	LBB10_44
; %bb.43:                               ;   in Loop: Header=BB10_36 Depth=1
	ldr	x3, [x3, #16]
	sub	x3, x3, #7
	cmn	x3, #6
	b.hs	LBB10_35
LBB10_44:
	mov	w10, #0                         ; =0x0
	add	x8, x16, #1
	str	x8, [x9, #24]
	b	LBB10_26
LBB10_45:
	str	x16, [x9, #24]
LBB10_46:
	cmp	x11, x8
	cset	w8, eq
	and	w8, w8, w10
	and	w8, w8, w15
	cmp	w8, #1
	b.ne	LBB10_51
; %bb.47:
	cbz	x1, LBB10_49
; %bb.48:
	ubfx	x8, x1, #3, #29
	eor	w8, w8, w1, lsr #9
	add	x8, x0, w8, uxtb #3
	str	x1, [x8, #40]
LBB10_49:
	cbz	x2, LBB10_51
; %bb.50:
	ubfx	x8, x2, #3, #29
	eor	w8, w8, w2, lsr #9
	add	x8, x0, w8, uxtb #3
	str	x2, [x8, #40]
LBB10_51:
	and	w10, w10, w15
	b	LBB10_26
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh20, Lloh21
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_resource_attach_v1   ; -- Begin function neoclr_gc_resource_attach_v1
	.p2align	2
_neoclr_gc_resource_attach_v1:          ; @neoclr_gc_resource_attach_v1
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x4
	mov	x21, x3
	mov	x19, x2
	mov	x22, x1
	mov	x23, x0
Lloh22:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh23:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x4, LBB11_15
; %bb.1:
	cbz	x19, LBB11_15
; %bb.2:
	cbz	x22, LBB11_15
; %bb.3:
	cbz	x23, LBB11_15
; %bb.4:
	ldr	w8, [x8, #88]
	cbnz	w8, LBB11_15
; %bb.5:
	add	x0, x23, #1048
	mov	x1, x22
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB11_14
; %bb.6:
Lloh24:
	adrp	x0, _resource_head@TLVPPAGE
Lloh25:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB11_11
; %bb.7:
	mov	w9, #0                          ; =0x0
	mov	x10, x8
LBB11_8:                                ; =>This Inner Loop Header: Depth=1
	cmp	x10, x19
	b.eq	LBB11_14
; %bb.9:                                ;   in Loop: Header=BB11_8 Depth=1
	ldr	x11, [x10]
	cmp	x11, x23
	cinc	w9, w9, eq
	ldr	x10, [x10, #32]
	cbnz	x10, LBB11_8
; %bb.10:
	cmp	w9, #1023
	cset	w9, hi
	ldr	x10, [x19]
	cbnz	x10, LBB11_14
	b	LBB11_12
LBB11_11:
	mov	w9, #0                          ; =0x0
	ldr	x10, [x19]
	cbnz	x10, LBB11_14
LBB11_12:
	ldr	x10, [x19, #8]
	cbnz	x10, LBB11_14
; %bb.13:
	ldr	x10, [x19, #16]
	cbz	x10, LBB11_16
LBB11_14:
	mov	w0, #3                          ; =0x3
LBB11_15:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB11_16:
	mov	x10, x0
	ldr	x11, [x19, #24]
	mov	w0, #3                          ; =0x3
	cbnz	x11, LBB11_15
; %bb.17:
	ldr	x11, [x19, #32]
	cmp	x11, #0
	cset	w11, ne
	orr	w9, w11, w9
	mov	w11, #5                         ; =0x5
	csel	w0, w0, w11, ne
	tbnz	w9, #0, LBB11_15
; %bb.18:
	mov	w0, #0                          ; =0x0
	stp	x23, x22, [x19]
	stp	x21, x20, [x19, #16]
	str	x8, [x19, #32]
	str	x19, [x10]
	b	LBB11_15
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh24, Lloh25
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_resource_release_v1  ; -- Begin function neoclr_gc_resource_release_v1
	.p2align	2
_neoclr_gc_resource_release_v1:         ; @neoclr_gc_resource_release_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh26:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh27:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x19, x0
	ldr	w11, [x0, #88]
Lloh28:
	adrp	x0, _resource_head@TLVPPAGE
Lloh29:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	w9, #3                          ; =0x3
	cbz	x1, LBB12_8
; %bb.1:
	cbz	x8, LBB12_8
; %bb.2:
	ldr	x10, [x0]
	cmp	w11, #0
	ccmp	x10, #0, #4, eq
	b.ne	LBB12_4
	b	LBB12_8
LBB12_3:                                ;   in Loop: Header=BB12_4 Depth=1
	ldr	x9, [x10, #32]!
	mov	x0, x10
	mov	x10, x9
	cbz	x9, LBB12_7
LBB12_4:                                ; =>This Inner Loop Header: Depth=1
	cmp	x10, x1
	b.ne	LBB12_3
; %bb.5:                                ;   in Loop: Header=BB12_4 Depth=1
	ldr	x9, [x10]
	cmp	x9, x8
	b.ne	LBB12_3
; %bb.6:
	ldp	x8, x9, [x10, #16]
	ldr	x11, [x10, #32]
	str	x11, [x0]
	str	xzr, [x10, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x10]
	mov	w10, #1                         ; =0x1
	str	w10, [x19, #88]
	mov	x0, x8
	blr	x9
	mov	w9, #0                          ; =0x0
	str	wzr, [x19, #88]
	b	LBB12_8
LBB12_7:
	mov	w9, #3                          ; =0x3
LBB12_8:
	mov	x0, x9
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_host_root_create_v1  ; -- Begin function neoclr_gc_host_root_create_v1
	.p2align	2
_neoclr_gc_host_root_create_v1:         ; @neoclr_gc_host_root_create_v1
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB13_15
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	cbz	x2, LBB13_14
; %bb.2:
	mov	x20, x1
	mov	x21, x8
	add	x0, x8, #1048
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB13_7
; %bb.3:
Lloh30:
	adrp	x0, _host_roots@TLVPPAGE
Lloh31:
	ldr	x0, [x0, _host_roots@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w8, #256                        ; =0x100
LBB13_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x0]
	cbz	x9, LBB13_8
; %bb.5:                                ;   in Loop: Header=BB13_4 Depth=1
	add	x0, x0, #56
	subs	x8, x8, #1
	b.ne	LBB13_4
LBB13_6:
	mov	w0, #5                          ; =0x5
	b	LBB13_14
LBB13_7:
	mov	w0, #3                          ; =0x3
	b	LBB13_14
LBB13_8:
Lloh32:
	adrp	x8, _next_host_handle@PAGE
Lloh33:
	ldr	x10, [x8, _next_host_handle@PAGEOFF]
Lloh34:
	adrp	x8, _next_host_handle@PAGE
Lloh35:
	add	x8, x8, _next_host_handle@PAGEOFF
LBB13_9:                                ; =>This Inner Loop Header: Depth=1
	cmn	x10, #1
	b.eq	LBB13_6
; %bb.10:                               ;   in Loop: Header=BB13_9 Depth=1
	mov	x9, x10
	add	x11, x10, #1
	cas	x10, x11, [x8]
	cmp	x10, x9
	b.ne	LBB13_9
; %bb.11:
Lloh36:
	adrp	x8, _host_head@TLVPPAGE
Lloh37:
	ldr	x8, [x8, _host_head@TLVPPAGEOFF]
	ldr	x11, [x8]
	mov	x10, x0
	mov	x0, x8
	blr	x11
	mov	x8, x0
	ldr	x11, [x0]
	stp	x21, x20, [x10]
	stp	xzr, xzr, [x10, #16]
	stp	x9, xzr, [x10, #32]
	str	x11, [x10, #48]
	cbz	x11, LBB13_13
; %bb.12:
	str	x10, [x11, #40]
LBB13_13:
	mov	w0, #0                          ; =0x0
	str	x10, [x8]
	str	x9, [x19]
LBB13_14:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB13_15:
	ret
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpLdr	Lloh36, Lloh37
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_gc_host_root_create_owned_v1
lCPI14_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_gc_host_root_create_owned_v1
	.p2align	2
_neoclr_gc_host_root_create_owned_v1:   ; @neoclr_gc_host_root_create_owned_v1
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x1, LBB14_16
; %bb.1:
	cbz	x8, LBB14_16
; %bb.2:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x3
	cbz	x3, LBB14_15
; %bb.3:
	mov	x21, x2
	mov	x20, x1
	mov	x22, x8
	add	x0, x8, #1048
	mov	x1, x2
	mov	x2, x20
	bl	_validated_bases
	cbz	w0, LBB14_8
; %bb.4:
Lloh38:
	adrp	x0, _host_roots@TLVPPAGE
Lloh39:
	ldr	x0, [x0, _host_roots@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w8, #256                        ; =0x100
LBB14_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x0]
	cbz	x9, LBB14_9
; %bb.6:                                ;   in Loop: Header=BB14_5 Depth=1
	add	x0, x0, #56
	subs	x8, x8, #1
	b.ne	LBB14_5
LBB14_7:
	mov	w0, #5                          ; =0x5
	b	LBB14_15
LBB14_8:
	mov	w0, #3                          ; =0x3
	b	LBB14_15
LBB14_9:
Lloh40:
	adrp	x8, _next_host_handle@PAGE
Lloh41:
	ldr	x10, [x8, _next_host_handle@PAGEOFF]
Lloh42:
	adrp	x8, _next_host_handle@PAGE
Lloh43:
	add	x8, x8, _next_host_handle@PAGEOFF
LBB14_10:                               ; =>This Inner Loop Header: Depth=1
	cmn	x10, #1
	b.eq	LBB14_7
; %bb.11:                               ;   in Loop: Header=BB14_10 Depth=1
	mov	x9, x10
	add	x11, x10, #1
	cas	x10, x11, [x8]
	cmp	x10, x9
	b.ne	LBB14_10
; %bb.12:
Lloh44:
	adrp	x8, _host_head@TLVPPAGE
Lloh45:
	ldr	x8, [x8, _host_head@TLVPPAGEOFF]
	ldr	x11, [x8]
	mov	x10, x0
	mov	x0, x8
	blr	x11
	mov	x8, x0
	ldr	x11, [x0]
	stp	x22, x21, [x10]
	str	x20, [x10, #16]
Lloh46:
	adrp	x12, lCPI14_0@PAGE
Lloh47:
	ldr	d0, [x12, lCPI14_0@PAGEOFF]
	str	d0, [x10, #24]
	stp	x9, xzr, [x10, #32]
	str	x11, [x10, #48]
	cbz	x11, LBB14_14
; %bb.13:
	str	x10, [x11, #40]
LBB14_14:
	mov	w0, #0                          ; =0x0
	str	x10, [x8]
	str	x9, [x19]
LBB14_15:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB14_16:
	ret
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdrp	Lloh40, Lloh42
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpLdr	Lloh44, Lloh45
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_host_root_replace_v1 ; -- Begin function neoclr_gc_host_root_replace_v1
	.p2align	2
_neoclr_gc_host_root_replace_v1:        ; @neoclr_gc_host_root_replace_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh48:
	adrp	x0, _host_head@TLVPPAGE
Lloh49:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB15_8
; %bb.1:
	cbz	x1, LBB15_8
; %bb.2:
	ldr	x19, [x9]
	cbnz	x19, LBB15_4
	b	LBB15_8
LBB15_3:                                ;   in Loop: Header=BB15_4 Depth=1
	ldr	x19, [x19, #48]
	cbz	x19, LBB15_7
LBB15_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	cmp	x9, x8
	b.ne	LBB15_3
; %bb.5:                                ;   in Loop: Header=BB15_4 Depth=1
	ldr	x9, [x19, #32]
	cmp	x9, x1
	b.ne	LBB15_3
; %bb.6:
	ldr	w9, [x19, #28]
	cbz	w9, LBB15_9
LBB15_7:
	mov	w0, #3                          ; =0x3
LBB15_8:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB15_9:
	add	x0, x8, #1048
	mov	x20, x2
	mov	x1, x2
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB15_7
; %bb.10:
	mov	w0, #0                          ; =0x0
	str	x20, [x19, #8]
	b	LBB15_8
	.loh AdrpLdr	Lloh48, Lloh49
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_host_root_read_v1    ; -- Begin function neoclr_gc_host_root_read_v1
	.p2align	2
_neoclr_gc_host_root_read_v1:           ; @neoclr_gc_host_root_read_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh50:
	adrp	x0, _host_head@TLVPPAGE
Lloh51:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB16_3
; %bb.1:
	cbz	x1, LBB16_3
; %bb.2:
	ldr	x9, [x9]
	cbnz	x9, LBB16_5
LBB16_3:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB16_4:                                ;   in Loop: Header=BB16_5 Depth=1
	ldr	x9, [x9, #48]
	cbz	x9, LBB16_10
LBB16_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9]
	cmp	x10, x8
	b.ne	LBB16_4
; %bb.6:                                ;   in Loop: Header=BB16_5 Depth=1
	ldr	x10, [x9, #32]
	cmp	x10, x1
	b.ne	LBB16_4
; %bb.7:
	mov	w0, #3                          ; =0x3
	cbz	x2, LBB16_3
; %bb.8:
	ldr	w8, [x9, #28]
	cbnz	w8, LBB16_3
; %bb.9:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x9, #8]
	str	x8, [x2]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB16_10:
	mov	w0, #3                          ; =0x3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh50, Lloh51
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_host_root_release_v1 ; -- Begin function neoclr_gc_host_root_release_v1
	.p2align	2
_neoclr_gc_host_root_release_v1:        ; @neoclr_gc_host_root_release_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh52:
	adrp	x0, _host_head@TLVPPAGE
Lloh53:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	w9, #3                          ; =0x3
	cbz	x8, LBB17_10
; %bb.1:
	cbz	x1, LBB17_10
; %bb.2:
	ldr	x10, [x0]
	cbnz	x10, LBB17_4
	b	LBB17_10
LBB17_3:                                ;   in Loop: Header=BB17_4 Depth=1
	ldr	x10, [x10, #48]
	cbz	x10, LBB17_9
LBB17_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x10]
	cmp	x9, x8
	b.ne	LBB17_3
; %bb.5:                                ;   in Loop: Header=BB17_4 Depth=1
	ldr	x9, [x10, #32]
	cmp	x9, x1
	b.ne	LBB17_3
; %bb.6:
	ldp	x8, x9, [x10, #40]
	add	x11, x8, #48
	cmp	x8, #0
	csel	x11, x0, x11, eq
	str	x9, [x11]
	cbz	x9, LBB17_8
; %bb.7:
	str	x8, [x9, #40]
LBB17_8:
	mov	w9, #0                          ; =0x0
	str	xzr, [x10, #48]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x10, #16]
	str	q0, [x10]
	b	LBB17_10
LBB17_9:
	mov	w9, #3                          ; =0x3
LBB17_10:
	mov	x0, x9
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh52, Lloh53
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_callback_read_v1     ; -- Begin function neoclr_gc_callback_read_v1
	.p2align	2
_neoclr_gc_callback_read_v1:            ; @neoclr_gc_callback_read_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x21, x1
	mov	x20, x0
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB18_3
LBB18_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x20
	b.eq	LBB18_18
; %bb.2:                                ;   in Loop: Header=BB18_1 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB18_1
LBB18_3:
Lloh54:
	adrp	x0, _host_head@TLVPPAGE
Lloh55:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x20, LBB18_19
; %bb.4:
	cbz	x21, LBB18_19
; %bb.5:
	ldr	x22, [x8]
	cbnz	x22, LBB18_7
	b	LBB18_19
LBB18_6:                                ;   in Loop: Header=BB18_7 Depth=1
	ldr	x22, [x22, #48]
	cbz	x22, LBB18_18
LBB18_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x22]
	cmp	x8, x20
	b.ne	LBB18_6
; %bb.8:                                ;   in Loop: Header=BB18_7 Depth=1
	ldr	x8, [x22, #32]
	cmp	x8, x21
	b.ne	LBB18_6
; %bb.9:
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB18_19
; %bb.10:
	ldr	w8, [x22, #24]
	cbnz	w8, LBB18_19
; %bb.11:
	ldr	x1, [x22, #8]
	cbz	x1, LBB18_19
; %bb.12:
	ldr	w8, [x20]
	cbnz	w8, LBB18_19
; %bb.13:
	add	x0, x20, #1048
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB18_18
; %bb.14:
	ldr	x8, [x22, #8]
	ldur	x9, [x8, #-16]
	cmp	x9, #2
	b.ne	LBB18_18
; %bb.15:
	ldur	x9, [x8, #-24]
	cmp	x9, #24
	b.ne	LBB18_18
; %bb.16:
	ldr	x9, [x8]
	mov	w10, #-1                        ; =0xffffffff
	cmp	x9, x10
	b.ne	LBB18_18
; %bb.17:
	mov	w0, #0                          ; =0x0
	str	x8, [x19]
	b	LBB18_19
LBB18_18:
	mov	w0, #3                          ; =0x3
LBB18_19:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh54, Lloh55
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_callback_read_suspended_v1 ; -- Begin function neoclr_gc_callback_read_suspended_v1
	.p2align	2
_neoclr_gc_callback_read_suspended_v1:  ; @neoclr_gc_callback_read_suspended_v1
	.cfi_startproc
; %bb.0:
	cbz	x3, LBB19_5
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x3
	mov	x19, x0
	mov	x22, x1
	mov	x21, x2
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x20
	b.ne	LBB19_3
; %bb.2:
	ldr	x8, [x20, #8]
	cmp	x8, x19
	b.eq	LBB19_6
LBB19_3:
	mov	w0, #3                          ; =0x3
LBB19_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB19_5:
	mov	w0, #3                          ; =0x3
	ret
LBB19_6:
Lloh56:
	adrp	x0, _host_head@TLVPPAGE
Lloh57:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB19_4
; %bb.7:
	cbz	x22, LBB19_4
; %bb.8:
	ldr	x20, [x8]
	cbz	x20, LBB19_4
; %bb.9:
	mov	x9, x22
	mov	x8, x21
	b	LBB19_11
LBB19_10:                               ;   in Loop: Header=BB19_11 Depth=1
	ldr	x20, [x20, #48]
	cbz	x20, LBB19_3
LBB19_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x20]
	cmp	x10, x19
	b.ne	LBB19_10
; %bb.12:                               ;   in Loop: Header=BB19_11 Depth=1
	ldr	x10, [x20, #32]
	cmp	x10, x9
	b.ne	LBB19_10
; %bb.13:
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB19_4
; %bb.14:
	ldr	w8, [x20, #24]
	cbnz	w8, LBB19_4
; %bb.15:
	ldr	x1, [x20, #8]
	cbz	x1, LBB19_4
; %bb.16:
	ldr	w8, [x19]
	cbnz	w8, LBB19_4
; %bb.17:
	add	x0, x19, #1048
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB19_3
; %bb.18:
	ldr	x8, [x20, #8]
	ldur	x9, [x8, #-16]
	cmp	x9, #2
	b.ne	LBB19_3
; %bb.19:
	ldur	x9, [x8, #-24]
	cmp	x9, #24
	b.ne	LBB19_3
; %bb.20:
	ldr	x9, [x8]
	mov	w10, #-1                        ; =0xffffffff
	cmp	x9, x10
	b.ne	LBB19_3
; %bb.21:
	mov	w0, #0                          ; =0x0
	str	x8, [x21]
	b	LBB19_4
	.loh AdrpLdr	Lloh56, Lloh57
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_roots_park_owned_v1  ; -- Begin function neoclr_gc_roots_park_owned_v1
	.p2align	2
_neoclr_gc_roots_park_owned_v1:         ; @neoclr_gc_roots_park_owned_v1
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB20_11
; %bb.1:
	cbz	x1, LBB20_11
; %bb.2:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	cbz	x2, LBB20_10
; %bb.3:
	mov	x21, x8
	add	x0, x8, #1048
	mov	x20, x1
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB20_9
; %bb.4:
	ldr	x8, [x19]
	cbnz	x8, LBB20_9
; %bb.5:
	ldr	x8, [x19, #8]
	cbnz	x8, LBB20_9
; %bb.6:
	ldr	x8, [x19, #16]
	cbnz	x8, LBB20_9
; %bb.7:
	ldr	x8, [x19, #24]
	cbnz	x8, LBB20_9
; %bb.8:
	ldr	w8, [x19, #32]
	cbz	w8, LBB20_12
LBB20_9:
	mov	w0, #3                          ; =0x3
LBB20_10:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB20_11:
	ret
LBB20_12:
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB20_15
LBB20_13:                               ; =>This Inner Loop Header: Depth=1
	cmp	x0, x19
	b.eq	LBB20_9
; %bb.14:                               ;   in Loop: Header=BB20_13 Depth=1
	ldr	x0, [x0, #8]
	cbnz	x0, LBB20_13
LBB20_15:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB20_18
LBB20_16:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x21
	b.ne	LBB20_9
; %bb.17:                               ;   in Loop: Header=BB20_16 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB20_16
LBB20_18:
	mov	x0, x19
	bl	_neoclr_roots_park_v1
	mov	w0, #0                          ; =0x0
	stp	x21, x20, [x19, #16]
	b	LBB20_10
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_complete_invocation_v1 ; -- Begin function neoclr_gc_complete_invocation_v1
	.p2align	2
_neoclr_gc_complete_invocation_v1:      ; @neoclr_gc_complete_invocation_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB21_11
; %bb.1:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	add	x20, x0, #1048
	mov	x0, x20
	bl	_blocks_valid
	cbz	w0, LBB21_12
; %bb.2:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB21_5
LBB21_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x19
	b.eq	LBB21_12
; %bb.4:                                ;   in Loop: Header=BB21_3 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB21_3
LBB21_5:
	ldr	x8, [x19, #1064]
	cbz	x8, LBB21_13
; %bb.6:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x20]
	mov	w11, #3                         ; =0x3
	b	LBB21_8
LBB21_7:                                ;   in Loop: Header=BB21_8 Depth=1
	ldr	x12, [x12]
	add	x9, x12, x9
	cmp	x9, x8
	b.hs	LBB21_13
LBB21_8:                                ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9
	ldrb	w13, [x12, #24]
	tbz	w13, #0, LBB21_7
; %bb.9:                                ;   in Loop: Header=BB21_8 Depth=1
	ldr	x13, [x12, #16]
	cmp	x13, #6
	b.ne	LBB21_7
; %bb.10:                               ;   in Loop: Header=BB21_8 Depth=1
	str	x11, [x12, #16]
	b	LBB21_7
LBB21_11:
	mov	w0, #3                          ; =0x3
	ret
LBB21_12:
	mov	w0, #3                          ; =0x3
	b	LBB21_14
LBB21_13:
	mov	w0, #0                          ; =0x0
	str	xzr, [x19, #1072]
LBB21_14:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_entry_check_v1       ; -- Begin function neoclr_gc_entry_check_v1
	.p2align	2
_neoclr_gc_entry_check_v1:              ; @neoclr_gc_entry_check_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh58:
	adrp	x0, _resource_head@TLVPPAGE
Lloh59:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB22_3
LBB22_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x19
	b.eq	LBB22_16
; %bb.2:                                ;   in Loop: Header=BB22_1 Depth=1
	ldr	x8, [x8, #32]
	cbnz	x8, LBB22_1
LBB22_3:
	cbz	x19, LBB22_16
; %bb.4:
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB22_10
LBB22_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB22_7 Depth 2
	ldr	x8, [x0, #16]
	cmp	x8, x19
	b.eq	LBB22_16
; %bb.6:                                ;   in Loop: Header=BB22_5 Depth=1
	mov	x8, x0
LBB22_7:                                ;   Parent Loop BB22_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x8]
	cbz	x8, LBB22_9
; %bb.8:                                ;   in Loop: Header=BB22_7 Depth=2
	ldr	x9, [x8, #8]
	cmp	x9, x19
	b.ne	LBB22_7
	b	LBB22_16
LBB22_9:                                ;   in Loop: Header=BB22_5 Depth=1
	ldr	x0, [x0, #8]
	cbnz	x0, LBB22_5
LBB22_10:
Lloh60:
	adrp	x0, _host_head@TLVPPAGE
Lloh61:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB22_13
LBB22_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x19
	b.eq	LBB22_16
; %bb.12:                               ;   in Loop: Header=BB22_11 Depth=1
	ldr	x8, [x8, #48]
	cbnz	x8, LBB22_11
LBB22_13:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB22_17
LBB22_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x19
	b.eq	LBB22_16
; %bb.15:                               ;   in Loop: Header=BB22_14 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB22_14
	b	LBB22_17
LBB22_16:
	mov	w0, #3                          ; =0x3
LBB22_17:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh60, Lloh61
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_owned_roots_check_v1 ; -- Begin function neoclr_gc_owned_roots_check_v1
	.p2align	2
_neoclr_gc_owned_roots_check_v1:        ; @neoclr_gc_owned_roots_check_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh62:
	adrp	x0, _resource_head@TLVPPAGE
Lloh63:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB23_3
LBB23_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x19
	b.eq	LBB23_32
; %bb.2:                                ;   in Loop: Header=BB23_1 Depth=1
	ldr	x8, [x8, #32]
	cbnz	x8, LBB23_1
LBB23_3:
	mov	w8, #3                          ; =0x3
	cbz	x19, LBB23_33
; %bb.4:
	cmp	w2, #256
	b.hi	LBB23_33
; %bb.5:
	cbnz	x1, LBB23_7
; %bb.6:
	cbnz	w2, LBB23_33
LBB23_7:
	mov	x20, x1
	mov	x21, x2
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB23_13
LBB23_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB23_10 Depth 2
	ldr	x8, [x0, #16]
	cmp	x8, x19
	b.eq	LBB23_32
; %bb.9:                                ;   in Loop: Header=BB23_8 Depth=1
	mov	x8, x0
LBB23_10:                               ;   Parent Loop BB23_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x8]
	cbz	x8, LBB23_12
; %bb.11:                               ;   in Loop: Header=BB23_10 Depth=2
	ldr	x9, [x8, #8]
	cmp	x9, x19
	b.ne	LBB23_10
	b	LBB23_32
LBB23_12:                               ;   in Loop: Header=BB23_8 Depth=1
	ldr	x0, [x0, #8]
	cbnz	x0, LBB23_8
LBB23_13:
	bl	_neoclr_root_probe_head_v1
	mov	x9, x21
	mov	x10, x20
	cbz	x0, LBB23_16
LBB23_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x19
	b.eq	LBB23_32
; %bb.15:                               ;   in Loop: Header=BB23_14 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB23_14
LBB23_16:
Lloh64:
	adrp	x0, _host_head@TLVPPAGE
Lloh65:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	cbz	w9, LBB23_29
; %bb.17:
	ldr	x11, [x0]
	cbz	x11, LBB23_32
; %bb.18:
	mov	x12, #0                         ; =0x0
	mov	w13, w9
LBB23_19:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB23_22 Depth 2
                                        ;     Child Loop BB23_26 Depth 2
	ldr	x14, [x10, x12, lsl #3]
	cbz	x14, LBB23_32
; %bb.20:                               ;   in Loop: Header=BB23_19 Depth=1
	mov	x15, x11
	b	LBB23_22
LBB23_21:                               ;   in Loop: Header=BB23_22 Depth=2
	ldr	x15, [x15, #48]
	mov	w8, #3                          ; =0x3
	cbz	x15, LBB23_33
LBB23_22:                               ;   Parent Loop BB23_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x15]
	cmp	x8, x19
	b.ne	LBB23_21
; %bb.23:                               ;   in Loop: Header=BB23_22 Depth=2
	ldr	x8, [x15, #32]
	cmp	x8, x14
	b.ne	LBB23_21
; %bb.24:                               ;   in Loop: Header=BB23_19 Depth=1
	cbz	x12, LBB23_28
; %bb.25:                               ;   in Loop: Header=BB23_19 Depth=1
	mov	x8, #0                          ; =0x0
LBB23_26:                               ;   Parent Loop BB23_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x15, [x10, x8, lsl #3]
	cmp	x15, x14
	b.eq	LBB23_32
; %bb.27:                               ;   in Loop: Header=BB23_26 Depth=2
	add	x8, x8, #1
	cmp	x12, x8
	b.ne	LBB23_26
LBB23_28:                               ;   in Loop: Header=BB23_19 Depth=1
	add	x12, x12, #1
	cmp	x12, x13
	b.ne	LBB23_19
LBB23_29:
	ldr	x8, [x0]
	cbz	x8, LBB23_34
; %bb.30:
	mov	w10, #0                         ; =0x0
LBB23_31:                               ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x8]
	cmp	x11, x19
	cinc	w10, w10, eq
	ldr	x8, [x8, #48]
	cbnz	x8, LBB23_31
	b	LBB23_35
LBB23_32:
	mov	w8, #3                          ; =0x3
LBB23_33:
	mov	x0, x8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB23_34:
	mov	w10, #0                         ; =0x0
LBB23_35:
	mov	w8, #3                          ; =0x3
	cmp	w10, w9
	csel	w8, wzr, w8, eq
	b	LBB23_33
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpLdr	Lloh64, Lloh65
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_allocate_v1          ; -- Begin function neoclr_gc_allocate_v1
	.p2align	2
_neoclr_gc_allocate_v1:                 ; @neoclr_gc_allocate_v1
	.cfi_startproc
; %bb.0:
	mov	w8, #3                          ; =0x3
	cbz	x0, LBB24_19
; %bb.1:
	cbz	x3, LBB24_19
; %bb.2:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
Lloh66:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh67:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x21, [x0]
	cmp	x21, x19
	b.eq	LBB24_14
; %bb.3:
	ldp	x9, x10, [x19, #8]
LBB24_4:
	mov	w8, #3                          ; =0x3
	subs	x13, x9, x10
	b.lo	LBB24_18
; %bb.5:
	and	x11, x10, #0x7
	cbnz	x11, LBB24_18
; %bb.6:
	ldr	x11, [x19]
	cbz	x9, LBB24_8
; %bb.7:
	cbz	x11, LBB24_18
LBB24_8:
	sub	w9, w2, #7
	cmn	w9, #6
	b.lo	LBB24_18
; %bb.9:
	cbz	x1, LBB24_18
; %bb.10:
	and	x9, x11, #0x7
	cbnz	x9, LBB24_18
; %bb.11:
	add	x8, x1, #7
	and	x8, x8, #0xfffffffffffffff8
	add	x9, x8, #32
	cmn	x1, #40
	csinv	x15, x9, xzr, ls
	add	x14, x0, #32
	cmp	x21, x19
	b.eq	LBB24_30
; %bb.12:
	mov	x12, #0                         ; =0x0
	cbz	x10, LBB24_44
; %bb.13:
	mov	x16, #0                         ; =0x0
	b	LBB24_22
LBB24_14:
	ldr	x8, [x19]
	ldr	x9, [x0, #8]
	cmp	x8, x9
	b.ne	LBB24_17
; %bb.15:
	ldr	x9, [x19, #8]
	ldr	x8, [x0, #16]
	cmp	x9, x8
	b.ne	LBB24_17
; %bb.16:
	ldr	x10, [x19, #16]
	ldr	x8, [x0, #24]
	cmp	x10, x8
	b.eq	LBB24_4
LBB24_17:
	mov	w8, #3                          ; =0x3
LBB24_18:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
LBB24_19:
	mov	x0, x8
	ret
LBB24_20:                               ;   in Loop: Header=BB24_22 Depth=1
	cmp	x17, x15
	csel	x8, xzr, x4, lo
	cmp	x12, #0
	csel	x12, x12, x8, ne
LBB24_21:                               ;   in Loop: Header=BB24_22 Depth=1
	add	x16, x17, x16
	cmp	x16, x10
	b.hs	LBB24_44
LBB24_22:                               ; =>This Inner Loop Header: Depth=1
	sub	x5, x10, x16
	cmp	x5, #32
	b.lo	LBB24_17
; %bb.23:                               ;   in Loop: Header=BB24_22 Depth=1
	add	x4, x11, x16
	ldr	x17, [x4]
	mov	w8, #3                          ; =0x3
	cmp	x17, x5
	b.hi	LBB24_18
; %bb.24:                               ;   in Loop: Header=BB24_22 Depth=1
	and	x5, x17, #0x7
	cmp	x17, #40
	ccmp	x5, #0, #0, hs
	b.ne	LBB24_18
; %bb.25:                               ;   in Loop: Header=BB24_22 Depth=1
	ldr	x8, [x4, #24]
	cmp	x8, #7
	b.hi	LBB24_17
; %bb.26:                               ;   in Loop: Header=BB24_22 Depth=1
	cbz	x8, LBB24_20
; %bb.27:                               ;   in Loop: Header=BB24_22 Depth=1
	tbz	w8, #0, LBB24_17
; %bb.28:                               ;   in Loop: Header=BB24_22 Depth=1
	ldr	x8, [x4, #8]
	sub	x5, x17, #32
	sub	x8, x8, #1
	cmp	x8, x5
	b.hs	LBB24_17
; %bb.29:                               ;   in Loop: Header=BB24_22 Depth=1
	ldr	x8, [x4, #16]
	sub	x8, x8, #7
	cmn	x8, #6
	b.hs	LBB24_21
	b	LBB24_17
LBB24_30:
	ldr	x16, [x14]
	cbz	x16, LBB24_43
LBB24_31:                               ; =>This Inner Loop Header: Depth=1
	sub	x5, x16, #1
	and	x8, x5, #0x7
	cmp	x8, #0
	ccmp	x10, x5, #0, eq
	b.ls	LBB24_17
; %bb.32:                               ;   in Loop: Header=BB24_31 Depth=1
	sub	x16, x10, x5
	cmp	x16, #32
	b.lo	LBB24_17
; %bb.33:                               ;   in Loop: Header=BB24_31 Depth=1
	add	x12, x11, x5
	ldr	x17, [x12]
	mov	w8, #3                          ; =0x3
	cmp	x17, x16
	b.hi	LBB24_18
; %bb.34:                               ;   in Loop: Header=BB24_31 Depth=1
	and	x16, x17, #0x7
	cmp	x17, #40
	ccmp	x16, #0, #0, hs
	b.ne	LBB24_18
; %bb.35:                               ;   in Loop: Header=BB24_31 Depth=1
	ldr	x8, [x12, #24]
	cbnz	x8, LBB24_17
; %bb.36:                               ;   in Loop: Header=BB24_31 Depth=1
	mov	x4, x12
	ldr	x16, [x4, #8]!
	cbz	x16, LBB24_40
; %bb.37:                               ;   in Loop: Header=BB24_31 Depth=1
	sub	x6, x16, #1
	add	x8, x17, x5
	cmp	x6, x8
	b.lo	LBB24_17
; %bb.38:                               ;   in Loop: Header=BB24_31 Depth=1
	mov	w8, #3                          ; =0x3
	cmp	x6, x10
	b.hs	LBB24_18
; %bb.39:                               ;   in Loop: Header=BB24_31 Depth=1
	and	x5, x6, #0x7
	cbnz	x5, LBB24_18
LBB24_40:                               ;   in Loop: Header=BB24_31 Depth=1
	cmp	x17, x15
	b.hs	LBB24_44
; %bb.41:                               ;   in Loop: Header=BB24_31 Depth=1
	mov	x14, x4
	cbnz	x16, LBB24_31
; %bb.42:
	mov	x12, #0                         ; =0x0
	mov	x14, x4
	b	LBB24_44
LBB24_43:
	mov	x12, #0                         ; =0x0
LBB24_44:
	cmn	x1, #40
	b.ls	LBB24_46
LBB24_45:
	mov	w8, #5                          ; =0x5
	b	LBB24_18
LBB24_46:
	cbz	x12, LBB24_50
; %bb.47:
	cmp	x21, x19
	b.eq	LBB24_52
; %bb.48:
	mov	x22, x3
	ldr	x8, [x12]
	sub	x10, x8, x9
	cmp	x10, #40
	b.lo	LBB24_56
; %bb.49:
	add	x8, x12, x9
	stp	x10, xzr, [x8]
	stp	xzr, xzr, [x8, #16]
	str	x9, [x12]
	b	LBB24_57
LBB24_50:
	cmp	x9, x13
	b.hi	LBB24_45
; %bb.51:
	mov	x22, x3
	add	x12, x11, x10
	str	x9, [x12]
	add	x8, x10, x9
	str	x8, [x19, #16]
	cmp	x21, x19
	b.ne	LBB24_57
	b	LBB24_55
LBB24_52:
	ldp	x10, x8, [x12]
	sub	x10, x10, x9
	mov	x22, x3
	cmp	x10, #39
	b.ls	LBB24_54
; %bb.53:
	add	x13, x12, x9
	sub	x11, x13, x11
	stp	x10, x8, [x13]
	stp	xzr, xzr, [x13, #16]
	add	x8, x11, #1
	str	x9, [x12]
LBB24_54:
	str	x8, [x14]
LBB24_55:
	ldr	x8, [x19, #16]
	str	x8, [x0, #24]
	ldr	x9, [x12]
	b	LBB24_57
LBB24_56:
	mov	x9, x8
LBB24_57:
	mov	x24, x0
	mov	w8, w2
	mov	x23, x1
	stp	x1, x8, [x12, #8]
	mov	w8, #1                          ; =0x1
	str	x8, [x12, #24]
	add	x20, x12, #32
	sub	x1, x9, #32
	mov	x0, x20
	bl	_bzero
	cmp	x21, x19
	b.ne	LBB24_59
; %bb.58:
	ubfx	x8, x20, #3, #29
	eor	w8, w8, w20, lsr #9
	add	x8, x24, w8, uxtb #3
	str	x20, [x8, #40]
LBB24_59:
	str	x20, [x22]
Lloh68:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh69:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0, #32]
	add	x8, x8, #1
	str	x8, [x0, #32]
Lloh70:
	adrp	x0, _profile@TLVPPAGE
Lloh71:
	ldr	x0, [x0, _profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldp	x8, x10, [x0, #32]
	add	x8, x8, x23
	str	x8, [x0, #32]
	ldr	x9, [x19, #16]
	cmp	x9, x10
	b.ls	LBB24_61
; %bb.60:
	mov	w8, #0                          ; =0x0
	str	x9, [x0, #40]
	b	LBB24_18
LBB24_61:
	mov	w8, #0                          ; =0x0
	b	LBB24_18
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpLdr	Lloh68, Lloh69
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_gc_allocate_rooted_values_v1
lCPI25_0:
	.long	8                               ; 0x8
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_gc_allocate_rooted_values_v1
	.p2align	2
_neoclr_gc_allocate_rooted_values_v1:   ; @neoclr_gc_allocate_rooted_values_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #464
	stp	x28, x27, [sp, #368]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #384]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #400]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #416]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #432]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #448]            ; 16-byte Folded Spill
	add	x29, sp, #448
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh72:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh73:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh74:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	cmp	w3, #16
	b.hi	LBB25_5
; %bb.1:
	mov	x19, x0
	cmp	x2, #0
	ccmp	w3, #0, #4, eq
	cset	w9, ne
Lloh75:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh76:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB25_6
; %bb.2:
	tbnz	w9, #0, LBB25_6
; %bb.3:
	ldr	w8, [x8, #88]
	cbnz	w8, LBB25_6
; %bb.4:
	mov	x25, x2
	mov	x24, x3
	mov	x22, x4
	mov	x21, x5
	mov	x20, x6
	mov	x26, x1
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x26
	b.eq	LBB25_8
LBB25_5:
	mov	w0, #3                          ; =0x3
LBB25_6:
	ldur	x8, [x29, #-88]
Lloh77:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh78:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh79:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB25_25
; %bb.7:
	ldp	x29, x30, [sp, #448]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #432]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #416]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #400]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #384]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #368]            ; 16-byte Folded Reload
	add	sp, sp, #464
	ret
LBB25_8:
	mov	x8, x26
	cbz	x26, LBB25_10
; %bb.9:
	ldr	x8, [x8, #8]
	cmp	x8, x19
	b.ne	LBB25_5
LBB25_10:
	add	x0, x19, #1048
	mov	x23, x22
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	bl	_neoclr_gc_allocate_v1
	cmp	w0, #5
	b.ne	LBB25_6
; %bb.11:
	cmn	x23, #40
	b.hi	LBB25_13
; %bb.12:
	add	x11, x23, #7
	and	x11, x11, #0xfffffffffffffff8
	add	x11, x11, #32
	ldr	x12, [x19, #1056]
	cmp	x11, x12
	b.ls	LBB25_14
LBB25_13:
	mov	w0, #5                          ; =0x5
	b	LBB25_6
LBB25_14:
	mov	x9, x26
	mov	x8, x24
	mov	x1, x26
	cbz	w24, LBB25_23
; %bb.15:
	mov	x10, x25
	mov	w11, w8
	adrp	x12, lCPI25_0@PAGE
	cmp	w8, #3
	b.hi	LBB25_17
; %bb.16:
	mov	x13, #0                         ; =0x0
	b	LBB25_20
LBB25_17:
	and	x13, x11, #0x1c
	add	x14, sp, #104
	add	x14, x14, #32
	ldr	d0, [x12, lCPI25_0@PAGEOFF]
	mov	x15, x10
	mov	x16, x13
LBB25_18:                               ; =>This Inner Loop Header: Depth=1
	add	x17, x15, #8
	stur	x15, [x14, #-32]
	add	x0, x15, #16
	add	x1, x15, #24
	stur	x17, [x14, #-16]
	str	x0, [x14]
	str	x1, [x14, #16]
	stur	d0, [x14, #-24]
	stur	d0, [x14, #-8]
	str	d0, [x14, #8]
	str	d0, [x14, #24]
	add	x14, x14, #64
	add	x15, x15, #32
	subs	x16, x16, #4
	b.ne	LBB25_18
; %bb.19:
	cmp	x13, x11
	b.eq	LBB25_22
LBB25_20:
	add	x14, sp, #104
	add	x14, x14, x13, lsl #4
	add	x14, x14, #8
	add	x10, x10, x13, lsl #3
	sub	x11, x11, x13
	ldr	d0, [x12, lCPI25_0@PAGEOFF]
LBB25_21:                               ; =>This Inner Loop Header: Depth=1
	stur	x10, [x14, #-8]
	str	d0, [x14], #16
	add	x10, x10, #8
	subs	x11, x11, #1
	b.ne	LBB25_21
LBB25_22:
	mov	x1, sp
LBB25_23:
	stp	x9, x19, [sp]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #16]
	add	x9, sp, #104
	stp	x9, xzr, [sp, #48]
	str	w8, [sp, #64]
Lloh80:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh81:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x23, x0
	stur	q0, [sp, #68]
	stur	q0, [sp, #84]
	str	wzr, [sp, #100]
	ldr	x8, [x0, #16]
	add	x8, x8, #1
	str	x8, [x0, #16]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cmp	w0, #0
	ldr	x8, [x23, #80]
	cinc	x8, x8, ne
	str	x8, [x23, #80]
	cbnz	w0, LBB25_6
; %bb.24:
	add	x0, x19, #1048
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	bl	_neoclr_gc_allocate_v1
	b	LBB25_6
LBB25_25:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh72, Lloh73, Lloh74
	.loh AdrpLdr	Lloh75, Lloh76
	.loh AdrpLdrGotLdr	Lloh77, Lloh78, Lloh79
	.loh AdrpLdr	Lloh80, Lloh81
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_allocate_rooted_v1   ; -- Begin function neoclr_gc_allocate_rooted_v1
	.p2align	2
_neoclr_gc_allocate_rooted_v1:          ; @neoclr_gc_allocate_rooted_v1
	.cfi_startproc
; %bb.0:
	mov	x6, x4
	mov	x5, x3
	mov	x4, x2
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	b	_neoclr_gc_allocate_rooted_values_v1
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_collect_v1           ; -- Begin function neoclr_gc_collect_v1
	.p2align	2
_neoclr_gc_collect_v1:                  ; @neoclr_gc_collect_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh82:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh83:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x19, x0
	ldr	x9, [x0]
	add	x9, x9, #1
	str	x9, [x0]
	mov	x0, x8
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cmp	w0, #0
	ldr	x8, [x19, #64]
	cinc	x8, x8, ne
	str	x8, [x19, #64]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh82, Lloh83
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_collect_conditional_v1 ; -- Begin function neoclr_gc_collect_conditional_v1
	.p2align	2
_neoclr_gc_collect_conditional_v1:      ; @neoclr_gc_collect_conditional_v1
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #2384
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x19, x3
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
Lloh84:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh85:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh86:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB28_55
; %bb.1:
Lloh87:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh88:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w23, #3                         ; =0x3
	cbz	x22, LBB28_43
; %bb.2:
	ldr	w8, [x0, #88]
	cbnz	w8, LBB28_43
; %bb.3:
	add	x8, x22, #1048
Lloh89:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh90:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	x9, x8
	b.eq	LBB28_13
; %bb.4:
	ldr	x10, [x22, #1064]
	ldr	x11, [x22, #1056]
LBB28_5:
	cmp	x10, x11
	b.hi	LBB28_43
; %bb.6:
	and	x12, x10, #0x7
	cbnz	x12, LBB28_43
; %bb.7:
	ldr	x12, [x8]
	cmp	x12, #0
	ccmp	x11, #0, #4, eq
	b.ne	LBB28_43
; %bb.8:
	and	x11, x12, #0x7
	cbnz	x11, LBB28_43
; %bb.9:
	cbz	x10, LBB28_39
; %bb.10:
	sub	x13, x10, #1
	mov	w11, #5                         ; =0x5
LBB28_11:                               ; =>This Inner Loop Header: Depth=1
	add	w11, w11, #1
	lsr	x14, x13, x11
	cmp	x14, #255
	b.hi	LBB28_11
; %bb.12:
	ldr	x13, [x0, #32]
	cmp	x9, x8
	csel	x1, x13, xzr, eq
Lloh91:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh92:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x13, [x0]
	blr	x13
	mov	x14, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x15, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	mov	x2, #0                          ; =0x0
	ldr	x17, [x0, #32]
	add	x3, sp, #328
	add	x4, sp, #72
	b	LBB28_18
LBB28_13:
	ldr	x10, [x8]
	ldr	x11, [x0, #8]
	cmp	x10, x11
	b.ne	LBB28_43
; %bb.14:
	ldr	x11, [x22, #1056]
	ldr	x10, [x0, #16]
	cmp	x11, x10
	b.ne	LBB28_43
; %bb.15:
	ldr	x10, [x22, #1064]
	ldr	x12, [x0, #24]
	cmp	x10, x12
	b.eq	LBB28_5
	b	LBB28_43
LBB28_16:                               ;   in Loop: Header=BB28_18 Depth=1
	mov	w2, w2
LBB28_17:                               ;   in Loop: Header=BB28_18 Depth=1
	add	x15, x15, #1
	cmp	x16, x10
	b.hs	LBB28_52
LBB28_18:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB28_35 Depth 2
	add	x17, x17, #1
	sub	x7, x10, x16
	cmp	x7, #32
	b.lo	LBB28_37
; %bb.19:                               ;   in Loop: Header=BB28_18 Depth=1
	add	x5, x12, x16
	ldr	x6, [x5]
	cmp	x6, x7
	b.hi	LBB28_37
; %bb.20:                               ;   in Loop: Header=BB28_18 Depth=1
	and	x7, x6, #0x7
	cmp	x6, #40
	ccmp	x7, #0, #0, hs
	b.ne	LBB28_37
; %bb.21:                               ;   in Loop: Header=BB28_18 Depth=1
	ldr	x7, [x5, #24]
	cmp	x7, #7
	b.hi	LBB28_37
; %bb.22:                               ;   in Loop: Header=BB28_18 Depth=1
	cbz	x7, LBB28_31
; %bb.23:                               ;   in Loop: Header=BB28_18 Depth=1
	tbz	w7, #0, LBB28_37
; %bb.24:                               ;   in Loop: Header=BB28_18 Depth=1
	ldr	x23, [x5, #8]
	sub	x24, x6, #32
	sub	x23, x23, #1
	cmp	x23, x24
	b.hs	LBB28_37
; %bb.25:                               ;   in Loop: Header=BB28_18 Depth=1
	ldr	x23, [x5, #16]
	sub	x24, x23, #7
	cmn	x24, #6
	b.lo	LBB28_37
; %bb.26:                               ;   in Loop: Header=BB28_18 Depth=1
	cmp	x7, #1
	cset	w7, ne
	orr	w13, w13, w7
	cmp	x23, #6
	b.ne	LBB28_34
; %bb.27:                               ;   in Loop: Header=BB28_18 Depth=1
	cmp	x14, #32
	b.hi	LBB28_34
; %bb.28:                               ;   in Loop: Header=BB28_18 Depth=1
	b.eq	LBB28_30
; %bb.29:                               ;   in Loop: Header=BB28_18 Depth=1
	str	x5, [x4, x14, lsl #3]
LBB28_30:                               ;   in Loop: Header=BB28_18 Depth=1
	add	x14, x14, #1
	b	LBB28_34
LBB28_31:                               ;   in Loop: Header=BB28_18 Depth=1
	cmp	x9, x8
	b.ne	LBB28_34
; %bb.32:                               ;   in Loop: Header=BB28_18 Depth=1
	orr	x7, x16, #0x1
	cmp	x1, x7
	b.ne	LBB28_37
; %bb.33:                               ;   in Loop: Header=BB28_18 Depth=1
	ldr	x1, [x5, #8]
LBB28_34:                               ;   in Loop: Header=BB28_18 Depth=1
	add	x16, x6, x16
	cmp	x2, #255
	b.hi	LBB28_17
LBB28_35:                               ;   Parent Loop BB28_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x6, x2, x11
	cmp	x6, x16
	b.hs	LBB28_16
; %bb.36:                               ;   in Loop: Header=BB28_35 Depth=2
	str	x5, [x3, x2, lsl #3]
	add	x6, x2, #1
	mov	x2, x6
	cmp	x6, #256
	b.ne	LBB28_35
	b	LBB28_17
LBB28_37:
	str	x17, [x0, #32]
LBB28_38:
	mov	w23, #3                         ; =0x3
	b	LBB28_43
LBB28_39:
	ldr	x10, [x0, #32]
	cmp	x9, x8
	ccmp	x10, #0, #4, eq
	b.ne	LBB28_43
; %bb.40:
	mov	x14, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	x15, #0                         ; =0x0
	mov	w11, #6                         ; =0x6
LBB28_41:
	add	x8, sp, #328
	add	x9, sp, #72
	stp	x8, x9, [sp, #16]
	mov	w8, #256                        ; =0x100
	stp	w8, w11, [sp, #32]
	str	w14, [sp, #40]
	stp	x15, xzr, [sp, #48]
	str	w13, [sp, #64]
	add	x4, sp, #16
	mov	x0, x22
	mov	x1, x21
	mov	x2, x20
	mov	x3, x19
	bl	_collect_indexed
LBB28_42:
	mov	x23, x0
LBB28_43:
	add	x1, sp, #328
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB28_55
; %bb.44:
	ldp	x8, x9, [sp, #328]
	ldp	x10, x11, [sp]
	sub	x8, x8, x10
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x8, x8, x10, x9
	sub	x8, x8, x11
	cmp	x8, #2
	b.lo	LBB28_47
; %bb.45:
	mov	x9, #0                          ; =0x0
	mov	x10, x8
LBB28_46:                               ; =>This Inner Loop Header: Depth=1
	lsr	x11, x10, #1
	add	x9, x9, #1
	cmp	x10, #3
	mov	x10, x11
	b.hi	LBB28_46
	b	LBB28_48
LBB28_47:
	mov	x9, #0                          ; =0x0
LBB28_48:
Lloh93:
	adrp	x0, _profile@TLVPPAGE
Lloh94:
	ldr	x0, [x0, _profile@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	add	x9, x0, x9, lsl #3
	ldr	x10, [x9, #72]
	add	x10, x10, #1
	str	x10, [x9, #72]
	cmp	w23, #0
	ldp	x10, x9, [x0, #16]
	cinc	x9, x9, ne
	str	x9, [x0, #24]
	mov	w9, #1                          ; =0x1
	dup.2d	v0, x9
	ldr	q1, [x0]
	mov.d	v0[1], x8
	add.2d	v0, v1, v0
	str	q0, [x0]
	cmp	x8, x10
	b.ls	LBB28_50
; %bb.49:
	str	x8, [x0, #16]
LBB28_50:
	ldur	x8, [x29, #-72]
Lloh95:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh96:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh97:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB28_56
; %bb.51:
	mov	x0, x23
	add	sp, sp, #2384
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB28_52:
	str	x17, [x0, #32]
	cbnz	x1, LBB28_38
; %bb.53:
	cmp	x15, #2049
	b.lo	LBB28_41
; %bb.54:
	mov	x0, x22
	mov	x1, x21
	mov	x2, x20
	mov	x3, x19
	bl	_collect_dense
	b	LBB28_42
LBB28_55:
	bl	_abort
LBB28_56:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh84, Lloh85, Lloh86
	.loh AdrpLdr	Lloh87, Lloh88
	.loh AdrpLdr	Lloh89, Lloh90
	.loh AdrpLdr	Lloh91, Lloh92
	.loh AdrpLdr	Lloh93, Lloh94
	.loh AdrpLdrGotLdr	Lloh95, Lloh96, Lloh97
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_idle_v1              ; -- Begin function neoclr_gc_idle_v1
	.p2align	2
_neoclr_gc_idle_v1:                     ; @neoclr_gc_idle_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh98:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh99:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	ldr	x8, [x0, #8]
	add	x8, x8, #1
	str	x8, [x0, #8]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cmp	w0, #0
	ldr	x8, [x20, #72]
	cinc	x8, x8, ne
	str	x8, [x20, #72]
	cbnz	w0, LBB29_2
; %bb.1:
Lloh100:
	adrp	x8, _neoclr_execution_state_v1@TLVPPAGE
Lloh101:
	ldr	x8, [x8, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x10, [x8]
	mov	x9, x0
	mov	x0, x8
	blr	x10
	mov	x8, x0
	mov	x0, x9
	str	x19, [x8, #56]
	ldur	q0, [x8, #24]
	ext.16b	v0, v0, v0, #8
	str	q0, [x8, #64]
	str	xzr, [x8, #80]
LBB29_2:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpLdr	Lloh100, Lloh101
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_paced_collect_v1     ; -- Begin function neoclr_gc_paced_collect_v1
	.p2align	2
_neoclr_gc_paced_collect_v1:            ; @neoclr_gc_paced_collect_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x0
Lloh102:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh103:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x19, x0
	ldr	x8, [x0, #56]
	cmp	x8, x20
	b.eq	LBB30_2
; %bb.1:
	mov	w8, #4                          ; =0x4
	b	LBB30_5
LBB30_2:
	ldr	x8, [x19, #24]
	ldr	x9, [x19, #72]
	cmp	x8, x9
	b.ne	LBB30_4
; %bb.3:
	ldr	x8, [x19, #32]
	ldr	x9, [x19, #64]
	sub	x8, x8, x9
	cmp	x8, #255
	mov	w8, #6                          ; =0x6
	cinc	x8, x8, ls
	b	LBB30_5
LBB30_4:
	mov	w8, #5                          ; =0x5
LBB30_5:
Lloh104:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh105:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	add	x21, x0, x8, lsl #3
	ldr	x8, [x21]
	add	x8, x8, #1
	str	x8, [x21]
	mov	x0, x20
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cmp	w0, #0
	ldr	x8, [x21, #64]
	cinc	x8, x8, ne
	str	x8, [x21, #64]
	cbnz	w0, LBB30_7
; %bb.6:
	str	x20, [x19, #56]
	ldur	q0, [x19, #24]
	ext.16b	v0, v0, v0, #8
	str	q0, [x19, #64]
	str	xzr, [x19, #80]
LBB30_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpLdr	Lloh104, Lloh105
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_boundary_v1          ; -- Begin function neoclr_gc_boundary_v1
	.p2align	2
_neoclr_gc_boundary_v1:                 ; @neoclr_gc_boundary_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x1
	mov	x19, x0
Lloh106:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh107:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB31_4
; %bb.1:
	ldr	w8, [x20, #88]
	cbnz	w8, LBB31_4
; %bb.2:
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x21
	b.eq	LBB31_5
LBB31_3:
	mov	w0, #3                          ; =0x3
LBB31_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB31_5:
	cbz	x21, LBB31_7
; %bb.6:
	ldr	x8, [x21, #8]
	cmp	x8, x19
	b.ne	LBB31_3
LBB31_7:
	ldr	x8, [x20, #56]
	cmp	x8, x19
	b.eq	LBB31_9
; %bb.8:
	mov	w8, #4                          ; =0x4
	b	LBB31_15
LBB31_9:
	ldr	x8, [x20, #24]
	ldr	x9, [x20, #72]
	cmp	x8, x9
	b.ne	LBB31_13
; %bb.10:
	ldr	x8, [x20, #32]
	ldr	x9, [x20, #64]
	sub	x8, x8, x9
	cmp	x8, #255
	b.hi	LBB31_14
; %bb.11:
	ldr	x8, [x20, #80]
	add	x8, x8, #1
	str	x8, [x20, #80]
	cmp	x8, #1, lsl #12                 ; =4096
	b.hs	LBB31_14
; %bb.12:
	mov	w0, #0                          ; =0x0
	b	LBB31_4
LBB31_13:
	mov	w8, #5                          ; =0x5
	b	LBB31_15
LBB31_14:
	ldr	x8, [x20, #32]
	ldr	x9, [x20, #64]
	sub	x8, x8, x9
	cmp	x8, #255
	mov	w8, #6                          ; =0x6
	cinc	x8, x8, ls
LBB31_15:
Lloh108:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh109:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	add	x22, x0, x8, lsl #3
	ldr	x8, [x22]
	add	x8, x8, #1
	str	x8, [x22]
	mov	x0, x19
	mov	x1, x21
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cmp	w0, #0
	ldr	x8, [x22, #64]
	cinc	x8, x8, ne
	str	x8, [x22, #64]
	cbnz	w0, LBB31_4
; %bb.16:
	str	x19, [x20, #56]
	ldur	q0, [x20, #24]
	ext.16b	v0, v0, v0, #8
	str	q0, [x20, #64]
	str	xzr, [x20, #80]
	b	LBB31_4
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpLdr	Lloh108, Lloh109
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_published_boundary_v1 ; -- Begin function neoclr_gc_published_boundary_v1
	.p2align	2
_neoclr_gc_published_boundary_v1:       ; @neoclr_gc_published_boundary_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh110:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh111:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB32_14
; %bb.1:
	cbz	x1, LBB32_14
; %bb.2:
	ldr	w9, [x8, #88]
	cbnz	w9, LBB32_14
; %bb.3:
	ldr	x9, [x1, #8]
	cmp	x9, x19
	b.ne	LBB32_14
; %bb.4:
	ldr	x9, [x8, #56]
	cmp	x9, x19
	b.eq	LBB32_6
; %bb.5:
	mov	x20, x8
	mov	w8, #4                          ; =0x4
	b	LBB32_12
LBB32_6:
	ldr	x9, [x8, #24]
	ldr	x10, [x8, #72]
	cmp	x9, x10
	b.ne	LBB32_10
; %bb.7:
	ldr	x9, [x8, #32]
	ldr	x10, [x8, #64]
	sub	x9, x9, x10
	cmp	x9, #255
	b.hi	LBB32_11
; %bb.8:
	ldr	x9, [x8, #80]
	add	x9, x9, #1
	str	x9, [x8, #80]
	cmp	x9, #1, lsl #12                 ; =4096
	b.hs	LBB32_11
; %bb.9:
	mov	w0, #0                          ; =0x0
	b	LBB32_14
LBB32_10:
	mov	x20, x8
	mov	w8, #5                          ; =0x5
	b	LBB32_12
LBB32_11:
	ldr	x9, [x8, #32]
	mov	x20, x8
	ldr	x8, [x8, #64]
	sub	x8, x9, x8
	cmp	x8, #255
	mov	w8, #6                          ; =0x6
	cinc	x8, x8, ls
LBB32_12:
Lloh112:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh113:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	add	x21, x0, x8, lsl #3
	ldr	x8, [x21]
	add	x8, x8, #1
	str	x8, [x21]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cmp	w0, #0
	ldr	x8, [x21, #64]
	cinc	x8, x8, ne
	str	x8, [x21, #64]
	cbnz	w0, LBB32_14
; %bb.13:
	str	x19, [x20, #56]
	ldur	q0, [x20, #24]
	ext.16b	v0, v0, v0, #8
	str	q0, [x20, #64]
	str	xzr, [x20, #80]
LBB32_14:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpLdr	Lloh112, Lloh113
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_statistics_v1        ; -- Begin function neoclr_gc_statistics_v1
	.p2align	2
_neoclr_gc_statistics_v1:               ; @neoclr_gc_statistics_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh114:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh115:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldur	q0, [x0, #24]
	ldur	q1, [x0, #40]
	stp	q0, q1, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh114, Lloh115
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_string_intern_v1        ; -- Begin function neoclr_string_intern_v1
	.p2align	2
_neoclr_string_intern_v1:               ; @neoclr_string_intern_v1
	.cfi_startproc
; %bb.0:
	mov	w3, #0                          ; =0x0
	b	_string_intern
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function string_intern
_string_intern:                         ; @string_intern
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x0
	mov	w0, #3                          ; =0x3
	cbz	x20, LBB35_26
; %bb.1:
	mov	x19, x2
	cbz	x2, LBB35_26
; %bb.2:
	mov	x21, x1
	str	w3, [sp, #12]                   ; 4-byte Folded Spill
	mov	x0, x1
	bl	_blocks_valid
	cbz	w0, LBB35_25
; %bb.3:
	ldr	x25, [x21, #16]
	cbz	x25, LBB35_15
; %bb.4:
	str	x19, [sp]                       ; 8-byte Folded Spill
	mov	x26, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	mov	x27, #0                         ; =0x0
	ldr	x28, [x21]
	mov	w9, #1048576                    ; =0x100000
	b	LBB35_7
LBB35_5:                                ;   in Loop: Header=BB35_7 Depth=1
	add	x24, x22, x24
	add	x26, x26, #1
LBB35_6:                                ;   in Loop: Header=BB35_7 Depth=1
	ldr	x8, [x23]
	add	x27, x8, x27
	cmp	x27, x25
	b.hs	LBB35_16
LBB35_7:                                ; =>This Inner Loop Header: Depth=1
	add	x23, x28, x27
	ldrb	w8, [x23, #24]
	tbz	w8, #0, LBB35_6
; %bb.8:                                ;   in Loop: Header=BB35_7 Depth=1
	ldr	x8, [x23, #16]
	cmp	x8, #6
	b.ne	LBB35_6
; %bb.9:                                ;   in Loop: Header=BB35_7 Depth=1
	ldr	x8, [x23, #8]
	cmp	x8, #8
	b.ne	LBB35_25
; %bb.10:                               ;   in Loop: Header=BB35_7 Depth=1
	ldr	x19, [x23, #32]
	cbz	x19, LBB35_25
; %bb.11:                               ;   in Loop: Header=BB35_7 Depth=1
	ldr	x22, [x19]
	sub	x8, x9, x24
	cmp	x22, x8
	b.hi	LBB35_25
; %bb.12:                               ;   in Loop: Header=BB35_7 Depth=1
	ldr	x8, [x20]
	cmp	x22, x8
	b.ne	LBB35_5
; %bb.13:                               ;   in Loop: Header=BB35_7 Depth=1
	add	x0, x19, #8
	add	x1, x20, #8
	mov	x2, x22
	bl	_memcmp
	mov	w9, #1048576                    ; =0x100000
	cbnz	w0, LBB35_5
; %bb.14:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x19, [x8]
	b	LBB35_26
LBB35_15:
	mov	w9, #1048576                    ; =0x100000
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	b	LBB35_18
LBB35_16:
	cmp	x26, #4095
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	b.hi	LBB35_19
; %bb.17:
	mov	w9, #1048576                    ; =0x100000
	sub	x9, x9, x24
	ldr	x19, [sp]                       ; 8-byte Folded Reload
LBB35_18:
	ldr	x10, [x20]
	cmp	x10, x9
	b.ls	LBB35_20
LBB35_19:
	mov	w0, #10                         ; =0xa
	b	LBB35_26
LBB35_20:
	cbz	w8, LBB35_27
; %bb.21:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB35_25
; %bb.22:
	mov	x1, x0
	ldr	x8, [x0, #8]
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB35_26
; %bb.23:
	add	x9, x8, #1048
	cmp	x9, x21
	b.ne	LBB35_26
; %bb.24:
	str	x20, [sp, #16]
	add	x2, sp, #16
	add	x6, sp, #24
	mov	x0, x8
	mov	w3, #1                          ; =0x1
	mov	w4, #8                          ; =0x8
	mov	w5, #6                          ; =0x6
	bl	_neoclr_gc_allocate_rooted_values_v1
	b	LBB35_28
LBB35_25:
	mov	w0, #3                          ; =0x3
LBB35_26:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB35_27:
	add	x3, sp, #24
	mov	x0, x21
	mov	w1, #8                          ; =0x8
	mov	w2, #6                          ; =0x6
	bl	_neoclr_gc_allocate_v1
LBB35_28:
	cbnz	w0, LBB35_26
; %bb.29:
	ldr	x8, [sp, #24]
	str	x20, [x8]
	str	x20, [x19]
	b	LBB35_26
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_string_intern_rooted_v1 ; -- Begin function neoclr_string_intern_rooted_v1
	.p2align	2
_neoclr_string_intern_rooted_v1:        ; @neoclr_string_intern_rooted_v1
	.cfi_startproc
; %bb.0:
	mov	w3, #1                          ; =0x1
	b	_string_intern
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_collect_managed_v1   ; -- Begin function neoclr_gc_collect_managed_v1
	.p2align	2
_neoclr_gc_collect_managed_v1:          ; @neoclr_gc_collect_managed_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_neoclr_root_probe_head_v1
	mov	x1, x0
Lloh116:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh117:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cmp	w0, #0
	ldr	x8, [x20, #88]
	cinc	x8, x8, ne
	str	x8, [x20, #88]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh116, Lloh117
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_dense
_collect_dense:                         ; @collect_dense
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #33088                      ; =0x8140
Lloh118:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh119:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
Lloh120:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh121:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh122:
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	ldr	x11, [x0, #1064]
	cbz	x11, LBB38_15
; %bb.1:
	sub	x9, x11, #1
	mov	w8, #5                          ; =0x5
LBB38_2:                                ; =>This Inner Loop Header: Depth=1
	add	w8, w8, #1
	lsr	x10, x9, x8
	cmp	x10, #4095
	b.hi	LBB38_2
; %bb.3:
	mov	x13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	ldr	x14, [x0, #1048]
	add	x15, sp, #312
	add	x16, sp, #56
	b	LBB38_6
LBB38_4:                                ;   in Loop: Header=BB38_6 Depth=1
	mov	w13, w13
LBB38_5:                                ;   in Loop: Header=BB38_6 Depth=1
	orr	w9, w9, w17
	cmp	x12, x11
	b.hs	LBB38_16
LBB38_6:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB38_13 Depth 2
	add	x4, x14, x12
	ldr	x5, [x4, #24]
	cmp	x5, #1
	cset	w17, hi
	cbz	x5, LBB38_12
; %bb.7:                                ;   in Loop: Header=BB38_6 Depth=1
	ldr	x5, [x4, #16]
	cmp	x5, #6
	b.ne	LBB38_12
; %bb.8:                                ;   in Loop: Header=BB38_6 Depth=1
	cmp	x10, #32
	b.hi	LBB38_12
; %bb.9:                                ;   in Loop: Header=BB38_6 Depth=1
	b.eq	LBB38_11
; %bb.10:                               ;   in Loop: Header=BB38_6 Depth=1
	str	x4, [x16, x10, lsl #3]
LBB38_11:                               ;   in Loop: Header=BB38_6 Depth=1
	add	x10, x10, #1
LBB38_12:                               ;   in Loop: Header=BB38_6 Depth=1
	ldr	x5, [x4]
	add	x12, x5, x12
	cmp	x13, #4095
	b.hi	LBB38_5
LBB38_13:                               ;   Parent Loop BB38_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x5, x13, x8
	cmp	x5, x12
	b.hs	LBB38_4
; %bb.14:                               ;   in Loop: Header=BB38_13 Depth=2
	str	x4, [x15, x13, lsl #3]
	add	x5, x13, #1
	mov	x13, x5
	cmp	x5, #1, lsl #12                 ; =4096
	b.ne	LBB38_13
	b	LBB38_5
LBB38_15:
	mov	x10, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	mov	w8, #6                          ; =0x6
LBB38_16:
	add	x11, sp, #312
	add	x12, sp, #56
	stp	x11, x12, [sp]
	mov	w11, #4096                      ; =0x1000
	stp	w11, w8, [sp, #16]
	str	w10, [sp, #24]
	stp	xzr, xzr, [sp, #32]
	str	w9, [sp, #48]
	mov	x4, sp
	bl	_collect_indexed
	ldur	x8, [x29, #-24]
Lloh123:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh124:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh125:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB38_18
; %bb.17:
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #320
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
LBB38_18:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh120, Lloh121, Lloh122
	.loh AdrpLdrGotLdr	Lloh123, Lloh124, Lloh125
	.loh AdrpLdrGot	Lloh118, Lloh119
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_indexed
_collect_indexed:                       ; @collect_indexed
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1152
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh126:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh127:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh128:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cmp	w3, #256
	b.hi	LBB39_3
; %bb.1:
	mov	x22, x4
	mov	x20, x0
	cbnz	x2, LBB39_6
; %bb.2:
	cbz	w3, LBB39_6
LBB39_3:
	mov	w0, #3                          ; =0x3
LBB39_4:
	ldur	x8, [x29, #-96]
Lloh129:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh130:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh131:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB39_225
; %bb.5:
	add	sp, sp, #1152
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB39_6:
	add	x19, x20, #1048
Lloh132:
	adrp	x0, _resource_head@TLVPPAGE
Lloh133:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x21, x0
	ldr	x9, [x0]
	cbz	x9, LBB39_18
; %bb.7:
Lloh134:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh135:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ldr	x10, [x0, #40]
	ldr	x11, [x0, #56]
	mov	w0, #3                          ; =0x3
	b	LBB39_9
LBB39_8:                                ;   in Loop: Header=BB39_9 Depth=1
	ldr	x9, [x9, #32]
	cbz	x9, LBB39_18
LBB39_9:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB39_14 Depth 2
	ldr	x12, [x9]
	cmp	x12, x20
	b.ne	LBB39_8
; %bb.10:                               ;   in Loop: Header=BB39_9 Depth=1
	ldr	x12, [x9, #8]
	cbz	x12, LBB39_3
; %bb.11:                               ;   in Loop: Header=BB39_9 Depth=1
	add	x10, x10, #1
	str	x10, [x8, #40]
	ldr	x13, [x19]
	cmp	x13, x12
	b.hi	LBB39_61
; %bb.12:                               ;   in Loop: Header=BB39_9 Depth=1
	ldr	x14, [x20, #1064]
	sub	x15, x12, x13
	cmp	x15, x14
	b.hs	LBB39_61
; %bb.13:                               ;   in Loop: Header=BB39_9 Depth=1
	ldr	x16, [x22]
	ldr	w17, [x22, #20]
	lsr	x17, x15, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x13
LBB39_14:                               ;   Parent Loop BB39_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x17, x14
	b.hs	LBB39_3
; %bb.15:                               ;   in Loop: Header=BB39_14 Depth=2
	mov	x16, x17
	add	x11, x11, #1
	str	x11, [x8, #56]
	ldr	x17, [x13, x17]
	add	x17, x17, x16
	cmp	x15, x17
	b.hs	LBB39_14
; %bb.16:                               ;   in Loop: Header=BB39_9 Depth=1
	add	x13, x13, x16
	ldrb	w14, [x13, #24]
	tbz	w14, #0, LBB39_4
; %bb.17:                               ;   in Loop: Header=BB39_9 Depth=1
	add	x13, x13, #32
	cmp	x13, x12
	b.eq	LBB39_8
	b	LBB39_4
LBB39_18:
	cbz	w3, LBB39_39
; %bb.19:
Lloh136:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh137:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	x9, #0                          ; =0x0
	ldr	x11, [x0, #40]
	ldr	x10, [x0, #56]
	mov	w12, w3
	mov	w13, #24                        ; =0x18
LBB39_20:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB39_24 Depth 2
                                        ;     Child Loop BB39_32 Depth 2
	madd	x14, x9, x13, x2
	ldr	x16, [x14]
	cbz	x16, LBB39_36
; %bb.21:                               ;   in Loop: Header=BB39_20 Depth=1
	add	x15, x11, #1
	str	x15, [x8, #40]
	ldr	x17, [x19]
	cmp	x17, x16
	b.hi	LBB39_61
; %bb.22:                               ;   in Loop: Header=BB39_20 Depth=1
	ldr	x0, [x20, #1064]
	sub	x4, x16, x17
	cmp	x4, x0
	b.hs	LBB39_61
; %bb.23:                               ;   in Loop: Header=BB39_20 Depth=1
	ldr	x5, [x22]
	ldr	w6, [x22, #20]
	lsr	x6, x4, x6
	ldr	x5, [x5, x6, lsl #3]
	sub	x6, x5, x17
LBB39_24:                               ;   Parent Loop BB39_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x6, x0
	b.hs	LBB39_3
; %bb.25:                               ;   in Loop: Header=BB39_24 Depth=2
	mov	x5, x6
	add	x10, x10, #1
	str	x10, [x8, #56]
	ldr	x6, [x17, x6]
	add	x6, x6, x5
	cmp	x4, x6
	b.hs	LBB39_24
; %bb.26:                               ;   in Loop: Header=BB39_20 Depth=1
	add	x17, x17, x5
	mov	w0, #3                          ; =0x3
	ldrb	w4, [x17, #24]
	tbz	w4, #0, LBB39_4
; %bb.27:                               ;   in Loop: Header=BB39_20 Depth=1
	add	x17, x17, #32
	cmp	x17, x16
	b.ne	LBB39_4
; %bb.28:                               ;   in Loop: Header=BB39_20 Depth=1
	ldr	x14, [x14, #8]
	cbz	x14, LBB39_37
; %bb.29:                               ;   in Loop: Header=BB39_20 Depth=1
	add	x11, x11, #2
	str	x11, [x8, #40]
	ldr	x15, [x19]
	cmp	x15, x14
	b.hi	LBB39_88
; %bb.30:                               ;   in Loop: Header=BB39_20 Depth=1
	ldr	x16, [x20, #1064]
	sub	x17, x14, x15
	cmp	x17, x16
	b.hs	LBB39_88
; %bb.31:                               ;   in Loop: Header=BB39_20 Depth=1
	ldr	x0, [x22]
	ldr	w4, [x22, #20]
	lsr	x4, x17, x4
	ldr	x0, [x0, x4, lsl #3]
	sub	x4, x0, x15
LBB39_32:                               ;   Parent Loop BB39_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x4, x16
	b.hs	LBB39_3
; %bb.33:                               ;   in Loop: Header=BB39_32 Depth=2
	mov	x0, x4
	add	x10, x10, #1
	str	x10, [x8, #56]
	ldr	x4, [x15, x4]
	add	x4, x4, x0
	cmp	x17, x4
	b.hs	LBB39_32
; %bb.34:                               ;   in Loop: Header=BB39_20 Depth=1
	add	x15, x15, x0
	mov	w0, #3                          ; =0x3
	ldrb	w16, [x15, #24]
	tbz	w16, #0, LBB39_4
; %bb.35:                               ;   in Loop: Header=BB39_20 Depth=1
	add	x15, x15, #32
	cmp	x15, x14
	b.eq	LBB39_38
	b	LBB39_4
LBB39_36:                               ;   in Loop: Header=BB39_20 Depth=1
	ldr	x14, [x14, #8]
	cbz	x14, LBB39_38
	b	LBB39_3
LBB39_37:                               ;   in Loop: Header=BB39_20 Depth=1
	mov	x11, x15
LBB39_38:                               ;   in Loop: Header=BB39_20 Depth=1
	add	x9, x9, #1
	cmp	x9, x12
	b.ne	LBB39_20
LBB39_39:
Lloh138:
	adrp	x0, _host_head@TLVPPAGE
Lloh139:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x23, x0
	ldr	x9, [x0]
	cbz	x9, LBB39_62
; %bb.40:
Lloh140:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh141:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ldr	x10, [x0, #40]
	ldr	x11, [x0, #56]
	b	LBB39_42
LBB39_41:                               ;   in Loop: Header=BB39_42 Depth=1
	ldr	x9, [x9, #48]
	cbz	x9, LBB39_62
LBB39_42:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB39_47 Depth 2
                                        ;     Child Loop BB39_57 Depth 2
	ldr	x12, [x9]
	cmp	x12, x20
	b.ne	LBB39_41
; %bb.43:                               ;   in Loop: Header=BB39_42 Depth=1
	ldr	x12, [x9, #8]
	cbz	x12, LBB39_51
; %bb.44:                               ;   in Loop: Header=BB39_42 Depth=1
	add	x10, x10, #1
	str	x10, [x8, #40]
	ldr	x13, [x19]
	cmp	x13, x12
	b.hi	LBB39_61
; %bb.45:                               ;   in Loop: Header=BB39_42 Depth=1
	ldr	x14, [x20, #1064]
	sub	x15, x12, x13
	cmp	x15, x14
	b.hs	LBB39_61
; %bb.46:                               ;   in Loop: Header=BB39_42 Depth=1
	ldr	x16, [x22]
	ldr	w17, [x22, #20]
	lsr	x17, x15, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x13
LBB39_47:                               ;   Parent Loop BB39_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x17, x14
	b.hs	LBB39_3
; %bb.48:                               ;   in Loop: Header=BB39_47 Depth=2
	mov	x16, x17
	add	x11, x11, #1
	str	x11, [x8, #56]
	ldr	x17, [x13, x17]
	add	x17, x17, x16
	cmp	x15, x17
	b.hs	LBB39_47
; %bb.49:                               ;   in Loop: Header=BB39_42 Depth=1
	add	x13, x13, x16
	mov	w0, #3                          ; =0x3
	ldrb	w14, [x13, #24]
	tbz	w14, #0, LBB39_4
; %bb.50:                               ;   in Loop: Header=BB39_42 Depth=1
	add	x13, x13, #32
	cmp	x13, x12
	b.ne	LBB39_4
LBB39_51:                               ;   in Loop: Header=BB39_42 Depth=1
	ldr	w12, [x9, #24]
	cbz	w12, LBB39_41
; %bb.52:                               ;   in Loop: Header=BB39_42 Depth=1
	ldr	w12, [x9, #28]
	cbnz	w12, LBB39_41
; %bb.53:                               ;   in Loop: Header=BB39_42 Depth=1
	ldr	x12, [x9, #16]
	cbz	x12, LBB39_3
; %bb.54:                               ;   in Loop: Header=BB39_42 Depth=1
	add	x10, x10, #1
	str	x10, [x8, #40]
	ldr	x13, [x19]
	cmp	x13, x12
	b.hi	LBB39_61
; %bb.55:                               ;   in Loop: Header=BB39_42 Depth=1
	ldr	x14, [x20, #1064]
	sub	x15, x12, x13
	cmp	x15, x14
	b.hs	LBB39_61
; %bb.56:                               ;   in Loop: Header=BB39_42 Depth=1
	ldr	x16, [x22]
	ldr	w17, [x22, #20]
	lsr	x17, x15, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x13
LBB39_57:                               ;   Parent Loop BB39_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x17, x14
	b.hs	LBB39_3
; %bb.58:                               ;   in Loop: Header=BB39_57 Depth=2
	mov	x16, x17
	add	x11, x11, #1
	str	x11, [x8, #56]
	ldr	x17, [x13, x17]
	add	x17, x17, x16
	cmp	x15, x17
	b.hs	LBB39_57
; %bb.59:                               ;   in Loop: Header=BB39_42 Depth=1
	add	x13, x13, x16
	mov	w0, #3                          ; =0x3
	ldrb	w14, [x13, #24]
	tbz	w14, #0, LBB39_4
; %bb.60:                               ;   in Loop: Header=BB39_42 Depth=1
	add	x13, x13, #32
	cmp	x13, x12
	b.eq	LBB39_41
	b	LBB39_4
LBB39_61:
	ldr	x9, [x8, #48]
	add	x9, x9, #1
	str	x9, [x8, #48]
	b	LBB39_3
LBB39_62:
	str	x2, [sp, #48]                   ; 8-byte Folded Spill
	str	w3, [sp, #72]                   ; 4-byte Folded Spill
	mov	x24, x1
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB39_75
; %bb.63:
	mov	x8, x0
Lloh142:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh143:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	ldr	x10, [x0, #40]
	ldr	x11, [x0, #56]
	mov	w0, #3                          ; =0x3
	b	LBB39_65
LBB39_64:                               ;   in Loop: Header=BB39_65 Depth=1
	ldr	x8, [x8, #8]
	cbz	x8, LBB39_75
LBB39_65:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB39_71 Depth 2
	ldr	x12, [x8, #16]
	cmp	x12, x20
	b.ne	LBB39_64
; %bb.66:                               ;   in Loop: Header=BB39_65 Depth=1
	ldr	w12, [x8, #32]
	cbnz	w12, LBB39_64
; %bb.67:                               ;   in Loop: Header=BB39_65 Depth=1
	ldr	x12, [x8, #24]
	cbz	x12, LBB39_3
; %bb.68:                               ;   in Loop: Header=BB39_65 Depth=1
	add	x10, x10, #1
	str	x10, [x9, #40]
	ldr	x13, [x19]
	cmp	x13, x12
	b.hi	LBB39_166
; %bb.69:                               ;   in Loop: Header=BB39_65 Depth=1
	ldr	x14, [x20, #1064]
	sub	x15, x12, x13
	cmp	x15, x14
	b.hs	LBB39_166
; %bb.70:                               ;   in Loop: Header=BB39_65 Depth=1
	ldr	x16, [x22]
	ldr	w17, [x22, #20]
	lsr	x17, x15, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x13
LBB39_71:                               ;   Parent Loop BB39_65 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x17, x14
	b.hs	LBB39_3
; %bb.72:                               ;   in Loop: Header=BB39_71 Depth=2
	mov	x16, x17
	add	x11, x11, #1
	str	x11, [x9, #56]
	ldr	x17, [x13, x17]
	add	x17, x17, x16
	cmp	x15, x17
	b.hs	LBB39_71
; %bb.73:                               ;   in Loop: Header=BB39_65 Depth=1
	add	x13, x13, x16
	ldrb	w14, [x13, #24]
	tbz	w14, #0, LBB39_4
; %bb.74:                               ;   in Loop: Header=BB39_65 Depth=1
	add	x13, x13, #32
	cmp	x13, x12
	b.eq	LBB39_64
	b	LBB39_4
LBB39_75:
	str	x23, [sp, #40]                  ; 8-byte Folded Spill
	str	x21, [sp]                       ; 8-byte Folded Spill
	add	x1, sp, #96
	mov	x0, x20
	mov	w2, #65                         ; =0x41
	bl	_neoclr_probe_fault_roots_v1
	tbnz	w0, #31, LBB39_3
; %bb.76:
	mov	x25, x0
	bl	_neoclr_roots_parked_v1
	cbnz	x0, LBB39_82
LBB39_77:
	str	xzr, [sp, #88]
	ldr	w8, [x22, #48]
	cbnz	w8, LBB39_79
; %bb.78:
	ldr	w8, [x22, #24]
	cmp	w8, #32
	b.ls	LBB39_89
LBB39_79:
	ldr	x8, [x20, #1064]
	cbz	x8, LBB39_92
; %bb.80:
	mov	x21, #0                         ; =0x0
	b	LBB39_85
LBB39_81:                               ;   in Loop: Header=BB39_82 Depth=1
	ldr	x0, [x0, #8]
	cbz	x0, LBB39_77
LBB39_82:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #16]
	cmp	x8, x20
	b.ne	LBB39_81
; %bb.83:                               ;   in Loop: Header=BB39_82 Depth=1
	str	wzr, [x0, #36]
	b	LBB39_81
LBB39_84:                               ;   in Loop: Header=BB39_85 Depth=1
	ldr	x9, [x23]
	add	x21, x9, x21
	cmp	x21, x8
	b.hs	LBB39_92
LBB39_85:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	add	x23, x9, x21
	ldr	x9, [x23, #24]
	and	x10, x9, #0x1
	str	x10, [x23, #24]
	tbz	w9, #0, LBB39_84
; %bb.86:                               ;   in Loop: Header=BB39_85 Depth=1
	ldr	x9, [x23, #16]
	cmp	x9, #6
	b.ne	LBB39_84
; %bb.87:                               ;   in Loop: Header=BB39_85 Depth=1
	add	x2, x23, #32
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	ldr	x8, [x20, #1064]
	b	LBB39_84
LBB39_88:
	ldr	x9, [x8, #48]
	add	x9, x9, #1
	str	x9, [x8, #48]
	b	LBB39_4
LBB39_89:
	cbz	w8, LBB39_92
; %bb.90:
	mov	x21, #0                         ; =0x0
LBB39_91:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x22, #8]
	ldr	x8, [x8, x21, lsl #3]
	add	x2, x8, #32
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	add	x21, x21, #1
	ldr	w8, [x22, #24]
	cmp	x21, x8
	b.lo	LBB39_91
LBB39_92:
	cbz	w25, LBB39_97
; %bb.93:
	mov	w21, w25
	add	x8, sp, #96
	add	x23, x8, #8
	b	LBB39_95
LBB39_94:                               ;   in Loop: Header=BB39_95 Depth=1
	add	x23, x23, #16
	subs	x21, x21, #1
	b.eq	LBB39_97
LBB39_95:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x23]
	cmp	w8, #8
	b.ne	LBB39_94
; %bb.96:                               ;   in Loop: Header=BB39_95 Depth=1
	ldur	x8, [x23, #-8]
	ldr	x2, [x8]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	b	LBB39_94
LBB39_97:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x21, [x8]
	cbnz	x21, LBB39_101
LBB39_98:
	ldr	x2, [x20, #1072]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	add	x3, sp, #88
	mov	x0, x20
	mov	x1, x22
	mov	x2, x24
	bl	_mark_frames
	bl	_neoclr_roots_parked_v1
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w8, [sp, #72]                   ; 4-byte Folded Reload
	cbz	x0, LBB39_107
; %bb.99:
	mov	x24, x0
	b	LBB39_105
LBB39_100:                              ;   in Loop: Header=BB39_101 Depth=1
	ldr	x21, [x21, #48]
	cbz	x21, LBB39_98
LBB39_101:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x21]
	cmp	x8, x20
	b.ne	LBB39_100
; %bb.102:                              ;   in Loop: Header=BB39_101 Depth=1
	ldr	w8, [x21, #24]
	cbnz	w8, LBB39_100
; %bb.103:                              ;   in Loop: Header=BB39_101 Depth=1
	ldr	x2, [x21, #8]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	b	LBB39_100
LBB39_104:                              ;   in Loop: Header=BB39_105 Depth=1
	ldr	x24, [x24, #8]
	cbz	x24, LBB39_107
LBB39_105:                              ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x24, #16]
	cbnz	x10, LBB39_104
; %bb.106:                              ;   in Loop: Header=BB39_105 Depth=1
	ldr	x2, [x24]
	add	x3, sp, #88
	mov	x0, x20
	mov	x1, x22
	bl	_mark_frames
	ldr	w8, [sp, #72]                   ; 4-byte Folded Reload
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	b	LBB39_104
LBB39_107:
Lloh144:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh145:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	str	x0, [sp, #80]                   ; 8-byte Folded Spill
	ldr	x25, [sp, #88]
	add	x9, x9, #8
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	mov	w9, w8
	stp	x9, x20, [sp, #24]              ; 16-byte Folded Spill
LBB39_108:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB39_133 Depth 2
                                        ;       Child Loop BB39_160 Depth 3
                                        ;         Child Loop BB39_162 Depth 4
                                        ;       Child Loop BB39_143 Depth 3
                                        ;       Child Loop BB39_150 Depth 3
                                        ;     Child Loop BB39_115 Depth 2
                                        ;     Child Loop BB39_119 Depth 2
                                        ;     Child Loop BB39_125 Depth 2
	ldr	x9, [x22, #40]
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	cbnz	x25, LBB39_133
LBB39_109:                              ;   in Loop: Header=BB39_108 Depth=1
	ldp	x21, x20, [sp, #24]             ; 16-byte Folded Reload
	ldr	x23, [sp, #8]                   ; 8-byte Folded Reload
	ldr	x24, [sp, #40]                  ; 8-byte Folded Reload
	cbnz	w8, LBB39_115
LBB39_110:                              ;   in Loop: Header=BB39_108 Depth=1
	ldr	x21, [x24]
	cbnz	x21, LBB39_119
LBB39_111:                              ;   in Loop: Header=BB39_108 Depth=1
	bl	_neoclr_roots_parked_v1
	ldr	w8, [sp, #72]                   ; 4-byte Folded Reload
	mov	x25, x0
	cbnz	x0, LBB39_125
LBB39_112:                              ;   in Loop: Header=BB39_108 Depth=1
	ldr	x25, [sp, #88]
	cbnz	x25, LBB39_108
; %bb.113:                              ;   in Loop: Header=BB39_108 Depth=1
	ldr	x9, [x22, #40]
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	cmp	x10, x9
	b.ne	LBB39_108
	b	LBB39_167
LBB39_114:                              ;   in Loop: Header=BB39_115 Depth=2
	add	x23, x23, #24
	subs	x21, x21, #1
	b.eq	LBB39_110
LBB39_115:                              ;   Parent Loop BB39_108 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x8, [x23, #-8]
	cbz	x8, LBB39_114
; %bb.116:                              ;   in Loop: Header=BB39_115 Depth=2
	ldurb	w8, [x8, #-8]
	tbz	w8, #1, LBB39_114
; %bb.117:                              ;   in Loop: Header=BB39_115 Depth=2
	ldr	x2, [x23]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	b	LBB39_114
LBB39_118:                              ;   in Loop: Header=BB39_119 Depth=2
	ldr	x21, [x21, #48]
	cbz	x21, LBB39_111
LBB39_119:                              ;   Parent Loop BB39_108 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x21]
	cmp	x8, x20
	b.ne	LBB39_118
; %bb.120:                              ;   in Loop: Header=BB39_119 Depth=2
	ldr	w8, [x21, #24]
	cbz	w8, LBB39_118
; %bb.121:                              ;   in Loop: Header=BB39_119 Depth=2
	ldr	w8, [x21, #28]
	cbnz	w8, LBB39_118
; %bb.122:                              ;   in Loop: Header=BB39_119 Depth=2
	ldr	x8, [x21, #16]
	ldurb	w8, [x8, #-8]
	tbz	w8, #1, LBB39_118
; %bb.123:                              ;   in Loop: Header=BB39_119 Depth=2
	ldr	x2, [x21, #8]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	b	LBB39_118
LBB39_124:                              ;   in Loop: Header=BB39_125 Depth=2
	ldr	x25, [x25, #8]
	cbz	x25, LBB39_112
LBB39_125:                              ;   Parent Loop BB39_108 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x9, [x25, #16]
	cmp	x9, x20
	b.ne	LBB39_124
; %bb.126:                              ;   in Loop: Header=BB39_125 Depth=2
	ldr	w9, [x25, #32]
	cbnz	w9, LBB39_124
; %bb.127:                              ;   in Loop: Header=BB39_125 Depth=2
	ldr	w9, [x25, #36]
	cbnz	w9, LBB39_124
; %bb.128:                              ;   in Loop: Header=BB39_125 Depth=2
	ldr	x9, [x25, #24]
	ldurb	w9, [x9, #-8]
	tbz	w9, #1, LBB39_124
; %bb.129:                              ;   in Loop: Header=BB39_125 Depth=2
	mov	w8, #1                          ; =0x1
	str	w8, [x25, #36]
	ldr	x2, [x25]
	add	x3, sp, #88
	mov	x0, x20
	mov	x1, x22
	bl	_mark_frames
	ldr	w8, [sp, #72]                   ; 4-byte Folded Reload
	b	LBB39_124
LBB39_130:                              ;   in Loop: Header=BB39_133 Depth=2
	ldr	x2, [x9]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
LBB39_131:                              ;   in Loop: Header=BB39_133 Depth=2
	ldr	x10, [sp, #88]
	ldr	w8, [sp, #72]                   ; 4-byte Folded Reload
LBB39_132:                              ;   in Loop: Header=BB39_133 Depth=2
	mov	x25, x10
	cbz	x10, LBB39_109
LBB39_133:                              ;   Parent Loop BB39_108 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB39_160 Depth 3
                                        ;         Child Loop BB39_162 Depth 4
                                        ;       Child Loop BB39_143 Depth 3
                                        ;       Child Loop BB39_150 Depth 3
	ldp	x11, x9, [x25, #16]
	and	x10, x9, #0xfffffffffffffff8
	str	x10, [sp, #88]
	mov	w9, #7                          ; =0x7
	str	x9, [x25, #24]
	cmp	x11, #4
	b.gt	LBB39_145
; %bb.134:                              ;   in Loop: Header=BB39_133 Depth=2
	cmp	x11, #2
	b.eq	LBB39_148
; %bb.135:                              ;   in Loop: Header=BB39_133 Depth=2
	cmp	x11, #4
	b.ne	LBB39_132
; %bb.136:                              ;   in Loop: Header=BB39_133 Depth=2
	ldr	x8, [x25, #8]
	subs	x8, x8, #16
	b.lo	LBB39_163
; %bb.137:                              ;   in Loop: Header=BB39_133 Depth=2
	ldr	w23, [x25, #32]
	mov	x9, #-5                         ; =0xfffffffffffffffb
	movk	x9, #32767, lsl #16
	add	x9, x23, x9
	cmn	x9, #2
	b.lo	LBB39_163
; %bb.138:                              ;   in Loop: Header=BB39_133 Depth=2
	ldr	x26, [x25, #40]
	mov	w9, #4                          ; =0x4
	movk	w9, #32768, lsl #16
	cmp	x23, x9
	mov	w9, #8                          ; =0x8
	cinc	x9, x9, eq
	udiv	x8, x8, x9
	cmp	x26, x8
	b.hi	LBB39_163
; %bb.139:                              ;   in Loop: Header=BB39_133 Depth=2
	cbz	x26, LBB39_131
; %bb.140:                              ;   in Loop: Header=BB39_133 Depth=2
	add	x21, x25, #48
	add	x25, x21, x26, lsl #3
	b	LBB39_143
LBB39_141:                              ;   in Loop: Header=BB39_143 Depth=3
	ldr	x2, [x21]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
LBB39_142:                              ;   in Loop: Header=BB39_143 Depth=3
	add	x25, x25, #1
	add	x21, x21, #8
	subs	x26, x26, #1
	b.eq	LBB39_131
LBB39_143:                              ;   Parent Loop BB39_108 Depth=1
                                        ;     Parent Loop BB39_133 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	mov	w8, #4                          ; =0x4
	movk	w8, #32768, lsl #16
	cmp	x23, x8
	b.ne	LBB39_141
; %bb.144:                              ;   in Loop: Header=BB39_143 Depth=3
	ldrb	w8, [x25]
	cbnz	w8, LBB39_141
	b	LBB39_142
LBB39_145:                              ;   in Loop: Header=BB39_133 Depth=2
	add	x9, x25, #32
	cmp	x11, #5
	b.eq	LBB39_151
; %bb.146:                              ;   in Loop: Header=BB39_133 Depth=2
	cmp	x11, #6
	b.ne	LBB39_132
; %bb.147:                              ;   in Loop: Header=BB39_133 Depth=2
	ldr	x8, [x25, #8]
	cmp	x8, #8
	b.eq	LBB39_130
	b	LBB39_163
LBB39_148:                              ;   in Loop: Header=BB39_133 Depth=2
	ldr	x8, [x25, #8]
	cmp	x8, #16
	b.lo	LBB39_131
; %bb.149:                              ;   in Loop: Header=BB39_133 Depth=2
	add	x21, x25, #40
	mov	w23, #16                        ; =0x10
LBB39_150:                              ;   Parent Loop BB39_108 Depth=1
                                        ;     Parent Loop BB39_133 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #88]
	add	x8, x8, #1
	str	x8, [x9, #88]
	ldr	x2, [x21], #8
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	add	x23, x23, #8
	ldr	x8, [x25, #8]
	cmp	x23, x8
	b.ls	LBB39_150
	b	LBB39_131
LBB39_151:                              ;   in Loop: Header=BB39_133 Depth=2
	ldr	x8, [x25, #8]
	subs	x8, x8, #24
	b.lo	LBB39_163
; %bb.152:                              ;   in Loop: Header=BB39_133 Depth=2
	ldr	x10, [x25, #32]
	mov	w11, w10
	mov	w12, #4                         ; =0x4
	movk	w12, #32768, lsl #16
	add	x12, x12, #1
	lsr	x10, x10, #32
	cmp	x10, #1024
	ccmp	x11, x12, #0, ls
	b.ne	LBB39_163
; %bb.153:                              ;   in Loop: Header=BB39_133 Depth=2
	ldr	x20, [x25, #48]
	cmp	x20, #1
	ccmp	x10, #0, #4, ne
	b.ne	LBB39_163
; %bb.154:                              ;   in Loop: Header=BB39_133 Depth=2
	sub	x10, x20, #257
	cmn	x10, #256
	b.lo	LBB39_163
; %bb.155:                              ;   in Loop: Header=BB39_133 Depth=2
	ldr	x26, [x25, #40]
	cmp	x26, #16, lsl #12               ; =65536
	b.hi	LBB39_163
; %bb.156:                              ;   in Loop: Header=BB39_133 Depth=2
	mov	w10, #1                         ; =0x1
	bfi	x10, x20, #3, #60
	udiv	x8, x8, x10
	cmp	x26, x8
	b.hi	LBB39_163
; %bb.157:                              ;   in Loop: Header=BB39_133 Depth=2
	cbz	x26, LBB39_131
; %bb.158:                              ;   in Loop: Header=BB39_133 Depth=2
	mov	x27, #0                         ; =0x0
	lsl	x21, x20, #3
	mul	x8, x26, x20
	add	x8, x9, x8, lsl #3
	add	x28, x8, #24
	add	x24, x25, #56
	b	LBB39_160
LBB39_159:                              ;   in Loop: Header=BB39_160 Depth=3
	add	x27, x27, #1
	add	x24, x24, x21
	cmp	x27, x26
	b.eq	LBB39_131
LBB39_160:                              ;   Parent Loop BB39_108 Depth=1
                                        ;     Parent Loop BB39_133 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB39_162 Depth 4
	ldrb	w8, [x28, x27]
	cbz	w8, LBB39_159
; %bb.161:                              ;   in Loop: Header=BB39_160 Depth=3
	mov	x25, x24
	mov	x23, x20
LBB39_162:                              ;   Parent Loop BB39_108 Depth=1
                                        ;     Parent Loop BB39_133 Depth=2
                                        ;       Parent Loop BB39_160 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	x2, [x25], #8
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	subs	x23, x23, #1
	b.ne	LBB39_162
	b	LBB39_159
LBB39_163:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #1064]
	cbz	x8, LBB39_3
; %bb.164:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x19]
LBB39_165:                              ; =>This Inner Loop Header: Depth=1
	add	x11, x10, x9
	ldr	x12, [x11, #24]
	and	x12, x12, #0x1
	str	x12, [x11, #24]
	ldr	x11, [x11]
	add	x9, x11, x9
	cmp	x9, x8
	b.lo	LBB39_165
	b	LBB39_3
LBB39_166:
	ldr	x8, [x9, #48]
	add	x8, x8, #1
	str	x8, [x9, #48]
	b	LBB39_3
LBB39_167:
	ldr	x22, [sp]                       ; 8-byte Folded Reload
	ldr	x8, [x22]
Lloh146:
	adrp	x25, _neoclr_execution_state_v1@TLVPPAGE
Lloh147:
	ldr	x25, [x25, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x23, [sp, #40]                  ; 8-byte Folded Reload
	cbz	x8, LBB39_173
; %bb.168:
	ldr	x9, [x25]
	mov	x0, x25
	blr	x9
	mov	x24, x0
	mov	w21, #1                         ; =0x1
	b	LBB39_170
LBB39_169:                              ;   in Loop: Header=BB39_170 Depth=1
	add	x22, x8, #32
	ldr	x8, [x22]
	cbz	x8, LBB39_173
LBB39_170:                              ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x20
	b.ne	LBB39_169
; %bb.171:                              ;   in Loop: Header=BB39_170 Depth=1
	ldr	x9, [x8, #8]
	ldurb	w9, [x9, #-8]
	tbnz	w9, #1, LBB39_169
; %bb.172:                              ;   in Loop: Header=BB39_170 Depth=1
	ldp	x0, x9, [x8, #16]
	ldr	x10, [x8, #32]
	str	x10, [x22]
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	str	w21, [x24, #88]
	blr	x9
	str	wzr, [x24, #88]
	ldr	x8, [x22]
	cbnz	x8, LBB39_170
LBB39_173:
	ldr	x8, [x23]
	cbz	x8, LBB39_181
; %bb.174:
	mov	w9, #1                          ; =0x1
	b	LBB39_176
LBB39_175:                              ;   in Loop: Header=BB39_176 Depth=1
	ldr	x8, [x8, #48]
	cbz	x8, LBB39_181
LBB39_176:                              ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x8]
	cmp	x10, x20
	b.ne	LBB39_175
; %bb.177:                              ;   in Loop: Header=BB39_176 Depth=1
	ldr	w10, [x8, #24]
	cbz	w10, LBB39_175
; %bb.178:                              ;   in Loop: Header=BB39_176 Depth=1
	ldr	w10, [x8, #28]
	cbnz	w10, LBB39_175
; %bb.179:                              ;   in Loop: Header=BB39_176 Depth=1
	ldr	x10, [x8, #16]
	ldurb	w10, [x10, #-8]
	tbnz	w10, #1, LBB39_175
; %bb.180:                              ;   in Loop: Header=BB39_176 Depth=1
	stp	xzr, xzr, [x8, #8]
	str	w9, [x8, #28]
	b	LBB39_175
LBB39_181:
	bl	_neoclr_roots_parked_v1
	ldr	w8, [sp, #72]                   ; 4-byte Folded Reload
	cbz	x0, LBB39_188
; %bb.182:
	mov	w9, #1                          ; =0x1
	b	LBB39_184
LBB39_183:                              ;   in Loop: Header=BB39_184 Depth=1
	ldr	x0, [x0, #8]
	cbz	x0, LBB39_188
LBB39_184:                              ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x0, #16]
	cmp	x10, x20
	b.ne	LBB39_183
; %bb.185:                              ;   in Loop: Header=BB39_184 Depth=1
	ldr	w10, [x0, #32]
	cbnz	w10, LBB39_183
; %bb.186:                              ;   in Loop: Header=BB39_184 Depth=1
	ldr	x10, [x0, #24]
	ldurb	w10, [x10, #-8]
	tbnz	w10, #1, LBB39_183
; %bb.187:                              ;   in Loop: Header=BB39_184 Depth=1
	str	xzr, [x0]
	str	xzr, [x0, #24]
	str	w9, [x0, #32]
	b	LBB39_183
LBB39_188:
	cbz	w8, LBB39_195
; %bb.189:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	add	x8, x8, #16
	b	LBB39_193
LBB39_190:                              ;   in Loop: Header=BB39_193 Depth=1
	str	wzr, [x8]
LBB39_191:                              ;   in Loop: Header=BB39_193 Depth=1
	stp	xzr, xzr, [x9]
LBB39_192:                              ;   in Loop: Header=BB39_193 Depth=1
	add	x8, x8, #24
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	subs	x9, x9, #1
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	b.eq	LBB39_195
LBB39_193:                              ; =>This Inner Loop Header: Depth=1
	mov	x9, x8
	ldr	x10, [x9, #-16]!
	cbz	x10, LBB39_190
; %bb.194:                              ;   in Loop: Header=BB39_193 Depth=1
	ldur	x10, [x10, #-8]
	ubfx	x11, x10, #1, #1
	str	w11, [x8]
	tbz	w10, #1, LBB39_191
	b	LBB39_192
LBB39_195:
	ldr	x8, [x20, #1064]
Lloh148:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh149:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	cbz	x8, LBB39_217
; %bb.196:
	ldr	x8, [x0]
	blr	x8
	mov	x23, x0
	ldr	x8, [x25]
	mov	x0, x25
	blr	x8
	mov	x24, x0
	mov	x28, #0                         ; =0x0
	str	xzr, [sp, #40]                  ; 8-byte Folded Spill
	mov	x25, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	stp	xzr, xzr, [sp, #72]             ; 16-byte Folded Spill
	mov	w8, #1                          ; =0x1
	dup.2d	v0, x8
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
	add	x8, x23, #40
	stp	xzr, x8, [sp, #16]              ; 16-byte Folded Spill
	b	LBB39_200
LBB39_197:                              ;   in Loop: Header=BB39_200 Depth=1
	ldr	x8, [x23]
	cmp	x19, x8
	b.eq	LBB39_213
LBB39_198:                              ;   in Loop: Header=BB39_200 Depth=1
	mov	x26, x25
	str	x28, [sp, #40]                  ; 8-byte Folded Spill
LBB39_199:                              ;   in Loop: Header=BB39_200 Depth=1
	ldr	x8, [x20, #1064]
	add	x28, x21, x28
	cmp	x28, x8
	mov	x25, x26
	b.hs	LBB39_215
LBB39_200:                              ; =>This Inner Loop Header: Depth=1
	mov	x26, x22
	ldr	x8, [x19]
	add	x22, x8, x28
	ldr	x21, [x22]
	ldr	x8, [x22, #24]
	and	x9, x8, #0x2
	cmp	x8, #0
	ccmp	x9, #0, #0, ne
	b.eq	LBB39_206
; %bb.201:                              ;   in Loop: Header=BB39_200 Depth=1
	and	x9, x8, #0x1
	str	x9, [x22, #24]
	tbz	w8, #0, LBB39_210
; %bb.202:                              ;   in Loop: Header=BB39_200 Depth=1
	ldr	x8, [x22, #8]
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	add	x9, x8, x9
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	add	x8, x8, #1
	stp	x8, x9, [sp, #72]               ; 16-byte Folded Spill
	mov	x22, #0                         ; =0x0
	cbz	x26, LBB39_212
; %bb.203:                              ;   in Loop: Header=BB39_200 Depth=1
	ldr	x8, [x23]
	cmp	x19, x8
	b.ne	LBB39_212
; %bb.204:                              ;   in Loop: Header=BB39_200 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x8, #1
	mov	x22, #0                         ; =0x0
	cbnz	x25, LBB39_214
; %bb.205:                              ;   in Loop: Header=BB39_200 Depth=1
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB39_199
LBB39_206:                              ;   in Loop: Header=BB39_200 Depth=1
	mov	x27, x22
	ldr	x8, [x27, #8]!
	ldur	q0, [x24, #40]
	ldr	q1, [sp, #48]                   ; 16-byte Folded Reload
	mov.d	v1[1], x8
	add.2d	v0, v0, v1
	stur	q0, [x24, #40]
	ldr	x8, [x23]
	cmp	x19, x8
	b.ne	LBB39_209
; %bb.207:                              ;   in Loop: Header=BB39_200 Depth=1
	add	x9, x22, #32
	ubfx	x8, x9, #3, #29
	eor	w8, w8, w9, lsr #9
	and	x8, x8, #0xff
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	ldr	x10, [x10, x8, lsl #3]
	cmp	x10, x9
	b.ne	LBB39_209
; %bb.208:                              ;   in Loop: Header=BB39_200 Depth=1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	str	xzr, [x9, x8, lsl #3]
LBB39_209:                              ;   in Loop: Header=BB39_200 Depth=1
	sub	x2, x21, #32
	add	x0, x22, #32
	mov	w1, #221                        ; =0xdd
	bl	_memset
	stp	xzr, xzr, [x27, #8]
	str	xzr, [x27]
LBB39_210:                              ;   in Loop: Header=BB39_200 Depth=1
	cbz	x26, LBB39_197
; %bb.211:                              ;   in Loop: Header=BB39_200 Depth=1
	ldr	x8, [x26]
	add	x8, x8, x21
	str	x8, [x26]
	mov	x22, x26
LBB39_212:                              ;   in Loop: Header=BB39_200 Depth=1
	mov	x26, x25
	b	LBB39_199
LBB39_213:                              ;   in Loop: Header=BB39_200 Depth=1
	str	xzr, [x22, #8]
	b	LBB39_198
LBB39_214:                              ;   in Loop: Header=BB39_200 Depth=1
	str	x8, [x25, #8]
	b	LBB39_199
LBB39_215:
	cbz	x22, LBB39_218
; %bb.216:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	str	x8, [x20, #1064]
	b	LBB39_219
LBB39_217:
	str	xzr, [sp, #16]                  ; 8-byte Folded Spill
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	str	xzr, [sp, #40]                  ; 8-byte Folded Spill
	b	LBB39_220
LBB39_218:
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
LBB39_219:
Lloh150:
	adrp	x25, _neoclr_execution_state_v1@TLVPPAGE
Lloh151:
	ldr	x25, [x25, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldp	x9, x10, [sp, #72]              ; 16-byte Folded Reload
Lloh152:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh153:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
LBB39_220:
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x19, x8
	b.ne	LBB39_222
; %bb.221:
	ldr	x11, [sp, #40]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	stp	x11, x8, [x0, #24]
LBB39_222:
	ldr	x8, [x25]
	mov	x0, x25
	blr	x8
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
Lloh154:
	adrp	x0, _profile@TLVPPAGE
Lloh155:
	ldr	x0, [x0, _profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	stp	x10, x9, [x0, #48]
	ldr	x9, [x0, #64]
	cmp	x10, x9
	b.ls	LBB39_224
; %bb.223:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	str	x10, [x8, #64]
	b	LBB39_4
LBB39_224:
	mov	w0, #0                          ; =0x0
	b	LBB39_4
LBB39_225:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh126, Lloh127, Lloh128
	.loh AdrpLdrGotLdr	Lloh129, Lloh130, Lloh131
	.loh AdrpLdr	Lloh132, Lloh133
	.loh AdrpLdr	Lloh134, Lloh135
	.loh AdrpLdr	Lloh136, Lloh137
	.loh AdrpLdr	Lloh138, Lloh139
	.loh AdrpLdr	Lloh140, Lloh141
	.loh AdrpLdr	Lloh142, Lloh143
	.loh AdrpLdr	Lloh144, Lloh145
	.loh AdrpLdr	Lloh146, Lloh147
	.loh AdrpLdr	Lloh148, Lloh149
	.loh AdrpLdr	Lloh152, Lloh153
	.loh AdrpLdr	Lloh150, Lloh151
	.loh AdrpLdr	Lloh154, Lloh155
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mark
_mark:                                  ; @mark
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh156:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh157:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0, #64]
	add	x9, x9, #1
	str	x9, [x0, #64]
	ldr	x9, [x0, #40]
	add	x9, x9, #1
	str	x9, [x0, #40]
	ldr	x9, [x8]
	cmp	x9, x2
	b.hi	LBB40_7
; %bb.1:
	ldr	x8, [x8, #16]
	sub	x10, x2, x9
	cmp	x10, x8
	b.hs	LBB40_7
; %bb.2:
	ldr	x11, [x1]
	ldr	w12, [x1, #20]
	lsr	x12, x10, x12
	ldr	x11, [x11, x12, lsl #3]
	sub	x13, x11, x9
	ldr	x11, [x0, #56]
	add	x11, x11, #1
LBB40_3:                                ; =>This Inner Loop Header: Depth=1
	cmp	x13, x8
	b.hs	LBB40_6
; %bb.4:                                ;   in Loop: Header=BB40_3 Depth=1
	mov	x12, x13
	str	x11, [x0, #56]
	ldr	x13, [x9, x13]
	add	x11, x11, #1
	add	x13, x13, x12
	cmp	x10, x13
	b.hs	LBB40_3
; %bb.5:
	add	x8, x9, x12
	ldr	x9, [x8, #24]
	cmp	x9, #0
	add	x10, x8, #32
	ccmp	x10, x2, #2, ne
	b.ls	LBB40_8
LBB40_6:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB40_7:
	ldr	x8, [x0, #48]
	add	x8, x8, #1
	str	x8, [x0, #48]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB40_8:
	ldr	x11, [x8, #8]
	sub	x10, x2, x10
	cmp	x10, x11
	b.hs	LBB40_10
; %bb.9:
	ldr	x11, [x0, #72]
	add	x11, x11, #1
	str	x11, [x0, #72]
LBB40_10:
	tbnz	w9, #1, LBB40_6
; %bb.11:
	ldr	x9, [x8, #8]
	cmp	x10, x9
	b.hs	LBB40_6
; %bb.12:
	ldr	x9, [x0, #80]
	add	x9, x9, #1
	str	x9, [x0, #80]
	ldr	x9, [x8, #16]
	orr	x9, x9, #0x2
	cmp	x9, #3
	b.ne	LBB40_14
; %bb.13:
	mov	w9, #7                          ; =0x7
	str	x9, [x8, #24]
	ldr	x8, [x1, #40]
	add	x8, x8, #1
	str	x8, [x1, #40]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB40_14:
	ldr	x9, [x3]
	orr	x9, x9, #0x3
	str	x9, [x8, #24]
	str	x8, [x3]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh156, Lloh157
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mark_frames
_mark_frames:                           ; @mark_frames
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB41_18
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x3
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
	b	LBB41_3
LBB41_2:                                ;   in Loop: Header=BB41_3 Depth=1
	ldr	x20, [x20]
	cbz	x20, LBB41_17
LBB41_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB41_7 Depth 2
                                        ;     Child Loop BB41_12 Depth 2
                                        ;     Child Loop BB41_16 Depth 2
	ldr	x8, [x20, #8]
	cmp	x8, x22
	b.ne	LBB41_2
; %bb.4:                                ;   in Loop: Header=BB41_3 Depth=1
	ldr	w23, [x20, #64]
	cbz	w23, LBB41_9
; %bb.5:                                ;   in Loop: Header=BB41_3 Depth=1
	ldr	x8, [x20, #48]
	add	x24, x8, #8
	b	LBB41_7
LBB41_6:                                ;   in Loop: Header=BB41_7 Depth=2
	add	x24, x24, #16
	subs	x23, x23, #1
	b.eq	LBB41_9
LBB41_7:                                ;   Parent Loop BB41_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [x24]
	cmp	w8, #8
	b.ne	LBB41_6
; %bb.8:                                ;   in Loop: Header=BB41_7 Depth=2
	ldur	x8, [x24, #-8]
	ldr	x2, [x8]
	add	x0, x22, #1048
	mov	x1, x21
	mov	x3, x19
	bl	_mark
	b	LBB41_6
LBB41_9:                                ;   in Loop: Header=BB41_3 Depth=1
	ldr	w23, [x20, #88]
	cbz	w23, LBB41_14
; %bb.10:                               ;   in Loop: Header=BB41_3 Depth=1
	ldr	x8, [x20, #72]
	add	x24, x8, #8
	b	LBB41_12
LBB41_11:                               ;   in Loop: Header=BB41_12 Depth=2
	add	x24, x24, #16
	subs	x23, x23, #1
	b.eq	LBB41_14
LBB41_12:                               ;   Parent Loop BB41_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [x24]
	cmp	w8, #8
	b.ne	LBB41_11
; %bb.13:                               ;   in Loop: Header=BB41_12 Depth=2
	ldur	x8, [x24, #-8]
	ldr	x2, [x8]
	add	x0, x22, #1048
	mov	x1, x21
	mov	x3, x19
	bl	_mark
	b	LBB41_11
LBB41_14:                               ;   in Loop: Header=BB41_3 Depth=1
	ldr	w8, [x20, #36]
	cbz	w8, LBB41_2
; %bb.15:                               ;   in Loop: Header=BB41_3 Depth=1
	mov	x23, #0                         ; =0x0
LBB41_16:                               ;   Parent Loop BB41_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x20, #16]
	ldr	x2, [x8, x23, lsl #3]
	add	x0, x22, #1048
	mov	x1, x21
	mov	x3, x19
	bl	_mark
	add	x23, x23, #1
	ldr	w8, [x20, #36]
	cmp	x23, x8
	b.lo	LBB41_16
	b	LBB41_2
LBB41_17:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
LBB41_18:
	ret
	.cfi_endproc
                                        ; -- End function
.tbss _trigger_profile$tlv$init, 128, 3 ; @trigger_profile

	.section	__DATA,__thread_vars,thread_local_variables
_trigger_profile:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_trigger_profile$tlv$init

.tbss _lookup_profile$tlv$init, 96, 3   ; @lookup_profile

_lookup_profile:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_lookup_profile$tlv$init

.tbss _profile$tlv$init, 584, 3         ; @profile

_profile:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_profile$tlv$init

.tbss _owned_heap$tlv$init, 2088, 3     ; @owned_heap

_owned_heap:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_owned_heap$tlv$init

.tbss _resource_head$tlv$init, 8, 3     ; @resource_head

_resource_head:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_resource_head$tlv$init

.tbss _host_head$tlv$init, 8, 3         ; @host_head

_host_head:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_host_head$tlv$init

.tbss _host_roots$tlv$init, 14336, 3    ; @host_roots

_host_roots:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_host_roots$tlv$init

	.section	__DATA,__data
	.p2align	3, 0x0                          ; @next_host_handle
_next_host_handle:
	.quad	1                               ; 0x1

.subsections_via_symbols
