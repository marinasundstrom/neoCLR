	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 26, 2	sdk_version 26, 2
	.globl	_neoclr_gc_trigger_profile_v1   ; -- Begin function neoclr_gc_trigger_profile_v1
	.p2align	2
_neoclr_gc_trigger_profile_v1:          ; @neoclr_gc_trigger_profile_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh0:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh1:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0, #64]
	stp	q0, q1, [x8, #64]
	ldp	q0, q1, [x0, #96]
	stp	q0, q1, [x8, #96]
	ldp	q0, q1, [x0]
	stp	q0, q1, [x8]
	ldp	q0, q1, [x0, #32]
	stp	q0, q1, [x8, #32]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_trigger_profile_reset_v1 ; -- Begin function neoclr_gc_trigger_profile_reset_v1
	.p2align	2
_neoclr_gc_trigger_profile_reset_v1:    ; @neoclr_gc_trigger_profile_reset_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh2:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh3:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #96]
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_lookup_profile_v1    ; -- Begin function neoclr_gc_lookup_profile_v1
	.p2align	2
_neoclr_gc_lookup_profile_v1:           ; @neoclr_gc_lookup_profile_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh4:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh5:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0, #32]
	stp	q0, q1, [x8, #32]
	ldp	q0, q1, [x0, #64]
	stp	q0, q1, [x8, #64]
	ldp	q0, q1, [x0]
	stp	q0, q1, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_lookup_profile_reset_v1 ; -- Begin function neoclr_gc_lookup_profile_reset_v1
	.p2align	2
_neoclr_gc_lookup_profile_reset_v1:     ; @neoclr_gc_lookup_profile_reset_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh6:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh7:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_profile_v1           ; -- Begin function neoclr_gc_profile_v1
	.p2align	2
_neoclr_gc_profile_v1:                  ; @neoclr_gc_profile_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh8:
	adrp	x0, _profile@TLVPPAGE
Lloh9:
	ldr	x0, [x0, _profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x1, x0
	mov	x0, x8
	mov	w2, #584                        ; =0x248
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_memcpy
	.loh AdrpLdr	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_profile_reset_v1     ; -- Begin function neoclr_gc_profile_reset_v1
	.p2align	2
_neoclr_gc_profile_reset_v1:            ; @neoclr_gc_profile_reset_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh10:
	adrp	x0, _profile@TLVPPAGE
Lloh11:
	ldr	x0, [x0, _profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w1, #584                        ; =0x248
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_bzero
	.loh AdrpLdr	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_index_counts     ; -- Begin function experiment_gc_index_counts
	.p2align	2
_experiment_gc_index_counts:            ; @experiment_gc_index_counts
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh12:
	adrp	x0, _owned_index_counts@TLVPPAGE
Lloh13:
	ldr	x0, [x0, _owned_index_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	q0, [x0]
	ldr	x9, [x0, #16]
	str	x9, [x8, #16]
	str	q0, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh12, Lloh13
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_heap_acquire_v1      ; -- Begin function neoclr_gc_heap_acquire_v1
	.p2align	2
_neoclr_gc_heap_acquire_v1:             ; @neoclr_gc_heap_acquire_v1
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
Lloh14:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh15:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB7_11
; %bb.1:
	ldr	x9, [x8]
	cbnz	x9, LBB7_11
; %bb.2:
	ldp	x9, x10, [x19, #8]
	and	x11, x10, #0x7
	cmp	x10, x9
	ccmp	x11, #0, #0, ls
	b.ne	LBB7_11
; %bb.3:
	ldr	x21, [x19]
	cmp	x21, #0
	ccmp	x9, #0, #4, eq
	and	x11, x21, #0x7
	orr	x10, x11, x10
	ccmp	x10, #0, #0, eq
	b.ne	LBB7_11
; %bb.4:
	mov	x24, x8
	lsr	x8, x9, #9
	tst	x9, #0x1ff
	cinc	x22, x8, ne
	lsr	x8, x22, #6
	tst	x22, #0x3f
	cinc	x23, x8, ne
	add	x20, x23, x22
	cbz	x22, LBB7_7
; %bb.5:
	mov	x0, x20
	mov	w1, #8                          ; =0x8
	bl	_calloc
	mov	x8, x0
	cbnz	x0, LBB7_8
; %bb.6:
	mov	w0, #3                          ; =0x3
	b	LBB7_11
LBB7_7:
	mov	x8, #0                          ; =0x0
LBB7_8:
Lloh16:
	adrp	x0, _owned_index_counts@TLVPPAGE
Lloh17:
	ldr	x0, [x0, _owned_index_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	cmp	x22, #0
	lsl	x9, x20, #3
	ldr	x10, [x0]
	cinc	x10, x10, ne
	stp	x10, x9, [x0]
	ldr	x10, [x0, #16]
	cmp	x9, x10
	b.ls	LBB7_10
; %bb.9:
	str	x9, [x0, #16]
LBB7_10:
	mov	w0, #0                          ; =0x0
	str	x8, [x24, #2088]
	add	x8, x8, x22, lsl #3
	cmp	x22, #0
	csel	x8, x8, xzr, ne
	str	x8, [x24, #2096]
	str	x22, [x24, #2104]
	str	x23, [x24, #2112]
	stp	x19, x21, [x24]
	ldr	x8, [x19, #8]
	stp	x8, xzr, [x24, #16]
	str	xzr, [x24, #32]
LBB7_11:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_heap_release_v1      ; -- Begin function neoclr_gc_heap_release_v1
	.p2align	2
_neoclr_gc_heap_release_v1:             ; @neoclr_gc_heap_release_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh18:
	adrp	x0, _native_scope_depth@TLVPPAGE
Lloh19:
	ldr	x0, [x0, _native_scope_depth@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w8, [x0]
	cbz	w8, LBB8_3
LBB8_1:
	mov	w0, #3                          ; =0x3
LBB8_2:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB8_3:
Lloh20:
	adrp	x0, _live_owner@TLVPPAGE
Lloh21:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w8, [x0, #8]
	cbz	w8, LBB8_5
; %bb.4:
	mov	x20, x0
	bl	_candidate_dispose
Lloh22:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh23:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0, #16]
	add	x8, x8, #1
	str	x8, [x0, #16]
	str	xzr, [x20]
	str	wzr, [x20, #8]
LBB8_5:
	bl	_shadow_stop
	cbz	x19, LBB8_1
; %bb.6:
Lloh24:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh25:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	ldr	x9, [x0]
	mov	w0, #3                          ; =0x3
	cmp	x9, x19
	b.ne	LBB8_2
; %bb.7:
	mov	w21, #3                         ; =0x3
	mov	x0, x19
	bl	_blocks_valid
	cmp	w0, #0
	csel	w21, w21, wzr, eq
	ldr	x0, [x20, #2088]
	bl	_free
Lloh26:
	adrp	x0, _owned_index_counts@TLVPPAGE
Lloh27:
	ldr	x0, [x0, _owned_index_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	xzr, [x0, #8]
	mov	x0, x20
	mov	w1, #2120                       ; =0x848
	bl	_bzero
	mov	x0, x21
	b	LBB8_2
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function shadow_stop
_shadow_stop:                           ; @shadow_stop
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh28:
	adrp	x0, _shadow_owner@TLVPPAGE
Lloh29:
	ldr	x0, [x0, _shadow_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x20, [x0]
	cbz	x20, LBB9_8
; %bb.1:
	mov	x19, x0
	bl	_shadow_drain
	add	x0, x20, #8
	bl	_pthread_mutex_lock
	cbnz	w0, LBB9_9
; %bb.2:
	mov	w8, #1                          ; =0x1
	str	w8, [x20, #136]
	add	x0, x20, #72
	bl	_pthread_cond_broadcast
	cbnz	w0, LBB9_9
; %bb.3:
	add	x0, x20, #8
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB9_9
; %bb.4:
	ldr	x0, [x20]
	mov	x1, #0                          ; =0x0
	bl	_pthread_join
	cbnz	w0, LBB9_9
; %bb.5:
	add	x0, x20, #72
	bl	_pthread_cond_destroy
	cbnz	w0, LBB9_9
; %bb.6:
	add	x0, x20, #8
	bl	_pthread_mutex_destroy
	cbnz	w0, LBB9_9
; %bb.7:
	mov	x0, x20
	bl	_free
	str	xzr, [x19]
LBB9_8:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB9_9:
	bl	_abort
	.loh AdrpLdr	Lloh28, Lloh29
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function blocks_valid
_blocks_valid:                          ; @blocks_valid
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB10_12
; %bb.1:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh30:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh31:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x10, [x0]
	cmp	x10, x8
	b.eq	LBB10_7
; %bb.2:
	ldp	x9, x11, [x8, #8]
LBB10_3:
	and	x12, x11, #0x7
	cmp	x11, x9
	ccmp	x12, #0, #0, ls
	b.ne	LBB10_10
; %bb.4:
	ldr	x12, [x8]
	cmp	x12, #0
	ccmp	x9, #0, #4, eq
	and	x9, x12, #0x7
	ccmp	x9, #0, #0, eq
	b.ne	LBB10_10
; %bb.5:
	ldr	x9, [x0, #32]
	cmp	x10, x8
	csel	x9, x9, xzr, eq
	cbz	x11, LBB10_26
; %bb.6:
	mov	x13, #0                         ; =0x0
	b	LBB10_15
LBB10_7:
	ldr	x9, [x8]
	ldr	x11, [x0, #8]
	cmp	x9, x11
	b.ne	LBB10_10
; %bb.8:
	ldr	x9, [x8, #8]
	ldr	x11, [x0, #16]
	cmp	x9, x11
	b.ne	LBB10_10
; %bb.9:
	ldr	x11, [x8, #16]
	ldr	x12, [x0, #24]
	cmp	x11, x12
	b.eq	LBB10_3
LBB10_10:
	mov	w0, #0                          ; =0x0
LBB10_11:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB10_12:
	ret
LBB10_13:                               ;   in Loop: Header=BB10_15 Depth=1
	cmp	x10, x8
	b.eq	LBB10_23
LBB10_14:                               ;   in Loop: Header=BB10_15 Depth=1
	add	x13, x14, x13
	cmp	x13, x11
	b.hs	LBB10_26
LBB10_15:                               ; =>This Inner Loop Header: Depth=1
	sub	x16, x11, x13
	cmp	x16, #32
	b.lo	LBB10_25
; %bb.16:                               ;   in Loop: Header=BB10_15 Depth=1
	add	x15, x12, x13
	ldr	x14, [x15]
	cmp	x14, x16
	b.hi	LBB10_25
; %bb.17:                               ;   in Loop: Header=BB10_15 Depth=1
	and	x16, x14, #0x7
	cmp	x14, #40
	ccmp	x16, #0, #0, hs
	b.ne	LBB10_25
; %bb.18:                               ;   in Loop: Header=BB10_15 Depth=1
	ldr	x16, [x15, #24]
	cmp	x16, #7
	b.hi	LBB10_25
; %bb.19:                               ;   in Loop: Header=BB10_15 Depth=1
	cbz	x16, LBB10_13
; %bb.20:                               ;   in Loop: Header=BB10_15 Depth=1
	tbz	w16, #0, LBB10_25
; %bb.21:                               ;   in Loop: Header=BB10_15 Depth=1
	ldr	x16, [x15, #8]
	sub	x17, x14, #32
	sub	x16, x16, #1
	cmp	x16, x17
	b.hs	LBB10_25
; %bb.22:                               ;   in Loop: Header=BB10_15 Depth=1
	ldr	x15, [x15, #16]
	sub	x15, x15, #7
	cmn	x15, #6
	b.hs	LBB10_14
	b	LBB10_25
LBB10_23:                               ;   in Loop: Header=BB10_15 Depth=1
	orr	x16, x13, #0x1
	cmp	x9, x16
	b.ne	LBB10_25
; %bb.24:                               ;   in Loop: Header=BB10_15 Depth=1
	ldr	x9, [x15, #8]
	b	LBB10_14
LBB10_25:
	mov	w8, #0                          ; =0x0
	b	LBB10_27
LBB10_26:
	mov	w8, #1                          ; =0x1
LBB10_27:
	cmp	x9, #0
	csel	w0, wzr, w8, ne
	b	LBB10_11
	.loh AdrpLdr	Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_allocation_info_v1   ; -- Begin function neoclr_gc_allocation_info_v1
	.p2align	2
_neoclr_gc_allocation_info_v1:          ; @neoclr_gc_allocation_info_v1
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB11_8
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	cbz	x1, LBB11_7
; %bb.2:
	mov	x21, x2
	cbz	x2, LBB11_7
; %bb.3:
	mov	x19, x3
	cbz	x3, LBB11_7
; %bb.4:
	add	x0, x8, #1048
	mov	x1, x20
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB11_6
; %bb.5:
	mov	w0, #0                          ; =0x0
	ldur	x8, [x20, #-24]
	str	x8, [x21]
	ldur	x8, [x20, #-16]
	str	w8, [x19]
	b	LBB11_7
LBB11_6:
	mov	w0, #3                          ; =0x3
LBB11_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB11_8:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function validated_bases
_validated_bases:                       ; @validated_bases
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh32:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh33:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x10, [x0]
	add	x10, x10, #1
	str	x10, [x0]
	cbz	x8, LBB12_13
; %bb.1:
	mov	x9, x0
Lloh34:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh35:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x11, [x0]
	cmp	x11, x8
	b.eq	LBB12_10
; %bb.2:
	ldp	x14, x12, [x8, #8]
LBB12_3:
	mov	w10, #0                         ; =0x0
	cmp	x12, x14
	b.hi	LBB12_14
; %bb.4:
	and	x13, x12, #0x7
	cbnz	x13, LBB12_14
; %bb.5:
	mov	w10, #0                         ; =0x0
	ldr	x13, [x8]
	cmp	x13, #0
	ccmp	x14, #0, #4, eq
	b.ne	LBB12_14
; %bb.6:
	and	x14, x13, #0x7
	cbnz	x14, LBB12_14
; %bb.7:
	cmp	x11, x8
	b.eq	LBB12_27
LBB12_8:
	ldr	x10, [x9, #16]
	add	x10, x10, #1
	str	x10, [x9, #16]
	cmp	x1, #0
	cset	w10, eq
	cmp	x2, #0
	cset	w15, eq
	mov	x14, #0                         ; =0x0
	cbz	x12, LBB12_39
; %bb.9:
	cmp	x2, #0
	cset	w15, eq
	cmp	x1, #0
	cset	w16, eq
	ldr	x10, [x9, #24]
	add	x17, x10, #1
	b	LBB12_17
LBB12_10:
	ldr	x10, [x8]
	ldr	x12, [x0, #8]
	cmp	x10, x12
	b.ne	LBB12_13
; %bb.11:
	ldr	x14, [x8, #8]
	ldr	x10, [x0, #16]
	cmp	x14, x10
	b.ne	LBB12_13
; %bb.12:
	ldr	x12, [x8, #16]
	ldr	x10, [x0, #24]
	cmp	x12, x10
	b.eq	LBB12_3
LBB12_13:
	mov	w10, #0                         ; =0x0
LBB12_14:
	mov	x0, x10
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB12_15:                               ;   in Loop: Header=BB12_17 Depth=1
	add	x10, x4, #32
	cmp	x10, x1
	cset	w4, eq
	orr	w16, w16, w4
	cmp	x10, x2
	cset	w10, eq
	orr	w15, w15, w10
LBB12_16:                               ;   in Loop: Header=BB12_17 Depth=1
	add	x17, x17, #1
	add	x14, x3, x14
	cmp	x14, x12
	b.hs	LBB12_38
LBB12_17:                               ; =>This Inner Loop Header: Depth=1
	cbz	w16, LBB12_19
; %bb.18:                               ;   in Loop: Header=BB12_17 Depth=1
	cbnz	w15, LBB12_38
LBB12_19:                               ;   in Loop: Header=BB12_17 Depth=1
	str	x17, [x9, #24]
	sub	x5, x12, x14
	cmp	x5, #32
	b.lo	LBB12_13
; %bb.20:                               ;   in Loop: Header=BB12_17 Depth=1
	mov	w10, #0                         ; =0x0
	add	x4, x13, x14
	ldr	x3, [x4]
	cmp	x3, x5
	b.hi	LBB12_14
; %bb.21:                               ;   in Loop: Header=BB12_17 Depth=1
	and	x5, x3, #0x7
	cmp	x3, #40
	ccmp	x5, #0, #0, hs
	b.ne	LBB12_14
; %bb.22:                               ;   in Loop: Header=BB12_17 Depth=1
	ldr	x10, [x4, #24]
	cmp	x10, #7
	b.hi	LBB12_13
; %bb.23:                               ;   in Loop: Header=BB12_17 Depth=1
	cbz	x10, LBB12_16
; %bb.24:                               ;   in Loop: Header=BB12_17 Depth=1
	tbz	w10, #0, LBB12_13
; %bb.25:                               ;   in Loop: Header=BB12_17 Depth=1
	ldr	x10, [x4, #8]
	sub	x5, x3, #32
	sub	x10, x10, #1
	cmp	x10, x5
	b.hs	LBB12_13
; %bb.26:                               ;   in Loop: Header=BB12_17 Depth=1
	ldr	x10, [x4, #16]
	sub	x10, x10, #7
	cmn	x10, #6
	b.hs	LBB12_15
	b	LBB12_13
LBB12_27:
	cbz	x1, LBB12_32
; %bb.28:
	ubfx	x10, x1, #3, #29
	eor	w10, w10, w1, lsr #9
	add	x10, x0, w10, uxtb #3
	ldr	x10, [x10, #40]
	cmp	x10, x1
	b.eq	LBB12_32
; %bb.29:
	ldr	x10, [x0, #8]
	cmp	x10, x1
	b.hi	LBB12_8
; %bb.30:
	sub	x10, x1, x10
	ldr	x14, [x0, #24]
	and	x15, x10, #0x7
	cmp	x15, #0
	ccmp	x10, x14, #2, eq
	b.hs	LBB12_8
; %bb.31:
	lsr	x14, x10, #3
	ldr	x15, [x0, #2088]
	lsr	x10, x10, #6
	and	x10, x10, #0x3fffffffffffff8
	ldr	x10, [x15, x10]
	lsr	x10, x10, x14
	tbz	w10, #0, LBB12_8
LBB12_32:
	cbz	x2, LBB12_37
; %bb.33:
	ubfx	x10, x2, #3, #29
	eor	w10, w10, w2, lsr #9
	add	x10, x0, w10, uxtb #3
	ldr	x10, [x10, #40]
	cmp	x10, x2
	b.eq	LBB12_37
; %bb.34:
	ldr	x10, [x0, #8]
	cmp	x10, x2
	b.hi	LBB12_8
; %bb.35:
	sub	x10, x2, x10
	ldr	x14, [x0, #24]
	and	x15, x10, #0x7
	cmp	x15, #0
	ccmp	x10, x14, #2, eq
	b.hs	LBB12_8
; %bb.36:
	lsr	x14, x10, #3
	ldr	x15, [x0, #2088]
	lsr	x10, x10, #6
	and	x10, x10, #0x3fffffffffffff8
	ldr	x10, [x15, x10]
	lsr	x10, x10, x14
	tbz	w10, #0, LBB12_8
LBB12_37:
	ldr	x8, [x9, #8]
	add	x8, x8, #1
	str	x8, [x9, #8]
	mov	w10, #1                         ; =0x1
	b	LBB12_14
LBB12_38:
	cmp	w16, #0
	cset	w10, ne
	cmp	w15, #0
	cset	w15, ne
LBB12_39:
	cmp	x14, x12
	b.hs	LBB12_52
; %bb.40:
	ldr	x16, [x9, #24]
	b	LBB12_42
LBB12_41:                               ;   in Loop: Header=BB12_42 Depth=1
	add	x16, x16, #1
	add	x14, x17, x14
	cmp	x14, x12
	b.hs	LBB12_51
LBB12_42:                               ; =>This Inner Loop Header: Depth=1
	sub	x4, x12, x14
	cmp	x4, #32
	b.lo	LBB12_50
; %bb.43:                               ;   in Loop: Header=BB12_42 Depth=1
	add	x3, x13, x14
	ldr	x17, [x3]
	cmp	x17, x4
	b.hi	LBB12_50
; %bb.44:                               ;   in Loop: Header=BB12_42 Depth=1
	and	x4, x17, #0x7
	cmp	x17, #40
	ccmp	x4, #0, #0, hs
	b.ne	LBB12_50
; %bb.45:                               ;   in Loop: Header=BB12_42 Depth=1
	ldr	x4, [x3, #24]
	cmp	x4, #7
	b.hi	LBB12_50
; %bb.46:                               ;   in Loop: Header=BB12_42 Depth=1
	cbz	x4, LBB12_41
; %bb.47:                               ;   in Loop: Header=BB12_42 Depth=1
	tbz	w4, #0, LBB12_50
; %bb.48:                               ;   in Loop: Header=BB12_42 Depth=1
	ldr	x4, [x3, #8]
	sub	x5, x17, #32
	sub	x4, x4, #1
	cmp	x4, x5
	b.hs	LBB12_50
; %bb.49:                               ;   in Loop: Header=BB12_42 Depth=1
	ldr	x3, [x3, #16]
	sub	x3, x3, #7
	cmn	x3, #6
	b.hs	LBB12_41
LBB12_50:
	mov	w10, #0                         ; =0x0
	add	x8, x16, #1
	str	x8, [x9, #24]
	b	LBB12_14
LBB12_51:
	str	x16, [x9, #24]
LBB12_52:
	cmp	x11, x8
	cset	w8, eq
	and	w8, w8, w10
	and	w8, w8, w15
	cmp	w8, #1
	b.ne	LBB12_57
; %bb.53:
	cbz	x1, LBB12_55
; %bb.54:
	ubfx	x8, x1, #3, #29
	eor	w8, w8, w1, lsr #9
	add	x8, x0, w8, uxtb #3
	str	x1, [x8, #40]
LBB12_55:
	cbz	x2, LBB12_57
; %bb.56:
	ubfx	x8, x2, #3, #29
	eor	w8, w8, w2, lsr #9
	add	x8, x0, w8, uxtb #3
	str	x2, [x8, #40]
LBB12_57:
	and	w10, w10, w15
	b	LBB12_14
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpLdr	Lloh34, Lloh35
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_resource_attach_v1   ; -- Begin function neoclr_gc_resource_attach_v1
	.p2align	2
_neoclr_gc_resource_attach_v1:          ; @neoclr_gc_resource_attach_v1
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x4
	mov	x21, x3
	mov	x19, x2
	mov	x22, x1
	mov	x23, x0
Lloh36:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh37:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x4, LBB13_15
; %bb.1:
	cbz	x19, LBB13_15
; %bb.2:
	cbz	x22, LBB13_15
; %bb.3:
	cbz	x23, LBB13_15
; %bb.4:
	ldr	w8, [x8, #88]
	cbnz	w8, LBB13_15
; %bb.5:
	add	x0, x23, #1048
	mov	x1, x22
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB13_14
; %bb.6:
Lloh38:
	adrp	x0, _resource_head@TLVPPAGE
Lloh39:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB13_11
; %bb.7:
	mov	w9, #0                          ; =0x0
	mov	x10, x8
LBB13_8:                                ; =>This Inner Loop Header: Depth=1
	cmp	x10, x19
	b.eq	LBB13_14
; %bb.9:                                ;   in Loop: Header=BB13_8 Depth=1
	ldr	x11, [x10]
	cmp	x11, x23
	cinc	w9, w9, eq
	ldr	x10, [x10, #32]
	cbnz	x10, LBB13_8
; %bb.10:
	cmp	w9, #1023
	cset	w9, hi
	ldr	x10, [x19]
	cbnz	x10, LBB13_14
	b	LBB13_12
LBB13_11:
	mov	w9, #0                          ; =0x0
	ldr	x10, [x19]
	cbnz	x10, LBB13_14
LBB13_12:
	ldr	x10, [x19, #8]
	cbnz	x10, LBB13_14
; %bb.13:
	ldr	x10, [x19, #16]
	cbz	x10, LBB13_16
LBB13_14:
	mov	w0, #3                          ; =0x3
LBB13_15:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB13_16:
	mov	x10, x0
	ldr	x11, [x19, #24]
	mov	w0, #3                          ; =0x3
	cbnz	x11, LBB13_15
; %bb.17:
	ldr	x11, [x19, #32]
	cmp	x11, #0
	cset	w11, ne
	orr	w9, w11, w9
	mov	w11, #5                         ; =0x5
	csel	w0, w0, w11, ne
	tbnz	w9, #0, LBB13_15
; %bb.18:
	mov	w0, #0                          ; =0x0
	stp	x23, x22, [x19]
	stp	x21, x20, [x19, #16]
	str	x8, [x19, #32]
	str	x19, [x10]
	b	LBB13_15
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpLdr	Lloh38, Lloh39
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_resource_release_v1  ; -- Begin function neoclr_gc_resource_release_v1
	.p2align	2
_neoclr_gc_resource_release_v1:         ; @neoclr_gc_resource_release_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh40:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh41:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x19, x0
	ldr	w11, [x0, #88]
Lloh42:
	adrp	x0, _resource_head@TLVPPAGE
Lloh43:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	w9, #3                          ; =0x3
	cbz	x1, LBB14_8
; %bb.1:
	cbz	x8, LBB14_8
; %bb.2:
	ldr	x10, [x0]
	cmp	w11, #0
	ccmp	x10, #0, #4, eq
	b.ne	LBB14_4
	b	LBB14_8
LBB14_3:                                ;   in Loop: Header=BB14_4 Depth=1
	ldr	x9, [x10, #32]!
	mov	x0, x10
	mov	x10, x9
	cbz	x9, LBB14_7
LBB14_4:                                ; =>This Inner Loop Header: Depth=1
	cmp	x10, x1
	b.ne	LBB14_3
; %bb.5:                                ;   in Loop: Header=BB14_4 Depth=1
	ldr	x9, [x10]
	cmp	x9, x8
	b.ne	LBB14_3
; %bb.6:
	ldp	x8, x9, [x10, #16]
	ldr	x11, [x10, #32]
	str	x11, [x0]
	str	xzr, [x10, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x10]
	mov	w10, #1                         ; =0x1
	str	w10, [x19, #88]
	mov	x0, x8
	blr	x9
	mov	w9, #0                          ; =0x0
	str	wzr, [x19, #88]
	b	LBB14_8
LBB14_7:
	mov	w9, #3                          ; =0x3
LBB14_8:
	mov	x0, x9
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpLdr	Lloh40, Lloh41
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_host_root_create_v1  ; -- Begin function neoclr_gc_host_root_create_v1
	.p2align	2
_neoclr_gc_host_root_create_v1:         ; @neoclr_gc_host_root_create_v1
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB15_15
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	cbz	x2, LBB15_14
; %bb.2:
	mov	x20, x1
	mov	x21, x8
	add	x0, x8, #1048
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB15_7
; %bb.3:
Lloh44:
	adrp	x0, _host_roots@TLVPPAGE
Lloh45:
	ldr	x0, [x0, _host_roots@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w8, #256                        ; =0x100
LBB15_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x0]
	cbz	x9, LBB15_8
; %bb.5:                                ;   in Loop: Header=BB15_4 Depth=1
	add	x0, x0, #56
	subs	x8, x8, #1
	b.ne	LBB15_4
LBB15_6:
	mov	w0, #5                          ; =0x5
	b	LBB15_14
LBB15_7:
	mov	w0, #3                          ; =0x3
	b	LBB15_14
LBB15_8:
Lloh46:
	adrp	x8, _next_host_handle@PAGE
Lloh47:
	ldr	x10, [x8, _next_host_handle@PAGEOFF]
Lloh48:
	adrp	x8, _next_host_handle@PAGE
Lloh49:
	add	x8, x8, _next_host_handle@PAGEOFF
LBB15_9:                                ; =>This Inner Loop Header: Depth=1
	cmn	x10, #1
	b.eq	LBB15_6
; %bb.10:                               ;   in Loop: Header=BB15_9 Depth=1
	mov	x9, x10
	add	x11, x10, #1
	cas	x10, x11, [x8]
	cmp	x10, x9
	b.ne	LBB15_9
; %bb.11:
Lloh50:
	adrp	x8, _host_head@TLVPPAGE
Lloh51:
	ldr	x8, [x8, _host_head@TLVPPAGEOFF]
	ldr	x11, [x8]
	mov	x10, x0
	mov	x0, x8
	blr	x11
	mov	x8, x0
	ldr	x11, [x0]
	stp	x21, x20, [x10]
	stp	xzr, xzr, [x10, #16]
	stp	x9, xzr, [x10, #32]
	str	x11, [x10, #48]
	cbz	x11, LBB15_13
; %bb.12:
	str	x10, [x11, #40]
LBB15_13:
	mov	w0, #0                          ; =0x0
	str	x10, [x8]
	str	x9, [x19]
LBB15_14:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB15_15:
	ret
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpLdr	Lloh50, Lloh51
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_gc_host_root_create_owned_v1
lCPI16_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_gc_host_root_create_owned_v1
	.p2align	2
_neoclr_gc_host_root_create_owned_v1:   ; @neoclr_gc_host_root_create_owned_v1
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x1, LBB16_16
; %bb.1:
	cbz	x8, LBB16_16
; %bb.2:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x3
	cbz	x3, LBB16_15
; %bb.3:
	mov	x21, x2
	mov	x20, x1
	mov	x22, x8
	add	x0, x8, #1048
	mov	x1, x2
	mov	x2, x20
	bl	_validated_bases
	cbz	w0, LBB16_8
; %bb.4:
Lloh52:
	adrp	x0, _host_roots@TLVPPAGE
Lloh53:
	ldr	x0, [x0, _host_roots@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w8, #256                        ; =0x100
LBB16_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x0]
	cbz	x9, LBB16_9
; %bb.6:                                ;   in Loop: Header=BB16_5 Depth=1
	add	x0, x0, #56
	subs	x8, x8, #1
	b.ne	LBB16_5
LBB16_7:
	mov	w0, #5                          ; =0x5
	b	LBB16_15
LBB16_8:
	mov	w0, #3                          ; =0x3
	b	LBB16_15
LBB16_9:
Lloh54:
	adrp	x8, _next_host_handle@PAGE
Lloh55:
	ldr	x10, [x8, _next_host_handle@PAGEOFF]
Lloh56:
	adrp	x8, _next_host_handle@PAGE
Lloh57:
	add	x8, x8, _next_host_handle@PAGEOFF
LBB16_10:                               ; =>This Inner Loop Header: Depth=1
	cmn	x10, #1
	b.eq	LBB16_7
; %bb.11:                               ;   in Loop: Header=BB16_10 Depth=1
	mov	x9, x10
	add	x11, x10, #1
	cas	x10, x11, [x8]
	cmp	x10, x9
	b.ne	LBB16_10
; %bb.12:
Lloh58:
	adrp	x8, _host_head@TLVPPAGE
Lloh59:
	ldr	x8, [x8, _host_head@TLVPPAGEOFF]
	ldr	x11, [x8]
	mov	x10, x0
	mov	x0, x8
	blr	x11
	mov	x8, x0
	ldr	x11, [x0]
	stp	x22, x21, [x10]
	str	x20, [x10, #16]
Lloh60:
	adrp	x12, lCPI16_0@PAGE
Lloh61:
	ldr	d0, [x12, lCPI16_0@PAGEOFF]
	str	d0, [x10, #24]
	stp	x9, xzr, [x10, #32]
	str	x11, [x10, #48]
	cbz	x11, LBB16_14
; %bb.13:
	str	x10, [x11, #40]
LBB16_14:
	mov	w0, #0                          ; =0x0
	str	x10, [x8]
	str	x9, [x19]
LBB16_15:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB16_16:
	ret
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdd	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpLdr	Lloh58, Lloh59
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_host_root_replace_v1 ; -- Begin function neoclr_gc_host_root_replace_v1
	.p2align	2
_neoclr_gc_host_root_replace_v1:        ; @neoclr_gc_host_root_replace_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh62:
	adrp	x0, _host_head@TLVPPAGE
Lloh63:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB17_8
; %bb.1:
	cbz	x1, LBB17_8
; %bb.2:
	ldr	x19, [x9]
	cbnz	x19, LBB17_4
	b	LBB17_8
LBB17_3:                                ;   in Loop: Header=BB17_4 Depth=1
	ldr	x19, [x19, #48]
	cbz	x19, LBB17_7
LBB17_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	cmp	x9, x8
	b.ne	LBB17_3
; %bb.5:                                ;   in Loop: Header=BB17_4 Depth=1
	ldr	x9, [x19, #32]
	cmp	x9, x1
	b.ne	LBB17_3
; %bb.6:
	ldr	w9, [x19, #28]
	cbz	w9, LBB17_9
LBB17_7:
	mov	w0, #3                          ; =0x3
LBB17_8:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB17_9:
	add	x0, x8, #1048
	mov	x20, x2
	mov	x1, x2
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB17_7
; %bb.10:
	mov	w0, #0                          ; =0x0
	str	x20, [x19, #8]
	b	LBB17_8
	.loh AdrpLdr	Lloh62, Lloh63
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_host_root_read_v1    ; -- Begin function neoclr_gc_host_root_read_v1
	.p2align	2
_neoclr_gc_host_root_read_v1:           ; @neoclr_gc_host_root_read_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh64:
	adrp	x0, _host_head@TLVPPAGE
Lloh65:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB18_3
; %bb.1:
	cbz	x1, LBB18_3
; %bb.2:
	ldr	x9, [x9]
	cbnz	x9, LBB18_5
LBB18_3:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB18_4:                                ;   in Loop: Header=BB18_5 Depth=1
	ldr	x9, [x9, #48]
	cbz	x9, LBB18_10
LBB18_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9]
	cmp	x10, x8
	b.ne	LBB18_4
; %bb.6:                                ;   in Loop: Header=BB18_5 Depth=1
	ldr	x10, [x9, #32]
	cmp	x10, x1
	b.ne	LBB18_4
; %bb.7:
	mov	w0, #3                          ; =0x3
	cbz	x2, LBB18_3
; %bb.8:
	ldr	w8, [x9, #28]
	cbnz	w8, LBB18_3
; %bb.9:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x9, #8]
	str	x8, [x2]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB18_10:
	mov	w0, #3                          ; =0x3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh64, Lloh65
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_host_root_release_v1 ; -- Begin function neoclr_gc_host_root_release_v1
	.p2align	2
_neoclr_gc_host_root_release_v1:        ; @neoclr_gc_host_root_release_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh66:
	adrp	x0, _host_head@TLVPPAGE
Lloh67:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	w9, #3                          ; =0x3
	cbz	x8, LBB19_10
; %bb.1:
	cbz	x1, LBB19_10
; %bb.2:
	ldr	x10, [x0]
	cbnz	x10, LBB19_4
	b	LBB19_10
LBB19_3:                                ;   in Loop: Header=BB19_4 Depth=1
	ldr	x10, [x10, #48]
	cbz	x10, LBB19_9
LBB19_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x10]
	cmp	x9, x8
	b.ne	LBB19_3
; %bb.5:                                ;   in Loop: Header=BB19_4 Depth=1
	ldr	x9, [x10, #32]
	cmp	x9, x1
	b.ne	LBB19_3
; %bb.6:
	ldp	x8, x9, [x10, #40]
	add	x11, x8, #48
	cmp	x8, #0
	csel	x11, x0, x11, eq
	str	x9, [x11]
	cbz	x9, LBB19_8
; %bb.7:
	str	x8, [x9, #40]
LBB19_8:
	mov	w9, #0                          ; =0x0
	str	xzr, [x10, #48]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x10, #16]
	str	q0, [x10]
	b	LBB19_10
LBB19_9:
	mov	w9, #3                          ; =0x3
LBB19_10:
	mov	x0, x9
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh66, Lloh67
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_callback_read_v1     ; -- Begin function neoclr_gc_callback_read_v1
	.p2align	2
_neoclr_gc_callback_read_v1:            ; @neoclr_gc_callback_read_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x21, x1
	mov	x20, x0
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB20_3
LBB20_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x20
	b.eq	LBB20_18
; %bb.2:                                ;   in Loop: Header=BB20_1 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB20_1
LBB20_3:
Lloh68:
	adrp	x0, _host_head@TLVPPAGE
Lloh69:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x20, LBB20_19
; %bb.4:
	cbz	x21, LBB20_19
; %bb.5:
	ldr	x22, [x8]
	cbnz	x22, LBB20_7
	b	LBB20_19
LBB20_6:                                ;   in Loop: Header=BB20_7 Depth=1
	ldr	x22, [x22, #48]
	cbz	x22, LBB20_18
LBB20_7:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x22]
	cmp	x8, x20
	b.ne	LBB20_6
; %bb.8:                                ;   in Loop: Header=BB20_7 Depth=1
	ldr	x8, [x22, #32]
	cmp	x8, x21
	b.ne	LBB20_6
; %bb.9:
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB20_19
; %bb.10:
	ldr	w8, [x22, #24]
	cbnz	w8, LBB20_19
; %bb.11:
	ldr	x1, [x22, #8]
	cbz	x1, LBB20_19
; %bb.12:
	ldr	w8, [x20]
	cbnz	w8, LBB20_19
; %bb.13:
	add	x0, x20, #1048
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB20_18
; %bb.14:
	ldr	x8, [x22, #8]
	ldur	x9, [x8, #-16]
	cmp	x9, #2
	b.ne	LBB20_18
; %bb.15:
	ldur	x9, [x8, #-24]
	cmp	x9, #24
	b.ne	LBB20_18
; %bb.16:
	ldr	x9, [x8]
	mov	w10, #-1                        ; =0xffffffff
	cmp	x9, x10
	b.ne	LBB20_18
; %bb.17:
	mov	w0, #0                          ; =0x0
	str	x8, [x19]
	b	LBB20_19
LBB20_18:
	mov	w0, #3                          ; =0x3
LBB20_19:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh68, Lloh69
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_callback_read_suspended_v1 ; -- Begin function neoclr_gc_callback_read_suspended_v1
	.p2align	2
_neoclr_gc_callback_read_suspended_v1:  ; @neoclr_gc_callback_read_suspended_v1
	.cfi_startproc
; %bb.0:
	cbz	x3, LBB21_5
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x3
	mov	x19, x0
	mov	x22, x1
	mov	x21, x2
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x20
	b.ne	LBB21_3
; %bb.2:
	ldr	x8, [x20, #8]
	cmp	x8, x19
	b.eq	LBB21_6
LBB21_3:
	mov	w0, #3                          ; =0x3
LBB21_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB21_5:
	mov	w0, #3                          ; =0x3
	ret
LBB21_6:
Lloh70:
	adrp	x0, _host_head@TLVPPAGE
Lloh71:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB21_4
; %bb.7:
	cbz	x22, LBB21_4
; %bb.8:
	ldr	x20, [x8]
	cbz	x20, LBB21_4
; %bb.9:
	mov	x9, x22
	mov	x8, x21
	b	LBB21_11
LBB21_10:                               ;   in Loop: Header=BB21_11 Depth=1
	ldr	x20, [x20, #48]
	cbz	x20, LBB21_3
LBB21_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x20]
	cmp	x10, x19
	b.ne	LBB21_10
; %bb.12:                               ;   in Loop: Header=BB21_11 Depth=1
	ldr	x10, [x20, #32]
	cmp	x10, x9
	b.ne	LBB21_10
; %bb.13:
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB21_4
; %bb.14:
	ldr	w8, [x20, #24]
	cbnz	w8, LBB21_4
; %bb.15:
	ldr	x1, [x20, #8]
	cbz	x1, LBB21_4
; %bb.16:
	ldr	w8, [x19]
	cbnz	w8, LBB21_4
; %bb.17:
	add	x0, x19, #1048
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB21_3
; %bb.18:
	ldr	x8, [x20, #8]
	ldur	x9, [x8, #-16]
	cmp	x9, #2
	b.ne	LBB21_3
; %bb.19:
	ldur	x9, [x8, #-24]
	cmp	x9, #24
	b.ne	LBB21_3
; %bb.20:
	ldr	x9, [x8]
	mov	w10, #-1                        ; =0xffffffff
	cmp	x9, x10
	b.ne	LBB21_3
; %bb.21:
	mov	w0, #0                          ; =0x0
	str	x8, [x21]
	b	LBB21_4
	.loh AdrpLdr	Lloh70, Lloh71
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_roots_park_owned_v1  ; -- Begin function neoclr_gc_roots_park_owned_v1
	.p2align	2
_neoclr_gc_roots_park_owned_v1:         ; @neoclr_gc_roots_park_owned_v1
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB22_11
; %bb.1:
	cbz	x1, LBB22_11
; %bb.2:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	cbz	x2, LBB22_10
; %bb.3:
	mov	x21, x8
	add	x0, x8, #1048
	mov	x20, x1
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB22_9
; %bb.4:
	ldr	x8, [x19]
	cbnz	x8, LBB22_9
; %bb.5:
	ldr	x8, [x19, #8]
	cbnz	x8, LBB22_9
; %bb.6:
	ldr	x8, [x19, #16]
	cbnz	x8, LBB22_9
; %bb.7:
	ldr	x8, [x19, #24]
	cbnz	x8, LBB22_9
; %bb.8:
	ldr	w8, [x19, #32]
	cbz	w8, LBB22_12
LBB22_9:
	mov	w0, #3                          ; =0x3
LBB22_10:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB22_11:
	ret
LBB22_12:
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB22_15
LBB22_13:                               ; =>This Inner Loop Header: Depth=1
	cmp	x0, x19
	b.eq	LBB22_9
; %bb.14:                               ;   in Loop: Header=BB22_13 Depth=1
	ldr	x0, [x0, #8]
	cbnz	x0, LBB22_13
LBB22_15:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB22_18
LBB22_16:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x21
	b.ne	LBB22_9
; %bb.17:                               ;   in Loop: Header=BB22_16 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB22_16
LBB22_18:
	mov	x0, x19
	bl	_neoclr_roots_park_v1
	mov	w0, #0                          ; =0x0
	stp	x21, x20, [x19, #16]
	b	LBB22_10
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_complete_invocation_v1 ; -- Begin function neoclr_gc_complete_invocation_v1
	.p2align	2
_neoclr_gc_complete_invocation_v1:      ; @neoclr_gc_complete_invocation_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB23_13
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	add	x20, x0, #1048
	mov	x0, x20
	bl	_blocks_valid
	cbz	w0, LBB23_14
; %bb.2:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB23_5
LBB23_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x19
	b.eq	LBB23_14
; %bb.4:                                ;   in Loop: Header=BB23_3 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB23_3
LBB23_5:
Lloh72:
	adrp	x0, _live_owner@TLVPPAGE
Lloh73:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w8, [x0, #8]
	cbz	w8, LBB23_7
; %bb.6:
	mov	x21, x0
	bl	_candidate_dispose
Lloh74:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh75:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0, #16]
	add	x8, x8, #1
	str	x8, [x0, #16]
	str	xzr, [x21]
	str	wzr, [x21, #8]
LBB23_7:
	ldr	x8, [x19, #1064]
	cbz	x8, LBB23_15
; %bb.8:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x20]
	mov	w11, #3                         ; =0x3
	b	LBB23_10
LBB23_9:                                ;   in Loop: Header=BB23_10 Depth=1
	ldr	x12, [x12]
	add	x9, x12, x9
	cmp	x9, x8
	b.hs	LBB23_15
LBB23_10:                               ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9
	ldrb	w13, [x12, #24]
	tbz	w13, #0, LBB23_9
; %bb.11:                               ;   in Loop: Header=BB23_10 Depth=1
	ldr	x13, [x12, #16]
	cmp	x13, #6
	b.ne	LBB23_9
; %bb.12:                               ;   in Loop: Header=BB23_10 Depth=1
	str	x11, [x12, #16]
	b	LBB23_9
LBB23_13:
	mov	w0, #3                          ; =0x3
	ret
LBB23_14:
	mov	w0, #3                          ; =0x3
	b	LBB23_16
LBB23_15:
	mov	w0, #0                          ; =0x0
	str	xzr, [x19, #1072]
LBB23_16:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpLdr	Lloh74, Lloh75
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_entry_check_v1       ; -- Begin function neoclr_gc_entry_check_v1
	.p2align	2
_neoclr_gc_entry_check_v1:              ; @neoclr_gc_entry_check_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh76:
	adrp	x0, _resource_head@TLVPPAGE
Lloh77:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB24_3
LBB24_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x19
	b.eq	LBB24_18
; %bb.2:                                ;   in Loop: Header=BB24_1 Depth=1
	ldr	x8, [x8, #32]
	cbnz	x8, LBB24_1
LBB24_3:
	cbz	x19, LBB24_18
; %bb.4:
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB24_10
LBB24_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB24_7 Depth 2
	ldr	x8, [x0, #16]
	cmp	x8, x19
	b.eq	LBB24_18
; %bb.6:                                ;   in Loop: Header=BB24_5 Depth=1
	mov	x8, x0
LBB24_7:                                ;   Parent Loop BB24_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x8]
	cbz	x8, LBB24_9
; %bb.8:                                ;   in Loop: Header=BB24_7 Depth=2
	ldr	x9, [x8, #8]
	cmp	x9, x19
	b.ne	LBB24_7
	b	LBB24_18
LBB24_9:                                ;   in Loop: Header=BB24_5 Depth=1
	ldr	x0, [x0, #8]
	cbnz	x0, LBB24_5
LBB24_10:
Lloh78:
	adrp	x0, _host_head@TLVPPAGE
Lloh79:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB24_13
LBB24_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x19
	b.eq	LBB24_18
; %bb.12:                               ;   in Loop: Header=BB24_11 Depth=1
	ldr	x8, [x8, #48]
	cbnz	x8, LBB24_11
LBB24_13:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB24_16
LBB24_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x19
	b.eq	LBB24_18
; %bb.15:                               ;   in Loop: Header=BB24_14 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB24_14
LBB24_16:
Lloh80:
	adrp	x0, _live_owner@TLVPPAGE
Lloh81:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w8, [x0, #8]
	cbz	w8, LBB24_20
; %bb.17:
	mov	x19, x0
	bl	_candidate_dispose
Lloh82:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh83:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldr	x9, [x8, #16]
	add	x9, x9, #1
	str	x9, [x8, #16]
	str	xzr, [x19]
	str	wzr, [x19, #8]
	b	LBB24_19
LBB24_18:
	mov	w0, #3                          ; =0x3
LBB24_19:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB24_20:
	mov	w0, #0                          ; =0x0
	b	LBB24_19
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpLdr	Lloh82, Lloh83
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_owned_roots_check_v1 ; -- Begin function neoclr_gc_owned_roots_check_v1
	.p2align	2
_neoclr_gc_owned_roots_check_v1:        ; @neoclr_gc_owned_roots_check_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh84:
	adrp	x0, _resource_head@TLVPPAGE
Lloh85:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB25_3
LBB25_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x19
	b.eq	LBB25_32
; %bb.2:                                ;   in Loop: Header=BB25_1 Depth=1
	ldr	x8, [x8, #32]
	cbnz	x8, LBB25_1
LBB25_3:
	mov	w8, #3                          ; =0x3
	cbz	x19, LBB25_33
; %bb.4:
	cmp	w2, #256
	b.hi	LBB25_33
; %bb.5:
	cbnz	x1, LBB25_7
; %bb.6:
	cbnz	w2, LBB25_33
LBB25_7:
	mov	x20, x1
	mov	x21, x2
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB25_13
LBB25_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB25_10 Depth 2
	ldr	x8, [x0, #16]
	cmp	x8, x19
	b.eq	LBB25_32
; %bb.9:                                ;   in Loop: Header=BB25_8 Depth=1
	mov	x8, x0
LBB25_10:                               ;   Parent Loop BB25_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x8]
	cbz	x8, LBB25_12
; %bb.11:                               ;   in Loop: Header=BB25_10 Depth=2
	ldr	x9, [x8, #8]
	cmp	x9, x19
	b.ne	LBB25_10
	b	LBB25_32
LBB25_12:                               ;   in Loop: Header=BB25_8 Depth=1
	ldr	x0, [x0, #8]
	cbnz	x0, LBB25_8
LBB25_13:
	bl	_neoclr_root_probe_head_v1
	mov	x9, x21
	mov	x10, x20
	cbz	x0, LBB25_16
LBB25_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x19
	b.eq	LBB25_32
; %bb.15:                               ;   in Loop: Header=BB25_14 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB25_14
LBB25_16:
Lloh86:
	adrp	x0, _host_head@TLVPPAGE
Lloh87:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	cbz	w9, LBB25_29
; %bb.17:
	ldr	x11, [x0]
	cbz	x11, LBB25_32
; %bb.18:
	mov	x12, #0                         ; =0x0
	mov	w13, w9
LBB25_19:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB25_22 Depth 2
                                        ;     Child Loop BB25_26 Depth 2
	ldr	x14, [x10, x12, lsl #3]
	cbz	x14, LBB25_32
; %bb.20:                               ;   in Loop: Header=BB25_19 Depth=1
	mov	x15, x11
	b	LBB25_22
LBB25_21:                               ;   in Loop: Header=BB25_22 Depth=2
	ldr	x15, [x15, #48]
	mov	w8, #3                          ; =0x3
	cbz	x15, LBB25_33
LBB25_22:                               ;   Parent Loop BB25_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x15]
	cmp	x8, x19
	b.ne	LBB25_21
; %bb.23:                               ;   in Loop: Header=BB25_22 Depth=2
	ldr	x8, [x15, #32]
	cmp	x8, x14
	b.ne	LBB25_21
; %bb.24:                               ;   in Loop: Header=BB25_19 Depth=1
	cbz	x12, LBB25_28
; %bb.25:                               ;   in Loop: Header=BB25_19 Depth=1
	mov	x8, #0                          ; =0x0
LBB25_26:                               ;   Parent Loop BB25_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x15, [x10, x8, lsl #3]
	cmp	x15, x14
	b.eq	LBB25_32
; %bb.27:                               ;   in Loop: Header=BB25_26 Depth=2
	add	x8, x8, #1
	cmp	x12, x8
	b.ne	LBB25_26
LBB25_28:                               ;   in Loop: Header=BB25_19 Depth=1
	add	x12, x12, #1
	cmp	x12, x13
	b.ne	LBB25_19
LBB25_29:
	ldr	x8, [x0]
	cbz	x8, LBB25_34
; %bb.30:
	mov	w10, #0                         ; =0x0
LBB25_31:                               ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x8]
	cmp	x11, x19
	cinc	w10, w10, eq
	ldr	x8, [x8, #48]
	cbnz	x8, LBB25_31
	b	LBB25_35
LBB25_32:
	mov	w8, #3                          ; =0x3
LBB25_33:
	mov	x0, x8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB25_34:
	mov	w10, #0                         ; =0x0
LBB25_35:
	mov	w8, #3                          ; =0x3
	cmp	w10, w9
	csel	w8, wzr, w8, eq
	b	LBB25_33
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpLdr	Lloh86, Lloh87
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_allocate_v1          ; -- Begin function neoclr_gc_allocate_v1
	.p2align	2
_neoclr_gc_allocate_v1:                 ; @neoclr_gc_allocate_v1
	.cfi_startproc
; %bb.0:
	mov	w8, #3                          ; =0x3
	cbz	x0, LBB26_19
; %bb.1:
	cbz	x3, LBB26_19
; %bb.2:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
Lloh88:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh89:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x21, [x0]
	cmp	x21, x19
	b.eq	LBB26_14
; %bb.3:
	ldp	x9, x10, [x19, #8]
LBB26_4:
	mov	w8, #3                          ; =0x3
	subs	x13, x9, x10
	b.lo	LBB26_18
; %bb.5:
	and	x11, x10, #0x7
	cbnz	x11, LBB26_18
; %bb.6:
	ldr	x11, [x19]
	cbz	x9, LBB26_8
; %bb.7:
	cbz	x11, LBB26_18
LBB26_8:
	sub	w9, w2, #7
	cmn	w9, #6
	b.lo	LBB26_18
; %bb.9:
	cbz	x1, LBB26_18
; %bb.10:
	and	x9, x11, #0x7
	cbnz	x9, LBB26_18
; %bb.11:
	add	x8, x1, #7
	and	x8, x8, #0xfffffffffffffff8
	add	x9, x8, #32
	cmn	x1, #40
	csinv	x15, x9, xzr, ls
	add	x14, x0, #32
	cmp	x21, x19
	b.eq	LBB26_30
; %bb.12:
	mov	x12, #0                         ; =0x0
	cbz	x10, LBB26_44
; %bb.13:
	mov	x16, #0                         ; =0x0
	b	LBB26_22
LBB26_14:
	ldr	x8, [x19]
	ldr	x9, [x0, #8]
	cmp	x8, x9
	b.ne	LBB26_17
; %bb.15:
	ldr	x9, [x19, #8]
	ldr	x8, [x0, #16]
	cmp	x9, x8
	b.ne	LBB26_17
; %bb.16:
	ldr	x10, [x19, #16]
	ldr	x8, [x0, #24]
	cmp	x10, x8
	b.eq	LBB26_4
LBB26_17:
	mov	w8, #3                          ; =0x3
LBB26_18:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
LBB26_19:
	mov	x0, x8
	ret
LBB26_20:                               ;   in Loop: Header=BB26_22 Depth=1
	cmp	x17, x15
	csel	x8, xzr, x4, lo
	cmp	x12, #0
	csel	x12, x12, x8, ne
LBB26_21:                               ;   in Loop: Header=BB26_22 Depth=1
	add	x16, x17, x16
	cmp	x16, x10
	b.hs	LBB26_44
LBB26_22:                               ; =>This Inner Loop Header: Depth=1
	sub	x5, x10, x16
	cmp	x5, #32
	b.lo	LBB26_17
; %bb.23:                               ;   in Loop: Header=BB26_22 Depth=1
	add	x4, x11, x16
	ldr	x17, [x4]
	mov	w8, #3                          ; =0x3
	cmp	x17, x5
	b.hi	LBB26_18
; %bb.24:                               ;   in Loop: Header=BB26_22 Depth=1
	and	x5, x17, #0x7
	cmp	x17, #40
	ccmp	x5, #0, #0, hs
	b.ne	LBB26_18
; %bb.25:                               ;   in Loop: Header=BB26_22 Depth=1
	ldr	x8, [x4, #24]
	cmp	x8, #7
	b.hi	LBB26_17
; %bb.26:                               ;   in Loop: Header=BB26_22 Depth=1
	cbz	x8, LBB26_20
; %bb.27:                               ;   in Loop: Header=BB26_22 Depth=1
	tbz	w8, #0, LBB26_17
; %bb.28:                               ;   in Loop: Header=BB26_22 Depth=1
	ldr	x8, [x4, #8]
	sub	x5, x17, #32
	sub	x8, x8, #1
	cmp	x8, x5
	b.hs	LBB26_17
; %bb.29:                               ;   in Loop: Header=BB26_22 Depth=1
	ldr	x8, [x4, #16]
	sub	x8, x8, #7
	cmn	x8, #6
	b.hs	LBB26_21
	b	LBB26_17
LBB26_30:
	ldr	x16, [x14]
	cbz	x16, LBB26_43
LBB26_31:                               ; =>This Inner Loop Header: Depth=1
	sub	x5, x16, #1
	and	x8, x5, #0x7
	cmp	x8, #0
	ccmp	x10, x5, #0, eq
	b.ls	LBB26_17
; %bb.32:                               ;   in Loop: Header=BB26_31 Depth=1
	sub	x16, x10, x5
	cmp	x16, #32
	b.lo	LBB26_17
; %bb.33:                               ;   in Loop: Header=BB26_31 Depth=1
	add	x12, x11, x5
	ldr	x17, [x12]
	mov	w8, #3                          ; =0x3
	cmp	x17, x16
	b.hi	LBB26_18
; %bb.34:                               ;   in Loop: Header=BB26_31 Depth=1
	and	x16, x17, #0x7
	cmp	x17, #40
	ccmp	x16, #0, #0, hs
	b.ne	LBB26_18
; %bb.35:                               ;   in Loop: Header=BB26_31 Depth=1
	ldr	x8, [x12, #24]
	cbnz	x8, LBB26_17
; %bb.36:                               ;   in Loop: Header=BB26_31 Depth=1
	mov	x4, x12
	ldr	x16, [x4, #8]!
	cbz	x16, LBB26_40
; %bb.37:                               ;   in Loop: Header=BB26_31 Depth=1
	sub	x6, x16, #1
	add	x8, x17, x5
	cmp	x6, x8
	b.lo	LBB26_17
; %bb.38:                               ;   in Loop: Header=BB26_31 Depth=1
	mov	w8, #3                          ; =0x3
	cmp	x6, x10
	b.hs	LBB26_18
; %bb.39:                               ;   in Loop: Header=BB26_31 Depth=1
	and	x5, x6, #0x7
	cbnz	x5, LBB26_18
LBB26_40:                               ;   in Loop: Header=BB26_31 Depth=1
	cmp	x17, x15
	b.hs	LBB26_44
; %bb.41:                               ;   in Loop: Header=BB26_31 Depth=1
	mov	x14, x4
	cbnz	x16, LBB26_31
; %bb.42:
	mov	x12, #0                         ; =0x0
	mov	x14, x4
	b	LBB26_44
LBB26_43:
	mov	x12, #0                         ; =0x0
LBB26_44:
	cmn	x1, #40
	b.ls	LBB26_46
LBB26_45:
	mov	w8, #5                          ; =0x5
	b	LBB26_18
LBB26_46:
	cbz	x12, LBB26_50
; %bb.47:
	cmp	x21, x19
	b.eq	LBB26_52
; %bb.48:
	mov	x22, x3
	ldr	x8, [x12]
	sub	x10, x8, x9
	cmp	x10, #40
	b.lo	LBB26_56
; %bb.49:
	add	x8, x12, x9
	stp	x10, xzr, [x8]
	stp	xzr, xzr, [x8, #16]
	str	x9, [x12]
	b	LBB26_57
LBB26_50:
	cmp	x9, x13
	b.hi	LBB26_45
; %bb.51:
	mov	x22, x3
	add	x12, x11, x10
	str	x9, [x12]
	add	x8, x10, x9
	str	x8, [x19, #16]
	cmp	x21, x19
	b.ne	LBB26_57
	b	LBB26_55
LBB26_52:
	ldp	x10, x8, [x12]
	sub	x10, x10, x9
	mov	x22, x3
	cmp	x10, #39
	b.ls	LBB26_54
; %bb.53:
	add	x13, x12, x9
	sub	x11, x13, x11
	stp	x10, x8, [x13]
	stp	xzr, xzr, [x13, #16]
	add	x8, x11, #1
	str	x9, [x12]
LBB26_54:
	str	x8, [x14]
LBB26_55:
	ldr	x8, [x19, #16]
	str	x8, [x0, #24]
	ldr	x9, [x12]
	b	LBB26_57
LBB26_56:
	mov	x9, x8
LBB26_57:
	mov	x24, x0
	mov	w8, w2
	mov	x23, x1
	stp	x1, x8, [x12, #8]
	mov	w8, #1                          ; =0x1
	str	x8, [x12, #24]
	add	x20, x12, #32
	sub	x1, x9, #32
	mov	x0, x20
	bl	_bzero
	cmp	x21, x19
	b.ne	LBB26_59
; %bb.58:
	ubfx	x8, x20, #3, #29
	eor	w8, w8, w20, lsr #9
	add	x8, x24, w8, uxtb #3
	str	x20, [x8, #40]
	ldr	x8, [x19]
	sub	x8, x20, x8
	lsr	x9, x8, #3
	lsr	x10, x8, #9
	mov	w11, #1                         ; =0x1
	lsl	x9, x11, x9
	ldr	x12, [x24, #2088]
	ldr	x13, [x12, x10, lsl #3]
	orr	x9, x9, x13
	str	x9, [x12, x10, lsl #3]
	lsl	x9, x11, x10
	ldr	x10, [x24, #2096]
	lsr	x8, x8, #12
	and	x8, x8, #0xffffffffffff8
	ldr	x11, [x10, x8]
	orr	x9, x11, x9
	str	x9, [x10, x8]
LBB26_59:
	str	x20, [x22]
Lloh90:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh91:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0, #32]
	add	x8, x8, #1
	str	x8, [x0, #32]
Lloh92:
	adrp	x0, _profile@TLVPPAGE
Lloh93:
	ldr	x0, [x0, _profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldp	x8, x10, [x0, #32]
	add	x8, x8, x23
	str	x8, [x0, #32]
	ldr	x9, [x19, #16]
	cmp	x9, x10
	b.ls	LBB26_61
; %bb.60:
	mov	w8, #0                          ; =0x0
	str	x9, [x0, #40]
	b	LBB26_18
LBB26_61:
	mov	w8, #0                          ; =0x0
	b	LBB26_18
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpLdr	Lloh90, Lloh91
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function block_valid
_block_valid:                           ; @block_valid
	.cfi_startproc
; %bb.0:
	ldr	x9, [x0, #16]
	sub	x10, x9, x1
	cmp	x10, #32
	b.hs	LBB27_3
LBB27_1:
	mov	w0, #0                          ; =0x0
LBB27_2:
	ret
LBB27_3:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldr	x8, [x8]
	add	x8, x8, x1
	ldr	x9, [x8]
	cmp	x9, x10
	b.hi	LBB27_2
; %bb.4:
	and	x10, x9, #0x7
	cmp	x9, #40
	ccmp	x10, #0, #0, hs
	b.ne	LBB27_2
; %bb.5:
	ldr	x10, [x8, #24]
	cmp	x10, #7
	b.hi	LBB27_1
; %bb.6:
	cbz	x10, LBB27_11
; %bb.7:
	tbz	w10, #0, LBB27_1
; %bb.8:
	ldr	x10, [x8, #8]
	sub	x9, x9, #32
	sub	x10, x10, #1
	cmp	x10, x9
	b.hs	LBB27_1
; %bb.9:
	ldr	x8, [x8, #16]
	cbz	x8, LBB27_1
; %bb.10:
	cmp	x8, #7
	cset	w0, lo
	ret
LBB27_11:
	mov	w0, #1                          ; =0x1
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_gc_allocate_rooted_values_v1
lCPI28_0:
	.long	8                               ; 0x8
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_gc_allocate_rooted_values_v1
	.p2align	2
_neoclr_gc_allocate_rooted_values_v1:   ; @neoclr_gc_allocate_rooted_values_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #464
	stp	x28, x27, [sp, #368]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #384]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #400]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #416]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #432]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #448]            ; 16-byte Folded Spill
	add	x29, sp, #448
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh94:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh95:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh96:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	cmp	w3, #16
	b.hi	LBB28_5
; %bb.1:
	mov	x19, x0
	cmp	x2, #0
	ccmp	w3, #0, #4, eq
	cset	w9, ne
Lloh97:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh98:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB28_6
; %bb.2:
	tbnz	w9, #0, LBB28_6
; %bb.3:
	ldr	w8, [x8, #88]
	cbnz	w8, LBB28_6
; %bb.4:
	mov	x25, x2
	mov	x24, x3
	mov	x22, x4
	mov	x21, x5
	mov	x20, x6
	mov	x26, x1
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x26
	b.eq	LBB28_8
LBB28_5:
	mov	w0, #3                          ; =0x3
LBB28_6:
	ldur	x8, [x29, #-88]
Lloh99:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh100:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh101:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB28_25
; %bb.7:
	ldp	x29, x30, [sp, #448]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #432]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #416]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #400]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #384]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #368]            ; 16-byte Folded Reload
	add	sp, sp, #464
	ret
LBB28_8:
	mov	x8, x26
	cbz	x26, LBB28_10
; %bb.9:
	ldr	x8, [x8, #8]
	cmp	x8, x19
	b.ne	LBB28_5
LBB28_10:
	add	x0, x19, #1048
	mov	x23, x22
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	bl	_neoclr_gc_allocate_v1
	cmp	w0, #5
	b.ne	LBB28_6
; %bb.11:
	cmn	x23, #40
	b.hi	LBB28_13
; %bb.12:
	add	x11, x23, #7
	and	x11, x11, #0xfffffffffffffff8
	add	x11, x11, #32
	ldr	x12, [x19, #1056]
	cmp	x11, x12
	b.ls	LBB28_14
LBB28_13:
	mov	w0, #5                          ; =0x5
	b	LBB28_6
LBB28_14:
	mov	x9, x26
	mov	x8, x24
	mov	x1, x26
	cbz	w24, LBB28_23
; %bb.15:
	mov	x10, x25
	mov	w11, w8
	adrp	x12, lCPI28_0@PAGE
	cmp	w8, #3
	b.hi	LBB28_17
; %bb.16:
	mov	x13, #0                         ; =0x0
	b	LBB28_20
LBB28_17:
	and	x13, x11, #0x1c
	add	x14, sp, #104
	add	x14, x14, #32
	ldr	d0, [x12, lCPI28_0@PAGEOFF]
	mov	x15, x10
	mov	x16, x13
LBB28_18:                               ; =>This Inner Loop Header: Depth=1
	add	x17, x15, #8
	stur	x15, [x14, #-32]
	add	x0, x15, #16
	add	x1, x15, #24
	stur	x17, [x14, #-16]
	str	x0, [x14]
	str	x1, [x14, #16]
	stur	d0, [x14, #-24]
	stur	d0, [x14, #-8]
	str	d0, [x14, #8]
	str	d0, [x14, #24]
	add	x14, x14, #64
	add	x15, x15, #32
	subs	x16, x16, #4
	b.ne	LBB28_18
; %bb.19:
	cmp	x13, x11
	b.eq	LBB28_22
LBB28_20:
	add	x14, sp, #104
	add	x14, x14, x13, lsl #4
	add	x14, x14, #8
	add	x10, x10, x13, lsl #3
	sub	x11, x11, x13
	ldr	d0, [x12, lCPI28_0@PAGEOFF]
LBB28_21:                               ; =>This Inner Loop Header: Depth=1
	stur	x10, [x14, #-8]
	str	d0, [x14], #16
	add	x10, x10, #8
	subs	x11, x11, #1
	b.ne	LBB28_21
LBB28_22:
	mov	x1, sp
LBB28_23:
	stp	x9, x19, [sp]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #16]
	add	x9, sp, #104
	stp	x9, xzr, [sp, #48]
	str	w8, [sp, #64]
Lloh102:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh103:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x23, x0
	stur	q0, [sp, #68]
	stur	q0, [sp, #84]
	str	wzr, [sp, #100]
	ldr	x8, [x0, #16]
	add	x8, x8, #1
	str	x8, [x0, #16]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cmp	w0, #0
	ldr	x8, [x23, #80]
	cinc	x8, x8, ne
	str	x8, [x23, #80]
	cbnz	w0, LBB28_6
; %bb.24:
	add	x0, x19, #1048
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	bl	_neoclr_gc_allocate_v1
	b	LBB28_6
LBB28_25:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh94, Lloh95, Lloh96
	.loh AdrpLdr	Lloh97, Lloh98
	.loh AdrpLdrGotLdr	Lloh99, Lloh100, Lloh101
	.loh AdrpLdr	Lloh102, Lloh103
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_allocate_rooted_v1   ; -- Begin function neoclr_gc_allocate_rooted_v1
	.p2align	2
_neoclr_gc_allocate_rooted_v1:          ; @neoclr_gc_allocate_rooted_v1
	.cfi_startproc
; %bb.0:
	mov	x6, x4
	mov	x5, x3
	mov	x4, x2
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	b	_neoclr_gc_allocate_rooted_values_v1
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_collect_v1           ; -- Begin function neoclr_gc_collect_v1
	.p2align	2
_neoclr_gc_collect_v1:                  ; @neoclr_gc_collect_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh104:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh105:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x19, x0
	ldr	x9, [x0]
	add	x9, x9, #1
	str	x9, [x0]
	mov	x0, x8
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cmp	w0, #0
	ldr	x8, [x19, #64]
	cinc	x8, x8, ne
	str	x8, [x19, #64]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh104, Lloh105
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_shadow           ; -- Begin function experiment_gc_shadow
	.p2align	2
_experiment_gc_shadow:                  ; @experiment_gc_shadow
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh106:
	adrp	x0, _live_owner@TLVPPAGE
Lloh107:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w8, [x0, #8]
	cbnz	w8, LBB31_2
; %bb.1:
	bl	_shadow_stop
Lloh108:
	adrp	x0, _shadow_stats@TLVPPAGE
Lloh109:
	ldr	x0, [x0, _shadow_stats@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldp	q0, q1, [x0]
	ldr	x8, [x0, #32]
	str	x8, [x19, #32]
	stp	q0, q1, [x19]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB31_2:
	bl	_abort
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpLdr	Lloh108, Lloh109
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_collect_conditional_v1 ; -- Begin function neoclr_gc_collect_conditional_v1
	.p2align	2
_neoclr_gc_collect_conditional_v1:      ; @neoclr_gc_collect_conditional_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x0
Lloh110:
	adrp	x0, _native_scope_depth@TLVPPAGE
Lloh111:
	ldr	x0, [x0, _native_scope_depth@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x21, x0
	ldr	w8, [x0]
	cbz	w8, LBB32_4
; %bb.1:
Lloh112:
	adrp	x0, _native_scope_context@TLVPPAGE
Lloh113:
	ldr	x0, [x0, _native_scope_context@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	x9, x19
	b.eq	LBB32_3
; %bb.2:
	mov	w0, #3                          ; =0x3
	b	LBB32_13
LBB32_3:
Lloh114:
	adrp	x0, _native_scope_counts@TLVPPAGE
Lloh115:
	ldr	x0, [x0, _native_scope_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0, #16]
	add	x9, x9, #1
	str	x9, [x0, #16]
LBB32_4:
Lloh116:
	adrp	x0, _candidate_phase@TLVPPAGE
Lloh117:
	ldr	x0, [x0, _candidate_phase@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	w9, [x0]
	cbz	w9, LBB32_14
LBB32_5:
	mov	x22, x1
	mov	x21, x2
	mov	x20, x3
	add	x1, sp, #16
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB32_30
; %bb.6:
	mov	x0, x19
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	bl	_collect_conditional
	mov	x19, x0
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB32_30
; %bb.7:
	ldp	x8, x9, [sp]
	ldp	x10, x11, [sp, #16]
	sub	x8, x8, x10
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x8, x8, x10, x9
	sub	x9, x8, x11
	cmp	x9, #2
	b.lo	LBB32_10
; %bb.8:
	mov	x10, #0                         ; =0x0
	mov	x8, x9
LBB32_9:                                ; =>This Inner Loop Header: Depth=1
	lsr	x11, x8, #1
	add	x10, x10, #1
	cmp	x8, #3
	mov	x8, x11
	b.hi	LBB32_9
	b	LBB32_11
LBB32_10:
	mov	x10, #0                         ; =0x0
LBB32_11:
Lloh118:
	adrp	x0, _profile@TLVPPAGE
Lloh119:
	ldr	x0, [x0, _profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	add	x10, x0, x10, lsl #3
	ldr	x11, [x10, #72]
	add	x11, x11, #1
	str	x11, [x10, #72]
	mov	x0, x19
	cmp	w19, #0
	ldp	x11, x10, [x8, #16]
	cinc	x10, x10, ne
	str	x10, [x8, #24]
	mov	w10, #1                         ; =0x1
	dup.2d	v0, x10
	ldr	q1, [x8]
	mov.d	v0[1], x9
	add.2d	v0, v1, v0
	str	q0, [x8]
	cmp	x9, x11
	b.ls	LBB32_13
; %bb.12:
	str	x9, [x8, #16]
LBB32_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB32_14:
	mov	x22, x0
Lloh120:
	adrp	x0, _candidate_autostart@TLVPPAGE
Lloh121:
	ldr	x0, [x0, _candidate_autostart@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	w10, [x0]
Lloh122:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh123:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x11, [x0]
	add	x12, x19, #1048
Lloh124:
	adrp	x0, _live_owner@TLVPPAGE
Lloh125:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x20, x0
	ldr	w9, [x0, #8]
	cmp	w8, #0
	ccmp	x19, #0, #4, eq
	ccmp	w10, #0, #4, ne
	ccmp	x11, x12, #0, ne
	b.eq	LBB32_18
; %bb.15:
	cbz	w9, LBB32_5
; %bb.16:
	ldr	x8, [x20]
	cmp	x8, x19
	b.eq	LBB32_22
; %bb.17:
	mov	x21, x3
	mov	x23, x2
	mov	x22, x1
	bl	_candidate_dispose
	mov	x1, x22
	mov	x2, x23
	mov	x3, x21
Lloh126:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh127:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0, #16]
	add	x8, x8, #1
	str	x8, [x0, #16]
	str	xzr, [x20]
	str	wzr, [x20, #8]
	b	LBB32_5
LBB32_18:
	ldr	x8, [x20]
	cmp	w9, #0
	ccmp	x8, x19, #0, ne
	b.eq	LBB32_21
; %bb.19:
	cbz	w9, LBB32_24
; %bb.20:
	mov	x23, x3
	mov	x25, x2
	mov	x24, x1
	bl	_candidate_dispose
	mov	x1, x24
	mov	x2, x25
	mov	x3, x23
Lloh128:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh129:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0, #16]
	add	x8, x8, #1
	str	x8, [x0, #16]
	str	xzr, [x20]
	str	wzr, [x20, #8]
	ldr	w8, [x21]
	cmp	w8, #0
	cset	w8, ne
	b	LBB32_25
LBB32_21:
	mov	x0, x19
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	b	_experiment_gc_finish
LBB32_22:
	mov	x0, x19
	mov	x20, x1
	mov	x21, x2
	mov	x22, x3
	bl	_experiment_gc_finish
	cbnz	w0, LBB32_13
; %bb.23:
	mov	x1, x20
	mov	x2, x21
	mov	x3, x22
Lloh130:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh131:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	b	LBB32_5
LBB32_24:
	mov	w8, #0                          ; =0x0
LBB32_25:
Lloh132:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh133:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x21, x0
	mov	w0, #3                          ; =0x3
	tbnz	w8, #0, LBB32_13
; %bb.26:
	ldr	w8, [x21, #88]
	cbnz	w8, LBB32_13
; %bb.27:
	str	x19, [x20]
	mov	w23, #1                         ; =0x1
	str	w23, [x22]
	mov	x0, x19
	bl	_neoclr_gc_collect_conditional_v1
	str	wzr, [x22]
	cbz	w0, LBB32_29
; %bb.28:
	str	xzr, [x20]
	b	LBB32_13
LBB32_29:
	str	w23, [x20, #8]
Lloh134:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh135:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldr	x9, [x8]
	add	x9, x9, #1
	str	x9, [x8]
	str	x19, [x21, #56]
	ldur	q0, [x21, #24]
	ext.16b	v0, v0, v0, #8
	str	q0, [x21, #64]
	str	xzr, [x21, #80]
	b	LBB32_13
LBB32_30:
	bl	_abort
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpLdr	Lloh124, Lloh125
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpLdr	Lloh120, Lloh121
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpLdr	Lloh132, Lloh133
	.loh AdrpLdr	Lloh134, Lloh135
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function experiment_gc_finish
lCPI33_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_experiment_gc_finish
	.p2align	2
_experiment_gc_finish:                  ; @experiment_gc_finish
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	mov	w9, #32784                      ; =0x8010
Lloh136:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh137:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x20, x0
Lloh138:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh139:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh140:
	ldr	x8, [x8]
	stur	x8, [x29, #-72]
Lloh141:
	adrp	x0, _live_owner@TLVPPAGE
Lloh142:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w8, [x0, #8]
	cbz	w8, LBB33_2
; %bb.1:
	mov	x19, x0
	ldr	x8, [x0]
Lloh143:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh144:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	w9, [x0, #88]
	cmp	x8, x20
	ccmp	w9, #0, #0, eq
	b.eq	LBB33_3
LBB33_2:
	mov	w0, #3                          ; =0x3
	b	LBB33_13
LBB33_3:
	mov	x21, x1
	mov	x22, x2
	mov	x23, x3
	bl	_candidate_wait
Lloh145:
	adrp	x0, _shadow_owner@TLVPPAGE
Lloh146:
	ldr	x0, [x0, _shadow_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x24, [x0]
	ldr	x25, [x24, #120]
	str	xzr, [sp]
	ldp	x0, x1, [x25, #64]
	add	x2, sp, #8
	mov	x4, sp
	mov	w3, #4096                       ; =0x1000
	bl	_gate_drain
	cbz	w0, LBB33_15
; %bb.4:
	str	wzr, [x25, #156]
	mov	x3, x23
	mov	x2, x22
	mov	x1, x21
LBB33_5:
	ldr	w8, [x25, #156]
	cbz	w8, LBB33_11
; %bb.6:
	ldr	x8, [x25, #120]
	cbz	x8, LBB33_11
; %bb.7:
	add	x0, x24, #8
	bl	_pthread_mutex_lock
	cbnz	w0, LBB33_31
; %bb.8:
Lloh147:
	adrp	x8, lCPI33_0@PAGE
Lloh148:
	ldr	d0, [x8, lCPI33_0@PAGEOFF]
	str	d0, [x24, #128]
	add	x0, x24, #72
	bl	_pthread_cond_broadcast
	cbnz	w0, LBB33_31
; %bb.9:
	add	x0, x24, #8
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB33_31
; %bb.10:
	bl	_candidate_wait
	mov	x3, x23
	mov	x2, x22
	mov	x1, x21
LBB33_11:
Lloh149:
	adrp	x0, _candidate_phase@TLVPPAGE
Lloh150:
	ldr	x0, [x0, _candidate_phase@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x21, x0
	mov	w8, #2                          ; =0x2
	str	w8, [x0]
	mov	x0, x20
	bl	_neoclr_gc_collect_conditional_v1
	mov	x20, x0
	str	wzr, [x21]
	str	xzr, [x19]
	str	wzr, [x19, #8]
	bl	_candidate_dispose
	mov	x0, x20
	cbnz	w20, LBB33_13
; %bb.12:
Lloh151:
	adrp	x8, _candidate_counts@TLVPPAGE
Lloh152:
	ldr	x8, [x8, _candidate_counts@TLVPPAGEOFF]
	ldr	x10, [x8]
	mov	x9, x0
	mov	x0, x8
	blr	x10
	mov	x8, x0
	mov	x0, x9
	ldr	x9, [x8, #8]
	add	x9, x9, #1
	str	x9, [x8, #8]
LBB33_13:
	ldur	x8, [x29, #-72]
Lloh153:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh154:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh155:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB33_30
; %bb.14:
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #16
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB33_15:
	ldr	x9, [sp]
	ldr	x8, [x25, #88]
	add	x8, x8, x9
	str	x8, [x25, #88]
	mov	x3, x23
	mov	x2, x22
	mov	x1, x21
	cbz	x9, LBB33_5
; %bb.16:
	mov	x8, #0                          ; =0x0
	add	x10, sp, #8
	mov	w11, #1                         ; =0x1
	b	LBB33_18
LBB33_17:                               ;   in Loop: Header=BB33_18 Depth=1
	add	x8, x8, #1
	cmp	x8, x9
	b.hs	LBB33_5
LBB33_18:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB33_21 Depth 2
	ldr	x12, [x10, x8, lsl #3]
	ldr	x13, [x25]
	subs	x13, x12, x13
	b.lo	LBB33_17
; %bb.19:                               ;   in Loop: Header=BB33_18 Depth=1
	ldr	x12, [x25, #32]
	cmp	x13, x12
	b.hs	LBB33_17
; %bb.20:                               ;   in Loop: Header=BB33_18 Depth=1
	ldr	x12, [x25, #96]
	ldr	w14, [x25, #108]
	lsr	x14, x13, x14
	ldr	x12, [x12, x14, lsl #3]
	ldr	x16, [x25, #112]
	add	x15, x12, #1
	cmp	x16, x15
	csinc	x12, x16, x12, hi
	sub	x12, x12, #1
	ldr	x14, [x25, #40]
LBB33_21:                               ;   Parent Loop BB33_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x15, x16
	b.hs	LBB33_24
; %bb.22:                               ;   in Loop: Header=BB33_21 Depth=2
	ldr	x17, [x14, x15, lsl #3]
	add	x15, x15, #1
	cmp	x17, x13
	b.ls	LBB33_21
; %bb.23:                               ;   in Loop: Header=BB33_18 Depth=1
	sub	x12, x15, #2
LBB33_24:                               ;   in Loop: Header=BB33_18 Depth=1
	ldr	x15, [x25, #56]
	add	x15, x15, x12, lsl #5
	ldrb	w16, [x15, #24]
	tbz	w16, #0, LBB33_17
; %bb.25:                               ;   in Loop: Header=BB33_18 Depth=1
	ldr	x14, [x14, x12, lsl #3]
	add	x14, x14, #32
	subs	x13, x13, x14
	b.lo	LBB33_17
; %bb.26:                               ;   in Loop: Header=BB33_18 Depth=1
	cmn	x12, #1
	b.eq	LBB33_17
; %bb.27:                               ;   in Loop: Header=BB33_18 Depth=1
	ldr	x14, [x15, #8]
	cmp	x13, x14
	b.hs	LBB33_17
; %bb.28:                               ;   in Loop: Header=BB33_18 Depth=1
	ldr	x13, [x25, #16]
	ldrb	w14, [x13, x12]
	cbnz	w14, LBB33_17
; %bb.29:                               ;   in Loop: Header=BB33_18 Depth=1
	strb	w11, [x13, x12]
	ldr	x9, [x25, #48]
	ldr	x13, [x25, #120]
	add	x14, x13, #1
	str	x14, [x25, #120]
	str	x12, [x9, x13, lsl #3]
	ldr	x9, [sp]
	b	LBB33_17
LBB33_30:
	bl	___stack_chk_fail
LBB33_31:
	bl	_abort
	.loh AdrpLdr	Lloh141, Lloh142
	.loh AdrpLdrGotLdr	Lloh138, Lloh139, Lloh140
	.loh AdrpLdr	Lloh143, Lloh144
	.loh AdrpLdr	Lloh145, Lloh146
	.loh AdrpLdr	Lloh147, Lloh148
	.loh AdrpLdr	Lloh149, Lloh150
	.loh AdrpLdr	Lloh151, Lloh152
	.loh AdrpLdrGotLdr	Lloh153, Lloh154, Lloh155
	.loh AdrpLdrGot	Lloh136, Lloh137
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_begin            ; -- Begin function experiment_gc_begin
	.p2align	2
_experiment_gc_begin:                   ; @experiment_gc_begin
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
Lloh156:
	adrp	x0, _native_scope_depth@TLVPPAGE
Lloh157:
	ldr	x0, [x0, _native_scope_depth@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w9, [x0]
Lloh158:
	adrp	x0, _live_owner@TLVPPAGE
Lloh159:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	ldr	w10, [x0, #8]
Lloh160:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh161:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB34_5
; %bb.1:
	ldr	w11, [x8, #88]
	cmp	w9, #0
	ccmp	w10, #0, #0, eq
	ccmp	w11, #0, #0, eq
	b.ne	LBB34_5
; %bb.2:
	mov	x22, x8
	str	x19, [x20]
Lloh162:
	adrp	x0, _candidate_phase@TLVPPAGE
Lloh163:
	ldr	x0, [x0, _candidate_phase@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x21, x0
	mov	w23, #1                         ; =0x1
	str	w23, [x0]
	mov	x0, x19
	bl	_neoclr_gc_collect_conditional_v1
	str	wzr, [x21]
	cbz	w0, LBB34_4
; %bb.3:
	str	xzr, [x20]
	b	LBB34_5
LBB34_4:
	str	w23, [x20, #8]
Lloh164:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh165:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldr	x9, [x8]
	add	x9, x9, #1
	str	x9, [x8]
	str	x19, [x22, #56]
	ldur	q0, [x22, #24]
	ext.16b	v0, v0, v0, #8
	str	q0, [x22, #64]
	str	xzr, [x22, #80]
LBB34_5:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh160, Lloh161
	.loh AdrpLdr	Lloh158, Lloh159
	.loh AdrpLdr	Lloh156, Lloh157
	.loh AdrpLdr	Lloh162, Lloh163
	.loh AdrpLdr	Lloh164, Lloh165
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_conditional
_collect_conditional:                   ; @collect_conditional
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #2368
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x8, x0
Lloh166:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh167:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh168:
	ldr	x9, [x9]
	stur	x9, [x29, #-72]
Lloh169:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh170:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	w9, #3                          ; =0x3
	cbz	x8, LBB35_45
; %bb.1:
	ldr	w10, [x0, #88]
	cbnz	w10, LBB35_45
; %bb.2:
Lloh171:
	adrp	x0, _live_owner@TLVPPAGE
Lloh172:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cbz	x9, LBB35_4
; %bb.3:
Lloh173:
	adrp	x0, _candidate_phase@TLVPPAGE
Lloh174:
	ldr	x0, [x0, _candidate_phase@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	w10, [x0]
	cmp	x9, x8
	ccmp	w10, #0, #4, eq
	b.eq	LBB35_44
LBB35_4:
	add	x10, x8, #1048
Lloh175:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh176:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x11, [x0]
	cmp	x11, x10
	b.eq	LBB35_14
; %bb.5:
	ldr	x12, [x8, #1064]
	ldr	x14, [x8, #1056]
LBB35_6:
	mov	w9, #3                          ; =0x3
	cmp	x12, x14
	b.hi	LBB35_45
; %bb.7:
	and	x13, x12, #0x7
	cbnz	x13, LBB35_45
; %bb.8:
	ldr	x13, [x10]
	cmp	x13, #0
	ccmp	x14, #0, #4, eq
	b.ne	LBB35_45
; %bb.9:
	and	x14, x13, #0x7
	cbnz	x14, LBB35_45
; %bb.10:
	cbz	x12, LBB35_39
; %bb.11:
	sub	x14, x12, #1
	mov	w9, #5                          ; =0x5
LBB35_12:                               ; =>This Inner Loop Header: Depth=1
	add	w9, w9, #1
	lsr	x15, x14, x9
	cmp	x15, #255
	b.hi	LBB35_12
; %bb.13:
	ldr	x14, [x0, #32]
	cmp	x11, x10
	csel	x4, x14, xzr, eq
Lloh177:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh178:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x14, [x0]
	blr	x14
	mov	x15, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	mov	x17, #0                         ; =0x0
	mov	x6, #0                          ; =0x0
	ldr	x5, [x0, #32]
	add	x7, sp, #312
	add	x19, sp, #56
	b	LBB35_19
LBB35_14:
	ldr	x9, [x10]
	ldr	x12, [x0, #8]
	cmp	x9, x12
	b.ne	LBB35_44
; %bb.15:
	ldr	x14, [x8, #1056]
	ldr	x9, [x0, #16]
	cmp	x14, x9
	b.ne	LBB35_44
; %bb.16:
	ldr	x12, [x8, #1064]
	ldr	x9, [x0, #24]
	cmp	x12, x9
	b.eq	LBB35_6
	b	LBB35_44
LBB35_17:                               ;   in Loop: Header=BB35_19 Depth=1
	mov	w6, w6
LBB35_18:                               ;   in Loop: Header=BB35_19 Depth=1
	add	x16, x16, #1
	cmp	x17, x12
	b.hs	LBB35_43
LBB35_19:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB35_36 Depth 2
	add	x5, x5, #1
	sub	x22, x12, x17
	cmp	x22, #32
	b.lo	LBB35_38
; %bb.20:                               ;   in Loop: Header=BB35_19 Depth=1
	add	x20, x13, x17
	ldr	x21, [x20]
	cmp	x21, x22
	b.hi	LBB35_38
; %bb.21:                               ;   in Loop: Header=BB35_19 Depth=1
	and	x22, x21, #0x7
	cmp	x21, #40
	ccmp	x22, #0, #0, hs
	b.ne	LBB35_38
; %bb.22:                               ;   in Loop: Header=BB35_19 Depth=1
	ldr	x22, [x20, #24]
	cmp	x22, #7
	b.hi	LBB35_38
; %bb.23:                               ;   in Loop: Header=BB35_19 Depth=1
	cbz	x22, LBB35_32
; %bb.24:                               ;   in Loop: Header=BB35_19 Depth=1
	tbz	w22, #0, LBB35_38
; %bb.25:                               ;   in Loop: Header=BB35_19 Depth=1
	ldr	x23, [x20, #8]
	sub	x24, x21, #32
	sub	x23, x23, #1
	cmp	x23, x24
	b.hs	LBB35_38
; %bb.26:                               ;   in Loop: Header=BB35_19 Depth=1
	ldr	x23, [x20, #16]
	sub	x24, x23, #7
	cmn	x24, #6
	b.lo	LBB35_38
; %bb.27:                               ;   in Loop: Header=BB35_19 Depth=1
	cmp	x22, #1
	cset	w22, ne
	orr	w14, w14, w22
	cmp	x23, #6
	b.ne	LBB35_35
; %bb.28:                               ;   in Loop: Header=BB35_19 Depth=1
	cmp	x15, #32
	b.hi	LBB35_35
; %bb.29:                               ;   in Loop: Header=BB35_19 Depth=1
	b.eq	LBB35_31
; %bb.30:                               ;   in Loop: Header=BB35_19 Depth=1
	str	x20, [x19, x15, lsl #3]
LBB35_31:                               ;   in Loop: Header=BB35_19 Depth=1
	add	x15, x15, #1
	b	LBB35_35
LBB35_32:                               ;   in Loop: Header=BB35_19 Depth=1
	cmp	x11, x10
	b.ne	LBB35_35
; %bb.33:                               ;   in Loop: Header=BB35_19 Depth=1
	orr	x22, x17, #0x1
	cmp	x4, x22
	b.ne	LBB35_38
; %bb.34:                               ;   in Loop: Header=BB35_19 Depth=1
	ldr	x4, [x20, #8]
LBB35_35:                               ;   in Loop: Header=BB35_19 Depth=1
	add	x17, x21, x17
	cmp	x6, #255
	b.hi	LBB35_18
LBB35_36:                               ;   Parent Loop BB35_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x21, x6, x9
	cmp	x21, x17
	b.hs	LBB35_17
; %bb.37:                               ;   in Loop: Header=BB35_36 Depth=2
	str	x20, [x7, x6, lsl #3]
	add	x21, x6, #1
	mov	x6, x21
	cmp	x21, #256
	b.ne	LBB35_36
	b	LBB35_18
LBB35_38:
	str	x5, [x0, #32]
	b	LBB35_44
LBB35_39:
	ldr	x9, [x0, #32]
	cmp	x11, x10
	ccmp	x9, #0, #4, eq
	b.ne	LBB35_44
; %bb.40:
	mov	x15, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	x16, #0                         ; =0x0
	mov	w9, #6                          ; =0x6
LBB35_41:
	add	x10, sp, #312
	add	x11, sp, #56
	stp	x10, x11, [sp]
	mov	w10, #256                       ; =0x100
	stp	w10, w9, [sp, #16]
	str	w15, [sp, #24]
	stp	x16, xzr, [sp, #32]
	str	w14, [sp, #48]
	mov	x4, sp
	mov	x0, x8
	bl	_collect_indexed
LBB35_42:
	mov	x9, x0
	b	LBB35_45
LBB35_43:
	str	x5, [x0, #32]
	cbz	x4, LBB35_47
LBB35_44:
	mov	w9, #3                          ; =0x3
LBB35_45:
	ldur	x8, [x29, #-72]
Lloh179:
	adrp	x10, ___stack_chk_guard@GOTPAGE
Lloh180:
	ldr	x10, [x10, ___stack_chk_guard@GOTPAGEOFF]
Lloh181:
	ldr	x10, [x10]
	cmp	x10, x8
	b.ne	LBB35_49
; %bb.46:
	mov	x0, x9
	add	sp, sp, #2368
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB35_47:
	cmp	x16, #2049
	b.lo	LBB35_41
; %bb.48:
	mov	x0, x8
	bl	_collect_dense
	b	LBB35_42
LBB35_49:
	bl	___stack_chk_fail
	.loh AdrpLdr	Lloh169, Lloh170
	.loh AdrpLdrGotLdr	Lloh166, Lloh167, Lloh168
	.loh AdrpLdr	Lloh171, Lloh172
	.loh AdrpLdr	Lloh173, Lloh174
	.loh AdrpLdr	Lloh175, Lloh176
	.loh AdrpLdr	Lloh177, Lloh178
	.loh AdrpLdrGotLdr	Lloh179, Lloh180, Lloh181
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_idle_v1              ; -- Begin function neoclr_gc_idle_v1
	.p2align	2
_neoclr_gc_idle_v1:                     ; @neoclr_gc_idle_v1
	.cfi_startproc
; %bb.0:
	mov	w2, #1                          ; =0x1
	b	_collect_idle
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_idle
_collect_idle:                          ; @collect_idle
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x21, x2
	mov	x20, x1
	mov	x19, x0
	and	w8, w2, #0xfffffffe
	cmp	w8, #6
	cset	w8, eq
Lloh182:
	adrp	x0, _candidate_autostart@TLVPPAGE
Lloh183:
	ldr	x0, [x0, _candidate_autostart@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x22, x0
	str	w8, [x0]
Lloh184:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh185:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	add	x23, x0, w2, uxtw #3
	ldr	x8, [x23]
	add	x8, x8, #1
	str	x8, [x23]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	mov	x8, x0
	cmp	w0, #0
	ldr	x9, [x23, #64]
	cinc	x9, x9, ne
	str	x9, [x23, #64]
	str	wzr, [x22]
Lloh186:
	adrp	x0, _native_scope_depth@TLVPPAGE
Lloh187:
	ldr	x0, [x0, _native_scope_depth@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	w9, [x0]
Lloh188:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh189:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	cmp	w21, #1
	b.ne	LBB37_7
; %bb.1:
	cbnz	w8, LBB37_7
; %bb.2:
	ldr	x10, [x0]
	add	x11, x19, #1048
	cmp	w9, #0
	ccmp	x10, x11, #0, eq
	b.ne	LBB37_7
; %bb.3:
Lloh190:
	adrp	x0, _live_owner@TLVPPAGE
Lloh191:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x21, x0
	ldr	w9, [x0, #8]
Lloh192:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh193:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	w8, #3                          ; =0x3
	cbz	x19, LBB37_11
; %bb.4:
	ldr	w10, [x0, #88]
	cmp	w9, #0
	ccmp	w10, #0, #0, eq
	b.ne	LBB37_11
; %bb.5:
	mov	x23, x0
	str	x19, [x21]
Lloh194:
	adrp	x0, _candidate_phase@TLVPPAGE
Lloh195:
	ldr	x0, [x0, _candidate_phase@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x22, x0
	mov	w24, #1                         ; =0x1
	str	w24, [x0]
	mov	x0, x19
	mov	x1, x20
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	str	wzr, [x22]
	cbz	w0, LBB37_9
; %bb.6:
	mov	x8, x0
	str	xzr, [x21]
	b	LBB37_11
LBB37_7:
	cbnz	w8, LBB37_11
; %bb.8:
Lloh196:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh197:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	b	LBB37_10
LBB37_9:
	str	w24, [x21, #8]
Lloh198:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh199:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ldr	x9, [x0]
	add	x9, x9, #1
	str	x9, [x0]
	mov	x0, x23
	str	x19, [x23, #56]
	ldur	q0, [x23, #24]
	ext.16b	v0, v0, v0, #8
	str	q0, [x23, #64]
	str	xzr, [x23, #80]
	ldr	x9, [x8, #32]
	add	x9, x9, #1
	str	x9, [x8, #32]
LBB37_10:
	mov	w8, #0                          ; =0x0
	str	x19, [x0, #56]
	ldur	q0, [x0, #24]
	ext.16b	v0, v0, v0, #8
	str	q0, [x0, #64]
	str	xzr, [x0, #80]
LBB37_11:
	mov	x0, x8
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh188, Lloh189
	.loh AdrpLdr	Lloh186, Lloh187
	.loh AdrpLdr	Lloh184, Lloh185
	.loh AdrpLdr	Lloh182, Lloh183
	.loh AdrpLdr	Lloh192, Lloh193
	.loh AdrpLdr	Lloh190, Lloh191
	.loh AdrpLdr	Lloh194, Lloh195
	.loh AdrpLdr	Lloh196, Lloh197
	.loh AdrpLdr	Lloh198, Lloh199
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_paced_collect_v1     ; -- Begin function neoclr_gc_paced_collect_v1
	.p2align	2
_neoclr_gc_paced_collect_v1:            ; @neoclr_gc_paced_collect_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x9, x0
Lloh200:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh201:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	x0, x9
	ldr	x9, [x8, #56]
	cmp	x9, x0
	b.eq	LBB38_2
; %bb.1:
	mov	w2, #4                          ; =0x4
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_collect_idle
LBB38_2:
	ldr	x9, [x8, #24]
	ldr	x10, [x8, #72]
	cmp	x9, x10
	b.ne	LBB38_4
; %bb.3:
	ldr	x9, [x8, #32]
	ldr	x8, [x8, #64]
	sub	x8, x9, x8
	cmp	x8, #1023
	mov	w8, #6                          ; =0x6
	cinc	w2, w8, ls
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_collect_idle
LBB38_4:
	mov	w2, #5                          ; =0x5
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_collect_idle
	.loh AdrpLdr	Lloh200, Lloh201
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_boundary_v1          ; -- Begin function neoclr_gc_boundary_v1
	.p2align	2
_neoclr_gc_boundary_v1:                 ; @neoclr_gc_boundary_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x1
	mov	x20, x0
Lloh202:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh203:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x20, LBB39_4
; %bb.1:
	ldr	w9, [x8, #88]
	cbnz	w9, LBB39_4
; %bb.2:
	mov	x21, x8
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x19
	b.eq	LBB39_5
LBB39_3:
	mov	w0, #3                          ; =0x3
LBB39_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB39_5:
	cbz	x19, LBB39_7
; %bb.6:
	ldr	x8, [x19, #8]
	cmp	x8, x20
	b.ne	LBB39_3
LBB39_7:
	ldr	x9, [x21, #56]
	cmp	x9, x20
	b.eq	LBB39_9
; %bb.8:
	mov	w2, #4                          ; =0x4
	b	LBB39_15
LBB39_9:
	mov	x8, x21
	ldr	x9, [x21, #24]
	ldr	x10, [x21, #72]
	cmp	x9, x10
	b.ne	LBB39_13
; %bb.10:
	ldr	x9, [x8, #32]
	ldr	x10, [x8, #64]
	sub	x9, x9, x10
	cmp	x9, #1023
	b.hi	LBB39_14
; %bb.11:
	ldr	x9, [x8, #80]
	add	x9, x9, #1
	str	x9, [x8, #80]
	cmp	x9, #4, lsl #12                 ; =16384
	b.hs	LBB39_14
; %bb.12:
	mov	w0, #0                          ; =0x0
	b	LBB39_4
LBB39_13:
	mov	w2, #5                          ; =0x5
	b	LBB39_15
LBB39_14:
	ldr	x9, [x8, #32]
	ldr	x8, [x8, #64]
	sub	x8, x9, x8
	cmp	x8, #1023
	mov	w8, #6                          ; =0x6
	cinc	w2, w8, ls
LBB39_15:
	mov	x0, x20
	mov	x1, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_collect_idle
	.loh AdrpLdr	Lloh202, Lloh203
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_published_boundary_v1 ; -- Begin function neoclr_gc_published_boundary_v1
	.p2align	2
_neoclr_gc_published_boundary_v1:       ; @neoclr_gc_published_boundary_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh204:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh205:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	w9, #3                          ; =0x3
	cbz	x8, LBB40_5
; %bb.1:
	cbz	x1, LBB40_5
; %bb.2:
	ldr	w10, [x0, #88]
	cbnz	w10, LBB40_5
; %bb.3:
	ldr	x9, [x1, #8]
	cmp	x9, x8
	b.eq	LBB40_6
; %bb.4:
	mov	w9, #3                          ; =0x3
LBB40_5:
	mov	x0, x9
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB40_6:
	ldr	x9, [x0, #56]
	cmp	x9, x8
	b.eq	LBB40_8
; %bb.7:
	mov	w2, #4                          ; =0x4
	b	LBB40_14
LBB40_8:
	ldr	x9, [x0, #24]
	ldr	x10, [x0, #72]
	cmp	x9, x10
	b.ne	LBB40_12
; %bb.9:
	ldr	x9, [x0, #32]
	ldr	x10, [x0, #64]
	sub	x9, x9, x10
	cmp	x9, #1023
	b.hi	LBB40_13
; %bb.10:
	ldr	x9, [x0, #80]
	add	x9, x9, #1
	str	x9, [x0, #80]
	cmp	x9, #4, lsl #12                 ; =16384
	b.hs	LBB40_13
; %bb.11:
	mov	w9, #0                          ; =0x0
	b	LBB40_5
LBB40_12:
	mov	w2, #5                          ; =0x5
	b	LBB40_14
LBB40_13:
	ldr	x9, [x0, #32]
	ldr	x10, [x0, #64]
	sub	x9, x9, x10
	cmp	x9, #1023
	mov	w9, #6                          ; =0x6
	cinc	w2, w9, ls
LBB40_14:
	mov	x0, x8
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_collect_idle
	.loh AdrpLdr	Lloh204, Lloh205
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_statistics_v1        ; -- Begin function neoclr_gc_statistics_v1
	.p2align	2
_neoclr_gc_statistics_v1:               ; @neoclr_gc_statistics_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh206:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh207:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldur	q0, [x0, #24]
	ldur	q1, [x0, #40]
	stp	q0, q1, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh206, Lloh207
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_string_intern_v1        ; -- Begin function neoclr_string_intern_v1
	.p2align	2
_neoclr_string_intern_v1:               ; @neoclr_string_intern_v1
	.cfi_startproc
; %bb.0:
	mov	w3, #0                          ; =0x0
	b	_string_intern
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function string_intern
_string_intern:                         ; @string_intern
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x0
	mov	w0, #3                          ; =0x3
	cbz	x20, LBB43_26
; %bb.1:
	mov	x19, x2
	cbz	x2, LBB43_26
; %bb.2:
	mov	x21, x1
	str	w3, [sp, #12]                   ; 4-byte Folded Spill
	mov	x0, x1
	bl	_blocks_valid
	cbz	w0, LBB43_25
; %bb.3:
	ldr	x25, [x21, #16]
	cbz	x25, LBB43_15
; %bb.4:
	str	x19, [sp]                       ; 8-byte Folded Spill
	mov	x26, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	mov	x27, #0                         ; =0x0
	ldr	x28, [x21]
	mov	w9, #1048576                    ; =0x100000
	b	LBB43_7
LBB43_5:                                ;   in Loop: Header=BB43_7 Depth=1
	add	x24, x22, x24
	add	x26, x26, #1
LBB43_6:                                ;   in Loop: Header=BB43_7 Depth=1
	ldr	x8, [x23]
	add	x27, x8, x27
	cmp	x27, x25
	b.hs	LBB43_16
LBB43_7:                                ; =>This Inner Loop Header: Depth=1
	add	x23, x28, x27
	ldrb	w8, [x23, #24]
	tbz	w8, #0, LBB43_6
; %bb.8:                                ;   in Loop: Header=BB43_7 Depth=1
	ldr	x8, [x23, #16]
	cmp	x8, #6
	b.ne	LBB43_6
; %bb.9:                                ;   in Loop: Header=BB43_7 Depth=1
	ldr	x8, [x23, #8]
	cmp	x8, #8
	b.ne	LBB43_25
; %bb.10:                               ;   in Loop: Header=BB43_7 Depth=1
	ldr	x19, [x23, #32]
	cbz	x19, LBB43_25
; %bb.11:                               ;   in Loop: Header=BB43_7 Depth=1
	ldr	x22, [x19]
	sub	x8, x9, x24
	cmp	x22, x8
	b.hi	LBB43_25
; %bb.12:                               ;   in Loop: Header=BB43_7 Depth=1
	ldr	x8, [x20]
	cmp	x22, x8
	b.ne	LBB43_5
; %bb.13:                               ;   in Loop: Header=BB43_7 Depth=1
	add	x0, x19, #8
	add	x1, x20, #8
	mov	x2, x22
	bl	_memcmp
	mov	w9, #1048576                    ; =0x100000
	cbnz	w0, LBB43_5
; %bb.14:
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x19, [x8]
	b	LBB43_26
LBB43_15:
	mov	w9, #1048576                    ; =0x100000
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	b	LBB43_18
LBB43_16:
	cmp	x26, #4095
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	b.hi	LBB43_19
; %bb.17:
	mov	w9, #1048576                    ; =0x100000
	sub	x9, x9, x24
	ldr	x19, [sp]                       ; 8-byte Folded Reload
LBB43_18:
	ldr	x10, [x20]
	cmp	x10, x9
	b.ls	LBB43_20
LBB43_19:
	mov	w0, #10                         ; =0xa
	b	LBB43_26
LBB43_20:
	cbz	w8, LBB43_27
; %bb.21:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB43_25
; %bb.22:
	mov	x1, x0
	ldr	x8, [x0, #8]
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB43_26
; %bb.23:
	add	x9, x8, #1048
	cmp	x9, x21
	b.ne	LBB43_26
; %bb.24:
	str	x20, [sp, #16]
	add	x2, sp, #16
	add	x6, sp, #24
	mov	x0, x8
	mov	w3, #1                          ; =0x1
	mov	w4, #8                          ; =0x8
	mov	w5, #6                          ; =0x6
	bl	_neoclr_gc_allocate_rooted_values_v1
	b	LBB43_28
LBB43_25:
	mov	w0, #3                          ; =0x3
LBB43_26:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB43_27:
	add	x3, sp, #24
	mov	x0, x21
	mov	w1, #8                          ; =0x8
	mov	w2, #6                          ; =0x6
	bl	_neoclr_gc_allocate_v1
LBB43_28:
	cbnz	w0, LBB43_26
; %bb.29:
	ldr	x8, [sp, #24]
	str	x20, [x8]
	str	x20, [x19]
	b	LBB43_26
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_string_intern_rooted_v1 ; -- Begin function neoclr_string_intern_rooted_v1
	.p2align	2
_neoclr_string_intern_rooted_v1:        ; @neoclr_string_intern_rooted_v1
	.cfi_startproc
; %bb.0:
	mov	w3, #1                          ; =0x1
	b	_string_intern
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_gc_collect_managed_v1   ; -- Begin function neoclr_gc_collect_managed_v1
	.p2align	2
_neoclr_gc_collect_managed_v1:          ; @neoclr_gc_collect_managed_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_neoclr_root_probe_head_v1
	mov	x1, x0
Lloh208:
	adrp	x0, _trigger_profile@TLVPPAGE
Lloh209:
	ldr	x0, [x0, _trigger_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	mov	w3, #0                          ; =0x0
	bl	_neoclr_gc_collect_conditional_v1
	cmp	w0, #0
	ldr	x8, [x20, #88]
	cinc	x8, x8, ne
	str	x8, [x20, #88]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh208, Lloh209
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function candidate_wait
_candidate_wait:                        ; @candidate_wait
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh210:
	adrp	x0, _shadow_owner@TLVPPAGE
Lloh211:
	ldr	x0, [x0, _shadow_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x19, [x0]
	cbz	x19, LBB46_5
; %bb.1:
	ldr	x8, [x19, #120]
	cbz	x8, LBB46_5
; %bb.2:
	add	x0, x19, #8
	bl	_pthread_mutex_lock
	cbnz	w0, LBB46_5
LBB46_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x19, #132]
	cbnz	w8, LBB46_6
; %bb.4:                                ;   in Loop: Header=BB46_3 Depth=1
	add	x0, x19, #72
	add	x1, x19, #8
	bl	_pthread_cond_wait
	cbz	w0, LBB46_3
LBB46_5:
	bl	_abort
LBB46_6:
	add	x0, x19, #8
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB46_5
; %bb.7:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh210, Lloh211
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function candidate_dispose
_candidate_dispose:                     ; @candidate_dispose
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	bl	_candidate_wait
Lloh212:
	adrp	x0, _shadow_owner@TLVPPAGE
Lloh213:
	ldr	x0, [x0, _shadow_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x20, [x0]
	add	x0, x20, #8
	bl	_pthread_mutex_lock
	cbnz	w0, LBB47_4
; %bb.1:
	ldr	x19, [x20, #120]
	str	xzr, [x20, #120]
	add	x0, x20, #8
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB47_4
; %bb.2:
	ldr	x0, [x19, #96]
	bl	_free
	ldr	x0, [x19, #64]
	bl	_gate_stop
	ldr	x0, [x19, #64]
	bl	_gate_destroy
	cbnz	w0, LBB47_4
; %bb.3:
	ldr	x8, [x19, #160]
Lloh214:
	adrp	x0, _live_time_counts@TLVPPAGE
Lloh215:
	ldr	x0, [x0, _live_time_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	add	x8, x9, x8
	str	x8, [x0]
	ldr	x8, [x19, #112]
Lloh216:
	adrp	x0, _live_counts@TLVPPAGE
Lloh217:
	ldr	x0, [x0, _live_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	add	x8, x9, x8, lsl #5
	str	x8, [x0]
	ldr	q0, [x19, #80]
	ldur	q1, [x0, #8]
	add.2d	v0, v1, v0
	stur	q0, [x0, #8]
	ldr	w8, [x19, #156]
	cmp	w8, #0
	ldp	x8, x9, [x0, #24]
	cinc	x8, x8, ne
	cinc	x9, x9, eq
	stp	x8, x9, [x0, #24]
	ldr	x0, [x19, #64]
	bl	_free
	ldr	x0, [x19, #56]
	bl	_free
	ldr	x0, [x19, #144]
	bl	_free
	ldr	x0, [x19, #48]
	bl	_free
	ldr	x0, [x19, #40]
	bl	_free
	ldr	x0, [x19, #24]
	bl	_free
	ldr	x0, [x19, #16]
	bl	_free
	ldr	x0, [x19, #8]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
LBB47_4:
	bl	_abort
	.loh AdrpLdr	Lloh212, Lloh213
	.loh AdrpLdr	Lloh216, Lloh217
	.loh AdrpLdr	Lloh214, Lloh215
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_time_counts      ; -- Begin function experiment_gc_time_counts
	.p2align	2
_experiment_gc_time_counts:             ; @experiment_gc_time_counts
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh218:
	adrp	x0, _live_time_counts@TLVPPAGE
Lloh219:
	ldr	x0, [x0, _live_time_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0]
	ldr	x9, [x0, #32]
	str	x9, [x8, #32]
	stp	q0, q1, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh218, Lloh219
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_batch_counts     ; -- Begin function experiment_gc_batch_counts
	.p2align	2
_experiment_gc_batch_counts:            ; @experiment_gc_batch_counts
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh220:
	adrp	x0, _live_batch_counts@TLVPPAGE
Lloh221:
	ldr	x0, [x0, _live_batch_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0]
	ldr	x9, [x0, #32]
	str	x9, [x8, #32]
	stp	q0, q1, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh220, Lloh221
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_live_counts      ; -- Begin function experiment_gc_live_counts
	.p2align	2
_experiment_gc_live_counts:             ; @experiment_gc_live_counts
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh222:
	adrp	x0, _live_counts@TLVPPAGE
Lloh223:
	ldr	x0, [x0, _live_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0]
	ldr	x9, [x0, #32]
	str	x9, [x8, #32]
	stp	q0, q1, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh222, Lloh223
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_live_wait        ; -- Begin function experiment_gc_live_wait
	.p2align	2
_experiment_gc_live_wait:               ; @experiment_gc_live_wait
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh224:
	adrp	x0, _live_owner@TLVPPAGE
Lloh225:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w8, [x0, #8]
	cbz	w8, LBB51_2
; %bb.1:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_candidate_wait
LBB51_2:
	bl	_abort
	.loh AdrpLdr	Lloh224, Lloh225
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_write            ; -- Begin function experiment_gc_write
	.p2align	2
_experiment_gc_write:                   ; @experiment_gc_write
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x8, x0
Lloh226:
	adrp	x0, _live_owner@TLVPPAGE
Lloh227:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	w9, [x0, #8]
	ldr	x10, [x0]
	cmp	w9, #0
	mov	w0, #1                          ; =0x1
	ccmp	x10, x8, #0, ne
	b.eq	LBB52_2
LBB52_1:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB52_2:
	cbz	x8, LBB52_1
; %bb.3:
	cbz	x1, LBB52_1
; %bb.4:
	mov	x20, x2
	mov	x19, x3
	add	x0, x8, #1048
	mov	x21, x1
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB52_34
; %bb.5:
	mov	x1, x21
	ldur	x2, [x21, #-24]
	ldur	w9, [x21, #-16]
	cmp	w9, #4
	cset	w10, eq
Lloh228:
	adrp	x0, _shadow_owner@TLVPPAGE
Lloh229:
	ldr	x0, [x0, _shadow_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ubfiz	x10, x10, #4, #32
	cmp	w9, #5
	mov	w11, #24                        ; =0x18
	csel	x10, x11, x10, eq
	cmp	x20, #0
	ccmp	x19, #0, #4, eq
	cset	w11, ne
	mov	w0, #1                          ; =0x1
	cmp	x19, #8
	b.hi	LBB52_1
; %bb.6:
	tbnz	w11, #0, LBB52_1
; %bb.7:
	mov	x4, x20
	mov	x5, x19
	ldr	x8, [x8]
	ldr	x19, [x8, #120]
	cbz	x5, LBB52_31
; %bb.8:
	ldr	x8, [x4, #8]
	cbz	x8, LBB52_10
; %bb.9:
	ldr	x8, [x4]
	cmp	x8, x10
	b.lo	LBB52_1
LBB52_10:
	cmp	x5, #1
	b.eq	LBB52_31
; %bb.11:
	ldr	x8, [x4, #32]
	cbz	x8, LBB52_13
; %bb.12:
	ldr	x8, [x4, #24]
	cmp	x8, x10
	b.lo	LBB52_1
LBB52_13:
	cmp	x5, #2
	b.eq	LBB52_31
; %bb.14:
	ldr	x8, [x4, #56]
	cbz	x8, LBB52_16
; %bb.15:
	ldr	x8, [x4, #48]
	cmp	x8, x10
	b.lo	LBB52_1
LBB52_16:
	cmp	x5, #3
	b.eq	LBB52_31
; %bb.17:
	ldr	x8, [x4, #80]
	cbz	x8, LBB52_19
; %bb.18:
	ldr	x8, [x4, #72]
	cmp	x8, x10
	b.lo	LBB52_1
LBB52_19:
	cmp	x5, #4
	b.eq	LBB52_31
; %bb.20:
	ldr	x8, [x4, #104]
	cbz	x8, LBB52_22
; %bb.21:
	ldr	x8, [x4, #96]
	cmp	x8, x10
	b.lo	LBB52_1
LBB52_22:
	cmp	x5, #5
	b.eq	LBB52_31
; %bb.23:
	ldr	x8, [x4, #128]
	cbz	x8, LBB52_25
; %bb.24:
	ldr	x8, [x4, #120]
	cmp	x8, x10
	b.lo	LBB52_1
LBB52_25:
	cmp	x5, #6
	b.eq	LBB52_31
; %bb.26:
	ldr	x8, [x4, #152]
	cbz	x8, LBB52_28
; %bb.27:
	ldr	x8, [x4, #144]
	cmp	x8, x10
	b.lo	LBB52_1
LBB52_28:
	cmp	x5, #7
	b.eq	LBB52_31
; %bb.29:
	ldr	x8, [x4, #176]
	cbz	x8, LBB52_31
; %bb.30:
	ldr	x8, [x4, #168]
	cmp	x8, x10
	b.lo	LBB52_1
LBB52_31:
	ldr	x0, [x19, #64]
	cmp	w9, #2
	cset	w8, eq
	ubfiz	x3, x8, #3, #32
	bl	_gate_write
	cbnz	w0, LBB52_1
; %bb.32:
	ldr	x8, [x19, #64]
	ldr	w8, [x8, #96]
	cbz	w8, LBB52_35
; %bb.33:
Lloh230:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh231:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	mov	w9, #16384                      ; =0x4000
	str	x9, [x8, #80]
	b	LBB52_1
LBB52_34:
	mov	w0, #1                          ; =0x1
	b	LBB52_1
LBB52_35:
	mov	w0, #0                          ; =0x0
	b	LBB52_1
	.loh AdrpLdr	Lloh226, Lloh227
	.loh AdrpLdr	Lloh228, Lloh229
	.loh AdrpLdr	Lloh230, Lloh231
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function live_write_known
_live_write_known:                      ; @live_write_known
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x5, x4
	mov	x4, x3
	mov	x8, x1
	mov	x1, x0
	cmp	w2, #4
	cset	w10, eq
Lloh232:
	adrp	x0, _shadow_owner@TLVPPAGE
Lloh233:
	ldr	x0, [x0, _shadow_owner@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	ubfiz	x10, x10, #4, #32
	cmp	w2, #5
	mov	w11, #24                        ; =0x18
	csel	x10, x11, x10, eq
	cmp	x3, #0
	ccmp	x5, #0, #4, eq
	cset	w11, ne
	mov	w0, #1                          ; =0x1
	cmp	x5, #8
	b.hi	LBB53_30
; %bb.1:
	tbnz	w11, #0, LBB53_30
; %bb.2:
	ldr	x9, [x9]
	ldr	x19, [x9, #120]
	cbz	x5, LBB53_26
; %bb.3:
	ldr	x9, [x4, #8]
	cbz	x9, LBB53_5
; %bb.4:
	ldr	x9, [x4]
	cmp	x9, x10
	b.lo	LBB53_30
LBB53_5:
	cmp	x5, #1
	b.eq	LBB53_26
; %bb.6:
	ldr	x9, [x4, #32]
	cbz	x9, LBB53_8
; %bb.7:
	ldr	x9, [x4, #24]
	cmp	x9, x10
	b.lo	LBB53_30
LBB53_8:
	cmp	x5, #2
	b.eq	LBB53_26
; %bb.9:
	ldr	x9, [x4, #56]
	cbz	x9, LBB53_11
; %bb.10:
	ldr	x9, [x4, #48]
	cmp	x9, x10
	b.lo	LBB53_30
LBB53_11:
	cmp	x5, #3
	b.eq	LBB53_26
; %bb.12:
	ldr	x9, [x4, #80]
	cbz	x9, LBB53_14
; %bb.13:
	ldr	x9, [x4, #72]
	cmp	x9, x10
	b.lo	LBB53_30
LBB53_14:
	cmp	x5, #4
	b.eq	LBB53_26
; %bb.15:
	ldr	x9, [x4, #104]
	cbz	x9, LBB53_17
; %bb.16:
	ldr	x9, [x4, #96]
	cmp	x9, x10
	b.lo	LBB53_30
LBB53_17:
	cmp	x5, #5
	b.eq	LBB53_26
; %bb.18:
	ldr	x9, [x4, #128]
	cbz	x9, LBB53_20
; %bb.19:
	ldr	x9, [x4, #120]
	cmp	x9, x10
	b.lo	LBB53_30
LBB53_20:
	cmp	x5, #6
	b.eq	LBB53_26
; %bb.21:
	ldr	x9, [x4, #152]
	cbz	x9, LBB53_23
; %bb.22:
	ldr	x9, [x4, #144]
	cmp	x9, x10
	b.lo	LBB53_30
LBB53_23:
	cmp	x5, #7
	b.eq	LBB53_26
; %bb.24:
	ldr	x9, [x4, #176]
	cbz	x9, LBB53_26
; %bb.25:
	ldr	x9, [x4, #168]
	cmp	x9, x10
	b.lo	LBB53_30
LBB53_26:
	ldr	x0, [x19, #64]
	cmp	w2, #2
	cset	w9, eq
	ubfiz	x3, x9, #3, #32
	mov	x2, x8
	bl	_gate_write
	cbnz	w0, LBB53_30
; %bb.27:
	ldr	x8, [x19, #64]
	ldr	w8, [x8, #96]
	cbz	w8, LBB53_29
; %bb.28:
Lloh234:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh235:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	mov	w9, #16384                      ; =0x4000
	str	x9, [x8, #80]
	b	LBB53_30
LBB53_29:
	mov	w0, #0                          ; =0x0
LBB53_30:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh232, Lloh233
	.loh AdrpLdr	Lloh234, Lloh235
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_live_active      ; -- Begin function experiment_gc_live_active
	.p2align	2
_experiment_gc_live_active:             ; @experiment_gc_live_active
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh236:
	adrp	x0, _live_owner@TLVPPAGE
Lloh237:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	w9, [x0, #8]
	cmp	w9, #0
	ldr	x9, [x0]
	ccmp	x9, x8, #0, ne
	cset	w0, eq
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh236, Lloh237
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_store            ; -- Begin function experiment_gc_store
	.p2align	2
_experiment_gc_store:                   ; @experiment_gc_store
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
Lloh238:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh239:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh240:
	ldr	x8, [x8]
	stur	x8, [x29, #-56]
Lloh241:
	adrp	x8, _live_owner@TLVPPAGE
Lloh242:
	ldr	x8, [x8, _live_owner@TLVPPAGEOFF]
	cbz	x0, LBB55_5
; %bb.1:
	mov	x9, x0
Lloh243:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh244:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x11, [x0]
	add	x10, x9, #1048
	cmp	x11, x10
	b.ne	LBB55_5
; %bb.2:
	ldr	x11, [x10]
	ldr	x12, [x0, #8]
	cmp	x11, x12
	b.ne	LBB55_5
; %bb.3:
	ldr	x13, [x9, #1056]
	ldr	x12, [x0, #16]
	cmp	x13, x12
	b.ne	LBB55_5
; %bb.4:
	ldr	x12, [x9, #1064]
	ldr	x14, [x0, #24]
	cmp	x12, x14
	and	x14, x12, #0x7
	ccmp	x12, x13, #2, eq
	ccmp	x14, #0, #0, ls
	b.eq	LBB55_8
LBB55_5:
	ldr	x9, [x8]
	mov	x0, x8
	blr	x9
	ldr	x8, [x0, #48]
	add	x8, x8, #1
	str	x8, [x0, #48]
	mov	w0, #3                          ; =0x3
LBB55_6:
	ldur	x8, [x29, #-56]
Lloh245:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh246:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh247:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB55_41
; %bb.7:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
LBB55_8:
	cbz	x13, LBB55_10
; %bb.9:
	cbz	x11, LBB55_5
LBB55_10:
	cbz	x1, LBB55_5
; %bb.11:
	and	x14, x11, #0x7
	cbnz	x14, LBB55_5
; %bb.12:
	cmp	w3, #8
	b.hi	LBB55_5
; %bb.13:
	mov	w14, #1                         ; =0x1
	lsl	w14, w14, w3
	mov	w15, #278                       ; =0x116
	tst	w14, w15
	b.eq	LBB55_5
; %bb.14:
	ldr	x14, [x8]
	mov	x0, x8
	blr	x14
	ldr	w14, [x0, #8]
	ldr	x15, [x0]
	cmp	w14, #0
	ccmp	x15, x9, #4, ne
	b.ne	LBB55_5
; %bb.15:
	mov	w9, w3
	cmn	x9, x1
	cset	w16, hs
	cmn	x13, x11
	cset	w15, hs
	tbnz	w16, #0, LBB55_5
; %bb.16:
	tbnz	w15, #0, LBB55_5
; %bb.17:
	add	x15, x9, x1
	cmp	x15, x11
	b.ls	LBB55_32
; %bb.18:
	add	x13, x13, x11
	cmp	x13, x1
	b.ls	LBB55_32
; %bb.19:
	cmp	x11, x1
	b.hi	LBB55_5
; %bb.20:
	sub	x19, x1, x11
	cmp	x19, x12
	b.hs	LBB55_5
; %bb.21:
	stp	x12, x11, [sp, #8]              ; 16-byte Folded Spill
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	stp	x0, x10, [sp, #48]              ; 16-byte Folded Spill
	str	x1, [sp, #64]                   ; 8-byte Folded Spill
	str	x2, [sp, #40]                   ; 8-byte Folded Spill
	str	w3, [sp, #36]                   ; 4-byte Folded Spill
	cbz	w14, LBB55_34
; %bb.22:
Lloh248:
	adrp	x0, _shadow_owner@TLVPPAGE
Lloh249:
	ldr	x0, [x0, _shadow_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	ldr	x21, [x8, #120]
	mov	x0, x21
	ldr	x1, [sp, #64]                   ; 8-byte Folded Reload
	bl	_shadow_find
	cmn	x0, #1
	b.eq	LBB55_34
; %bb.23:
	mov	x20, x0
	ldr	x8, [x21, #40]
	ldr	x19, [x8, x0, lsl #3]
	ldr	x21, [x21, #56]
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	mov	x1, x19
	bl	_block_valid
	ldr	w2, [sp, #36]                   ; 4-byte Folded Reload
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x10, [sp, #64]                  ; 8-byte Folded Reload
Lloh250:
	adrp	x8, _live_owner@TLVPPAGE
Lloh251:
	ldr	x8, [x8, _live_owner@TLVPPAGEOFF]
	ldp	x11, x9, [sp, #16]              ; 16-byte Folded Reload
	cbz	w0, LBB55_5
; %bb.24:
	add	x11, x11, x19
	ldrb	w12, [x11, #24]
	tbz	w12, #0, LBB55_5
; %bb.25:
	add	x12, x21, x20, lsl #5
	ldr	x13, [x11]
	ldr	x14, [x12]
	cmp	x13, x14
	b.ne	LBB55_5
; %bb.26:
	ldr	x19, [x11, #8]
	ldr	x13, [x12, #8]
	cmp	x19, x13
	b.ne	LBB55_5
; %bb.27:
	ldr	x20, [x11, #16]
	ldr	x12, [x12, #16]
	cmp	x20, x12
	b.ne	LBB55_5
; %bb.28:
	add	x21, x11, #32
	sub	x22, x10, x21
	sub	x10, x19, x22
	cmp	x10, x9
	b.lo	LBB55_5
; %bb.29:
	sub	x23, x29, #64
	sub	x0, x29, #64
	mov	x24, x9
	bl	_live_store_bits
	stp	x22, x24, [sp, #72]
	str	x23, [sp, #88]
	add	x3, sp, #72
	mov	x0, x21
	mov	x1, x19
	mov	x2, x20
	mov	w4, #1                          ; =0x1
	bl	_live_write_known
	cbz	w0, LBB55_42
; %bb.30:
	cmp	w0, #3
	ldr	w19, [sp, #36]                  ; 4-byte Folded Reload
	ldp	x20, x9, [sp, #40]              ; 16-byte Folded Reload
	ldr	x21, [sp, #64]                  ; 8-byte Folded Reload
Lloh252:
	adrp	x8, _live_owner@TLVPPAGE
Lloh253:
	ldr	x8, [x8, _live_owner@TLVPPAGEOFF]
	b.ne	LBB55_5
; %bb.31:
	mov	x22, x9
	bl	_candidate_dispose
	str	xzr, [x22]
	str	wzr, [x22, #8]
Lloh254:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh255:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0, #16]
	add	x8, x8, #1
	str	x8, [x0, #16]
	ldr	x8, [x22, #40]
	add	x8, x8, #1
	str	x8, [x22, #40]
	mov	x0, x21
	mov	x1, x20
	mov	x2, x19
	b	LBB55_33
LBB55_32:
	ldr	x8, [x0, #16]
	add	x8, x8, #1
	str	x8, [x0, #16]
	mov	x0, x1
	mov	x1, x2
	mov	x2, x3
LBB55_33:
	bl	_live_store_bits
	mov	w0, #0                          ; =0x0
	b	LBB55_6
LBB55_34:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #64]
	add	x9, x9, #1
	str	x9, [x8, #64]
	mov	x0, x19
	bl	_owned_index_before
	mov	x20, x0
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	cmp	x0, x8
Lloh256:
	adrp	x8, _live_owner@TLVPPAGE
Lloh257:
	ldr	x8, [x8, _live_owner@TLVPPAGEOFF]
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	b.hs	LBB55_5
; %bb.35:
	sub	x21, x20, #32
	cmn	x21, #34
	b.hi	LBB55_5
; %bb.36:
	mov	x1, x21
	bl	_block_valid
	ldp	x12, x11, [sp, #16]             ; 16-byte Folded Reload
Lloh258:
	adrp	x8, _live_owner@TLVPPAGE
Lloh259:
	ldr	x8, [x8, _live_owner@TLVPPAGEOFF]
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	ldp	x1, x10, [sp, #40]              ; 16-byte Folded Reload
	ldr	w2, [sp, #36]                   ; 4-byte Folded Reload
	cbz	w0, LBB55_5
; %bb.37:
	add	x13, x12, x21
	ldrb	w14, [x13, #24]
	tbz	w14, #0, LBB55_5
; %bb.38:
	ldr	x13, [x13, #8]
	sub	x14, x19, x20
	cmp	x14, x13
	b.hs	LBB55_5
; %bb.39:
	add	x12, x12, x20
	sub	x12, x12, x9
	add	x12, x12, x13
	cmp	x12, x11
	b.lo	LBB55_5
; %bb.40:
	ldr	x8, [x10, #24]
	add	x8, x8, #1
	str	x8, [x10, #24]
	mov	x0, x9
	b	LBB55_33
LBB55_41:
	bl	___stack_chk_fail
LBB55_42:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x9, [x8, #32]
	add	x9, x9, #1
	str	x9, [x8, #32]
	b	LBB55_6
	.loh AdrpLdr	Lloh241, Lloh242
	.loh AdrpLdrGotLdr	Lloh238, Lloh239, Lloh240
	.loh AdrpLdr	Lloh243, Lloh244
	.loh AdrpLdrGotLdr	Lloh245, Lloh246, Lloh247
	.loh AdrpLdr	Lloh248, Lloh249
	.loh AdrpLdr	Lloh250, Lloh251
	.loh AdrpLdr	Lloh252, Lloh253
	.loh AdrpLdr	Lloh254, Lloh255
	.loh AdrpLdr	Lloh256, Lloh257
	.loh AdrpLdr	Lloh258, Lloh259
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function live_store_bits
_live_store_bits:                       ; @live_store_bits
	.cfi_startproc
; %bb.0:
	cmp	w2, #4
	b.eq	LBB56_5
; %bb.1:
	cmp	w2, #2
	b.eq	LBB56_4
; %bb.2:
	cmp	w2, #1
	b.ne	LBB56_6
; %bb.3:
	strb	w1, [x0]
	ret
LBB56_4:
	strh	w1, [x0]
	ret
LBB56_5:
	str	w1, [x0]
	ret
LBB56_6:
	str	x1, [x0]
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function shadow_find
_shadow_find:                           ; @shadow_find
	.cfi_startproc
; %bb.0:
	ldr	x8, [x0]
	subs	x8, x1, x8
	b.lo	LBB57_9
; %bb.1:
	ldr	x9, [x0, #32]
	cmp	x8, x9
	b.hs	LBB57_9
; %bb.2:
	ldr	x9, [x0, #96]
	ldr	w10, [x0, #108]
	lsr	x10, x8, x10
	ldr	x9, [x9, x10, lsl #3]
	ldr	x12, [x0, #112]
	add	x11, x9, #1
	cmp	x12, x11
	csinc	x9, x12, x9, hi
	sub	x9, x9, #1
	ldr	x10, [x0, #40]
LBB57_3:                                ; =>This Inner Loop Header: Depth=1
	cmp	x11, x12
	b.hs	LBB57_6
; %bb.4:                                ;   in Loop: Header=BB57_3 Depth=1
	ldr	x13, [x10, x11, lsl #3]
	add	x11, x11, #1
	cmp	x13, x8
	b.ls	LBB57_3
; %bb.5:
	sub	x9, x11, #2
LBB57_6:
	ldr	x11, [x0, #56]
	add	x11, x11, x9, lsl #5
	mov	x0, #-1                         ; =0xffffffffffffffff
	ldrb	w12, [x11, #24]
	tbz	w12, #0, LBB57_10
; %bb.7:
	ldr	x10, [x10, x9, lsl #3]
	add	x10, x10, #32
	subs	x8, x8, x10
	b.lo	LBB57_10
; %bb.8:
	ldr	x10, [x11, #8]
	cmp	x8, x10
	csinv	x0, x9, xzr, lo
	ret
LBB57_9:
	mov	x0, #-1                         ; =0xffffffffffffffff
LBB57_10:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function owned_index_before
_owned_index_before:                    ; @owned_index_before
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
	mov	w9, #-1                         ; =0xffffffff
	eor	w10, w9, w8, lsr #3
	lsr	x11, x0, #9
Lloh260:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh261:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0, #2088]
	ldr	x13, [x9, x11, lsl #3]
	mov	x12, #-1                        ; =0xffffffffffffffff
	lsr	x10, x12, x10
	ands	x10, x13, x10
	b.ne	LBB58_8
; %bb.1:
	lsr	x10, x8, #15
	ldr	x13, [x0, #2096]
	ldr	x14, [x13, x10, lsl #3]
	lsl	x11, x12, x11
	bics	x11, x14, x11
	cset	w12, eq
	cbnz	x11, LBB58_5
; %bb.2:
	cmp	x8, #8, lsl #12                 ; =32768
	b.lo	LBB58_5
; %bb.3:
	sub	x8, x13, #8
LBB58_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x8, x10, lsl #3]
	cmp	x11, #0
	cset	w12, eq
	ccmp	x10, #1, #4, eq
	sub	x10, x10, #1
	b.ne	LBB58_4
LBB58_5:
	tbz	w12, #0, LBB58_7
; %bb.6:
	mov	x0, #-1                         ; =0xffffffffffffffff
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB58_7:
	clz	x8, x11
	orr	x8, x8, x10, lsl #6
	eor	x11, x8, #0x3f
	ldr	x10, [x9, x11, lsl #3]
LBB58_8:
	mov	w8, #63                         ; =0x3f
	orr	x8, x8, x11, lsl #6
	clz	x9, x10
	sub	x8, x8, x9
	lsl	x0, x8, #3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh260, Lloh261
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_store_lookup_counts ; -- Begin function experiment_gc_store_lookup_counts
	.p2align	2
_experiment_gc_store_lookup_counts:     ; @experiment_gc_store_lookup_counts
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh262:
	adrp	x0, _live_owner@TLVPPAGE
Lloh263:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldur	q0, [x0, #56]
	str	q0, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh262, Lloh263
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_store_counts     ; -- Begin function experiment_gc_store_counts
	.p2align	2
_experiment_gc_store_counts:            ; @experiment_gc_store_counts
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh264:
	adrp	x0, _live_owner@TLVPPAGE
Lloh265:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0, #16]
	ldr	x9, [x0, #48]
	str	x9, [x8, #32]
	stp	q0, q1, [x8]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh264, Lloh265
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_store_record     ; -- Begin function experiment_gc_store_record
	.p2align	2
_experiment_gc_store_record:            ; @experiment_gc_store_record
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh266:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh267:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh268:
	ldr	x9, [x9]
	str	x9, [sp, #56]
	cbz	x0, LBB61_21
; %bb.1:
	mov	x8, x0
Lloh269:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh270:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	mov	w0, #3                          ; =0x3
	cbz	x3, LBB61_22
; %bb.2:
	cbz	x1, LBB61_22
; %bb.3:
	ldr	x10, [x9]
	add	x9, x8, #1048
	cmp	x10, x9
	b.ne	LBB61_22
; %bb.4:
Lloh271:
	adrp	x0, _live_owner@TLVPPAGE
Lloh272:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	w10, [x0, #8]
	ldr	x11, [x0]
	cmp	w10, #0
	ccmp	x11, x8, #4, ne
	b.ne	LBB61_21
; %bb.5:
	mov	x20, x4
	mov	x21, x2
	mov	x25, x3
	mov	x24, x0
	mov	x0, x9
	mov	x19, x1
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB61_21
; %bb.6:
	ldur	w9, [x19, #-16]
	mov	w0, #3                          ; =0x3
	cmp	w9, #5
	b.ne	LBB61_22
; %bb.7:
	mov	x8, x19
	mov	x13, x20
	ldur	x20, [x19, #-24]
	subs	x10, x20, #24
	b.lo	LBB61_22
; %bb.8:
	ldr	x12, [x8]
	lsr	x14, x12, #32
	cmp	x14, #1024
	b.hi	LBB61_22
; %bb.9:
	mov	w12, w12
	mov	w15, #5                         ; =0x5
	movk	w15, #32768, lsl #16
	cmp	x12, x15
	b.ne	LBB61_22
; %bb.10:
	ldr	x12, [x8, #16]
	cmp	x12, #1
	ccmp	x14, #0, #4, ne
	b.ne	LBB61_22
; %bb.11:
	sub	x14, x12, #257
	cmn	x14, #256
	b.lo	LBB61_22
; %bb.12:
	cmp	x12, w13, uxtw
	b.ne	LBB61_22
; %bb.13:
	ldr	x13, [x8, #8]
	cmp	x13, #16, lsl #12               ; =65536
	b.hi	LBB61_22
; %bb.14:
	mov	w11, w21
	cmp	x13, x11
	b.ls	LBB61_22
; %bb.15:
	mov	w22, #1                         ; =0x1
	mov	w14, #1                         ; =0x1
	bfi	x14, x12, #3, #60
	udiv	x10, x10, x14
	cmp	x13, x10
	b.hi	LBB61_22
; %bb.16:
	mov	x1, x25
	lsl	x21, x12, #3
	strb	w22, [sp, #7]
	mul	x10, x11, x12
	lsl	x10, x10, #3
	add	x26, x10, #24
	stp	x26, x21, [sp, #8]
	mul	x10, x13, x12
	add	x10, x11, x10, lsl #3
	add	x27, x10, #24
	stp	x25, x27, [sp, #24]
	add	x23, sp, #7
	stp	x22, x23, [sp, #40]
	ldr	w9, [x24, #8]
	cbz	w9, LBB61_25
; %bb.17:
Lloh273:
	adrp	x0, _shadow_owner@TLVPPAGE
Lloh274:
	ldr	x0, [x0, _shadow_owner@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	ldr	x0, [x9, #120]
	mov	x1, x8
	bl	_shadow_find
	cmn	x0, #1
	b.eq	LBB61_24
; %bb.18:
	add	x3, sp, #8
	mov	x0, x19
	mov	x1, x20
	mov	w2, #5                          ; =0x5
	mov	w4, #2                          ; =0x2
	bl	_live_write_known
	cbz	w0, LBB61_27
; %bb.19:
	cmp	w0, #3
	b.ne	LBB61_21
; %bb.20:
	bl	_candidate_dispose
	str	xzr, [x24]
	str	wzr, [x24, #8]
Lloh275:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh276:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0, #16]
	add	x9, x9, #1
	str	x9, [x0, #16]
	ldr	x9, [x24, #40]
	add	x9, x9, #1
	str	x9, [x24, #40]
	ldp	x26, x21, [sp, #8]
	ldp	x1, x27, [sp, #24]
	ldp	x22, x23, [sp, #40]
	mov	x8, x19
	b	LBB61_25
LBB61_21:
	mov	w0, #3                          ; =0x3
LBB61_22:
	ldr	x8, [sp, #56]
Lloh277:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh278:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh279:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB61_28
; %bb.23:
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB61_24:
	add	x23, sp, #7
	mov	w22, #1                         ; =0x1
	mov	x8, x19
	mov	x1, x25
LBB61_25:
	add	x0, x8, x26
	mov	x19, x8
	mov	x2, x21
	bl	_memcpy
	add	x0, x19, x27
	mov	x1, x23
	mov	x2, x22
	bl	_memcpy
	mov	w8, #24                         ; =0x18
LBB61_26:
	mov	w0, #0                          ; =0x0
	ldr	x9, [x24, x8]
	add	x9, x9, #1
	str	x9, [x24, x8]
	b	LBB61_22
LBB61_27:
	mov	w8, #32                         ; =0x20
	b	LBB61_26
LBB61_28:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh266, Lloh267, Lloh268
	.loh AdrpLdr	Lloh269, Lloh270
	.loh AdrpLdr	Lloh271, Lloh272
	.loh AdrpLdr	Lloh273, Lloh274
	.loh AdrpLdr	Lloh275, Lloh276
	.loh AdrpLdrGotLdr	Lloh277, Lloh278, Lloh279
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_store_text       ; -- Begin function experiment_gc_store_text
	.p2align	2
_experiment_gc_store_text:              ; @experiment_gc_store_text
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
Lloh280:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh281:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh282:
	ldr	x9, [x9]
	stur	x9, [x29, #-56]
	str	x3, [sp, #16]
	cbz	x0, LBB62_18
; %bb.1:
	mov	x8, x0
Lloh283:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh284:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	mov	w0, #3                          ; =0x3
	cbz	x1, LBB62_19
; %bb.2:
	ldr	x10, [x9]
	add	x9, x8, #1048
	cmp	x10, x9
	b.ne	LBB62_19
; %bb.3:
Lloh285:
	adrp	x0, _live_owner@TLVPPAGE
Lloh286:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	w10, [x0, #8]
	ldr	x11, [x0]
	cmp	w10, #0
	ccmp	x11, x8, #4, ne
	b.ne	LBB62_18
; %bb.4:
	mov	x20, x2
	mov	x22, x0
	mov	x0, x9
	mov	x19, x1
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB62_18
; %bb.5:
	ldur	w9, [x19, #-16]
	mov	w0, #3                          ; =0x3
	cmp	w9, #4
	b.ne	LBB62_19
; %bb.6:
	mov	x8, x19
	ldur	x21, [x19, #-24]
	subs	x13, x21, #16
	b.lo	LBB62_19
; %bb.7:
	ldr	w9, [x8]
	mov	w14, #65531                     ; =0xfffb
	movk	w14, #32767, lsl #16
	add	w11, w9, w14
	cmn	w11, #2
	b.lo	LBB62_19
; %bb.8:
	ldr	x11, [x8, #8]
	mov	w12, w20
	cmp	x11, x12
	b.ls	LBB62_19
; %bb.9:
	add	w10, w14, #9
	cmp	w9, w10
	mov	w14, #8                         ; =0x8
	cinc	x14, x14, eq
	udiv	x13, x13, x14
	cmp	x11, x13
	b.hi	LBB62_19
; %bb.10:
	mov	w13, #1                         ; =0x1
	strb	w13, [sp, #15]
	lsl	x14, x12, #3
	add	x14, x14, #16
	mov	w15, #8                         ; =0x8
	stp	x14, x15, [sp, #24]
	add	x14, sp, #16
	add	x11, x12, x11, lsl #3
	add	x11, x11, #16
	stp	x14, x11, [sp, #40]
	add	x11, sp, #15
	stp	x13, x11, [sp, #56]
	cmp	w9, w10
	cinc	w20, w13, eq
	ldr	w9, [x22, #8]
	cbz	w9, LBB62_15
; %bb.11:
Lloh287:
	adrp	x0, _shadow_owner@TLVPPAGE
Lloh288:
	ldr	x0, [x0, _shadow_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	ldr	x0, [x8, #120]
	mov	x1, x19
	bl	_shadow_find
	mov	x8, x19
	cmn	x0, #1
	b.eq	LBB62_15
; %bb.12:
	add	x3, sp, #24
	mov	x0, x8
	mov	x1, x21
	mov	w2, #4                          ; =0x4
	mov	x4, x20
	bl	_live_write_known
	cbz	w0, LBB62_21
; %bb.13:
	cmp	w0, #3
	b.ne	LBB62_18
; %bb.14:
	bl	_candidate_dispose
	str	xzr, [x22]
	str	wzr, [x22, #8]
Lloh289:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh290:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0, #16]
	add	x9, x9, #1
	str	x9, [x0, #16]
	ldr	x9, [x22, #40]
	add	x9, x9, #1
	str	x9, [x22, #40]
	mov	x8, x19
LBB62_15:
	add	x9, sp, #24
	add	x23, x9, #8
	mov	w21, #24                        ; =0x18
LBB62_16:                               ; =>This Inner Loop Header: Depth=1
	ldp	x2, x1, [x23]
	ldur	x9, [x23, #-8]
	add	x0, x8, x9
	bl	_memcpy
	mov	x8, x19
	add	x23, x23, #24
	subs	x20, x20, #1
	b.ne	LBB62_16
LBB62_17:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x22, x21]
	add	x8, x8, #1
	str	x8, [x22, x21]
	b	LBB62_19
LBB62_18:
	mov	w0, #3                          ; =0x3
LBB62_19:
	ldur	x8, [x29, #-56]
Lloh291:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh292:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh293:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB62_22
; %bb.20:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB62_21:
	mov	w21, #32                        ; =0x20
	b	LBB62_17
LBB62_22:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh280, Lloh281, Lloh282
	.loh AdrpLdr	Lloh283, Lloh284
	.loh AdrpLdr	Lloh285, Lloh286
	.loh AdrpLdr	Lloh287, Lloh288
	.loh AdrpLdr	Lloh289, Lloh290
	.loh AdrpLdrGotLdr	Lloh291, Lloh292, Lloh293
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_store_scalar     ; -- Begin function experiment_gc_store_scalar
	.p2align	2
_experiment_gc_store_scalar:            ; @experiment_gc_store_scalar
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB63_25
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x8, x0
Lloh294:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh295:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x10, [x0]
	add	x9, x8, #1048
	cmp	x10, x9
	b.ne	LBB63_23
; %bb.2:
	ldr	x10, [x9]
	ldr	x11, [x0, #8]
	cmp	x10, x11
	b.ne	LBB63_23
; %bb.3:
	ldr	x11, [x8, #1056]
	ldr	x12, [x0, #16]
	cmp	x11, x12
	b.ne	LBB63_23
; %bb.4:
	ldr	x12, [x8, #1064]
	ldr	x13, [x0, #24]
	mov	w0, #3                          ; =0x3
	cmp	x12, x13
	b.ne	LBB63_24
; %bb.5:
	cmp	x12, x11
	b.hi	LBB63_24
; %bb.6:
	and	x12, x12, #0x7
	cbnz	x12, LBB63_24
; %bb.7:
	cbz	x11, LBB63_9
; %bb.8:
	cbz	x10, LBB63_24
LBB63_9:
	cbz	x3, LBB63_24
; %bb.10:
	cbz	x1, LBB63_24
; %bb.11:
	and	x10, x10, #0x7
	cbnz	x10, LBB63_24
; %bb.12:
Lloh296:
	adrp	x0, _live_owner@TLVPPAGE
Lloh297:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	w10, [x0, #8]
	ldr	x11, [x0]
	cmp	w10, #0
	ccmp	x11, x8, #4, ne
	b.ne	LBB63_23
; %bb.13:
	mov	x21, x2
	mov	x19, x3
	mov	x0, x9
	mov	x20, x1
	mov	x2, #0                          ; =0x0
	bl	_validated_bases
	cbz	w0, LBB63_23
; %bb.14:
	ldur	w8, [x20, #-16]
	mov	w0, #3                          ; =0x3
	cmp	w8, #3
	b.ne	LBB63_24
; %bb.15:
	mov	x10, x20
	ldur	x8, [x20, #-24]
	subs	x8, x8, #24
	b.lo	LBB63_24
; %bb.16:
	ldr	x11, [x10]
	mov	w12, #6                         ; =0x6
	movk	w12, #32768, lsl #16
	cmp	w11, w12
	b.ne	LBB63_24
; %bb.17:
	lsr	x11, x11, #32
	cmp	x11, #1024
	b.hi	LBB63_24
; %bb.18:
	ldr	x11, [x10, #16]
	cmp	x11, #1
	b.ne	LBB63_24
; %bb.19:
	ldr	x10, [x10, #8]
	cmp	x10, #16, lsl #12               ; =65536
	b.hi	LBB63_24
; %bb.20:
	mov	w9, w21
	cmp	x10, x9
	b.ls	LBB63_24
; %bb.21:
	mov	x11, #58255                     ; =0xe38f
	movk	x11, #36408, lsl #16
	movk	x11, #14563, lsl #32
	movk	x11, #58254, lsl #48
	umulh	x8, x8, x11
	cmp	x10, x8, lsr #3
	b.hi	LBB63_24
; %bb.22:
	mov	w0, #0                          ; =0x0
	add	x8, x20, x9, lsl #3
	ldr	x11, [x19]
	str	x11, [x8, #24]
	add	x8, x20, x10, lsl #3
	add	x8, x8, x9
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #24]
	b	LBB63_24
LBB63_23:
	mov	w0, #3                          ; =0x3
LBB63_24:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB63_25:
	mov	w0, #3                          ; =0x3
	ret
	.loh AdrpLdr	Lloh294, Lloh295
	.loh AdrpLdr	Lloh296, Lloh297
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_live_capabilities_v1 ; -- Begin function experiment_gc_live_capabilities_v1
	.p2align	2
_experiment_gc_live_capabilities_v1:    ; @experiment_gc_live_capabilities_v1
	.cfi_startproc
; %bb.0:
	cmp	w0, #1
	mov	w8, #31                         ; =0x1f
	csel	x0, x8, xzr, eq
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_candidate_counts ; -- Begin function experiment_gc_candidate_counts
	.p2align	2
_experiment_gc_candidate_counts:        ; @experiment_gc_candidate_counts
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh298:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh299:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0]
	ldr	x9, [x0, #32]
	str	x9, [x8, #32]
	stp	q0, q1, [x8]
Lloh300:
	adrp	x0, _live_owner@TLVPPAGE
Lloh301:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldrsw	x9, [x0, #8]
	str	x9, [x8, #40]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh300, Lloh301
	.loh AdrpLdr	Lloh298, Lloh299
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_prepare_entry_v1 ; -- Begin function experiment_gc_prepare_entry_v1
	.p2align	2
_experiment_gc_prepare_entry_v1:        ; @experiment_gc_prepare_entry_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB66_9
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x0
Lloh302:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh303:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	ldr	x9, [x0]
	add	x8, x21, #1048
Lloh304:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh305:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	mov	x19, x0
	ldr	w10, [x0, #88]
Lloh306:
	adrp	x0, _candidate_phase@TLVPPAGE
Lloh307:
	ldr	x0, [x0, _candidate_phase@TLVPPAGEOFF]
	ldr	x11, [x0]
	blr	x11
	ldr	w11, [x0]
	cmp	x9, x8
	ccmp	w10, #0, #0, eq
	ccmp	w11, #0, #0, eq
	b.ne	LBB66_7
; %bb.2:
	mov	x0, x8
	bl	_blocks_valid
	cbz	w0, LBB66_7
; %bb.3:
	mov	x0, x21
	bl	_neoclr_gc_entry_check_v1
	cbnz	w0, LBB66_8
; %bb.4:
	add	x8, x21, #1064
	movi.2d	v0, #0000000000000000
	str	q0, [x8]
	add	x0, x20, #24
	mov	w1, #2064                       ; =0x810
	bl	_bzero
	ldr	x0, [x20, #2088]
	cbz	x0, LBB66_6
; %bb.5:
	ldr	x8, [x20, #2104]
	ldr	x9, [x20, #2112]
	add	x8, x9, x8
	lsl	x1, x8, #3
	bl	_bzero
LBB66_6:
	mov	w0, #0                          ; =0x0
	str	xzr, [x19, #56]
	b	LBB66_8
LBB66_7:
	mov	w0, #3                          ; =0x3
LBB66_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB66_9:
	mov	w0, #3                          ; =0x3
	ret
	.loh AdrpLdr	Lloh306, Lloh307
	.loh AdrpLdr	Lloh304, Lloh305
	.loh AdrpLdr	Lloh302, Lloh303
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_native_enter_v1  ; -- Begin function experiment_gc_native_enter_v1
	.p2align	2
_experiment_gc_native_enter_v1:         ; @experiment_gc_native_enter_v1
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	mov	x20, x0
	bl	_neoclr_root_probe_head_v1
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x20, LBB67_4
; %bb.1:
	cbz	x19, LBB67_4
; %bb.2:
	cbz	x8, LBB67_4
; %bb.3:
	ldr	x8, [x8, #8]
	cmp	x8, x20
	b.eq	LBB67_5
LBB67_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB67_5:
Lloh308:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh309:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x10, [x0]
	add	x11, x20, #1048
Lloh310:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh311:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w12, [x0, #88]
Lloh312:
	adrp	x0, _candidate_phase@TLVPPAGE
Lloh313:
	ldr	x0, [x0, _candidate_phase@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w13, [x0]
Lloh314:
	adrp	x0, _native_scope_depth@TLVPPAGE
Lloh315:
	ldr	x0, [x0, _native_scope_depth@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x21, x0
	ldr	w9, [x0]
Lloh316:
	adrp	x0, _native_scope_serial@TLVPPAGE
Lloh317:
	ldr	x0, [x0, _native_scope_serial@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cmp	x10, x11
	ccmp	w12, #0, #0, eq
	ccmp	w13, #0, #0, eq
	b.ne	LBB67_4
; %bb.6:
	ldr	x10, [x8]
	cmp	w9, #64
	ccmn	x10, #1, #4, ne
	b.eq	LBB67_4
; %bb.7:
	mov	x24, x8
Lloh318:
	adrp	x0, _native_scope_context@TLVPPAGE
Lloh319:
	ldr	x0, [x0, _native_scope_context@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	w9, #0
	ccmp	x8, x20, #4, ne
	b.ne	LBB67_10
; %bb.8:
	mov	x22, x0
Lloh320:
	adrp	x0, _live_owner@TLVPPAGE
Lloh321:
	ldr	x0, [x0, _live_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w8, [x0, #8]
	cbz	w8, LBB67_11
; %bb.9:
	mov	x23, x0
	bl	_candidate_dispose
Lloh322:
	adrp	x0, _candidate_counts@TLVPPAGE
Lloh323:
	ldr	x0, [x0, _candidate_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0, #16]
	add	x8, x8, #1
	str	x8, [x0, #16]
	str	xzr, [x23]
	str	wzr, [x23, #8]
Lloh324:
	adrp	x0, _native_scope_counts@TLVPPAGE
Lloh325:
	ldr	x0, [x0, _native_scope_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ldr	x9, [x0, #8]
	add	x9, x9, #1
	str	x9, [x0, #8]
	ldr	x10, [x24]
	ldr	w9, [x21]
	b	LBB67_12
LBB67_10:
	mov	w0, #3                          ; =0x3
	b	LBB67_4
LBB67_11:
Lloh326:
	adrp	x0, _native_scope_counts@TLVPPAGE
Lloh327:
	ldr	x0, [x0, _native_scope_counts@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
LBB67_12:
	str	x20, [x22]
	add	x10, x10, #1
	str	x10, [x24]
Lloh328:
	adrp	x0, _native_scope_tokens@TLVPPAGE
Lloh329:
	ldr	x0, [x0, _native_scope_tokens@TLVPPAGEOFF]
	ldr	x11, [x0]
	blr	x11
	add	w11, w9, #1
	str	w11, [x21]
	str	x10, [x0, w9, uxtw #3]
	ldr	x9, [x8, #24]
	cmp	x9, x11
	b.hs	LBB67_14
; %bb.13:
	str	x11, [x8, #24]
LBB67_14:
	mov	w0, #0                          ; =0x0
	ldr	x9, [x8]
	add	x9, x9, #1
	str	x9, [x8]
	str	x10, [x19]
	b	LBB67_4
	.loh AdrpLdr	Lloh316, Lloh317
	.loh AdrpLdr	Lloh314, Lloh315
	.loh AdrpLdr	Lloh312, Lloh313
	.loh AdrpLdr	Lloh310, Lloh311
	.loh AdrpLdr	Lloh308, Lloh309
	.loh AdrpLdr	Lloh318, Lloh319
	.loh AdrpLdr	Lloh320, Lloh321
	.loh AdrpLdr	Lloh324, Lloh325
	.loh AdrpLdr	Lloh322, Lloh323
	.loh AdrpLdr	Lloh326, Lloh327
	.loh AdrpLdr	Lloh328, Lloh329
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_native_leave_v1  ; -- Begin function experiment_gc_native_leave_v1
	.p2align	2
_experiment_gc_native_leave_v1:         ; @experiment_gc_native_leave_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh330:
	adrp	x0, _native_scope_depth@TLVPPAGE
Lloh331:
	ldr	x0, [x0, _native_scope_depth@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	w12, [x0]
	cbz	w12, LBB68_2
; %bb.1:
	mov	x10, x0
Lloh332:
	adrp	x0, _native_scope_context@TLVPPAGE
Lloh333:
	ldr	x0, [x0, _native_scope_context@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	x9, x8
	b.eq	LBB68_3
LBB68_2:
	mov	w0, #3                          ; =0x3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB68_3:
	mov	x11, x0
Lloh334:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh335:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	mov	w0, #3                          ; =0x3
	cbz	x1, LBB68_8
; %bb.4:
	ldr	x9, [x9]
	add	x8, x8, #1048
	cmp	x9, x8
	b.ne	LBB68_8
; %bb.5:
Lloh336:
	adrp	x0, _native_scope_tokens@TLVPPAGE
Lloh337:
	ldr	x0, [x0, _native_scope_tokens@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	sub	w8, w12, #1
	ldr	x9, [x0, w8, uxtw #3]
	cmp	x9, x1
	b.ne	LBB68_2
; %bb.6:
	str	w8, [x10]
	str	xzr, [x0, w8, uxtw #3]
	mov	w0, #0                          ; =0x0
	cbnz	w8, LBB68_8
; %bb.7:
	str	xzr, [x11]
LBB68_8:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh330, Lloh331
	.loh AdrpLdr	Lloh332, Lloh333
	.loh AdrpLdr	Lloh334, Lloh335
	.loh AdrpLdr	Lloh336, Lloh337
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_native_scope_counts ; -- Begin function experiment_gc_native_scope_counts
	.p2align	2
_experiment_gc_native_scope_counts:     ; @experiment_gc_native_scope_counts
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh338:
	adrp	x0, _native_scope_counts@TLVPPAGE
Lloh339:
	ldr	x0, [x0, _native_scope_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0]
	stp	q0, q1, [x8]
Lloh340:
	adrp	x0, _native_scope_depth@TLVPPAGE
Lloh341:
	ldr	x0, [x0, _native_scope_depth@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	w9, [x0]
	str	x9, [x8, #32]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh340, Lloh341
	.loh AdrpLdr	Lloh338, Lloh339
	.cfi_endproc
                                        ; -- End function
	.globl	_experiment_gc_string_slice_utf8_rooted_v1 ; -- Begin function experiment_gc_string_slice_utf8_rooted_v1
	.p2align	2
_experiment_gc_string_slice_utf8_rooted_v1: ; @experiment_gc_string_slice_utf8_rooted_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x21, x4
	mov	x19, x3
	mov	x22, x2
	mov	x23, x1
	mov	x24, x0
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB70_6
; %bb.1:
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x21, LBB70_7
; %bb.2:
	ldr	x20, [x8, #8]
	add	x8, x20, #1048
	cmp	x20, #0
	ccmp	x8, x19, #0, ne
	b.ne	LBB70_7
; %bb.3:
	add	x1, sp, #8
	mov	x0, x20
	bl	_experiment_gc_native_enter_v1
	cbnz	w0, LBB70_7
; %bb.4:
	mov	x0, x24
	mov	x1, x23
	mov	x2, x22
	mov	x3, x19
	mov	x4, x21
	bl	_neoclr_string_slice_utf8_rooted_v1
	mov	x1, x0
	ldr	x9, [sp, #8]
Lloh342:
	adrp	x0, _native_scope_depth@TLVPPAGE
Lloh343:
	ldr	x0, [x0, _native_scope_depth@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w12, [x0]
	cbz	w12, LBB70_6
; %bb.5:
	mov	x10, x0
Lloh344:
	adrp	x0, _native_scope_context@TLVPPAGE
Lloh345:
	ldr	x0, [x0, _native_scope_context@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x8, x20
	b.eq	LBB70_8
LBB70_6:
	mov	w0, #3                          ; =0x3
LBB70_7:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB70_8:
	mov	x11, x0
Lloh346:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh347:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x9, LBB70_7
; %bb.9:
	ldr	x8, [x8]
	cmp	x8, x19
	b.ne	LBB70_7
; %bb.10:
Lloh348:
	adrp	x0, _native_scope_tokens@TLVPPAGE
Lloh349:
	ldr	x0, [x0, _native_scope_tokens@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	sub	w8, w12, #1
	ldr	x12, [x0, w8, uxtw #3]
	cmp	x12, x9
	b.ne	LBB70_6
; %bb.11:
	str	w8, [x10]
	str	xzr, [x0, w8, uxtw #3]
	cbnz	w8, LBB70_13
; %bb.12:
	str	xzr, [x11]
LBB70_13:
	mov	x0, x1
	b	LBB70_7
	.loh AdrpLdr	Lloh342, Lloh343
	.loh AdrpLdr	Lloh344, Lloh345
	.loh AdrpLdr	Lloh346, Lloh347
	.loh AdrpLdr	Lloh348, Lloh349
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function shadow_drain
_shadow_drain:                          ; @shadow_drain
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh350:
	adrp	x0, _shadow_owner@TLVPPAGE
Lloh351:
	ldr	x0, [x0, _shadow_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x20, [x0]
	cbz	x20, LBB71_6
; %bb.1:
	ldr	x8, [x20, #120]
	cbz	x8, LBB71_6
; %bb.2:
	add	x0, x20, #8
	bl	_pthread_mutex_lock
	cbnz	w0, LBB71_5
LBB71_3:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x20, #132]
	cbnz	w8, LBB71_7
; %bb.4:                                ;   in Loop: Header=BB71_3 Depth=1
	add	x0, x20, #72
	add	x1, x20, #8
	bl	_pthread_cond_wait
	cbz	w0, LBB71_3
LBB71_5:
	bl	_abort
LBB71_6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB71_7:
	ldr	x19, [x20, #120]
	str	xzr, [x20, #120]
	add	x0, x20, #8
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB71_5
; %bb.8:
	ldr	w8, [x19, #152]
	cbz	w8, LBB71_12
; %bb.9:
	ldr	w8, [x19, #156]
	cbz	w8, LBB71_5
; %bb.10:
	ldp	x0, x1, [x19, #16]
	ldr	x2, [x19, #112]
	bl	_memcmp
	cbnz	w0, LBB71_5
; %bb.11:
Lloh352:
	adrp	x0, _shadow_stats@TLVPPAGE
Lloh353:
	ldr	x0, [x0, _shadow_stats@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	b	LBB71_13
LBB71_12:
Lloh354:
	adrp	x0, _shadow_stats@TLVPPAGE
Lloh355:
	ldr	x0, [x0, _shadow_stats@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	add	x8, x0, #32
LBB71_13:
	ldr	x9, [x8]
	add	x9, x9, #1
	str	x9, [x8]
	ldr	x8, [x19, #160]
	ldr	x9, [x0, #24]
	add	x8, x9, x8
	str	x8, [x0, #24]
	ldr	x0, [x19, #96]
	bl	_free
	ldr	x0, [x19, #64]
	bl	_gate_stop
	ldr	x0, [x19, #64]
	bl	_gate_destroy
	cbnz	w0, LBB71_5
; %bb.14:
	ldr	x8, [x19, #160]
Lloh356:
	adrp	x0, _live_time_counts@TLVPPAGE
Lloh357:
	ldr	x0, [x0, _live_time_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	add	x8, x9, x8
	str	x8, [x0]
	ldr	x8, [x19, #112]
Lloh358:
	adrp	x0, _live_counts@TLVPPAGE
Lloh359:
	ldr	x0, [x0, _live_counts@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	add	x8, x9, x8, lsl #5
	str	x8, [x0]
	ldr	q0, [x19, #80]
	ldur	q1, [x0, #8]
	add.2d	v0, v1, v0
	stur	q0, [x0, #8]
	ldr	w8, [x19, #156]
	cmp	w8, #0
	ldp	x8, x9, [x0, #24]
	cinc	x8, x8, ne
	cinc	x9, x9, eq
	stp	x8, x9, [x0, #24]
	ldr	x0, [x19, #64]
	bl	_free
	ldr	x0, [x19, #56]
	bl	_free
	ldr	x0, [x19, #144]
	bl	_free
	ldr	x0, [x19, #48]
	bl	_free
	ldr	x0, [x19, #40]
	bl	_free
	ldr	x0, [x19, #24]
	bl	_free
	ldr	x0, [x19, #16]
	bl	_free
	ldr	x0, [x19, #8]
	bl	_free
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_free
	.loh AdrpLdr	Lloh350, Lloh351
	.loh AdrpLdr	Lloh352, Lloh353
	.loh AdrpLdr	Lloh354, Lloh355
	.loh AdrpLdr	Lloh358, Lloh359
	.loh AdrpLdr	Lloh356, Lloh357
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_dense
_collect_dense:                         ; @collect_dense
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	mov	w9, #33088                      ; =0x8140
Lloh360:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh361:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
Lloh362:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh363:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh364:
	ldr	x8, [x8]
	stur	x8, [x29, #-24]
	ldr	x11, [x0, #1064]
	cbz	x11, LBB72_15
; %bb.1:
	sub	x9, x11, #1
	mov	w8, #5                          ; =0x5
LBB72_2:                                ; =>This Inner Loop Header: Depth=1
	add	w8, w8, #1
	lsr	x10, x9, x8
	cmp	x10, #4095
	b.hi	LBB72_2
; %bb.3:
	mov	x13, #0                         ; =0x0
	mov	x12, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	ldr	x14, [x0, #1048]
	add	x15, sp, #312
	add	x16, sp, #56
	b	LBB72_6
LBB72_4:                                ;   in Loop: Header=BB72_6 Depth=1
	mov	w13, w13
LBB72_5:                                ;   in Loop: Header=BB72_6 Depth=1
	orr	w9, w9, w17
	cmp	x12, x11
	b.hs	LBB72_16
LBB72_6:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB72_13 Depth 2
	add	x4, x14, x12
	ldr	x5, [x4, #24]
	cmp	x5, #1
	cset	w17, hi
	cbz	x5, LBB72_12
; %bb.7:                                ;   in Loop: Header=BB72_6 Depth=1
	ldr	x5, [x4, #16]
	cmp	x5, #6
	b.ne	LBB72_12
; %bb.8:                                ;   in Loop: Header=BB72_6 Depth=1
	cmp	x10, #32
	b.hi	LBB72_12
; %bb.9:                                ;   in Loop: Header=BB72_6 Depth=1
	b.eq	LBB72_11
; %bb.10:                               ;   in Loop: Header=BB72_6 Depth=1
	str	x4, [x16, x10, lsl #3]
LBB72_11:                               ;   in Loop: Header=BB72_6 Depth=1
	add	x10, x10, #1
LBB72_12:                               ;   in Loop: Header=BB72_6 Depth=1
	ldr	x5, [x4]
	add	x12, x5, x12
	cmp	x13, #4095
	b.hi	LBB72_5
LBB72_13:                               ;   Parent Loop BB72_6 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x5, x13, x8
	cmp	x5, x12
	b.hs	LBB72_4
; %bb.14:                               ;   in Loop: Header=BB72_13 Depth=2
	str	x4, [x15, x13, lsl #3]
	add	x5, x13, #1
	mov	x13, x5
	cmp	x5, #1, lsl #12                 ; =4096
	b.ne	LBB72_13
	b	LBB72_5
LBB72_15:
	mov	x10, #0                         ; =0x0
	mov	w9, #0                          ; =0x0
	mov	w8, #6                          ; =0x6
LBB72_16:
	add	x11, sp, #312
	add	x12, sp, #56
	stp	x11, x12, [sp]
	mov	w11, #4096                      ; =0x1000
	stp	w11, w8, [sp, #16]
	str	w10, [sp, #24]
	stp	xzr, xzr, [sp, #32]
	str	w9, [sp, #48]
	mov	x4, sp
	bl	_collect_indexed
	ldur	x8, [x29, #-24]
Lloh365:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh366:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh367:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB72_18
; %bb.17:
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #320
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #32             ; 16-byte Folded Reload
	ret
LBB72_18:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh362, Lloh363, Lloh364
	.loh AdrpLdrGotLdr	Lloh365, Lloh366, Lloh367
	.loh AdrpLdrGot	Lloh360, Lloh361
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function collect_indexed
_collect_indexed:                       ; @collect_indexed
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #1152
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh368:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh369:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh370:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	cmp	w3, #256
	b.hi	LBB73_3
; %bb.1:
	mov	x22, x4
	mov	x20, x0
	cbnz	x2, LBB73_6
; %bb.2:
	cbz	w3, LBB73_6
LBB73_3:
	mov	w0, #3                          ; =0x3
LBB73_4:
	ldur	x8, [x29, #-96]
Lloh371:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh372:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh373:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB73_232
; %bb.5:
	add	sp, sp, #1152
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB73_6:
	add	x19, x20, #1048
Lloh374:
	adrp	x0, _resource_head@TLVPPAGE
Lloh375:
	ldr	x0, [x0, _resource_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x26, x0
	ldr	x9, [x0]
	cbz	x9, LBB73_18
; %bb.7:
Lloh376:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh377:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ldr	x10, [x0, #40]
	ldr	x11, [x0, #56]
	mov	w0, #3                          ; =0x3
	b	LBB73_9
LBB73_8:                                ;   in Loop: Header=BB73_9 Depth=1
	ldr	x9, [x9, #32]
	cbz	x9, LBB73_18
LBB73_9:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB73_14 Depth 2
	ldr	x12, [x9]
	cmp	x12, x20
	b.ne	LBB73_8
; %bb.10:                               ;   in Loop: Header=BB73_9 Depth=1
	ldr	x12, [x9, #8]
	cbz	x12, LBB73_3
; %bb.11:                               ;   in Loop: Header=BB73_9 Depth=1
	add	x10, x10, #1
	str	x10, [x8, #40]
	ldr	x13, [x19]
	cmp	x13, x12
	b.hi	LBB73_61
; %bb.12:                               ;   in Loop: Header=BB73_9 Depth=1
	ldr	x14, [x20, #1064]
	sub	x15, x12, x13
	cmp	x15, x14
	b.hs	LBB73_61
; %bb.13:                               ;   in Loop: Header=BB73_9 Depth=1
	ldr	x16, [x22]
	ldr	w17, [x22, #20]
	lsr	x17, x15, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x13
LBB73_14:                               ;   Parent Loop BB73_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x17, x14
	b.hs	LBB73_3
; %bb.15:                               ;   in Loop: Header=BB73_14 Depth=2
	mov	x16, x17
	add	x11, x11, #1
	str	x11, [x8, #56]
	ldr	x17, [x13, x17]
	add	x17, x17, x16
	cmp	x15, x17
	b.hs	LBB73_14
; %bb.16:                               ;   in Loop: Header=BB73_9 Depth=1
	add	x13, x13, x16
	ldrb	w14, [x13, #24]
	tbz	w14, #0, LBB73_4
; %bb.17:                               ;   in Loop: Header=BB73_9 Depth=1
	add	x13, x13, #32
	cmp	x13, x12
	b.eq	LBB73_8
	b	LBB73_4
LBB73_18:
	cbz	w3, LBB73_39
; %bb.19:
Lloh378:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh379:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	x9, #0                          ; =0x0
	ldr	x11, [x0, #40]
	ldr	x10, [x0, #56]
	mov	w12, w3
	mov	w13, #24                        ; =0x18
LBB73_20:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB73_24 Depth 2
                                        ;     Child Loop BB73_32 Depth 2
	madd	x14, x9, x13, x2
	ldr	x16, [x14]
	cbz	x16, LBB73_36
; %bb.21:                               ;   in Loop: Header=BB73_20 Depth=1
	add	x15, x11, #1
	str	x15, [x8, #40]
	ldr	x17, [x19]
	cmp	x17, x16
	b.hi	LBB73_61
; %bb.22:                               ;   in Loop: Header=BB73_20 Depth=1
	ldr	x0, [x20, #1064]
	sub	x4, x16, x17
	cmp	x4, x0
	b.hs	LBB73_61
; %bb.23:                               ;   in Loop: Header=BB73_20 Depth=1
	ldr	x5, [x22]
	ldr	w6, [x22, #20]
	lsr	x6, x4, x6
	ldr	x5, [x5, x6, lsl #3]
	sub	x6, x5, x17
LBB73_24:                               ;   Parent Loop BB73_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x6, x0
	b.hs	LBB73_3
; %bb.25:                               ;   in Loop: Header=BB73_24 Depth=2
	mov	x5, x6
	add	x10, x10, #1
	str	x10, [x8, #56]
	ldr	x6, [x17, x6]
	add	x6, x6, x5
	cmp	x4, x6
	b.hs	LBB73_24
; %bb.26:                               ;   in Loop: Header=BB73_20 Depth=1
	add	x17, x17, x5
	mov	w0, #3                          ; =0x3
	ldrb	w4, [x17, #24]
	tbz	w4, #0, LBB73_4
; %bb.27:                               ;   in Loop: Header=BB73_20 Depth=1
	add	x17, x17, #32
	cmp	x17, x16
	b.ne	LBB73_4
; %bb.28:                               ;   in Loop: Header=BB73_20 Depth=1
	ldr	x14, [x14, #8]
	cbz	x14, LBB73_37
; %bb.29:                               ;   in Loop: Header=BB73_20 Depth=1
	add	x11, x11, #2
	str	x11, [x8, #40]
	ldr	x15, [x19]
	cmp	x15, x14
	b.hi	LBB73_88
; %bb.30:                               ;   in Loop: Header=BB73_20 Depth=1
	ldr	x16, [x20, #1064]
	sub	x17, x14, x15
	cmp	x17, x16
	b.hs	LBB73_88
; %bb.31:                               ;   in Loop: Header=BB73_20 Depth=1
	ldr	x0, [x22]
	ldr	w4, [x22, #20]
	lsr	x4, x17, x4
	ldr	x0, [x0, x4, lsl #3]
	sub	x4, x0, x15
LBB73_32:                               ;   Parent Loop BB73_20 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x4, x16
	b.hs	LBB73_3
; %bb.33:                               ;   in Loop: Header=BB73_32 Depth=2
	mov	x0, x4
	add	x10, x10, #1
	str	x10, [x8, #56]
	ldr	x4, [x15, x4]
	add	x4, x4, x0
	cmp	x17, x4
	b.hs	LBB73_32
; %bb.34:                               ;   in Loop: Header=BB73_20 Depth=1
	add	x15, x15, x0
	mov	w0, #3                          ; =0x3
	ldrb	w16, [x15, #24]
	tbz	w16, #0, LBB73_4
; %bb.35:                               ;   in Loop: Header=BB73_20 Depth=1
	add	x15, x15, #32
	cmp	x15, x14
	b.eq	LBB73_38
	b	LBB73_4
LBB73_36:                               ;   in Loop: Header=BB73_20 Depth=1
	ldr	x14, [x14, #8]
	cbz	x14, LBB73_38
	b	LBB73_3
LBB73_37:                               ;   in Loop: Header=BB73_20 Depth=1
	mov	x11, x15
LBB73_38:                               ;   in Loop: Header=BB73_20 Depth=1
	add	x9, x9, #1
	cmp	x9, x12
	b.ne	LBB73_20
LBB73_39:
Lloh380:
	adrp	x0, _host_head@TLVPPAGE
Lloh381:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x21, x0
	ldr	x9, [x0]
	cbz	x9, LBB73_62
; %bb.40:
Lloh382:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh383:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ldr	x10, [x0, #40]
	ldr	x11, [x0, #56]
	b	LBB73_42
LBB73_41:                               ;   in Loop: Header=BB73_42 Depth=1
	ldr	x9, [x9, #48]
	cbz	x9, LBB73_62
LBB73_42:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB73_47 Depth 2
                                        ;     Child Loop BB73_57 Depth 2
	ldr	x12, [x9]
	cmp	x12, x20
	b.ne	LBB73_41
; %bb.43:                               ;   in Loop: Header=BB73_42 Depth=1
	ldr	x12, [x9, #8]
	cbz	x12, LBB73_51
; %bb.44:                               ;   in Loop: Header=BB73_42 Depth=1
	add	x10, x10, #1
	str	x10, [x8, #40]
	ldr	x13, [x19]
	cmp	x13, x12
	b.hi	LBB73_61
; %bb.45:                               ;   in Loop: Header=BB73_42 Depth=1
	ldr	x14, [x20, #1064]
	sub	x15, x12, x13
	cmp	x15, x14
	b.hs	LBB73_61
; %bb.46:                               ;   in Loop: Header=BB73_42 Depth=1
	ldr	x16, [x22]
	ldr	w17, [x22, #20]
	lsr	x17, x15, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x13
LBB73_47:                               ;   Parent Loop BB73_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x17, x14
	b.hs	LBB73_3
; %bb.48:                               ;   in Loop: Header=BB73_47 Depth=2
	mov	x16, x17
	add	x11, x11, #1
	str	x11, [x8, #56]
	ldr	x17, [x13, x17]
	add	x17, x17, x16
	cmp	x15, x17
	b.hs	LBB73_47
; %bb.49:                               ;   in Loop: Header=BB73_42 Depth=1
	add	x13, x13, x16
	mov	w0, #3                          ; =0x3
	ldrb	w14, [x13, #24]
	tbz	w14, #0, LBB73_4
; %bb.50:                               ;   in Loop: Header=BB73_42 Depth=1
	add	x13, x13, #32
	cmp	x13, x12
	b.ne	LBB73_4
LBB73_51:                               ;   in Loop: Header=BB73_42 Depth=1
	ldr	w12, [x9, #24]
	cbz	w12, LBB73_41
; %bb.52:                               ;   in Loop: Header=BB73_42 Depth=1
	ldr	w12, [x9, #28]
	cbnz	w12, LBB73_41
; %bb.53:                               ;   in Loop: Header=BB73_42 Depth=1
	ldr	x12, [x9, #16]
	cbz	x12, LBB73_3
; %bb.54:                               ;   in Loop: Header=BB73_42 Depth=1
	add	x10, x10, #1
	str	x10, [x8, #40]
	ldr	x13, [x19]
	cmp	x13, x12
	b.hi	LBB73_61
; %bb.55:                               ;   in Loop: Header=BB73_42 Depth=1
	ldr	x14, [x20, #1064]
	sub	x15, x12, x13
	cmp	x15, x14
	b.hs	LBB73_61
; %bb.56:                               ;   in Loop: Header=BB73_42 Depth=1
	ldr	x16, [x22]
	ldr	w17, [x22, #20]
	lsr	x17, x15, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x13
LBB73_57:                               ;   Parent Loop BB73_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x17, x14
	b.hs	LBB73_3
; %bb.58:                               ;   in Loop: Header=BB73_57 Depth=2
	mov	x16, x17
	add	x11, x11, #1
	str	x11, [x8, #56]
	ldr	x17, [x13, x17]
	add	x17, x17, x16
	cmp	x15, x17
	b.hs	LBB73_57
; %bb.59:                               ;   in Loop: Header=BB73_42 Depth=1
	add	x13, x13, x16
	mov	w0, #3                          ; =0x3
	ldrb	w14, [x13, #24]
	tbz	w14, #0, LBB73_4
; %bb.60:                               ;   in Loop: Header=BB73_42 Depth=1
	add	x13, x13, #32
	cmp	x13, x12
	b.eq	LBB73_41
	b	LBB73_4
LBB73_61:
	ldr	x9, [x8, #48]
	add	x9, x9, #1
	str	x9, [x8, #48]
	b	LBB73_3
LBB73_62:
	str	x2, [sp, #48]                   ; 8-byte Folded Spill
	str	w3, [sp, #72]                   ; 4-byte Folded Spill
	mov	x24, x1
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB73_75
; %bb.63:
	mov	x8, x0
Lloh384:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh385:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	ldr	x10, [x0, #40]
	ldr	x11, [x0, #56]
	mov	w0, #3                          ; =0x3
	b	LBB73_65
LBB73_64:                               ;   in Loop: Header=BB73_65 Depth=1
	ldr	x8, [x8, #8]
	cbz	x8, LBB73_75
LBB73_65:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB73_71 Depth 2
	ldr	x12, [x8, #16]
	cmp	x12, x20
	b.ne	LBB73_64
; %bb.66:                               ;   in Loop: Header=BB73_65 Depth=1
	ldr	w12, [x8, #32]
	cbnz	w12, LBB73_64
; %bb.67:                               ;   in Loop: Header=BB73_65 Depth=1
	ldr	x12, [x8, #24]
	cbz	x12, LBB73_3
; %bb.68:                               ;   in Loop: Header=BB73_65 Depth=1
	add	x10, x10, #1
	str	x10, [x9, #40]
	ldr	x13, [x19]
	cmp	x13, x12
	b.hi	LBB73_173
; %bb.69:                               ;   in Loop: Header=BB73_65 Depth=1
	ldr	x14, [x20, #1064]
	sub	x15, x12, x13
	cmp	x15, x14
	b.hs	LBB73_173
; %bb.70:                               ;   in Loop: Header=BB73_65 Depth=1
	ldr	x16, [x22]
	ldr	w17, [x22, #20]
	lsr	x17, x15, x17
	ldr	x16, [x16, x17, lsl #3]
	sub	x17, x16, x13
LBB73_71:                               ;   Parent Loop BB73_65 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x17, x14
	b.hs	LBB73_3
; %bb.72:                               ;   in Loop: Header=BB73_71 Depth=2
	mov	x16, x17
	add	x11, x11, #1
	str	x11, [x9, #56]
	ldr	x17, [x13, x17]
	add	x17, x17, x16
	cmp	x15, x17
	b.hs	LBB73_71
; %bb.73:                               ;   in Loop: Header=BB73_65 Depth=1
	add	x13, x13, x16
	ldrb	w14, [x13, #24]
	tbz	w14, #0, LBB73_4
; %bb.74:                               ;   in Loop: Header=BB73_65 Depth=1
	add	x13, x13, #32
	cmp	x13, x12
	b.eq	LBB73_64
	b	LBB73_4
LBB73_75:
	add	x1, sp, #96
	mov	x0, x20
	mov	w2, #65                         ; =0x41
	bl	_neoclr_probe_fault_roots_v1
	tbnz	w0, #31, LBB73_3
; %bb.76:
	mov	x25, x0
	bl	_neoclr_roots_parked_v1
	cbnz	x0, LBB73_82
LBB73_77:
	str	x21, [sp, #40]                  ; 8-byte Folded Spill
	str	xzr, [sp, #88]
	ldr	w8, [x22, #48]
	cbnz	w8, LBB73_79
; %bb.78:
	ldr	w8, [x22, #24]
	cmp	w8, #32
	b.ls	LBB73_89
LBB73_79:
	ldr	x8, [x20, #1064]
	cbz	x8, LBB73_92
; %bb.80:
	mov	x21, #0                         ; =0x0
	b	LBB73_85
LBB73_81:                               ;   in Loop: Header=BB73_82 Depth=1
	ldr	x0, [x0, #8]
	cbz	x0, LBB73_77
LBB73_82:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #16]
	cmp	x8, x20
	b.ne	LBB73_81
; %bb.83:                               ;   in Loop: Header=BB73_82 Depth=1
	str	wzr, [x0, #36]
	b	LBB73_81
LBB73_84:                               ;   in Loop: Header=BB73_85 Depth=1
	ldr	x9, [x23]
	add	x21, x9, x21
	cmp	x21, x8
	b.hs	LBB73_92
LBB73_85:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	add	x23, x9, x21
	ldr	x9, [x23, #24]
	and	x10, x9, #0x1
	str	x10, [x23, #24]
	tbz	w9, #0, LBB73_84
; %bb.86:                               ;   in Loop: Header=BB73_85 Depth=1
	ldr	x9, [x23, #16]
	cmp	x9, #6
	b.ne	LBB73_84
; %bb.87:                               ;   in Loop: Header=BB73_85 Depth=1
	add	x2, x23, #32
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	ldr	x8, [x20, #1064]
	b	LBB73_84
LBB73_88:
	ldr	x9, [x8, #48]
	add	x9, x9, #1
	str	x9, [x8, #48]
	b	LBB73_4
LBB73_89:
	cbz	w8, LBB73_92
; %bb.90:
	mov	x21, #0                         ; =0x0
LBB73_91:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x22, #8]
	ldr	x8, [x8, x21, lsl #3]
	add	x2, x8, #32
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	add	x21, x21, #1
	ldr	w8, [x22, #24]
	cmp	x21, x8
	b.lo	LBB73_91
LBB73_92:
	cbz	w25, LBB73_97
; %bb.93:
	mov	w21, w25
	add	x8, sp, #96
	add	x23, x8, #8
	b	LBB73_95
LBB73_94:                               ;   in Loop: Header=BB73_95 Depth=1
	add	x23, x23, #16
	subs	x21, x21, #1
	b.eq	LBB73_97
LBB73_95:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x23]
	cmp	w8, #8
	b.ne	LBB73_94
; %bb.96:                               ;   in Loop: Header=BB73_95 Depth=1
	ldur	x8, [x23, #-8]
	ldr	x2, [x8]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	b	LBB73_94
LBB73_97:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x21, [x8]
	cbnz	x21, LBB73_101
LBB73_98:
	ldr	x2, [x20, #1072]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	add	x3, sp, #88
	mov	x0, x20
	mov	x1, x22
	mov	x2, x24
	bl	_mark_frames
	bl	_neoclr_roots_parked_v1
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	ldr	w2, [sp, #72]                   ; 4-byte Folded Reload
	cbz	x0, LBB73_107
; %bb.99:
	mov	x24, x0
	b	LBB73_105
LBB73_100:                              ;   in Loop: Header=BB73_101 Depth=1
	ldr	x21, [x21, #48]
	cbz	x21, LBB73_98
LBB73_101:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x21]
	cmp	x8, x20
	b.ne	LBB73_100
; %bb.102:                              ;   in Loop: Header=BB73_101 Depth=1
	ldr	w8, [x21, #24]
	cbnz	w8, LBB73_100
; %bb.103:                              ;   in Loop: Header=BB73_101 Depth=1
	ldr	x2, [x21, #8]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	b	LBB73_100
LBB73_104:                              ;   in Loop: Header=BB73_105 Depth=1
	ldr	x24, [x24, #8]
	cbz	x24, LBB73_107
LBB73_105:                              ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x24, #16]
	cbnz	x8, LBB73_104
; %bb.106:                              ;   in Loop: Header=BB73_105 Depth=1
	ldr	x2, [x24]
	add	x3, sp, #88
	mov	x0, x20
	mov	x1, x22
	bl	_mark_frames
	ldr	w2, [sp, #72]                   ; 4-byte Folded Reload
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	b	LBB73_104
LBB73_107:
Lloh386:
	adrp	x0, _candidate_phase@TLVPPAGE
Lloh387:
	ldr	x0, [x0, _candidate_phase@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w8, [x0]
	cmp	w8, #1
	b.eq	LBB73_169
; %bb.108:
	str	x26, [sp]                       ; 8-byte Folded Spill
	str	x20, [sp, #32]                  ; 8-byte Folded Spill
	cmp	w8, #2
	b.ne	LBB73_113
; %bb.109:
	add	x2, sp, #88
	ldr	x0, [sp, #32]                   ; 8-byte Folded Reload
	mov	x1, x22
	bl	_candidate_seed
	ldr	w2, [sp, #72]                   ; 4-byte Folded Reload
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	cbz	w0, LBB73_113
LBB73_110:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #1064]
	cbz	x8, LBB73_3
; %bb.111:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x19]
LBB73_112:                              ; =>This Inner Loop Header: Depth=1
	add	x11, x10, x9
	ldr	x12, [x11, #24]
	and	x12, x12, #0x1
	str	x12, [x11, #24]
	ldr	x11, [x11]
	add	x9, x11, x9
	cmp	x9, x8
	b.lo	LBB73_112
	b	LBB73_3
LBB73_113:
Lloh388:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh389:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	x0, [sp, #80]                   ; 8-byte Folded Spill
	ldr	x25, [sp, #88]
	add	x8, x1, #8
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w8, w2
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
LBB73_114:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB73_139 Depth 2
                                        ;       Child Loop BB73_166 Depth 3
                                        ;         Child Loop BB73_168 Depth 4
                                        ;       Child Loop BB73_149 Depth 3
                                        ;       Child Loop BB73_156 Depth 3
                                        ;     Child Loop BB73_121 Depth 2
                                        ;     Child Loop BB73_125 Depth 2
                                        ;     Child Loop BB73_131 Depth 2
	ldr	x8, [x22, #40]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	cbnz	x25, LBB73_139
LBB73_115:                              ;   in Loop: Header=BB73_114 Depth=1
	ldp	x21, x20, [sp, #24]             ; 16-byte Folded Reload
	ldr	x23, [sp, #8]                   ; 8-byte Folded Reload
	cbnz	w2, LBB73_121
LBB73_116:                              ;   in Loop: Header=BB73_114 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x21, [x8]
	cbnz	x21, LBB73_125
LBB73_117:                              ;   in Loop: Header=BB73_114 Depth=1
	bl	_neoclr_roots_parked_v1
	ldr	w2, [sp, #72]                   ; 4-byte Folded Reload
	mov	x25, x0
	cbnz	x0, LBB73_131
LBB73_118:                              ;   in Loop: Header=BB73_114 Depth=1
	ldr	x25, [sp, #88]
	cbnz	x25, LBB73_114
; %bb.119:                              ;   in Loop: Header=BB73_114 Depth=1
	ldr	x8, [x22, #40]
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	cmp	x9, x8
	b.ne	LBB73_114
	b	LBB73_174
LBB73_120:                              ;   in Loop: Header=BB73_121 Depth=2
	add	x23, x23, #24
	subs	x21, x21, #1
	b.eq	LBB73_116
LBB73_121:                              ;   Parent Loop BB73_114 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x8, [x23, #-8]
	cbz	x8, LBB73_120
; %bb.122:                              ;   in Loop: Header=BB73_121 Depth=2
	ldurb	w8, [x8, #-8]
	tbz	w8, #1, LBB73_120
; %bb.123:                              ;   in Loop: Header=BB73_121 Depth=2
	ldr	x2, [x23]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	b	LBB73_120
LBB73_124:                              ;   in Loop: Header=BB73_125 Depth=2
	ldr	x21, [x21, #48]
	cbz	x21, LBB73_117
LBB73_125:                              ;   Parent Loop BB73_114 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x21]
	cmp	x8, x20
	b.ne	LBB73_124
; %bb.126:                              ;   in Loop: Header=BB73_125 Depth=2
	ldr	w8, [x21, #24]
	cbz	w8, LBB73_124
; %bb.127:                              ;   in Loop: Header=BB73_125 Depth=2
	ldr	w8, [x21, #28]
	cbnz	w8, LBB73_124
; %bb.128:                              ;   in Loop: Header=BB73_125 Depth=2
	ldr	x8, [x21, #16]
	ldurb	w8, [x8, #-8]
	tbz	w8, #1, LBB73_124
; %bb.129:                              ;   in Loop: Header=BB73_125 Depth=2
	ldr	x2, [x21, #8]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	b	LBB73_124
LBB73_130:                              ;   in Loop: Header=BB73_131 Depth=2
	ldr	x25, [x25, #8]
	cbz	x25, LBB73_118
LBB73_131:                              ;   Parent Loop BB73_114 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x25, #16]
	cmp	x8, x20
	b.ne	LBB73_130
; %bb.132:                              ;   in Loop: Header=BB73_131 Depth=2
	ldr	w8, [x25, #32]
	cbnz	w8, LBB73_130
; %bb.133:                              ;   in Loop: Header=BB73_131 Depth=2
	ldr	w8, [x25, #36]
	cbnz	w8, LBB73_130
; %bb.134:                              ;   in Loop: Header=BB73_131 Depth=2
	ldr	x8, [x25, #24]
	ldurb	w8, [x8, #-8]
	tbz	w8, #1, LBB73_130
; %bb.135:                              ;   in Loop: Header=BB73_131 Depth=2
	mov	w8, #1                          ; =0x1
	str	w8, [x25, #36]
	ldr	x2, [x25]
	add	x3, sp, #88
	mov	x0, x20
	mov	x1, x22
	bl	_mark_frames
	ldr	w2, [sp, #72]                   ; 4-byte Folded Reload
	b	LBB73_130
LBB73_136:                              ;   in Loop: Header=BB73_139 Depth=2
	ldr	x2, [x8]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
LBB73_137:                              ;   in Loop: Header=BB73_139 Depth=2
	ldr	x9, [sp, #88]
	ldr	w2, [sp, #72]                   ; 4-byte Folded Reload
LBB73_138:                              ;   in Loop: Header=BB73_139 Depth=2
	mov	x25, x9
	cbz	x9, LBB73_115
LBB73_139:                              ;   Parent Loop BB73_114 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB73_166 Depth 3
                                        ;         Child Loop BB73_168 Depth 4
                                        ;       Child Loop BB73_149 Depth 3
                                        ;       Child Loop BB73_156 Depth 3
	ldp	x10, x8, [x25, #16]
	and	x9, x8, #0xfffffffffffffff8
	str	x9, [sp, #88]
	mov	w8, #7                          ; =0x7
	str	x8, [x25, #24]
	cmp	x10, #4
	b.gt	LBB73_151
; %bb.140:                              ;   in Loop: Header=BB73_139 Depth=2
	cmp	x10, #2
	b.eq	LBB73_154
; %bb.141:                              ;   in Loop: Header=BB73_139 Depth=2
	cmp	x10, #4
	b.ne	LBB73_138
; %bb.142:                              ;   in Loop: Header=BB73_139 Depth=2
	ldr	x8, [x25, #8]
	subs	x8, x8, #16
	b.lo	LBB73_110
; %bb.143:                              ;   in Loop: Header=BB73_139 Depth=2
	ldr	w23, [x25, #32]
	mov	x9, #-5                         ; =0xfffffffffffffffb
	movk	x9, #32767, lsl #16
	add	x9, x23, x9
	cmn	x9, #2
	b.lo	LBB73_110
; %bb.144:                              ;   in Loop: Header=BB73_139 Depth=2
	ldr	x26, [x25, #40]
	mov	w9, #4                          ; =0x4
	movk	w9, #32768, lsl #16
	cmp	x23, x9
	mov	w9, #8                          ; =0x8
	cinc	x9, x9, eq
	udiv	x8, x8, x9
	cmp	x26, x8
	b.hi	LBB73_110
; %bb.145:                              ;   in Loop: Header=BB73_139 Depth=2
	cbz	x26, LBB73_137
; %bb.146:                              ;   in Loop: Header=BB73_139 Depth=2
	add	x21, x25, #48
	add	x25, x21, x26, lsl #3
	b	LBB73_149
LBB73_147:                              ;   in Loop: Header=BB73_149 Depth=3
	ldr	x2, [x21]
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
LBB73_148:                              ;   in Loop: Header=BB73_149 Depth=3
	add	x25, x25, #1
	add	x21, x21, #8
	subs	x26, x26, #1
	b.eq	LBB73_137
LBB73_149:                              ;   Parent Loop BB73_114 Depth=1
                                        ;     Parent Loop BB73_139 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	mov	w8, #4                          ; =0x4
	movk	w8, #32768, lsl #16
	cmp	x23, x8
	b.ne	LBB73_147
; %bb.150:                              ;   in Loop: Header=BB73_149 Depth=3
	ldrb	w8, [x25]
	cbnz	w8, LBB73_147
	b	LBB73_148
LBB73_151:                              ;   in Loop: Header=BB73_139 Depth=2
	add	x8, x25, #32
	cmp	x10, #5
	b.eq	LBB73_157
; %bb.152:                              ;   in Loop: Header=BB73_139 Depth=2
	cmp	x10, #6
	b.ne	LBB73_138
; %bb.153:                              ;   in Loop: Header=BB73_139 Depth=2
	ldr	x9, [x25, #8]
	cmp	x9, #8
	b.eq	LBB73_136
	b	LBB73_110
LBB73_154:                              ;   in Loop: Header=BB73_139 Depth=2
	ldr	x8, [x25, #8]
	cmp	x8, #16
	b.lo	LBB73_137
; %bb.155:                              ;   in Loop: Header=BB73_139 Depth=2
	add	x21, x25, #40
	mov	w23, #16                        ; =0x10
LBB73_156:                              ;   Parent Loop BB73_114 Depth=1
                                        ;     Parent Loop BB73_139 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [x9, #88]
	add	x8, x8, #1
	str	x8, [x9, #88]
	ldr	x2, [x21], #8
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	add	x23, x23, #8
	ldr	x8, [x25, #8]
	cmp	x23, x8
	b.ls	LBB73_156
	b	LBB73_137
LBB73_157:                              ;   in Loop: Header=BB73_139 Depth=2
	ldr	x9, [x25, #8]
	subs	x9, x9, #24
	b.lo	LBB73_110
; %bb.158:                              ;   in Loop: Header=BB73_139 Depth=2
	ldr	x10, [x25, #32]
	mov	w11, w10
	mov	w12, #4                         ; =0x4
	movk	w12, #32768, lsl #16
	add	x12, x12, #1
	lsr	x10, x10, #32
	cmp	x10, #1024
	ccmp	x11, x12, #0, ls
	b.ne	LBB73_110
; %bb.159:                              ;   in Loop: Header=BB73_139 Depth=2
	ldr	x20, [x25, #48]
	cmp	x20, #1
	ccmp	x10, #0, #4, ne
	b.ne	LBB73_110
; %bb.160:                              ;   in Loop: Header=BB73_139 Depth=2
	sub	x10, x20, #257
	cmn	x10, #256
	b.lo	LBB73_110
; %bb.161:                              ;   in Loop: Header=BB73_139 Depth=2
	ldr	x23, [x25, #40]
	cmp	x23, #16, lsl #12               ; =65536
	b.hi	LBB73_110
; %bb.162:                              ;   in Loop: Header=BB73_139 Depth=2
	mov	w10, #1                         ; =0x1
	bfi	x10, x20, #3, #60
	udiv	x9, x9, x10
	cmp	x23, x9
	b.hi	LBB73_110
; %bb.163:                              ;   in Loop: Header=BB73_139 Depth=2
	cbz	x23, LBB73_137
; %bb.164:                              ;   in Loop: Header=BB73_139 Depth=2
	mov	x27, #0                         ; =0x0
	lsl	x28, x20, #3
	mul	x9, x23, x20
	add	x8, x8, x9, lsl #3
	add	x21, x8, #24
	add	x24, x25, #56
	b	LBB73_166
LBB73_165:                              ;   in Loop: Header=BB73_166 Depth=3
	add	x27, x27, #1
	add	x24, x24, x28
	cmp	x27, x23
	b.eq	LBB73_137
LBB73_166:                              ;   Parent Loop BB73_114 Depth=1
                                        ;     Parent Loop BB73_139 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB73_168 Depth 4
	ldrb	w8, [x21, x27]
	cbz	w8, LBB73_165
; %bb.167:                              ;   in Loop: Header=BB73_166 Depth=3
	mov	x25, x24
	mov	x26, x20
LBB73_168:                              ;   Parent Loop BB73_114 Depth=1
                                        ;     Parent Loop BB73_139 Depth=2
                                        ;       Parent Loop BB73_166 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ldr	x2, [x25], #8
	add	x3, sp, #88
	mov	x0, x19
	mov	x1, x22
	bl	_mark
	subs	x26, x26, #1
	b.ne	LBB73_168
	b	LBB73_165
LBB73_169:
	mov	x0, x20
	bl	_shadow_begin
	ldr	x8, [x20, #1064]
	cbz	x8, LBB73_172
; %bb.170:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x19]
LBB73_171:                              ; =>This Inner Loop Header: Depth=1
	add	x11, x10, x9
	ldr	x12, [x11, #24]
	and	x12, x12, #0x1
	str	x12, [x11, #24]
	ldr	x11, [x11]
	add	x9, x11, x9
	cmp	x9, x8
	b.lo	LBB73_171
LBB73_172:
	mov	w0, #0                          ; =0x0
	b	LBB73_4
LBB73_173:
	ldr	x8, [x9, #48]
	add	x8, x8, #1
	str	x8, [x9, #48]
	b	LBB73_3
LBB73_174:
	ldr	x22, [sp]                       ; 8-byte Folded Reload
	ldr	x8, [x22]
	cbz	x8, LBB73_180
; %bb.175:
Lloh390:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh391:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x24, x0
	mov	w21, #1                         ; =0x1
	b	LBB73_177
LBB73_176:                              ;   in Loop: Header=BB73_177 Depth=1
	add	x22, x8, #32
	ldr	x8, [x22]
	cbz	x8, LBB73_180
LBB73_177:                              ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x20
	b.ne	LBB73_176
; %bb.178:                              ;   in Loop: Header=BB73_177 Depth=1
	ldr	x9, [x8, #8]
	ldurb	w9, [x9, #-8]
	tbnz	w9, #1, LBB73_176
; %bb.179:                              ;   in Loop: Header=BB73_177 Depth=1
	ldp	x0, x9, [x8, #16]
	ldr	x10, [x8, #32]
	str	x10, [x22]
	str	xzr, [x8, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8]
	str	w21, [x24, #88]
	blr	x9
	str	wzr, [x24, #88]
	ldr	x8, [x22]
	cbnz	x8, LBB73_177
LBB73_180:
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbz	x8, LBB73_188
; %bb.181:
	mov	w9, #1                          ; =0x1
	b	LBB73_183
LBB73_182:                              ;   in Loop: Header=BB73_183 Depth=1
	ldr	x8, [x8, #48]
	cbz	x8, LBB73_188
LBB73_183:                              ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x8]
	cmp	x10, x20
	b.ne	LBB73_182
; %bb.184:                              ;   in Loop: Header=BB73_183 Depth=1
	ldr	w10, [x8, #24]
	cbz	w10, LBB73_182
; %bb.185:                              ;   in Loop: Header=BB73_183 Depth=1
	ldr	w10, [x8, #28]
	cbnz	w10, LBB73_182
; %bb.186:                              ;   in Loop: Header=BB73_183 Depth=1
	ldr	x10, [x8, #16]
	ldurb	w10, [x10, #-8]
	tbnz	w10, #1, LBB73_182
; %bb.187:                              ;   in Loop: Header=BB73_183 Depth=1
	stp	xzr, xzr, [x8, #8]
	str	w9, [x8, #28]
	b	LBB73_182
LBB73_188:
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB73_195
; %bb.189:
	mov	w8, #1                          ; =0x1
	b	LBB73_191
LBB73_190:                              ;   in Loop: Header=BB73_191 Depth=1
	ldr	x0, [x0, #8]
	cbz	x0, LBB73_195
LBB73_191:                              ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x0, #16]
	cmp	x9, x20
	b.ne	LBB73_190
; %bb.192:                              ;   in Loop: Header=BB73_191 Depth=1
	ldr	w9, [x0, #32]
	cbnz	w9, LBB73_190
; %bb.193:                              ;   in Loop: Header=BB73_191 Depth=1
	ldr	x9, [x0, #24]
	ldurb	w9, [x9, #-8]
	tbnz	w9, #1, LBB73_190
; %bb.194:                              ;   in Loop: Header=BB73_191 Depth=1
	str	xzr, [x0]
	str	xzr, [x0, #24]
	str	w8, [x0, #32]
	b	LBB73_190
LBB73_195:
	ldr	w8, [sp, #72]                   ; 4-byte Folded Reload
	cbz	w8, LBB73_202
; %bb.196:
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	add	x8, x8, #16
	b	LBB73_200
LBB73_197:                              ;   in Loop: Header=BB73_200 Depth=1
	str	wzr, [x8]
LBB73_198:                              ;   in Loop: Header=BB73_200 Depth=1
	stp	xzr, xzr, [x9]
LBB73_199:                              ;   in Loop: Header=BB73_200 Depth=1
	add	x8, x8, #24
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	subs	x9, x9, #1
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	b.eq	LBB73_202
LBB73_200:                              ; =>This Inner Loop Header: Depth=1
	mov	x9, x8
	ldr	x10, [x9, #-16]!
	cbz	x10, LBB73_197
; %bb.201:                              ;   in Loop: Header=BB73_200 Depth=1
	ldur	x10, [x10, #-8]
	ubfx	x11, x10, #1, #1
	str	w11, [x8]
	tbz	w10, #1, LBB73_198
	b	LBB73_199
LBB73_202:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8, #1064]
	cbz	x8, LBB73_226
; %bb.203:
Lloh392:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh393:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x23, x0
Lloh394:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh395:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x24, x0
	mov	x28, #0                         ; =0x0
	str	xzr, [sp, #40]                  ; 8-byte Folded Spill
	mov	x25, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	stp	xzr, xzr, [sp, #72]             ; 16-byte Folded Spill
	mov	w8, #1                          ; =0x1
	dup.2d	v0, x8
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
	add	x8, x23, #40
	stp	xzr, x8, [sp, #16]              ; 16-byte Folded Spill
	ldr	x20, [sp, #32]                  ; 8-byte Folded Reload
	b	LBB73_207
LBB73_204:                              ;   in Loop: Header=BB73_207 Depth=1
	ldr	x8, [x23]
	cmp	x19, x8
	b.eq	LBB73_222
LBB73_205:                              ;   in Loop: Header=BB73_207 Depth=1
	mov	x26, x25
	str	x28, [sp, #40]                  ; 8-byte Folded Spill
LBB73_206:                              ;   in Loop: Header=BB73_207 Depth=1
	ldr	x8, [x20, #1064]
	add	x28, x27, x28
	cmp	x28, x8
	mov	x25, x26
	b.hs	LBB73_224
LBB73_207:                              ; =>This Inner Loop Header: Depth=1
	mov	x26, x22
	ldr	x9, [x19]
	add	x22, x9, x28
	ldr	x27, [x22]
	ldr	x8, [x22, #24]
	and	x10, x8, #0x2
	cmp	x8, #0
	ccmp	x10, #0, #0, ne
	b.eq	LBB73_213
; %bb.208:                              ;   in Loop: Header=BB73_207 Depth=1
	and	x9, x8, #0x1
	str	x9, [x22, #24]
	tbz	w8, #0, LBB73_219
; %bb.209:                              ;   in Loop: Header=BB73_207 Depth=1
	ldr	x8, [x22, #8]
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	add	x9, x8, x9
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	add	x8, x8, #1
	stp	x8, x9, [sp, #72]               ; 16-byte Folded Spill
	mov	x22, #0                         ; =0x0
	cbz	x26, LBB73_221
; %bb.210:                              ;   in Loop: Header=BB73_207 Depth=1
	ldr	x8, [x23]
	cmp	x19, x8
	b.ne	LBB73_221
; %bb.211:                              ;   in Loop: Header=BB73_207 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x8, #1
	mov	x22, #0                         ; =0x0
	cbnz	x25, LBB73_223
; %bb.212:                              ;   in Loop: Header=BB73_207 Depth=1
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB73_206
LBB73_213:                              ;   in Loop: Header=BB73_207 Depth=1
	mov	x21, x22
	ldr	x8, [x21, #8]!
	ldur	q0, [x24, #40]
	ldr	q1, [sp, #48]                   ; 16-byte Folded Reload
	mov.d	v1[1], x8
	add.2d	v0, v0, v1
	stur	q0, [x24, #40]
	ldr	x8, [x23]
	cmp	x19, x8
	b.ne	LBB73_218
; %bb.214:                              ;   in Loop: Header=BB73_207 Depth=1
	add	x8, x22, #32
	sub	x9, x8, x9
	lsr	x10, x9, #3
	mov	w11, #1                         ; =0x1
	lsl	x10, x11, x10
	ldr	x11, [x23, #2088]
	lsr	x12, x9, #6
	and	x12, x12, #0x3fffffffffffff8
	ldr	x13, [x11, x12]
	bics	x10, x13, x10
	str	x10, [x11, x12]
	b.ne	LBB73_216
; %bb.215:                              ;   in Loop: Header=BB73_207 Depth=1
	lsr	x10, x9, #9
	mov	w11, #1                         ; =0x1
	lsl	x10, x11, x10
	ldr	x11, [x23, #2096]
	lsr	x9, x9, #12
	and	x9, x9, #0xffffffffffff8
	ldr	x12, [x11, x9]
	bic	x10, x12, x10
	str	x10, [x11, x9]
LBB73_216:                              ;   in Loop: Header=BB73_207 Depth=1
	ubfx	x9, x8, #3, #29
	eor	w9, w9, w8, lsr #9
	and	x9, x9, #0xff
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	ldr	x10, [x10, x9, lsl #3]
	cmp	x10, x8
	b.ne	LBB73_218
; %bb.217:                              ;   in Loop: Header=BB73_207 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	xzr, [x8, x9, lsl #3]
LBB73_218:                              ;   in Loop: Header=BB73_207 Depth=1
	sub	x2, x27, #32
	add	x0, x22, #32
	mov	w1, #221                        ; =0xdd
	bl	_memset
	stp	xzr, xzr, [x21, #8]
	str	xzr, [x21]
LBB73_219:                              ;   in Loop: Header=BB73_207 Depth=1
	cbz	x26, LBB73_204
; %bb.220:                              ;   in Loop: Header=BB73_207 Depth=1
	ldr	x8, [x26]
	add	x8, x8, x27
	str	x8, [x26]
	mov	x22, x26
LBB73_221:                              ;   in Loop: Header=BB73_207 Depth=1
	mov	x26, x25
	b	LBB73_206
LBB73_222:                              ;   in Loop: Header=BB73_207 Depth=1
	str	xzr, [x22, #8]
	b	LBB73_205
LBB73_223:                              ;   in Loop: Header=BB73_207 Depth=1
	str	x8, [x25, #8]
	b	LBB73_206
LBB73_224:
	cbz	x22, LBB73_227
; %bb.225:
	ldp	x8, x9, [sp, #32]               ; 16-byte Folded Reload
	str	x9, [x8, #1064]
	b	LBB73_228
LBB73_226:
	str	xzr, [sp, #16]                  ; 8-byte Folded Spill
	stp	xzr, xzr, [sp, #72]             ; 16-byte Folded Spill
	str	xzr, [sp, #40]                  ; 8-byte Folded Spill
	b	LBB73_228
LBB73_227:
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
LBB73_228:
Lloh396:
	adrp	x0, _owned_heap@TLVPPAGE
Lloh397:
	ldr	x0, [x0, _owned_heap@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x19, x8
	b.ne	LBB73_230
; %bb.229:
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	stp	x9, x8, [x0, #24]
LBB73_230:
Lloh398:
	adrp	x0, _neoclr_execution_state_v1@TLVPPAGE
Lloh399:
	ldr	x0, [x0, _neoclr_execution_state_v1@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
Lloh400:
	adrp	x0, _profile@TLVPPAGE
Lloh401:
	ldr	x0, [x0, _profile@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldp	x9, x10, [sp, #72]              ; 16-byte Folded Reload
	stp	x10, x9, [x0, #48]
	ldr	x9, [x0, #64]
	cmp	x10, x9
	b.ls	LBB73_172
; %bb.231:
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	str	x9, [x8, #64]
	b	LBB73_4
LBB73_232:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh368, Lloh369, Lloh370
	.loh AdrpLdrGotLdr	Lloh371, Lloh372, Lloh373
	.loh AdrpLdr	Lloh374, Lloh375
	.loh AdrpLdr	Lloh376, Lloh377
	.loh AdrpLdr	Lloh378, Lloh379
	.loh AdrpLdr	Lloh380, Lloh381
	.loh AdrpLdr	Lloh382, Lloh383
	.loh AdrpLdr	Lloh384, Lloh385
	.loh AdrpLdr	Lloh386, Lloh387
	.loh AdrpLdr	Lloh388, Lloh389
	.loh AdrpLdr	Lloh390, Lloh391
	.loh AdrpLdr	Lloh394, Lloh395
	.loh AdrpLdr	Lloh392, Lloh393
	.loh AdrpLdr	Lloh396, Lloh397
	.loh AdrpLdr	Lloh400, Lloh401
	.loh AdrpLdr	Lloh398, Lloh399
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mark
_mark:                                  ; @mark
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh402:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh403:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0, #64]
	add	x9, x9, #1
	str	x9, [x0, #64]
	ldr	x9, [x0, #40]
	add	x9, x9, #1
	str	x9, [x0, #40]
	ldr	x9, [x8]
	cmp	x9, x2
	b.hi	LBB74_7
; %bb.1:
	ldr	x8, [x8, #16]
	sub	x10, x2, x9
	cmp	x10, x8
	b.hs	LBB74_7
; %bb.2:
	ldr	x11, [x1]
	ldr	w12, [x1, #20]
	lsr	x12, x10, x12
	ldr	x11, [x11, x12, lsl #3]
	sub	x13, x11, x9
	ldr	x11, [x0, #56]
	add	x11, x11, #1
LBB74_3:                                ; =>This Inner Loop Header: Depth=1
	cmp	x13, x8
	b.hs	LBB74_6
; %bb.4:                                ;   in Loop: Header=BB74_3 Depth=1
	mov	x12, x13
	str	x11, [x0, #56]
	ldr	x13, [x9, x13]
	add	x11, x11, #1
	add	x13, x13, x12
	cmp	x10, x13
	b.hs	LBB74_3
; %bb.5:
	add	x8, x9, x12
	ldr	x9, [x8, #24]
	cmp	x9, #0
	add	x10, x8, #32
	ccmp	x10, x2, #2, ne
	b.ls	LBB74_8
LBB74_6:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB74_7:
	ldr	x8, [x0, #48]
	add	x8, x8, #1
	str	x8, [x0, #48]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB74_8:
	ldr	x11, [x8, #8]
	sub	x10, x2, x10
	cmp	x10, x11
	b.hs	LBB74_10
; %bb.9:
	ldr	x11, [x0, #72]
	add	x11, x11, #1
	str	x11, [x0, #72]
LBB74_10:
	tbnz	w9, #1, LBB74_6
; %bb.11:
	ldr	x9, [x8, #8]
	cmp	x10, x9
	b.hs	LBB74_6
; %bb.12:
	ldr	x9, [x0, #80]
	add	x9, x9, #1
	str	x9, [x0, #80]
	ldr	x9, [x8, #16]
	orr	x9, x9, #0x2
	cmp	x9, #3
	b.ne	LBB74_14
; %bb.13:
	mov	w9, #7                          ; =0x7
	str	x9, [x8, #24]
	ldr	x8, [x1, #40]
	add	x8, x8, #1
	str	x8, [x1, #40]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB74_14:
	ldr	x9, [x3]
	orr	x9, x9, #0x3
	str	x9, [x8, #24]
	str	x8, [x3]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh402, Lloh403
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function mark_frames
_mark_frames:                           ; @mark_frames
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB75_18
; %bb.1:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x3
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
	b	LBB75_3
LBB75_2:                                ;   in Loop: Header=BB75_3 Depth=1
	ldr	x20, [x20]
	cbz	x20, LBB75_17
LBB75_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB75_7 Depth 2
                                        ;     Child Loop BB75_12 Depth 2
                                        ;     Child Loop BB75_16 Depth 2
	ldr	x8, [x20, #8]
	cmp	x8, x22
	b.ne	LBB75_2
; %bb.4:                                ;   in Loop: Header=BB75_3 Depth=1
	ldr	w23, [x20, #64]
	cbz	w23, LBB75_9
; %bb.5:                                ;   in Loop: Header=BB75_3 Depth=1
	ldr	x8, [x20, #48]
	add	x24, x8, #8
	b	LBB75_7
LBB75_6:                                ;   in Loop: Header=BB75_7 Depth=2
	add	x24, x24, #16
	subs	x23, x23, #1
	b.eq	LBB75_9
LBB75_7:                                ;   Parent Loop BB75_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [x24]
	cmp	w8, #8
	b.ne	LBB75_6
; %bb.8:                                ;   in Loop: Header=BB75_7 Depth=2
	ldur	x8, [x24, #-8]
	ldr	x2, [x8]
	add	x0, x22, #1048
	mov	x1, x21
	mov	x3, x19
	bl	_mark
	b	LBB75_6
LBB75_9:                                ;   in Loop: Header=BB75_3 Depth=1
	ldr	w23, [x20, #88]
	cbz	w23, LBB75_14
; %bb.10:                               ;   in Loop: Header=BB75_3 Depth=1
	ldr	x8, [x20, #72]
	add	x24, x8, #8
	b	LBB75_12
LBB75_11:                               ;   in Loop: Header=BB75_12 Depth=2
	add	x24, x24, #16
	subs	x23, x23, #1
	b.eq	LBB75_14
LBB75_12:                               ;   Parent Loop BB75_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w8, [x24]
	cmp	w8, #8
	b.ne	LBB75_11
; %bb.13:                               ;   in Loop: Header=BB75_12 Depth=2
	ldur	x8, [x24, #-8]
	ldr	x2, [x8]
	add	x0, x22, #1048
	mov	x1, x21
	mov	x3, x19
	bl	_mark
	b	LBB75_11
LBB75_14:                               ;   in Loop: Header=BB75_3 Depth=1
	ldr	w8, [x20, #36]
	cbz	w8, LBB75_2
; %bb.15:                               ;   in Loop: Header=BB75_3 Depth=1
	mov	x23, #0                         ; =0x0
LBB75_16:                               ;   Parent Loop BB75_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x20, #16]
	ldr	x2, [x8, x23, lsl #3]
	add	x0, x22, #1048
	mov	x1, x21
	mov	x3, x19
	bl	_mark
	add	x23, x23, #1
	ldr	w8, [x20, #36]
	cmp	x23, x8
	b.lo	LBB75_16
	b	LBB75_2
LBB75_17:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
LBB75_18:
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function shadow_begin
lCPI76_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_shadow_begin:                          ; @shadow_begin
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x22, x2
	mov	x21, x1
	mov	x20, x0
	bl	_shadow_drain
	add	x1, sp, #32
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB76_118
; %bb.1:
	ldp	x9, x8, [sp, #32]
	stp	x9, x8, [sp]                    ; 16-byte Folded Spill
	mov	w23, #1                         ; =0x1
	mov	w0, #1                          ; =0x1
	mov	w1, #168                        ; =0xa8
	bl	_calloc
	cbz	x0, LBB76_118
; %bb.2:
	mov	x19, x0
	str	w23, [x0, #156]
	ldr	x8, [x20, #1048]
	str	x8, [x0]
	ldr	x8, [x20, #1064]
	str	x8, [x0, #32]
	mov	w0, #1                          ; =0x1
	mov	w1, #32872                      ; =0x8068
	bl	_calloc
	cbz	x0, LBB76_118
; %bb.3:
	str	x0, [x19, #64]
	bl	_gate_init
	cbnz	w0, LBB76_118
; %bb.4:
	ldr	x0, [x19, #64]
	add	x1, x19, #72
	bl	_gate_begin
	cbnz	w0, LBB76_118
; %bb.5:
	ldr	x28, [x19, #32]
	cbz	x28, LBB76_9
; %bb.6:
	mov	x8, #0                          ; =0x0
	ldr	x9, [x20, #1048]
	ldr	x27, [x19, #112]
LBB76_7:                                ; =>This Inner Loop Header: Depth=1
	add	x27, x27, #1
	ldr	x10, [x9, x8]
	add	x8, x10, x8
	cmp	x8, x28
	b.lo	LBB76_7
; %bb.8:
	str	x27, [x19, #112]
	lsr	x8, x27, #59
	cbz	x8, LBB76_10
	b	LBB76_118
LBB76_9:
	ldr	x27, [x19, #112]
	lsr	x8, x27, #59
	cbnz	x8, LBB76_118
LBB76_10:
	cmp	x27, #1
	csinc	x24, x27, xzr, hi
	mov	x0, x24
	mov	w1, #32                         ; =0x20
	bl	_calloc
	cbz	x0, LBB76_118
; %bb.11:
	str	x0, [x19, #56]
	mov	x0, x24
	mov	w1, #8                          ; =0x8
	bl	_calloc
	cbz	x0, LBB76_118
; %bb.12:
	mov	x23, x0
	str	x0, [x19, #40]
	mov	x0, x24
	mov	w1, #8                          ; =0x8
	bl	_calloc
	cbz	x0, LBB76_118
; %bb.13:
	str	x0, [x19, #48]
	mov	x0, x24
	mov	w1, #1                          ; =0x1
	bl	_calloc
	cbz	x0, LBB76_118
; %bb.14:
	str	x0, [x19, #16]
	mov	x0, x24
	mov	w1, #1                          ; =0x1
	bl	_calloc
	cbz	x0, LBB76_118
; %bb.15:
	str	x0, [x19, #24]
	cbz	x28, LBB76_22
; %bb.16:
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
LBB76_17:                               ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x20, #1048]
	add	x11, x11, x10
	ldr	x12, [x19, #56]
	add	x12, x12, x9
	ldp	q0, q1, [x11]
	stp	q0, q1, [x12]
	ldr	x23, [x19, #40]
	str	x10, [x23, x8]
	ldr	x12, [x11]
	ldr	x11, [x19, #32]
	add	x9, x9, #32
	add	x8, x8, #8
	add	x10, x12, x10
	cmp	x10, x11
	b.lo	LBB76_17
; %bb.18:
	ldr	x27, [x19, #112]
	cmp	x27, #2048
	mov	w8, #256                        ; =0x100
	mov	w9, #4096                       ; =0x1000
	csel	w28, w9, w8, hi
	str	w28, [x19, #104]
	add	x8, x19, #108
	cbz	x11, LBB76_23
; %bb.19:
	sub	x9, x11, #1
	mov	w25, #5                         ; =0x5
LBB76_20:                               ; =>This Inner Loop Header: Depth=1
	add	w25, w25, #1
	lsr	x10, x9, x25
	cmp	x10, x28
	b.hs	LBB76_20
; %bb.21:
	mov	x24, x28
	b	LBB76_24
LBB76_22:
	cmp	x27, #2048
	mov	w8, #256                        ; =0x100
	mov	w9, #4096                       ; =0x1000
	csel	w28, w9, w8, hi
	str	w28, [x19, #104]
	add	x8, x19, #108
LBB76_23:
	mov	w24, w28
	mov	w25, #6                         ; =0x6
LBB76_24:
	str	w25, [x8]
	mov	x0, x24
	mov	w1, #8                          ; =0x8
	bl	_calloc
	cbz	x0, LBB76_118
; %bb.25:
	str	x0, [x19, #96]
	cbz	x27, LBB76_48
; %bb.26:
	mov	w10, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	ldr	x9, [x19, #56]
	mov	w11, w25
	b	LBB76_29
LBB76_27:                               ;   in Loop: Header=BB76_29 Depth=1
	mov	x10, x28
LBB76_28:                               ;   in Loop: Header=BB76_29 Depth=1
	add	x8, x8, #1
	cmp	x8, x27
	b.eq	LBB76_33
LBB76_29:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB76_31 Depth 2
	cmp	w10, w28
	b.hs	LBB76_28
; %bb.30:                               ;   in Loop: Header=BB76_29 Depth=1
	lsl	x12, x8, #5
	ldr	x13, [x23, x8, lsl #3]
	ldr	x12, [x9, x12]
	add	x12, x12, x13
	mov	w10, w10
LBB76_31:                               ;   Parent Loop BB76_29 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x13, x10, x11
	cmp	x13, x12
	b.hs	LBB76_28
; %bb.32:                               ;   in Loop: Header=BB76_31 Depth=2
	str	x8, [x0, x10, lsl #3]
	add	x13, x10, #1
	mov	x10, x13
	cmp	x24, x13
	b.ne	LBB76_31
	b	LBB76_27
LBB76_33:
	mov	x8, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	b	LBB76_35
LBB76_34:                               ;   in Loop: Header=BB76_35 Depth=1
	add	x8, x8, #1
	cmp	x8, x27
	b.hs	LBB76_48
LBB76_35:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB76_39 Depth 2
	ldr	x11, [x19, #56]
	add	x10, x11, x8, lsl #5
	ldrb	w10, [x10, #24]
	tbz	w10, #1, LBB76_34
; %bb.36:                               ;   in Loop: Header=BB76_35 Depth=1
	ldr	x10, [x19]
	ldr	x12, [x19, #40]
	ldr	x13, [x12, x8, lsl #3]
	add	x13, x10, x13
	add	x13, x13, #32
	subs	x13, x13, x10
	b.lo	LBB76_34
; %bb.37:                               ;   in Loop: Header=BB76_35 Depth=1
	ldr	x10, [x19, #32]
	cmp	x13, x10
	b.hs	LBB76_34
; %bb.38:                               ;   in Loop: Header=BB76_35 Depth=1
	ldr	x10, [x19, #96]
	ldr	w14, [x19, #108]
	lsr	x14, x13, x14
	ldr	x10, [x10, x14, lsl #3]
	add	x14, x10, #1
	cmp	x27, x14
	csinc	x10, x27, x10, hi
	sub	x10, x10, #1
LBB76_39:                               ;   Parent Loop BB76_35 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x14, x27
	b.hs	LBB76_42
; %bb.40:                               ;   in Loop: Header=BB76_39 Depth=2
	ldr	x15, [x12, x14, lsl #3]
	add	x14, x14, #1
	cmp	x15, x13
	b.ls	LBB76_39
; %bb.41:                               ;   in Loop: Header=BB76_35 Depth=1
	sub	x10, x14, #2
LBB76_42:                               ;   in Loop: Header=BB76_35 Depth=1
	add	x11, x11, x10, lsl #5
	ldrb	w14, [x11, #24]
	tbz	w14, #0, LBB76_34
; %bb.43:                               ;   in Loop: Header=BB76_35 Depth=1
	ldr	x12, [x12, x10, lsl #3]
	add	x12, x12, #32
	subs	x12, x13, x12
	b.lo	LBB76_34
; %bb.44:                               ;   in Loop: Header=BB76_35 Depth=1
	cmn	x10, #1
	b.eq	LBB76_34
; %bb.45:                               ;   in Loop: Header=BB76_35 Depth=1
	ldr	x11, [x11, #8]
	cmp	x12, x11
	b.hs	LBB76_34
; %bb.46:                               ;   in Loop: Header=BB76_35 Depth=1
	ldr	x11, [x19, #16]
	ldrb	w12, [x11, x10]
	cbnz	w12, LBB76_34
; %bb.47:                               ;   in Loop: Header=BB76_35 Depth=1
	strb	w9, [x11, x10]
	ldr	x11, [x19, #48]
	ldr	x12, [x19, #120]
	add	x13, x12, #1
	str	x13, [x19, #120]
	str	x10, [x11, x12, lsl #3]
	ldr	x27, [x19, #112]
	b	LBB76_34
LBB76_48:
	cbz	w22, LBB76_57
; %bb.49:
	mov	w22, w22
	ldp	x9, x8, [x19, #128]
	mov	w23, #64                        ; =0x40
	b	LBB76_52
LBB76_50:                               ;   in Loop: Header=BB76_52 Depth=1
	ldr	x0, [x19, #144]
LBB76_51:                               ;   in Loop: Header=BB76_52 Depth=1
	add	x10, x9, #1
	str	x10, [x19, #128]
	str	q0, [x0, x9, lsl #4]
	add	x21, x21, #24
	mov	x9, x10
	subs	x22, x22, #1
	b.eq	LBB76_57
LBB76_52:                               ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x21]
	cmp	x9, x8
	b.ne	LBB76_50
; %bb.53:                               ;   in Loop: Header=BB76_52 Depth=1
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
	lsl	x9, x8, #1
	cmp	x8, #0
	csel	x24, x23, x9, eq
	cmp	x24, x8
	b.lo	LBB76_118
; %bb.54:                               ;   in Loop: Header=BB76_52 Depth=1
	lsr	x8, x24, #60
	cbnz	x8, LBB76_118
; %bb.55:                               ;   in Loop: Header=BB76_52 Depth=1
	ldr	x0, [x19, #144]
	lsl	x1, x24, #4
	bl	_realloc
	cbz	x0, LBB76_118
; %bb.56:                               ;   in Loop: Header=BB76_52 Depth=1
	stp	x24, x0, [x19, #136]
	mov	x8, x24
	ldr	x9, [x19, #128]
	ldr	q0, [sp, #16]                   ; 16-byte Folded Reload
	b	LBB76_51
LBB76_57:
Lloh404:
	adrp	x0, _host_head@TLVPPAGE
Lloh405:
	ldr	x0, [x0, _host_head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x21, [x0]
	cbz	x21, LBB76_69
; %bb.58:
	mov	w22, #64                        ; =0x40
	b	LBB76_62
LBB76_59:                               ;   in Loop: Header=BB76_62 Depth=1
	ldr	x0, [x19, #144]
LBB76_60:                               ;   in Loop: Header=BB76_62 Depth=1
	add	x9, x8, #1
	str	x9, [x19, #128]
	ext.16b	v0, v0, v0, #8
	str	q0, [x0, x8, lsl #4]
LBB76_61:                               ;   in Loop: Header=BB76_62 Depth=1
	ldr	x21, [x21, #48]
	cbz	x21, LBB76_69
LBB76_62:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x21]
	cmp	x8, x20
	b.ne	LBB76_61
; %bb.63:                               ;   in Loop: Header=BB76_62 Depth=1
	ldr	w8, [x21, #24]
	cbz	w8, LBB76_61
; %bb.64:                               ;   in Loop: Header=BB76_62 Depth=1
	ldr	w8, [x21, #28]
	cbnz	w8, LBB76_61
; %bb.65:                               ;   in Loop: Header=BB76_62 Depth=1
	ldur	q0, [x21, #8]
	ldp	x8, x9, [x19, #128]
	cmp	x8, x9
	b.ne	LBB76_59
; %bb.66:                               ;   in Loop: Header=BB76_62 Depth=1
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
	lsl	x9, x8, #1
	cmp	x8, #0
	csel	x23, x22, x9, eq
	cmp	x23, x8
	lsr	x8, x23, #60
	ccmp	x8, #0, #0, hs
	b.ne	LBB76_118
; %bb.67:                               ;   in Loop: Header=BB76_62 Depth=1
	ldr	x0, [x19, #144]
	lsl	x1, x23, #4
	bl	_realloc
	cbz	x0, LBB76_118
; %bb.68:                               ;   in Loop: Header=BB76_62 Depth=1
	stp	x23, x0, [x19, #136]
	ldr	x8, [x19, #128]
	ldr	q0, [sp, #16]                   ; 16-byte Folded Reload
	b	LBB76_60
LBB76_69:
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB76_107
; %bb.70:
	mov	x21, x0
	mov	w22, #64                        ; =0x40
	b	LBB76_72
LBB76_71:                               ;   in Loop: Header=BB76_72 Depth=1
	ldr	x21, [x21, #8]
	cbz	x21, LBB76_107
LBB76_72:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB76_76 Depth 2
                                        ;       Child Loop BB76_82 Depth 3
                                        ;       Child Loop BB76_93 Depth 3
                                        ;       Child Loop BB76_102 Depth 3
	ldr	x8, [x21, #16]
	cmp	x8, x20
	b.ne	LBB76_71
; %bb.73:                               ;   in Loop: Header=BB76_72 Depth=1
	ldr	w8, [x21, #32]
	cbnz	w8, LBB76_71
; %bb.74:                               ;   in Loop: Header=BB76_72 Depth=1
	ldr	x23, [x21]
	cbnz	x23, LBB76_76
	b	LBB76_71
LBB76_75:                               ;   in Loop: Header=BB76_76 Depth=2
	ldr	x23, [x23]
	cbz	x23, LBB76_71
LBB76_76:                               ;   Parent Loop BB76_72 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB76_82 Depth 3
                                        ;       Child Loop BB76_93 Depth 3
                                        ;       Child Loop BB76_102 Depth 3
	ldr	x8, [x23, #8]
	cmp	x8, x20
	b.ne	LBB76_75
; %bb.77:                               ;   in Loop: Header=BB76_76 Depth=2
	ldr	x24, [x21, #24]
	ldr	w27, [x23, #64]
	cbz	w27, LBB76_88
; %bb.78:                               ;   in Loop: Header=BB76_76 Depth=2
	ldr	x8, [x23, #48]
	add	x28, x8, #8
	b	LBB76_82
LBB76_79:                               ;   in Loop: Header=BB76_82 Depth=3
	ldr	x0, [x19, #144]
LBB76_80:                               ;   in Loop: Header=BB76_82 Depth=3
	add	x9, x8, #1
	str	x9, [x19, #128]
	add	x8, x0, x8, lsl #4
	stp	x24, x25, [x8]
LBB76_81:                               ;   in Loop: Header=BB76_82 Depth=3
	add	x28, x28, #16
	subs	x27, x27, #1
	b.eq	LBB76_87
LBB76_82:                               ;   Parent Loop BB76_72 Depth=1
                                        ;     Parent Loop BB76_76 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w8, [x28]
	cmp	w8, #8
	b.ne	LBB76_81
; %bb.83:                               ;   in Loop: Header=BB76_82 Depth=3
	ldur	x8, [x28, #-8]
	ldr	x25, [x8]
	ldp	x8, x9, [x19, #128]
	cmp	x8, x9
	b.ne	LBB76_79
; %bb.84:                               ;   in Loop: Header=BB76_82 Depth=3
	lsl	x9, x8, #1
	cmp	x8, #0
	csel	x26, x22, x9, eq
	cmp	x26, x8
	lsr	x8, x26, #60
	ccmp	x8, #0, #0, hs
	b.ne	LBB76_118
; %bb.85:                               ;   in Loop: Header=BB76_82 Depth=3
	ldr	x0, [x19, #144]
	lsl	x1, x26, #4
	bl	_realloc
	cbz	x0, LBB76_118
; %bb.86:                               ;   in Loop: Header=BB76_82 Depth=3
	stp	x26, x0, [x19, #136]
	ldr	x8, [x19, #128]
	b	LBB76_80
LBB76_87:                               ;   in Loop: Header=BB76_76 Depth=2
	ldr	x24, [x21, #24]
LBB76_88:                               ;   in Loop: Header=BB76_76 Depth=2
	ldr	w27, [x23, #88]
	cbz	w27, LBB76_98
; %bb.89:                               ;   in Loop: Header=BB76_76 Depth=2
	ldr	x8, [x23, #72]
	add	x28, x8, #8
	b	LBB76_93
LBB76_90:                               ;   in Loop: Header=BB76_93 Depth=3
	ldr	x0, [x19, #144]
LBB76_91:                               ;   in Loop: Header=BB76_93 Depth=3
	add	x9, x8, #1
	str	x9, [x19, #128]
	add	x8, x0, x8, lsl #4
	stp	x24, x25, [x8]
LBB76_92:                               ;   in Loop: Header=BB76_93 Depth=3
	add	x28, x28, #16
	subs	x27, x27, #1
	b.eq	LBB76_98
LBB76_93:                               ;   Parent Loop BB76_72 Depth=1
                                        ;     Parent Loop BB76_76 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w8, [x28]
	cmp	w8, #8
	b.ne	LBB76_92
; %bb.94:                               ;   in Loop: Header=BB76_93 Depth=3
	ldur	x8, [x28, #-8]
	ldr	x25, [x8]
	ldp	x8, x9, [x19, #128]
	cmp	x8, x9
	b.ne	LBB76_90
; %bb.95:                               ;   in Loop: Header=BB76_93 Depth=3
	lsl	x9, x8, #1
	cmp	x8, #0
	csel	x26, x22, x9, eq
	cmp	x26, x8
	lsr	x8, x26, #60
	ccmp	x8, #0, #0, hs
	b.ne	LBB76_118
; %bb.96:                               ;   in Loop: Header=BB76_93 Depth=3
	ldr	x0, [x19, #144]
	lsl	x1, x26, #4
	bl	_realloc
	cbz	x0, LBB76_118
; %bb.97:                               ;   in Loop: Header=BB76_93 Depth=3
	stp	x26, x0, [x19, #136]
	ldr	x8, [x19, #128]
	b	LBB76_91
LBB76_98:                               ;   in Loop: Header=BB76_76 Depth=2
	ldr	w8, [x23, #36]
	cbz	w8, LBB76_75
; %bb.99:                               ;   in Loop: Header=BB76_76 Depth=2
	mov	x24, #0                         ; =0x0
	ldp	x10, x9, [x19, #128]
	b	LBB76_102
LBB76_100:                              ;   in Loop: Header=BB76_102 Depth=3
	ldr	x0, [x19, #144]
LBB76_101:                              ;   in Loop: Header=BB76_102 Depth=3
	add	x11, x0, x10, lsl #4
	add	x10, x10, #1
	str	x10, [x19, #128]
	stp	x27, x28, [x11]
	add	x24, x24, #1
	cmp	x24, x8
	b.hs	LBB76_75
LBB76_102:                              ;   Parent Loop BB76_72 Depth=1
                                        ;     Parent Loop BB76_76 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	x27, [x21, #24]
	ldr	x11, [x23, #16]
	ldr	x28, [x11, x24, lsl #3]
	cmp	x10, x9
	b.ne	LBB76_100
; %bb.103:                              ;   in Loop: Header=BB76_102 Depth=3
	lsl	x8, x9, #1
	cmp	x9, #0
	csel	x25, x22, x8, eq
	cmp	x25, x9
	b.lo	LBB76_118
; %bb.104:                              ;   in Loop: Header=BB76_102 Depth=3
	lsr	x8, x25, #60
	cbnz	x8, LBB76_118
; %bb.105:                              ;   in Loop: Header=BB76_102 Depth=3
	ldr	x0, [x19, #144]
	lsl	x1, x25, #4
	bl	_realloc
	cbz	x0, LBB76_118
; %bb.106:                              ;   in Loop: Header=BB76_102 Depth=3
	stp	x25, x0, [x19, #136]
	ldr	x10, [x19, #128]
	ldr	w8, [x23, #36]
	mov	x9, x25
	b	LBB76_101
LBB76_107:
Lloh406:
	adrp	x0, _shadow_owner@TLVPPAGE
Lloh407:
	ldr	x0, [x0, _shadow_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x21, [x0]
	cbnz	x21, LBB76_113
; %bb.108:
	mov	x20, x0
	mov	w0, #1                          ; =0x1
	mov	w1, #144                        ; =0x90
	bl	_calloc
	cbz	x0, LBB76_118
; %bb.109:
	str	x0, [x20]
	add	x0, x0, #8
	mov	x1, #0                          ; =0x0
	bl	_pthread_mutex_init
	cbnz	w0, LBB76_118
; %bb.110:
	ldr	x8, [x20]
	add	x0, x8, #72
	mov	x1, #0                          ; =0x0
	bl	_pthread_cond_init
	cbnz	w0, LBB76_118
; %bb.111:
	ldr	x0, [x20]
Lloh408:
	adrp	x2, _shadow_run@PAGE
Lloh409:
	add	x2, x2, _shadow_run@PAGEOFF
	mov	x1, #0                          ; =0x0
	mov	x3, x0
	bl	_pthread_create
	cbnz	w0, LBB76_118
; %bb.112:
	ldr	x21, [x20]
LBB76_113:
	add	x0, x21, #8
	bl	_pthread_mutex_lock
	cbnz	w0, LBB76_118
; %bb.114:
	str	x19, [x21, #120]
Lloh410:
	adrp	x8, lCPI76_0@PAGE
Lloh411:
	ldr	d0, [x8, lCPI76_0@PAGEOFF]
	str	d0, [x21, #128]
	add	x0, x21, #72
	bl	_pthread_cond_broadcast
	cbnz	w0, LBB76_118
; %bb.115:
	add	x0, x21, #8
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB76_118
; %bb.116:
	ldr	x8, [x19, #112]
Lloh412:
	adrp	x0, _shadow_stats@TLVPPAGE
Lloh413:
	ldr	x0, [x0, _shadow_stats@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x19, x0
	ldr	x9, [x0, #8]
	add	x8, x9, x8, lsl #5
	str	x8, [x0, #8]
	add	x1, sp, #32
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB76_118
; %bb.117:
	ldp	x8, x9, [sp, #32]
	ldr	x10, [x19, #16]
	ldp	x11, x12, [sp]                  ; 16-byte Folded Reload
	sub	x8, x8, x11
	mov	w11, #51712                     ; =0xca00
	movk	w11, #15258, lsl #16
	sub	x9, x9, x12
	madd	x8, x8, x11, x9
	add	x8, x8, x10
	str	x8, [x19, #16]
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB76_118:
	bl	_abort
	.loh AdrpLdr	Lloh404, Lloh405
	.loh AdrpLdr	Lloh406, Lloh407
	.loh AdrpAdd	Lloh408, Lloh409
	.loh AdrpLdr	Lloh410, Lloh411
	.loh AdrpLdr	Lloh412, Lloh413
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function candidate_seed
_candidate_seed:                        ; @candidate_seed
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
Lloh414:
	adrp	x0, _shadow_owner@TLVPPAGE
Lloh415:
	ldr	x0, [x0, _shadow_owner@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	ldr	x23, [x8, #120]
	ldr	w8, [x23, #156]
	cbz	w8, LBB77_3
; %bb.1:
	add	x22, x21, #1048
	ldr	x9, [x22]
	ldr	x8, [x23]
	cmp	x8, x9
	b.ne	LBB77_3
; %bb.2:
	ldr	x8, [x21, #1064]
	ldr	x10, [x23, #32]
	cmp	x8, x10
	b.hs	LBB77_5
LBB77_3:
	mov	w0, #3                          ; =0x3
LBB77_4:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB77_5:
	ldr	x10, [x23, #112]
	cbz	x10, LBB77_18
; %bb.6:
	ldr	x11, [x23, #56]
Lloh416:
	adrp	x0, _lookup_profile@TLVPPAGE
Lloh417:
	ldr	x0, [x0, _lookup_profile@TLVPPAGEOFF]
	ldr	x12, [x0]
	blr	x12
	mov	x12, #0                         ; =0x0
	ldr	x13, [x0, #40]
	ldr	x14, [x0, #56]
	mvn	x15, x9
	b	LBB77_8
LBB77_7:                                ;   in Loop: Header=BB77_8 Depth=1
	add	x12, x12, #1
	cmp	x12, x10
	b.eq	LBB77_18
LBB77_8:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB77_11 Depth 2
	add	x16, x11, x12, lsl #5
	ldrb	w17, [x16, #24]
	tbz	w17, #0, LBB77_7
; %bb.9:                                ;   in Loop: Header=BB77_8 Depth=1
	ldr	x17, [x23, #40]
	ldr	x17, [x17, x12, lsl #3]
	add	x13, x13, #1
	str	x13, [x0, #40]
	cmp	x17, x15
	ccmp	x17, x8, #2, ls
	b.hs	LBB77_37
; %bb.10:                               ;   in Loop: Header=BB77_8 Depth=1
	ldr	x1, [x20]
	ldr	w2, [x20, #20]
	lsr	x2, x17, x2
	ldr	x1, [x1, x2, lsl #3]
	sub	x3, x1, x9
LBB77_11:                               ;   Parent Loop BB77_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x3, x8
	b.hs	LBB77_3
; %bb.12:                               ;   in Loop: Header=BB77_11 Depth=2
	mov	x1, x3
	add	x14, x14, #1
	str	x14, [x0, #56]
	ldr	x2, [x9, x3]
	add	x3, x2, x3
	cmp	x17, x3
	b.hs	LBB77_11
; %bb.13:                               ;   in Loop: Header=BB77_8 Depth=1
	cmp	x1, x17
	b.ne	LBB77_3
; %bb.14:                               ;   in Loop: Header=BB77_8 Depth=1
	add	x17, x9, x1
	ldrb	w1, [x17, #24]
	tbz	w1, #0, LBB77_3
; %bb.15:                               ;   in Loop: Header=BB77_8 Depth=1
	ldr	x1, [x16]
	cmp	x2, x1
	b.ne	LBB77_3
; %bb.16:                               ;   in Loop: Header=BB77_8 Depth=1
	ldr	x1, [x17, #8]
	ldr	x2, [x16, #8]
	cmp	x1, x2
	b.ne	LBB77_3
; %bb.17:                               ;   in Loop: Header=BB77_8 Depth=1
	ldr	x17, [x17, #16]
	ldr	x16, [x16, #16]
	cmp	x17, x16
	b.eq	LBB77_7
	b	LBB77_3
LBB77_18:
	cbz	x8, LBB77_36
; %bb.19:
	mov	x24, #0                         ; =0x0
	mov	x26, #0                         ; =0x0
	mov	w25, #7                         ; =0x7
	b	LBB77_22
LBB77_20:                               ;   in Loop: Header=BB77_22 Depth=1
	add	x2, x27, #32
	mov	x0, x22
	mov	x1, x20
	mov	x3, x19
	bl	_mark
	ldr	x8, [x21, #1064]
LBB77_21:                               ;   in Loop: Header=BB77_22 Depth=1
	ldr	x9, [x27]
	add	x24, x9, x24
	cmp	x24, x8
	b.hs	LBB77_36
LBB77_22:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB77_24 Depth 2
	ldr	x9, [x23, #112]
	cmp	x26, x9
	b.hs	LBB77_29
; %bb.23:                               ;   in Loop: Header=BB77_22 Depth=1
	ldr	x11, [x23, #40]
	neg	x10, x26, lsl #5
LBB77_24:                               ;   Parent Loop BB77_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x12, [x11, x26, lsl #3]
	cmp	x12, x24
	b.hs	LBB77_27
; %bb.25:                               ;   in Loop: Header=BB77_24 Depth=2
	add	x26, x26, #1
	sub	x10, x10, #32
	cmp	x9, x26
	b.ne	LBB77_24
; %bb.26:                               ;   in Loop: Header=BB77_22 Depth=1
	mov	x10, #0                         ; =0x0
	mov	x26, x9
	b	LBB77_30
LBB77_27:                               ;   in Loop: Header=BB77_22 Depth=1
	b.ne	LBB77_29
; %bb.28:                               ;   in Loop: Header=BB77_22 Depth=1
	ldr	x9, [x23, #56]
	sub	x10, x9, x10
	b	LBB77_30
LBB77_29:                               ;   in Loop: Header=BB77_22 Depth=1
	mov	x10, #0                         ; =0x0
LBB77_30:                               ;   in Loop: Header=BB77_22 Depth=1
	ldr	x9, [x22]
	add	x27, x9, x24
	ldr	x9, [x27, #24]
	tbz	w9, #0, LBB77_21
; %bb.31:                               ;   in Loop: Header=BB77_22 Depth=1
	cbz	x10, LBB77_20
; %bb.32:                               ;   in Loop: Header=BB77_22 Depth=1
	ldrb	w10, [x10, #24]
	tbz	w10, #0, LBB77_20
; %bb.33:                               ;   in Loop: Header=BB77_22 Depth=1
	tbnz	w9, #1, LBB77_21
; %bb.34:                               ;   in Loop: Header=BB77_22 Depth=1
	ldr	x9, [x23, #16]
	ldrb	w9, [x9, x26]
	cbz	w9, LBB77_21
; %bb.35:                               ;   in Loop: Header=BB77_22 Depth=1
	str	x25, [x27, #24]
	b	LBB77_21
LBB77_36:
	mov	w0, #0                          ; =0x0
	b	LBB77_4
LBB77_37:
	ldr	x8, [x0, #48]
	add	x8, x8, #1
	str	x8, [x0, #48]
	b	LBB77_3
	.loh AdrpLdr	Lloh414, Lloh415
	.loh AdrpLdr	Lloh416, Lloh417
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function shadow_run
_shadow_run:                            ; @shadow_run
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #32800                      ; =0x8020
Lloh418:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh419:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
Lloh420:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh421:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh422:
	ldr	x8, [x8]
	stur	x8, [x29, #-96]
	add	x0, x0, #8
	bl	_pthread_mutex_lock
	cbnz	w0, LBB78_98
; %bb.1:
	mov	w24, #4                         ; =0x4
	movk	w24, #32768, lsl #16
	add	x25, sp, #16
LBB78_2:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB78_9 Depth 2
                                        ;       Child Loop BB78_38 Depth 3
                                        ;       Child Loop BB78_87 Depth 3
                                        ;       Child Loop BB78_45 Depth 3
                                        ;         Child Loop BB78_48 Depth 4
                                        ;         Child Loop BB78_59 Depth 4
                                        ;       Child Loop BB78_72 Depth 3
                                        ;         Child Loop BB78_75 Depth 4
	ldr	w9, [x19, #128]
	ldr	w8, [x19, #136]
	cbz	w9, LBB78_91
; %bb.3:                                ;   in Loop: Header=BB78_2 Depth=1
	cbnz	w8, LBB78_99
; %bb.4:                                ;   in Loop: Header=BB78_2 Depth=1
	ldr	x20, [x19, #120]
	str	wzr, [x19, #128]
	add	x0, x19, #8
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB78_98
; %bb.5:                                ;   in Loop: Header=BB78_2 Depth=1
	add	x1, sp, #16
	mov	w0, #16                         ; =0x10
	bl	_clock_gettime
	cbnz	w0, LBB78_98
; %bb.6:                                ;   in Loop: Header=BB78_2 Depth=1
	ldp	x28, x27, [sp, #16]
	b	LBB78_9
LBB78_7:                                ;   in Loop: Header=BB78_9 Depth=2
	mov	w0, #0                          ; =0x0
LBB78_8:                                ;   in Loop: Header=BB78_9 Depth=2
	cbz	w0, LBB78_94
LBB78_9:                                ;   Parent Loop BB78_2 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB78_38 Depth 3
                                        ;       Child Loop BB78_87 Depth 3
                                        ;       Child Loop BB78_45 Depth 3
                                        ;         Child Loop BB78_48 Depth 4
                                        ;         Child Loop BB78_59 Depth 4
                                        ;       Child Loop BB78_72 Depth 3
                                        ;         Child Loop BB78_75 Depth 4
	ldr	x8, [x20, #120]
	cbz	x8, LBB78_41
; %bb.10:                               ;   in Loop: Header=BB78_9 Depth=2
	sub	x8, x8, #1
	str	x8, [x20, #120]
	ldp	x9, x10, [x20, #48]
	ldr	x8, [x9, x8, lsl #3]
	add	x21, x10, x8, lsl #5
	ldr	x9, [x21, #16]
	cmp	x9, #4
	b.gt	LBB78_20
; %bb.11:                               ;   in Loop: Header=BB78_9 Depth=2
	cmp	x9, #2
	b.eq	LBB78_24
; %bb.12:                               ;   in Loop: Header=BB78_9 Depth=2
	cmp	x9, #4
	b.ne	LBB78_9
; %bb.13:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	x3, [x21, #8]
	cmp	x3, #16
	b.lo	LBB78_7
; %bb.14:                               ;   in Loop: Header=BB78_9 Depth=2
	ldp	x0, x1, [x20, #64]
	ldr	x9, [x20]
	ldr	x10, [x20, #40]
	ldr	x8, [x10, x8, lsl #3]
	add	x8, x9, x8
	add	x2, x8, #32
	add	x5, sp, #16
	mov	x4, #0                          ; =0x0
	mov	w6, #16                         ; =0x10
	bl	_gate_read
	cbnz	w0, LBB78_7
; %bb.15:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	w8, [sp, #16]
	mov	x9, #-5                         ; =0xfffffffffffffffb
	movk	x9, #32767, lsl #16
	add	x9, x8, x9
	cmn	x9, #2
	b.lo	LBB78_7
; %bb.16:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	x26, [sp, #24]
	ldr	x9, [x21, #8]
	sub	x9, x9, #16
	cmp	x8, x24
	mov	w10, #8                         ; =0x8
	cinc	x10, x10, eq
	udiv	x9, x9, x10
	cmp	x26, x9
	b.hi	LBB78_7
; %bb.17:                               ;   in Loop: Header=BB78_9 Depth=2
	cmp	x8, x24
	b.ne	LBB78_90
; %bb.18:                               ;   in Loop: Header=BB78_9 Depth=2
	cbz	x26, LBB78_9
; %bb.19:                               ;   in Loop: Header=BB78_9 Depth=2
	lsl	x8, x26, #3
	add	x22, x8, #16
	mov	w23, #24                        ; =0x18
	b	LBB78_87
LBB78_20:                               ;   in Loop: Header=BB78_9 Depth=2
	cmp	x9, #5
	b.eq	LBB78_26
; %bb.21:                               ;   in Loop: Header=BB78_9 Depth=2
	cmp	x9, #6
	b.ne	LBB78_9
; %bb.22:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	x8, [x21, #8]
	cmp	x8, #8
	b.ne	LBB78_94
; %bb.23:                               ;   in Loop: Header=BB78_9 Depth=2
	mov	x0, x20
	mov	x1, x21
	mov	x2, #0                          ; =0x0
	mov	w3, #8                          ; =0x8
	bl	_live_words
	cmp	w0, #0
	cset	w0, ne
	b	LBB78_8
LBB78_24:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	x8, [x21, #8]
	and	x3, x8, #0xfffffffffffffff8
	mov	x0, x20
	mov	x1, x21
	mov	w2, #8                          ; =0x8
LBB78_25:                               ;   in Loop: Header=BB78_9 Depth=2
	bl	_live_words
	b	LBB78_8
LBB78_26:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	x3, [x21, #8]
	cmp	x3, #24
	b.lo	LBB78_94
; %bb.27:                               ;   in Loop: Header=BB78_9 Depth=2
	ldp	x0, x1, [x20, #64]
	ldr	x9, [x20]
	ldr	x10, [x20, #40]
	ldr	x8, [x10, x8, lsl #3]
	add	x8, x9, x8
	add	x2, x8, #32
	add	x5, sp, #16
	mov	x4, #0                          ; =0x0
	mov	w6, #24                         ; =0x18
	bl	_gate_read
	cbnz	w0, LBB78_94
; %bb.28:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	x8, [sp, #16]
	lsr	x9, x8, #32
	cmp	x9, #1024
	b.hi	LBB78_94
; %bb.29:                               ;   in Loop: Header=BB78_9 Depth=2
	mov	w8, w8
	add	x10, x24, #1
	cmp	x8, x10
	b.ne	LBB78_94
; %bb.30:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	x8, [sp, #32]
	cmp	x8, #1
	ccmp	x9, #0, #4, ne
	b.ne	LBB78_94
; %bb.31:                               ;   in Loop: Header=BB78_9 Depth=2
	sub	x9, x8, #257
	cmn	x9, #256
	b.lo	LBB78_94
; %bb.32:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	x22, [sp, #24]
	cmp	x22, #16, lsl #12               ; =65536
	b.hi	LBB78_94
; %bb.33:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	x9, [x21, #8]
	sub	x9, x9, #24
	mov	w10, #1                         ; =0x1
	bfi	x10, x8, #3, #60
	udiv	x9, x9, x10
	cmp	x22, x9
	b.hi	LBB78_94
; %bb.34:                               ;   in Loop: Header=BB78_9 Depth=2
	cbz	x22, LBB78_85
; %bb.35:                               ;   in Loop: Header=BB78_9 Depth=2
	mov	x23, #0                         ; =0x0
	lsl	x26, x8, #3
	mul	x8, x22, x8
	lsl	x8, x8, #3
	add	x24, x8, #24
	b	LBB78_38
LBB78_36:                               ;   in Loop: Header=BB78_38 Depth=3
	add	x23, x23, #1
LBB78_37:                               ;   in Loop: Header=BB78_38 Depth=3
	cmp	x23, x22
	b.eq	LBB78_85
LBB78_38:                               ;   Parent Loop BB78_2 Depth=1
                                        ;     Parent Loop BB78_9 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	x8, x0, [x20, #56]
	sub	x8, x21, x8
	ldr	x1, [x20, #72]
	ldr	x9, [x20]
	ldr	x10, [x20, #40]
	asr	x8, x8, #2
	ldr	x8, [x10, x8]
	add	x8, x9, x8
	ldr	x3, [x21, #8]
	add	x2, x8, #32
	add	x4, x24, x23
	add	x5, sp, #8
	mov	w6, #1                          ; =0x1
	bl	_gate_read
	cbnz	w0, LBB78_93
; %bb.39:                               ;   in Loop: Header=BB78_38 Depth=3
	ldrb	w8, [sp, #8]
	cbz	w8, LBB78_36
; %bb.40:                               ;   in Loop: Header=BB78_38 Depth=3
	mov	x8, #24                         ; =0x18
	madd	x2, x23, x26, x8
	add	x23, x23, #1
	madd	x3, x23, x26, x8
	mov	x0, x20
	mov	x1, x21
	bl	_live_words
	cbnz	w0, LBB78_37
	b	LBB78_93
LBB78_41:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	w8, [x20, #156]
	cbz	w8, LBB78_95
; %bb.42:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	x8, [x20, #128]
	cbz	x8, LBB78_68
; %bb.43:                               ;   in Loop: Header=BB78_9 Depth=2
	mov	x9, #0                          ; =0x0
	b	LBB78_45
LBB78_44:                               ;   in Loop: Header=BB78_45 Depth=3
	add	x9, x9, #1
	cmp	x9, x8
	b.hs	LBB78_68
LBB78_45:                               ;   Parent Loop BB78_2 Depth=1
                                        ;     Parent Loop BB78_9 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB78_48 Depth 4
                                        ;         Child Loop BB78_59 Depth 4
	ldr	x12, [x20, #144]
	lsl	x10, x9, #4
	ldr	x10, [x12, x10]
	ldr	x14, [x20]
	subs	x17, x10, x14
	b.lo	LBB78_44
; %bb.46:                               ;   in Loop: Header=BB78_45 Depth=3
	ldr	x15, [x20, #32]
	cmp	x17, x15
	b.hs	LBB78_44
; %bb.47:                               ;   in Loop: Header=BB78_45 Depth=3
	ldr	x13, [x20, #96]
	ldr	w16, [x20, #108]
	lsr	x10, x17, x16
	ldr	x10, [x13, x10, lsl #3]
	ldr	x11, [x20, #112]
	add	x0, x10, #1
	cmp	x11, x0
	csinc	x10, x11, x10, hi
	sub	x1, x10, #1
	ldr	x10, [x20, #40]
LBB78_48:                               ;   Parent Loop BB78_2 Depth=1
                                        ;     Parent Loop BB78_9 Depth=2
                                        ;       Parent Loop BB78_45 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	cmp	x0, x11
	b.hs	LBB78_51
; %bb.49:                               ;   in Loop: Header=BB78_48 Depth=4
	ldr	x2, [x10, x0, lsl #3]
	add	x0, x0, #1
	cmp	x2, x17
	b.ls	LBB78_48
; %bb.50:                               ;   in Loop: Header=BB78_45 Depth=3
	sub	x1, x0, #2
LBB78_51:                               ;   in Loop: Header=BB78_45 Depth=3
	ldr	x0, [x20, #56]
	add	x2, x0, x1, lsl #5
	ldrb	w3, [x2, #24]
	tbz	w3, #0, LBB78_44
; %bb.52:                               ;   in Loop: Header=BB78_45 Depth=3
	ldr	x3, [x10, x1, lsl #3]
	add	x3, x3, #32
	subs	x17, x17, x3
	b.lo	LBB78_44
; %bb.53:                               ;   in Loop: Header=BB78_45 Depth=3
	cmn	x1, #1
	b.eq	LBB78_44
; %bb.54:                               ;   in Loop: Header=BB78_45 Depth=3
	ldr	x2, [x2, #8]
	cmp	x17, x2
	b.hs	LBB78_44
; %bb.55:                               ;   in Loop: Header=BB78_45 Depth=3
	ldr	x17, [x20, #16]
	ldrb	w1, [x17, x1]
	cbz	w1, LBB78_44
; %bb.56:                               ;   in Loop: Header=BB78_45 Depth=3
	add	x12, x12, x9, lsl #4
	ldr	x12, [x12, #8]
	subs	x14, x12, x14
	b.lo	LBB78_44
; %bb.57:                               ;   in Loop: Header=BB78_45 Depth=3
	cmp	x14, x15
	b.hs	LBB78_44
; %bb.58:                               ;   in Loop: Header=BB78_45 Depth=3
	lsr	x12, x14, x16
	ldr	x12, [x13, x12, lsl #3]
	add	x13, x12, #1
	cmp	x11, x13
	csinc	x12, x11, x12, hi
	sub	x12, x12, #1
LBB78_59:                               ;   Parent Loop BB78_2 Depth=1
                                        ;     Parent Loop BB78_9 Depth=2
                                        ;       Parent Loop BB78_45 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	cmp	x13, x11
	b.hs	LBB78_62
; %bb.60:                               ;   in Loop: Header=BB78_59 Depth=4
	ldr	x15, [x10, x13, lsl #3]
	add	x13, x13, #1
	cmp	x15, x14
	b.ls	LBB78_59
; %bb.61:                               ;   in Loop: Header=BB78_45 Depth=3
	sub	x12, x13, #2
LBB78_62:                               ;   in Loop: Header=BB78_45 Depth=3
	add	x11, x0, x12, lsl #5
	ldrb	w13, [x11, #24]
	tbz	w13, #0, LBB78_44
; %bb.63:                               ;   in Loop: Header=BB78_45 Depth=3
	ldr	x10, [x10, x12, lsl #3]
	add	x10, x10, #32
	subs	x10, x14, x10
	b.lo	LBB78_44
; %bb.64:                               ;   in Loop: Header=BB78_45 Depth=3
	cmn	x12, #1
	b.eq	LBB78_44
; %bb.65:                               ;   in Loop: Header=BB78_45 Depth=3
	ldr	x11, [x11, #8]
	cmp	x10, x11
	b.hs	LBB78_44
; %bb.66:                               ;   in Loop: Header=BB78_45 Depth=3
	ldrb	w10, [x17, x12]
	cbnz	w10, LBB78_44
; %bb.67:                               ;   in Loop: Header=BB78_45 Depth=3
	mov	w8, #1                          ; =0x1
	strb	w8, [x17, x12]
	ldr	x8, [x20, #48]
	ldr	x10, [x20, #120]
	add	x11, x10, #1
	str	x11, [x20, #120]
	str	x12, [x8, x10, lsl #3]
	ldr	x8, [x20, #128]
	b	LBB78_44
LBB78_68:                               ;   in Loop: Header=BB78_9 Depth=2
	ldp	x0, x1, [x20, #64]
	add	x2, sp, #16
	add	x4, sp, #8
	mov	w3, #4096                       ; =0x1000
	bl	_gate_drain
	cbnz	w0, LBB78_94
; %bb.69:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	x8, [sp, #8]
	ldr	x9, [x20, #88]
	add	x9, x9, x8
	str	x9, [x20, #88]
	cbz	x8, LBB78_84
; %bb.70:                               ;   in Loop: Header=BB78_9 Depth=2
	mov	x9, #0                          ; =0x0
	b	LBB78_72
LBB78_71:                               ;   in Loop: Header=BB78_72 Depth=3
	add	x9, x9, #1
	cmp	x9, x8
	b.hs	LBB78_84
LBB78_72:                               ;   Parent Loop BB78_2 Depth=1
                                        ;     Parent Loop BB78_9 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB78_75 Depth 4
	ldr	x10, [x25, x9, lsl #3]
	ldr	x11, [x20]
	subs	x11, x10, x11
	b.lo	LBB78_71
; %bb.73:                               ;   in Loop: Header=BB78_72 Depth=3
	ldr	x10, [x20, #32]
	cmp	x11, x10
	b.hs	LBB78_71
; %bb.74:                               ;   in Loop: Header=BB78_72 Depth=3
	ldr	x10, [x20, #96]
	ldr	w12, [x20, #108]
	lsr	x12, x11, x12
	ldr	x10, [x10, x12, lsl #3]
	ldr	x14, [x20, #112]
	add	x13, x10, #1
	cmp	x14, x13
	csinc	x10, x14, x10, hi
	sub	x10, x10, #1
	ldr	x12, [x20, #40]
LBB78_75:                               ;   Parent Loop BB78_2 Depth=1
                                        ;     Parent Loop BB78_9 Depth=2
                                        ;       Parent Loop BB78_72 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	cmp	x13, x14
	b.hs	LBB78_78
; %bb.76:                               ;   in Loop: Header=BB78_75 Depth=4
	ldr	x15, [x12, x13, lsl #3]
	add	x13, x13, #1
	cmp	x15, x11
	b.ls	LBB78_75
; %bb.77:                               ;   in Loop: Header=BB78_72 Depth=3
	sub	x10, x13, #2
LBB78_78:                               ;   in Loop: Header=BB78_72 Depth=3
	ldr	x13, [x20, #56]
	add	x13, x13, x10, lsl #5
	ldrb	w14, [x13, #24]
	tbz	w14, #0, LBB78_71
; %bb.79:                               ;   in Loop: Header=BB78_72 Depth=3
	ldr	x12, [x12, x10, lsl #3]
	add	x12, x12, #32
	subs	x11, x11, x12
	b.lo	LBB78_71
; %bb.80:                               ;   in Loop: Header=BB78_72 Depth=3
	cmn	x10, #1
	b.eq	LBB78_71
; %bb.81:                               ;   in Loop: Header=BB78_72 Depth=3
	ldr	x12, [x13, #8]
	cmp	x11, x12
	b.hs	LBB78_71
; %bb.82:                               ;   in Loop: Header=BB78_72 Depth=3
	ldr	x11, [x20, #16]
	ldrb	w12, [x11, x10]
	cbnz	w12, LBB78_71
; %bb.83:                               ;   in Loop: Header=BB78_72 Depth=3
	mov	w8, #1                          ; =0x1
	strb	w8, [x11, x10]
	ldr	x8, [x20, #48]
	ldr	x11, [x20, #120]
	add	x12, x11, #1
	str	x12, [x20, #120]
	str	x10, [x8, x11, lsl #3]
	ldr	x8, [sp, #8]
	b	LBB78_71
LBB78_84:                               ;   in Loop: Header=BB78_9 Depth=2
	ldr	x8, [x20, #120]
	cbnz	x8, LBB78_9
	b	LBB78_95
LBB78_85:                               ;   in Loop: Header=BB78_9 Depth=2
	mov	w24, #4                         ; =0x4
	movk	w24, #32768, lsl #16
	b	LBB78_9
LBB78_86:                               ;   in Loop: Header=BB78_87 Depth=3
	add	x23, x23, #8
	add	x22, x22, #1
	subs	x26, x26, #1
	b.eq	LBB78_9
LBB78_87:                               ;   Parent Loop BB78_2 Depth=1
                                        ;     Parent Loop BB78_9 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	x8, x0, [x20, #56]
	sub	x8, x21, x8
	ldr	x1, [x20, #72]
	ldr	x9, [x20]
	ldr	x10, [x20, #40]
	asr	x8, x8, #2
	ldr	x8, [x10, x8]
	add	x8, x9, x8
	ldr	x3, [x21, #8]
	add	x2, x8, #32
	add	x5, sp, #8
	mov	x4, x22
	mov	w6, #1                          ; =0x1
	bl	_gate_read
	cbnz	w0, LBB78_7
; %bb.88:                               ;   in Loop: Header=BB78_87 Depth=3
	ldrb	w8, [sp, #8]
	cbz	w8, LBB78_86
; %bb.89:                               ;   in Loop: Header=BB78_87 Depth=3
	sub	x2, x23, #8
	mov	x0, x20
	mov	x1, x21
	mov	x3, x23
	bl	_live_words
	cbnz	w0, LBB78_86
	b	LBB78_7
LBB78_90:                               ;   in Loop: Header=BB78_9 Depth=2
	lsl	x8, x26, #3
	add	x3, x8, #16
	mov	x0, x20
	mov	x1, x21
	mov	w2, #16                         ; =0x10
	b	LBB78_25
LBB78_91:                               ;   in Loop: Header=BB78_2 Depth=1
	cbnz	w8, LBB78_99
; %bb.92:                               ;   in Loop: Header=BB78_2 Depth=1
	add	x0, x19, #72
	add	x1, x19, #8
	bl	_pthread_cond_wait
	cbz	w0, LBB78_2
	b	LBB78_98
LBB78_93:                               ;   in Loop: Header=BB78_2 Depth=1
	mov	w24, #4                         ; =0x4
	movk	w24, #32768, lsl #16
LBB78_94:                               ;   in Loop: Header=BB78_2 Depth=1
	str	wzr, [x20, #156]
LBB78_95:                               ;   in Loop: Header=BB78_2 Depth=1
	add	x1, sp, #16
	mov	w0, #16                         ; =0x10
	bl	_clock_gettime
	cbnz	w0, LBB78_98
; %bb.96:                               ;   in Loop: Header=BB78_2 Depth=1
	ldp	x8, x9, [sp, #16]
	ldr	x10, [x20, #160]
	sub	x8, x8, x28
	sub	x9, x9, x27
	mov	w11, #51712                     ; =0xca00
	movk	w11, #15258, lsl #16
	madd	x8, x8, x11, x9
	add	x8, x8, x10
	str	x8, [x20, #160]
	add	x0, x19, #8
	bl	_pthread_mutex_lock
	cbnz	w0, LBB78_98
; %bb.97:                               ;   in Loop: Header=BB78_2 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #132]
	add	x0, x19, #72
	bl	_pthread_cond_broadcast
	cbz	w0, LBB78_2
LBB78_98:
	bl	_abort
LBB78_99:
	add	x0, x19, #8
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB78_98
; %bb.100:
	ldur	x8, [x29, #-96]
Lloh423:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh424:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh425:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB78_102
; %bb.101:
	mov	x0, #0                          ; =0x0
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #32
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB78_102:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh420, Lloh421, Lloh422
	.loh AdrpLdrGotLdr	Lloh423, Lloh424, Lloh425
	.loh AdrpLdrGot	Lloh418, Lloh419
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function live_words
_live_words:                            ; @live_words
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #368
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #288]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	add	x29, sp, #352
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
Lloh426:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh427:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh428:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
	mov	w19, #1                         ; =0x1
	cmp	x2, x3
	b.hs	LBB79_21
; %bb.1:
	mov	x20, x3
	mov	x21, x2
	mov	x22, x1
	mov	x23, x0
	mov	w25, #256                       ; =0x100
	add	x26, sp, #8
	b	LBB79_3
LBB79_2:                                ;   in Loop: Header=BB79_3 Depth=1
	add	x21, x24, x21
	cmp	x21, x20
	b.hs	LBB79_20
LBB79_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB79_7 Depth 2
                                        ;       Child Loop BB79_10 Depth 3
	sub	x27, x20, x21
	cmp	x27, #256
	csel	x24, x27, x25, lo
	ldp	x8, x0, [x23, #56]
	sub	x8, x22, x8
	ldr	x1, [x23, #72]
	ldr	x9, [x23]
	ldr	x10, [x23, #40]
	asr	x8, x8, #2
	ldr	x8, [x10, x8]
	add	x8, x9, x8
	ldr	x3, [x22, #8]
	add	x2, x8, #32
	add	x5, sp, #8
	mov	x4, x21
	mov	x6, x24
	bl	_gate_read
	cbnz	w0, LBB79_19
; %bb.4:                                ;   in Loop: Header=BB79_3 Depth=1
	ldr	x8, [x23, #80]
	add	x8, x8, x24
	str	x8, [x23, #80]
	cmp	x27, #8
	b.lo	LBB79_2
; %bb.5:                                ;   in Loop: Header=BB79_3 Depth=1
	mov	x8, #0                          ; =0x0
	lsr	x9, x24, #3
	cmp	x9, #1
	csinc	x9, x9, xzr, hi
	b	LBB79_7
LBB79_6:                                ;   in Loop: Header=BB79_7 Depth=2
	add	x8, x8, #1
	cmp	x8, x9
	b.eq	LBB79_2
LBB79_7:                                ;   Parent Loop BB79_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB79_10 Depth 3
	ldr	x10, [x26, x8, lsl #3]
	ldr	x11, [x23]
	subs	x11, x10, x11
	b.lo	LBB79_6
; %bb.8:                                ;   in Loop: Header=BB79_7 Depth=2
	ldr	x10, [x23, #32]
	cmp	x11, x10
	b.hs	LBB79_6
; %bb.9:                                ;   in Loop: Header=BB79_7 Depth=2
	ldr	x10, [x23, #96]
	ldr	w12, [x23, #108]
	lsr	x12, x11, x12
	ldr	x10, [x10, x12, lsl #3]
	ldr	x14, [x23, #112]
	add	x13, x10, #1
	cmp	x14, x13
	csinc	x10, x14, x10, hi
	sub	x10, x10, #1
	ldr	x12, [x23, #40]
LBB79_10:                               ;   Parent Loop BB79_3 Depth=1
                                        ;     Parent Loop BB79_7 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x13, x14
	b.hs	LBB79_13
; %bb.11:                               ;   in Loop: Header=BB79_10 Depth=3
	ldr	x15, [x12, x13, lsl #3]
	add	x13, x13, #1
	cmp	x15, x11
	b.ls	LBB79_10
; %bb.12:                               ;   in Loop: Header=BB79_7 Depth=2
	sub	x10, x13, #2
LBB79_13:                               ;   in Loop: Header=BB79_7 Depth=2
	ldr	x13, [x23, #56]
	add	x13, x13, x10, lsl #5
	ldrb	w14, [x13, #24]
	tbz	w14, #0, LBB79_6
; %bb.14:                               ;   in Loop: Header=BB79_7 Depth=2
	ldr	x12, [x12, x10, lsl #3]
	add	x12, x12, #32
	subs	x11, x11, x12
	b.lo	LBB79_6
; %bb.15:                               ;   in Loop: Header=BB79_7 Depth=2
	cmn	x10, #1
	b.eq	LBB79_6
; %bb.16:                               ;   in Loop: Header=BB79_7 Depth=2
	ldr	x12, [x13, #8]
	cmp	x11, x12
	b.hs	LBB79_6
; %bb.17:                               ;   in Loop: Header=BB79_7 Depth=2
	ldr	x11, [x23, #16]
	ldrb	w12, [x11, x10]
	cbnz	w12, LBB79_6
; %bb.18:                               ;   in Loop: Header=BB79_7 Depth=2
	strb	w19, [x11, x10]
	ldr	x11, [x23, #48]
	ldr	x12, [x23, #120]
	add	x13, x12, #1
	str	x13, [x23, #120]
	str	x10, [x11, x12, lsl #3]
	b	LBB79_6
LBB79_19:
	mov	w19, #0                         ; =0x0
	b	LBB79_21
LBB79_20:
	mov	w19, #1                         ; =0x1
LBB79_21:
	ldur	x8, [x29, #-88]
Lloh429:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh430:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh431:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB79_23
; %bb.22:
	mov	x0, x19
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
LBB79_23:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh426, Lloh427, Lloh428
	.loh AdrpLdrGotLdr	Lloh429, Lloh430, Lloh431
	.cfi_endproc
                                        ; -- End function
.tbss _trigger_profile$tlv$init, 128, 3 ; @trigger_profile

	.section	__DATA,__thread_vars,thread_local_variables
_trigger_profile:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_trigger_profile$tlv$init

.tbss _lookup_profile$tlv$init, 96, 3   ; @lookup_profile

_lookup_profile:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_lookup_profile$tlv$init

.tbss _profile$tlv$init, 584, 3         ; @profile

_profile:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_profile$tlv$init

.tbss _owned_index_counts$tlv$init, 24, 3 ; @owned_index_counts

_owned_index_counts:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_owned_index_counts$tlv$init

.tbss _owned_heap$tlv$init, 2120, 3     ; @owned_heap

_owned_heap:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_owned_heap$tlv$init

.tbss _native_scope_depth$tlv$init, 4, 2 ; @native_scope_depth

_native_scope_depth:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_native_scope_depth$tlv$init

.tbss _live_owner$tlv$init, 72, 3       ; @live_owner

_live_owner:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_live_owner$tlv$init

.tbss _resource_head$tlv$init, 8, 3     ; @resource_head

_resource_head:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_resource_head$tlv$init

.tbss _host_head$tlv$init, 8, 3         ; @host_head

_host_head:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_host_head$tlv$init

.tbss _shadow_stats$tlv$init, 40, 3     ; @shadow_stats

_shadow_stats:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_shadow_stats$tlv$init

.tbss _native_scope_context$tlv$init, 8, 3 ; @native_scope_context

_native_scope_context:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_native_scope_context$tlv$init

.tbss _native_scope_counts$tlv$init, 32, 3 ; @native_scope_counts

_native_scope_counts:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_native_scope_counts$tlv$init

.tbss _candidate_phase$tlv$init, 4, 2   ; @candidate_phase

_candidate_phase:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_candidate_phase$tlv$init

.tbss _candidate_autostart$tlv$init, 4, 2 ; @candidate_autostart

_candidate_autostart:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_candidate_autostart$tlv$init

.tbss _candidate_counts$tlv$init, 40, 3 ; @candidate_counts

_candidate_counts:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_candidate_counts$tlv$init

.tbss _shadow_owner$tlv$init, 8, 3      ; @shadow_owner

_shadow_owner:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_shadow_owner$tlv$init

.tbss _live_time_counts$tlv$init, 40, 3 ; @live_time_counts

_live_time_counts:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_live_time_counts$tlv$init

.tbss _live_batch_counts$tlv$init, 40, 3 ; @live_batch_counts

_live_batch_counts:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_live_batch_counts$tlv$init

.tbss _live_counts$tlv$init, 40, 3      ; @live_counts

_live_counts:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_live_counts$tlv$init

.tbss _native_scope_serial$tlv$init, 8, 3 ; @native_scope_serial

_native_scope_serial:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_native_scope_serial$tlv$init

.tbss _native_scope_tokens$tlv$init, 512, 3 ; @native_scope_tokens

_native_scope_tokens:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_native_scope_tokens$tlv$init

.tbss _host_roots$tlv$init, 14336, 3    ; @host_roots

_host_roots:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_host_roots$tlv$init

	.section	__DATA,__data
	.p2align	3, 0x0                          ; @next_host_handle
_next_host_handle:
	.quad	1                               ; 0x1

.subsections_via_symbols
