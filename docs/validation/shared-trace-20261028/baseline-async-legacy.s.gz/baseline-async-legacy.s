	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 26, 2	sdk_version 26, 2
	.globl	_neoclr_runtime_async_statistics_v1 ; -- Begin function neoclr_runtime_async_statistics_v1
	.p2align	2
_neoclr_runtime_async_statistics_v1:    ; @neoclr_runtime_async_statistics_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh0:
	adrp	x0, _statistics@TLVPPAGE
Lloh1:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0]
	stp	q0, q1, [x8]
	ldr	q0, [x0, #32]
	str	q0, [x8, #32]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_async_trace_begin       ; -- Begin function neoclr_async_trace_begin
	.p2align	2
_neoclr_async_trace_begin:              ; @neoclr_async_trace_begin
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh2:
	adrp	x0, _state@TLVPPAGE
Lloh3:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh4:
	adrp	x0, _async_trace@TLVPPAGE
Lloh5:
	ldr	x0, [x0, _async_trace@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	sub	x10, x19, #16, lsl #12          ; =65536
	sub	x10, x10, #1
	cmn	x10, #16, lsl #12               ; =65536
	ccmp	x8, #0, #0, hs
	ccmp	x9, #0, #0, eq
	b.eq	LBB1_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	b	LBB1_6
LBB1_2:
	mov	x20, x0
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbnz	w8, LBB1_6
; %bb.3:
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp]
	madd	x21, x9, x8, x10
	cbz	x21, LBB1_6
; %bb.4:
	mov	x0, x19
	mov	w1, #40                         ; =0x28
	bl	_calloc
	cbz	x0, LBB1_6
; %bb.5:
	str	x0, [x20]
	stp	x19, x21, [x20, #16]
	mov	w0, #1                          ; =0x1
	str	w0, [x20, #56]
LBB1_6:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_async_trace_finish      ; -- Begin function neoclr_async_trace_finish
	.p2align	2
_neoclr_async_trace_finish:             ; @neoclr_async_trace_finish
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh6:
	adrp	x0, _state@TLVPPAGE
Lloh7:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x10, [x0]
Lloh8:
	adrp	x0, _async_trace@TLVPPAGE
Lloh9:
	ldr	x0, [x0, _async_trace@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	w9, #0                          ; =0x0
	cbz	x8, LBB2_3
; %bb.1:
	ldr	w11, [x0, #56]
	cmp	x10, #0
	ccmp	w11, #0, #4, eq
	b.eq	LBB2_3
; %bb.2:
	str	wzr, [x0, #56]
	ldr	x9, [x0]
	ldr	x10, [x0, #40]
	str	x9, [x8]
	ldur	q0, [x0, #8]
	stur	q0, [x8, #8]
	ldur	q0, [x0, #24]
	stur	q0, [x8, #24]
	str	x10, [x8, #40]
	mov	w9, #1                          ; =0x1
LBB2_3:
	mov	x0, x9
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_async_trace_dispose     ; -- Begin function neoclr_async_trace_dispose
	.p2align	2
_neoclr_async_trace_dispose:            ; @neoclr_async_trace_dispose
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh10:
	adrp	x0, _state@TLVPPAGE
Lloh11:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh12:
	adrp	x0, _async_trace@TLVPPAGE
Lloh13:
	ldr	x0, [x0, _async_trace@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	w9, [x0, #56]
	cmp	x8, #0
	ccmp	w9, #0, #0, eq
	b.eq	LBB3_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	b	LBB3_3
LBB3_2:
	ldr	x8, [x0]
	mov	x19, x0
	mov	x0, x8
	bl	_free
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19]
	mov	w0, #1                          ; =0x1
LBB3_3:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_reap_v1   ; -- Begin function neoclr_runtime_async_reap_v1
	.p2align	2
_neoclr_runtime_async_reap_v1:          ; @neoclr_runtime_async_reap_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB4_6
; %bb.1:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh14:
	adrp	x0, _state@TLVPPAGE
Lloh15:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	x9, x8
	b.ne	LBB4_5
; %bb.2:
	add	x8, x0, #34, lsl #12            ; =139264
	ldr	x9, [x8, #1056]
	cbnz	x9, LBB4_5
; %bb.3:
	ldr	w8, [x8, #1288]
	cbnz	w8, LBB4_5
; %bb.4:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB4_7
LBB4_5:
	mov	w0, #3                          ; =0x3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB4_6:
	mov	w0, #3                          ; =0x3
	ret
LBB4_7:
	bl	_reap_expired
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function reap_expired
lCPI5_0:
	.long	7                               ; 0x7
	.long	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_reap_expired:                          ; @reap_expired
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
Lloh16:
	adrp	x0, _state@TLVPPAGE
Lloh17:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	add	x24, x0, #34, lsl #12           ; =139264
	ldr	w8, [x24, #1284]
	cbz	w8, LBB5_31
; %bb.1:
	mov	x19, x0
	add	x25, x0, #3104
Lloh18:
	adrp	x0, _async_trace@TLVPPAGE
Lloh19:
	ldr	x0, [x0, _async_trace@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
Lloh20:
	adrp	x0, _statistics@TLVPPAGE
Lloh21:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x21, x0
	mov	x26, #0                         ; =0x0
	mov	w27, #1072                      ; =0x430
Lloh22:
	adrp	x8, lCPI5_0@PAGE
Lloh23:
	ldr	d8, [x8, lCPI5_0@PAGEOFF]
	b	LBB5_3
LBB5_2:                                 ;   in Loop: Header=BB5_3 Depth=1
	add	x26, x26, #1
	cmp	x26, #128
	b.eq	LBB5_24
LBB5_3:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB5_19 Depth 2
	madd	x22, x26, x27, x25
	ldr	x8, [x22, #920]
	cbz	x8, LBB5_2
; %bb.4:                                ;   in Loop: Header=BB5_3 Depth=1
	ldr	w8, [x22, #1028]
	cbz	w8, LBB5_2
; %bb.5:                                ;   in Loop: Header=BB5_3 Depth=1
	ldr	w8, [x22, #912]
	cbz	w8, LBB5_2
; %bb.6:                                ;   in Loop: Header=BB5_3 Depth=1
	ldr	x8, [x22, #984]
	ldr	x9, [x24, #1056]
	cmp	x8, #0
	ccmp	x22, x9, #4, ne
	b.eq	LBB5_32
; %bb.7:                                ;   in Loop: Header=BB5_3 Depth=1
	ldr	x8, [x22, #992]
	cbnz	x8, LBB5_32
; %bb.8:                                ;   in Loop: Header=BB5_3 Depth=1
	ldr	x8, [x22, #1000]
	cbnz	x8, LBB5_32
; %bb.9:                                ;   in Loop: Header=BB5_3 Depth=1
	ldr	w8, [x20, #56]
	cbz	w8, LBB5_16
; %bb.10:                               ;   in Loop: Header=BB5_3 Depth=1
	ldr	x23, [x22, #976]
	ldr	x28, [x22, #968]
	ldr	x8, [x20, #32]
	add	x27, x8, #1
	str	x27, [x20, #32]
	ldp	x8, x9, [x20, #8]
	cmp	x8, x9
	b.ne	LBB5_12
LBB5_11:                                ;   in Loop: Header=BB5_3 Depth=1
	ldr	x8, [x20, #40]
	add	x8, x8, #1
	str	x8, [x20, #40]
	b	LBB5_15
LBB5_12:                                ;   in Loop: Header=BB5_3 Depth=1
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB5_11
; %bb.13:                               ;   in Loop: Header=BB5_3 Depth=1
	ldp	x8, x9, [sp]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x8, x8, x10, x9
	cbz	x8, LBB5_11
; %bb.14:                               ;   in Loop: Header=BB5_3 Depth=1
	ldp	x9, x10, [x20]
	add	x11, x10, #1
	str	x11, [x20, #8]
	mov	w11, #40                        ; =0x28
	madd	x9, x10, x11, x9
	stp	x8, x27, [x9]
	stp	x23, x28, [x9, #16]
	str	d8, [x9, #32]
LBB5_15:                                ;   in Loop: Header=BB5_3 Depth=1
	mov	w27, #1072                      ; =0x430
LBB5_16:                                ;   in Loop: Header=BB5_3 Depth=1
	add	x0, x22, #880
	bl	_neoclr_roots_discard_v1
	ldr	x0, [x19]
	ldr	x1, [x22, #952]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB5_32
; %bb.17:                               ;   in Loop: Header=BB5_3 Depth=1
	ldr	x8, [x22, #960]
	mov	w9, #24                         ; =0x18
	b	LBB5_19
LBB5_18:                                ;   in Loop: Header=BB5_19 Depth=2
	add	x9, x9, #24
	cmp	x9, #3096
	b.eq	LBB5_22
LBB5_19:                                ;   Parent Loop BB5_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cbz	x8, LBB5_18
; %bb.20:                               ;   in Loop: Header=BB5_19 Depth=2
	ldr	x10, [x19, x9]
	cmp	x10, x8
	b.ne	LBB5_18
; %bb.21:                               ;   in Loop: Header=BB5_3 Depth=1
	add	x8, x19, x9
	stp	xzr, xzr, [x8]
	str	xzr, [x8, #16]
LBB5_22:                                ;   in Loop: Header=BB5_3 Depth=1
	ldr	x0, [x22, #920]
	ldr	x23, [x22, #928]
	mov	x1, x23
	bl	_munmap
	cbnz	w0, LBB5_32
; %bb.23:                               ;   in Loop: Header=BB5_3 Depth=1
	ldp	x8, x9, [x21, #24]
	add	x8, x8, #1
	sub	x9, x9, x23
	stp	x8, x9, [x21, #24]
	ldr	w8, [x24, #1284]
	sub	w8, w8, #1
	str	w8, [x24, #1284]
	mov	x0, x22
	mov	w1, #1072                       ; =0x430
	bl	_bzero
	b	LBB5_2
LBB5_24:
	mov	x20, #0                         ; =0x0
	b	LBB5_26
LBB5_25:                                ;   in Loop: Header=BB5_26 Depth=1
	add	x20, x20, #24
	cmp	x20, #3072
	b.eq	LBB5_31
LBB5_26:                                ; =>This Inner Loop Header: Depth=1
	add	x22, x19, x20
	mov	x21, x22
	ldr	x8, [x21, #24]!
	cbz	x8, LBB5_25
; %bb.27:                               ;   in Loop: Header=BB5_26 Depth=1
	ldr	x1, [x22, #40]
	cbz	x1, LBB5_25
; %bb.28:                               ;   in Loop: Header=BB5_26 Depth=1
	str	xzr, [sp]
	ldr	x0, [x19]
	mov	x2, sp
	bl	_neoclr_gc_host_root_read_v1
	cbz	w0, LBB5_25
; %bb.29:                               ;   in Loop: Header=BB5_26 Depth=1
	ldr	x0, [x19]
	ldr	x1, [x22, #40]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB5_32
; %bb.30:                               ;   in Loop: Header=BB5_26 Depth=1
	stp	xzr, xzr, [x21]
	str	xzr, [x21, #16]
	ldr	w8, [x24, #1284]
	sub	w8, w8, #1
	str	w8, [x24, #1284]
	b	LBB5_25
LBB5_31:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB5_32:
	bl	_abort
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh18, Lloh19
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_runtime_async_create_v1
lCPI6_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_runtime_async_create_v1
	.p2align	2
_neoclr_runtime_async_create_v1:        ; @neoclr_runtime_async_create_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_2
; %bb.1:
	ldr	w8, [x0]
	cbz	w8, LBB6_3
LBB6_2:
	mov	w0, #3                          ; =0x3
	ret
LBB6_3:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x11, x0
Lloh24:
	adrp	x0, _state@TLVPPAGE
Lloh25:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ldr	x12, [x0]
	cbnz	x12, LBB6_5
; %bb.4:
	mov	x12, x11
	str	x11, [x8]
LBB6_5:
Lloh26:
	adrp	x0, _next_id@TLVPPAGE
Lloh27:
	ldr	x0, [x0, _next_id@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x9, x0
	mov	w0, #3                          ; =0x3
	cbz	x1, LBB6_21
; %bb.6:
	ldr	x10, [x9]
	cmp	x12, x11
	mov	x11, #9223372036854775807       ; =0x7fffffffffffffff
	ccmp	x10, x11, #4, eq
	b.eq	LBB6_21
; %bb.7:
	add	x11, x8, #24
	mov	w12, #128                       ; =0x80
LBB6_8:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x11]
	cbz	x13, LBB6_11
; %bb.9:                                ;   in Loop: Header=BB6_8 Depth=1
	add	x11, x11, #24
	subs	x12, x12, #1
	b.ne	LBB6_8
; %bb.10:
	mov	w0, #5                          ; =0x5
	b	LBB6_21
LBB6_11:
	add	x20, x10, #1
	str	x20, [x9]
	stp	xzr, xzr, [x11, #8]
	str	x20, [x11]
	str	x20, [x1]
	mov	w9, #9248                       ; =0x2420
	movk	w9, #2, lsl #16
	ldr	x8, [x8, x9]
	cbz	x8, LBB6_13
; %bb.12:
	ldr	x21, [x8, #976]
	b	LBB6_14
LBB6_13:
	mov	x21, #0                         ; =0x0
LBB6_14:
Lloh28:
	adrp	x0, _async_trace@TLVPPAGE
Lloh29:
	ldr	x0, [x0, _async_trace@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w8, [x0, #56]
	cbz	w8, LBB6_17
; %bb.15:
	mov	x19, x0
	ldr	x8, [x0, #32]
	add	x22, x8, #1
	str	x22, [x0, #32]
	ldp	x8, x9, [x0, #8]
	cmp	x8, x9
	b.ne	LBB6_18
LBB6_16:
	mov	w0, #0                          ; =0x0
	ldr	x8, [x19, #40]
	add	x8, x8, #1
	str	x8, [x19, #40]
	b	LBB6_21
LBB6_17:
	mov	w0, #0                          ; =0x0
	b	LBB6_21
LBB6_18:
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB6_16
; %bb.19:
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp]
	madd	x8, x9, x8, x10
	cbz	x8, LBB6_16
; %bb.20:
	mov	w0, #0                          ; =0x0
	ldp	x9, x10, [x19]
	add	x11, x10, #1
	str	x11, [x19, #8]
	mov	w11, #40                        ; =0x28
	madd	x9, x10, x11, x9
	stp	x8, x22, [x9]
	stp	x21, x20, [x9, #16]
Lloh30:
	adrp	x8, lCPI6_0@PAGE
Lloh31:
	ldr	d0, [x8, lCPI6_0@PAGEOFF]
	str	d0, [x9, #32]
LBB6_21:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_start_v1  ; -- Begin function neoclr_runtime_async_start_v1
	.p2align	2
_neoclr_runtime_async_start_v1:         ; @neoclr_runtime_async_start_v1
	.cfi_startproc
; %bb.0:
	mov	x4, x3
	mov	x3, x2
	mov	x2, x1
	mov	x1, x0
	mov	x0, #0                          ; =0x0
	mov	w5, #0                          ; =0x0
	b	_start
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function start
_start:                                 ; @start
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbz	x2, LBB8_2
; %bb.1:
	ldr	w8, [x2]
	cbz	w8, LBB8_4
LBB8_2:
	mov	w0, #3                          ; =0x3
LBB8_3:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB8_4:
	mov	x21, x0
Lloh32:
	adrp	x0, _state@TLVPPAGE
Lloh33:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ldr	x9, [x0]
	cbnz	x9, LBB8_6
; %bb.5:
	str	x2, [x8]
	mov	x9, x2
LBB8_6:
	mov	w0, #3                          ; =0x3
	cbz	x4, LBB8_3
; %bb.7:
	cbz	x3, LBB8_3
; %bb.8:
	cmp	x9, x2
	b.ne	LBB8_3
; %bb.9:
	ldr	x9, [x8, #8]
	cmp	x9, #0
	ccmp	x9, x4, #4, ne
	b.ne	LBB8_3
; %bb.10:
	mov	x20, x1
	mov	x24, x5
	mov	x23, x3
	mov	x22, x8
	str	x4, [x8, #8]
	stp	xzr, xzr, [sp]
	mov	x1, sp
	mov	x19, x2
	mov	x0, x2
	bl	_neoclr_runtime_async_create_v1
	cbnz	w0, LBB8_3
; %bb.11:
	cbz	x21, LBB8_13
; %bb.12:
	add	x3, sp, #8
	mov	x0, x19
	mov	x1, x21
	mov	x2, x20
	bl	_neoclr_gc_host_root_create_owned_v1
	b	LBB8_14
LBB8_13:
	add	x2, sp, #8
	mov	x0, x19
	mov	x1, x20
	bl	_neoclr_gc_host_root_create_v1
LBB8_14:
	cbz	w0, LBB8_19
; %bb.15:
	mov	x8, x22
	ldr	x9, [sp]
LBB8_16:                                ; =>This Inner Loop Header: Depth=1
	add	x8, x8, #24
	cbz	x9, LBB8_16
; %bb.17:                               ;   in Loop: Header=BB8_16 Depth=1
	ldr	x10, [x8]
	cmp	x10, x9
	b.ne	LBB8_16
LBB8_18:
	str	xzr, [x8]
	b	LBB8_3
LBB8_19:
	ldp	x1, x0, [sp]
	mov	w2, #0                          ; =0x0
	bl	_allocate_fiber
	cbz	x0, LBB8_26
; %bb.20:
	mov	x20, x0
	str	x21, [x0, #984]
	str	w24, [x0, #1032]
	cbz	x21, LBB8_31
; %bb.21:
	mov	w8, #9476                       ; =0x2504
	movk	w8, #2, lsl #16
	ldr	w9, [x22, x8]
	add	w9, w9, #1
	str	w9, [x22, x8]
	ldr	x9, [sp]
	add	x8, x22, #36
	b	LBB8_23
LBB8_22:                                ;   in Loop: Header=BB8_23 Depth=1
	add	x8, x8, #24
LBB8_23:                                ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB8_22
; %bb.24:                               ;   in Loop: Header=BB8_23 Depth=1
	ldur	x10, [x8, #-12]
	cmp	x10, x9
	b.ne	LBB8_22
; %bb.25:
	mov	w9, #1                          ; =0x1
	str	w9, [x8]
	b	LBB8_36
LBB8_26:
	ldr	x1, [sp, #8]
	mov	x0, x19
	bl	_neoclr_gc_host_root_release_v1
	ldr	x9, [sp]
	add	x8, x22, #24
	b	LBB8_28
LBB8_27:                                ;   in Loop: Header=BB8_28 Depth=1
	add	x8, x8, #24
LBB8_28:                                ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB8_27
; %bb.29:                               ;   in Loop: Header=BB8_28 Depth=1
	ldr	x10, [x8]
	cmp	x10, x9
	b.ne	LBB8_27
; %bb.30:
	str	xzr, [x8]
	mov	w0, #5                          ; =0x5
	b	LBB8_3
LBB8_31:
	ldr	x8, [sp]
	add	x9, x22, #36
	mov	x10, x23
	b	LBB8_33
LBB8_32:                                ;   in Loop: Header=BB8_33 Depth=1
	add	x9, x9, #24
LBB8_33:                                ; =>This Inner Loop Header: Depth=1
	cbz	x8, LBB8_32
; %bb.34:                               ;   in Loop: Header=BB8_33 Depth=1
	ldur	x11, [x9, #-12]
	cmp	x11, x8
	b.ne	LBB8_32
; %bb.35:
	mov	w11, #1                         ; =0x1
	str	w11, [x9]
	str	x8, [x10]
LBB8_36:
	mov	x0, x20
	bl	_resume
	cbz	w0, LBB8_39
; %bb.37:
	ldr	x8, [x20, #920]
	cbz	x8, LBB8_39
; %bb.38:
	ldr	w8, [x20, #1028]
	cbz	w8, LBB8_40
LBB8_39:
	ldr	x8, [sp]
	str	x8, [x23]
	b	LBB8_3
LBB8_40:
	mov	x21, x0
	ldr	x1, [x20, #952]
	mov	x0, x19
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB8_47
; %bb.41:
	ldr	x0, [x20, #920]
	ldr	x1, [x20, #928]
	bl	_unmap_stack
	ldr	x8, [x20, #984]
	cbz	x8, LBB8_43
; %bb.42:
	mov	w8, #9476                       ; =0x2504
	movk	w8, #2, lsl #16
	ldr	w10, [x22, x8]
	sub	w10, w10, #1
	str	w10, [x22, x8]
LBB8_43:
	mov	x0, x20
	mov	w1, #1072                       ; =0x430
	bl	_bzero
	ldr	x9, [sp]
	add	x8, x22, #24
	mov	x0, x21
	b	LBB8_45
LBB8_44:                                ;   in Loop: Header=BB8_45 Depth=1
	add	x8, x8, #24
LBB8_45:                                ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB8_44
; %bb.46:                               ;   in Loop: Header=BB8_45 Depth=1
	ldr	x10, [x8]
	cmp	x10, x9
	b.ne	LBB8_44
	b	LBB8_18
LBB8_47:
	bl	_abort
	.loh AdrpLdr	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_start_owned_v1 ; -- Begin function neoclr_runtime_async_start_owned_v1
	.p2align	2
_neoclr_runtime_async_start_owned_v1:   ; @neoclr_runtime_async_start_owned_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB9_2
; %bb.1:
	mov	w5, #0                          ; =0x0
	b	_start
LBB9_2:
	mov	w0, #3                          ; =0x3
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_startmanaged_v1 ; -- Begin function neoclr_runtime_async_startmanaged_v1
	.p2align	2
_neoclr_runtime_async_startmanaged_v1:  ; @neoclr_runtime_async_startmanaged_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB10_2
; %bb.1:
	mov	w5, #1                          ; =0x1
	b	_start
LBB10_2:
	mov	w0, #3                          ; =0x3
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_currentowner_v1 ; -- Begin function neoclr_runtime_async_currentowner_v1
	.p2align	2
_neoclr_runtime_async_currentowner_v1:  ; @neoclr_runtime_async_currentowner_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB11_2
; %bb.1:
	ldr	w8, [x0]
	cbz	w8, LBB11_3
LBB11_2:
	mov	w0, #3                          ; =0x3
	ret
LBB11_3:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x9, x0
Lloh34:
	adrp	x0, _state@TLVPPAGE
Lloh35:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ldr	x10, [x0]
	cbnz	x10, LBB11_5
; %bb.4:
	mov	x10, x9
	str	x9, [x8]
LBB11_5:
	mov	w0, #3                          ; =0x3
	cbz	x1, LBB11_10
; %bb.6:
	cmp	x10, x9
	b.ne	LBB11_10
; %bb.7:
	mov	w9, #9248                       ; =0x2420
	movk	w9, #2, lsl #16
	ldr	x8, [x8, x9]
	cbz	x8, LBB11_9
; %bb.8:
	ldr	x8, [x8, #984]
LBB11_9:
	mov	w0, #0                          ; =0x0
	str	x8, [x1]
LBB11_10:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh34, Lloh35
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_createowned_v1 ; -- Begin function neoclr_runtime_async_createowned_v1
	.p2align	2
_neoclr_runtime_async_createowned_v1:   ; @neoclr_runtime_async_createowned_v1
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB12_2
; %bb.1:
	ldr	w8, [x1]
	cbz	w8, LBB12_3
LBB12_2:
	mov	w0, #3                          ; =0x3
	ret
LBB12_3:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x0
Lloh36:
	adrp	x0, _state@TLVPPAGE
Lloh37:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ldr	x9, [x0]
	cbnz	x9, LBB12_5
; %bb.4:
	str	x1, [x8]
	mov	x9, x1
LBB12_5:
	mov	w0, #3                          ; =0x3
	cbz	x2, LBB12_20
; %bb.6:
	cbz	x20, LBB12_20
; %bb.7:
	cmp	x9, x1
	b.ne	LBB12_20
; %bb.8:
	mov	x21, x8
	mov	x22, x2
	mov	x0, x1
	add	x1, sp, #8
	mov	x19, x0
	bl	_neoclr_runtime_async_create_v1
	cbnz	w0, LBB12_20
; %bb.9:
	mov	x3, sp
	mov	x0, x19
	mov	x1, x20
	mov	x2, x20
	bl	_neoclr_gc_host_root_create_owned_v1
	cbz	w0, LBB12_15
; %bb.10:
	ldr	x9, [sp, #8]
	add	x8, x21, #24
	b	LBB12_12
LBB12_11:                               ;   in Loop: Header=BB12_12 Depth=1
	add	x8, x8, #24
LBB12_12:                               ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB12_11
; %bb.13:                               ;   in Loop: Header=BB12_12 Depth=1
	ldr	x10, [x8]
	cmp	x10, x9
	b.ne	LBB12_11
; %bb.14:
	stp	xzr, xzr, [x8]
	str	xzr, [x8, #16]
	b	LBB12_20
LBB12_15:
	ldp	x9, x8, [sp]
	add	x10, x21, #40
	b	LBB12_17
LBB12_16:                               ;   in Loop: Header=BB12_17 Depth=1
	add	x10, x10, #24
LBB12_17:                               ; =>This Inner Loop Header: Depth=1
	cbz	x8, LBB12_16
; %bb.18:                               ;   in Loop: Header=BB12_17 Depth=1
	ldur	x11, [x10, #-16]
	cmp	x11, x8
	b.ne	LBB12_16
; %bb.19:
	mov	w0, #0                          ; =0x0
	str	x9, [x10]
	mov	w9, #9476                       ; =0x2504
	movk	w9, #2, lsl #16
	ldr	w10, [x21, x9]
	add	w10, w10, #1
	str	w10, [x21, x9]
	str	x8, [x22]
LBB12_20:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpLdr	Lloh36, Lloh37
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_runtime_async_completeunit_v1
lCPI13_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_runtime_async_completeunit_v1
	.p2align	2
_neoclr_runtime_async_completeunit_v1:  ; @neoclr_runtime_async_completeunit_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x1, LBB13_2
; %bb.1:
	ldr	w8, [x1]
	cbz	w8, LBB13_4
LBB13_2:
	mov	w19, #3                         ; =0x3
LBB13_3:
	mov	x0, x19
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB13_4:
	mov	x20, x0
Lloh38:
	adrp	x0, _state@TLVPPAGE
Lloh39:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbnz	x8, LBB13_6
; %bb.5:
	str	x1, [x0]
	mov	x8, x1
LBB13_6:
	mov	w19, #3                         ; =0x3
	cbz	x2, LBB13_3
; %bb.7:
	cmp	x8, x1
	b.ne	LBB13_3
; %bb.8:
	add	x22, x0, #36
	mov	w8, #128                        ; =0x80
	mov	x9, x20
	b	LBB13_10
LBB13_9:                                ;   in Loop: Header=BB13_10 Depth=1
	add	x22, x22, #24
	subs	x8, x8, #1
	b.eq	LBB13_13
LBB13_10:                               ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB13_9
; %bb.11:                               ;   in Loop: Header=BB13_10 Depth=1
	ldur	x10, [x22, #-12]
	cmp	x10, x9
	b.ne	LBB13_9
; %bb.12:
	ldur	w8, [x22, #-4]
	cbz	w8, LBB13_15
LBB13_13:
	mov	w19, #0                         ; =0x0
LBB13_14:
	str	wzr, [x2]
	b	LBB13_3
LBB13_15:
	ldr	w8, [x22]
	cmp	w8, #0
	cset	w10, eq
	str	w10, [x2]
	cbz	w8, LBB13_17
LBB13_16:
	mov	w19, #0                         ; =0x0
	b	LBB13_3
LBB13_17:
	mov	x23, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	mov	w8, #4112                       ; =0x1010
	add	x26, x0, x8
	b	LBB13_19
LBB13_18:                               ;   in Loop: Header=BB13_19 Depth=1
	add	x21, x21, #1
	add	x23, x23, #1072
	cmp	x21, #128
	b.eq	LBB13_26
LBB13_19:                               ; =>This Inner Loop Header: Depth=1
	add	x8, x0, x23
	ldr	x10, [x8, #4024]
	cbz	x10, LBB13_18
; %bb.20:                               ;   in Loop: Header=BB13_19 Depth=1
	ldr	x8, [x8, #4072]
	cmp	x8, x9
	b.ne	LBB13_18
; %bb.21:                               ;   in Loop: Header=BB13_19 Depth=1
	add	x10, x0, x23
	ldr	x8, [x10, #4088]
	cbz	x8, LBB13_18
; %bb.22:                               ;   in Loop: Header=BB13_19 Depth=1
	ldr	w10, [x10, #4016]
	cbnz	w10, LBB13_18
; %bb.23:                               ;   in Loop: Header=BB13_19 Depth=1
	mov	x24, x2
	add	x2, x26, x23
	mov	x27, x0
	mov	x0, x1
	mov	x25, x1
	mov	x1, x8
	bl	_neoclr_gc_host_root_create_v1
	mov	x1, x25
	mov	x2, x24
	mov	x19, x0
	mov	x0, x27
	mov	x9, x20
	cbz	w19, LBB13_18
; %bb.24:
	cbz	x23, LBB13_14
; %bb.25:
	mov	w8, #4112                       ; =0x1010
	add	x22, x0, x8
	b	LBB13_30
LBB13_26:
	mov	w8, #1                          ; =0x1
	stur	w8, [x22, #-4]
	mov	w8, #9248                       ; =0x2420
	movk	w8, #2, lsl #16
	ldr	x8, [x0, x8]
	cbz	x8, LBB13_34
; %bb.27:
	ldr	x21, [x8, #976]
	b	LBB13_35
LBB13_28:                               ;   in Loop: Header=BB13_30 Depth=1
	str	xzr, [x22]
	mov	x9, x20
	mov	x2, x24
	mov	x1, x25
LBB13_29:                               ;   in Loop: Header=BB13_30 Depth=1
	add	x22, x22, #1072
	subs	x21, x21, #1
	b.eq	LBB13_14
LBB13_30:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x22, #-40]
	cmp	x8, x9
	b.ne	LBB13_29
; %bb.31:                               ;   in Loop: Header=BB13_30 Depth=1
	ldr	x8, [x22]
	cbz	x8, LBB13_29
; %bb.32:                               ;   in Loop: Header=BB13_30 Depth=1
	mov	x0, x1
	mov	x1, x8
	bl	_neoclr_gc_host_root_release_v1
	cbz	w0, LBB13_28
; %bb.33:
	bl	_abort
LBB13_34:
	mov	x21, #0                         ; =0x0
LBB13_35:
Lloh40:
	adrp	x0, _async_trace@TLVPPAGE
Lloh41:
	ldr	x0, [x0, _async_trace@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w8, [x0, #56]
	cbz	w8, LBB13_16
; %bb.36:
	ldr	x8, [x0, #32]
	add	x22, x8, #1
	str	x22, [x0, #32]
	ldp	x8, x9, [x0, #8]
	cmp	x8, x9
	b.ne	LBB13_38
; %bb.37:
	mov	w19, #0                         ; =0x0
	ldr	x8, [x0, #40]
	add	x8, x8, #1
	str	x8, [x0, #40]
	b	LBB13_3
LBB13_38:
	mov	x23, x0
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB13_41
; %bb.39:
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp]
	madd	x8, x9, x8, x10
	cbz	x8, LBB13_41
; %bb.40:
	mov	w19, #0                         ; =0x0
	ldp	x9, x10, [x23]
	add	x11, x10, #1
	str	x11, [x23, #8]
	mov	w11, #40                        ; =0x28
	madd	x9, x10, x11, x9
	stp	x8, x22, [x9]
	stp	x21, x20, [x9, #16]
Lloh42:
	adrp	x8, lCPI13_0@PAGE
Lloh43:
	ldr	d0, [x8, lCPI13_0@PAGEOFF]
	str	d0, [x9, #32]
	b	LBB13_3
LBB13_41:
	mov	w19, #0                         ; =0x0
	ldr	x8, [x23, #40]
	add	x8, x8, #1
	str	x8, [x23, #40]
	b	LBB13_3
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpLdr	Lloh42, Lloh43
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_iscompleted_v1 ; -- Begin function neoclr_runtime_async_iscompleted_v1
	.p2align	2
_neoclr_runtime_async_iscompleted_v1:   ; @neoclr_runtime_async_iscompleted_v1
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB14_2
; %bb.1:
	ldr	w8, [x1]
	cbz	w8, LBB14_3
LBB14_2:
	mov	w0, #3                          ; =0x3
	ret
LBB14_3:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x10, x0
Lloh44:
	adrp	x0, _state@TLVPPAGE
Lloh45:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x9, [x0]
	cbnz	x9, LBB14_5
; %bb.4:
	str	x1, [x0]
	mov	x9, x1
LBB14_5:
	mov	w8, #3                          ; =0x3
	cbz	x2, LBB14_15
; %bb.6:
	cmp	x9, x1
	b.ne	LBB14_15
; %bb.7:
	add	x9, x0, #24
	mov	w11, #24                        ; =0x18
	mov	x8, x10
	b	LBB14_9
LBB14_8:                                ;   in Loop: Header=BB14_9 Depth=1
	add	x11, x11, #24
	cmp	x11, #3096
	b.eq	LBB14_14
LBB14_9:                                ; =>This Inner Loop Header: Depth=1
	cbz	x8, LBB14_8
; %bb.10:                               ;   in Loop: Header=BB14_9 Depth=1
	ldr	x10, [x0, x11]
	cmp	x10, x8
	b.ne	LBB14_8
; %bb.11:
	ldr	x10, [x9]
	cmp	x10, x8
	b.eq	LBB14_13
LBB14_12:                               ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9, #24]!
	cmp	x10, x8
	b.ne	LBB14_12
LBB14_13:
	mov	w8, #0                          ; =0x0
	ldr	w9, [x9, #8]
	str	w9, [x2]
	b	LBB14_15
LBB14_14:
	mov	w8, #3                          ; =0x3
LBB14_15:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	mov	x0, x8
	ret
	.loh AdrpLdr	Lloh44, Lloh45
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_release_v1 ; -- Begin function neoclr_runtime_async_release_v1
	.p2align	2
_neoclr_runtime_async_release_v1:       ; @neoclr_runtime_async_release_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	cbz	x1, LBB15_2
; %bb.1:
	ldr	w8, [x1]
	cbz	w8, LBB15_4
LBB15_2:
	mov	w8, #3                          ; =0x3
LBB15_3:
	mov	x0, x8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB15_4:
	mov	x19, x0
Lloh46:
	adrp	x0, _state@TLVPPAGE
Lloh47:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x9, [x0]
	cbnz	x9, LBB15_6
; %bb.5:
	str	x1, [x0]
	mov	x9, x1
LBB15_6:
	mov	w8, #3                          ; =0x3
	cbz	x2, LBB15_3
; %bb.7:
	cmp	x9, x1
	b.ne	LBB15_3
; %bb.8:
	str	wzr, [x2]
	add	x20, x0, #24
	mov	w9, #24                         ; =0x18
	mov	x8, x19
	b	LBB15_10
LBB15_9:                                ;   in Loop: Header=BB15_10 Depth=1
	add	x9, x9, #24
	cmp	x9, #3096
	b.eq	LBB15_22
LBB15_10:                               ; =>This Inner Loop Header: Depth=1
	cbz	x8, LBB15_9
; %bb.11:                               ;   in Loop: Header=BB15_10 Depth=1
	ldr	x10, [x0, x9]
	cmp	x10, x8
	b.ne	LBB15_9
; %bb.12:
	ldr	x9, [x20]
	mov	x10, x20
	cmp	x9, x8
	b.eq	LBB15_15
; %bb.13:
	mov	x10, x20
LBB15_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x10, #24]!
	cmp	x11, x8
	b.ne	LBB15_14
LBB15_15:
	ldr	w10, [x10, #8]
	cbz	w10, LBB15_22
; %bb.16:
	add	x10, x0, #4024
	mov	w11, #128                       ; =0x80
	b	LBB15_18
LBB15_17:                               ;   in Loop: Header=BB15_18 Depth=1
	add	x10, x10, #1072
	subs	x11, x11, #1
	b.eq	LBB15_23
LBB15_18:                               ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x10]
	cbz	x12, LBB15_17
; %bb.19:                               ;   in Loop: Header=BB15_18 Depth=1
	ldr	w12, [x10, #116]
	cbnz	w12, LBB15_17
; %bb.20:                               ;   in Loop: Header=BB15_18 Depth=1
	ldr	x12, [x10, #48]
	cmp	x12, x8
	b.eq	LBB15_22
; %bb.21:                               ;   in Loop: Header=BB15_18 Depth=1
	ldr	x12, [x10, #40]
	cmp	x12, x8
	b.ne	LBB15_17
LBB15_22:
	mov	w8, #0                          ; =0x0
	b	LBB15_3
LBB15_23:
	cmp	x9, x8
	b.ne	LBB15_25
; %bb.24:
	ldr	x11, [x0, #40]
	mov	x10, x20
	cbnz	x11, LBB15_31
	b	LBB15_34
LBB15_25:
	add	x10, x0, #48
LBB15_26:                               ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x10], #24
	cmp	x11, x8
	b.ne	LBB15_26
; %bb.27:
	ldur	x10, [x10, #-8]
	cbz	x10, LBB15_34
; %bb.28:
	mov	x10, x20
	cmp	x9, x8
	b.eq	LBB15_31
; %bb.29:
	mov	x10, x20
LBB15_30:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x10, #24]!
	cmp	x9, x8
	b.ne	LBB15_30
LBB15_31:
	mov	x22, x0
	mov	x21, x2
	ldr	x8, [x10, #16]
	mov	x0, x1
	mov	x1, x8
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB15_36
; %bb.32:
	mov	w8, #9476                       ; =0x2504
	movk	w8, #2, lsl #16
	ldr	w9, [x22, x8]
	sub	w9, w9, #1
	str	w9, [x22, x8]
	ldr	x9, [x22, #24]
	mov	x2, x21
	mov	x8, x19
	b	LBB15_34
LBB15_33:                               ;   in Loop: Header=BB15_34 Depth=1
	ldr	x9, [x20, #24]!
LBB15_34:                               ; =>This Inner Loop Header: Depth=1
	cmp	x9, x8
	b.ne	LBB15_33
; %bb.35:
	mov	w8, #0                          ; =0x0
	stp	xzr, xzr, [x20]
	str	xzr, [x20, #16]
	mov	w9, #1                          ; =0x1
	str	w9, [x2]
	b	LBB15_3
LBB15_36:
	bl	_abort
	.loh AdrpLdr	Lloh46, Lloh47
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_waitcompletion_v1 ; -- Begin function neoclr_runtime_async_waitcompletion_v1
	.p2align	2
_neoclr_runtime_async_waitcompletion_v1: ; @neoclr_runtime_async_waitcompletion_v1
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB16_2
; %bb.1:
	ldr	w8, [x1]
	cbz	w8, LBB16_3
LBB16_2:
	mov	w0, #3                          ; =0x3
	ret
LBB16_3:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x0
Lloh48:
	adrp	x0, _state@TLVPPAGE
Lloh49:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x10, [x0]
	cbnz	x10, LBB16_5
; %bb.4:
	str	x1, [x0]
	mov	x10, x1
LBB16_5:
	mov	w8, #3                          ; =0x3
	cbz	x2, LBB16_20
; %bb.6:
	cmp	x10, x1
	b.ne	LBB16_20
; %bb.7:
	mov	x9, x20
	add	x19, x0, #24
	mov	w8, #24                         ; =0x18
	b	LBB16_9
LBB16_8:                                ;   in Loop: Header=BB16_9 Depth=1
	add	x8, x8, #24
	cmp	x8, #3096
	b.eq	LBB16_19
LBB16_9:                                ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB16_8
; %bb.10:                               ;   in Loop: Header=BB16_9 Depth=1
	ldr	x10, [x0, x8]
	cmp	x10, x9
	b.ne	LBB16_8
; %bb.11:
	ldr	x10, [x19]
	mov	x8, x19
	cmp	x10, x9
	b.eq	LBB16_14
; %bb.12:
	mov	x8, x19
LBB16_13:                               ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x8, #24]!
	cmp	x10, x9
	b.ne	LBB16_13
LBB16_14:
	ldr	w8, [x8, #8]
	cbz	w8, LBB16_16
LBB16_15:
	mov	w8, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	str	w9, [x2]
	b	LBB16_20
LBB16_16:
	mov	w8, #9248                       ; =0x2420
	movk	w8, #2, lsl #16
	ldr	x21, [x0, x8]
	cbz	x21, LBB16_19
; %bb.17:
	ldr	x8, [x21, #960]
	cmp	x8, x9
	b.eq	LBB16_19
; %bb.18:
	mov	x22, x0
	mov	x23, x2
	str	x9, [x21, #968]
	mov	x24, x1
	bl	_yield
	str	xzr, [x21, #968]
	ldr	w8, [x24]
	cbz	w8, LBB16_21
LBB16_19:
	mov	w8, #3                          ; =0x3
LBB16_20:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB16_21:
	mov	w9, #24                         ; =0x18
	mov	x2, x23
	mov	x10, x22
LBB16_22:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x10, x9]
	cmp	x8, x20
	b.eq	LBB16_24
; %bb.23:                               ;   in Loop: Header=BB16_22 Depth=1
	add	x9, x9, #24
	mov	w8, #3                          ; =0x3
	cmp	x9, #3096
	b.ne	LBB16_22
	b	LBB16_20
LBB16_24:
	ldr	x8, [x19]
	cmp	x8, x20
	b.eq	LBB16_26
LBB16_25:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19, #24]!
	cmp	x8, x20
	b.ne	LBB16_25
LBB16_26:
	ldr	w8, [x19, #8]
	cbnz	w8, LBB16_15
	b	LBB16_19
	.loh AdrpLdr	Lloh48, Lloh49
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function yield
_yield:                                 ; @yield
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
Lloh50:
	adrp	x0, _state@TLVPPAGE
Lloh51:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	mov	w8, #9248                       ; =0x2420
	movk	w8, #2, lsl #16
	ldr	x19, [x0, x8]
	ldr	x1, [x19, #1000]
	cbz	x1, LBB17_2
; %bb.1:
	ldr	x0, [x20]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB17_17
LBB17_2:
	ldr	x1, [x19, #992]
	cbz	x1, LBB17_4
; %bb.3:
	ldr	x0, [x20]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB17_17
LBB17_4:
	add	x8, x19, #992
	stp	xzr, xzr, [x8]
	ldr	x1, [x19, #984]
	cbz	x1, LBB17_6
; %bb.5:
	ldr	w8, [x19, #1016]
	cbz	w8, LBB17_7
LBB17_6:
	add	x0, x19, #880
	bl	_neoclr_roots_park_v1
	b	LBB17_8
LBB17_7:
	ldr	x0, [x20]
	add	x2, x19, #880
	bl	_neoclr_gc_roots_park_owned_v1
	cbnz	w0, LBB17_17
LBB17_8:
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #1028]
	ldr	w8, [x19, #1016]
	cmp	w8, #0
	mov	w8, #5                          ; =0x5
	cinc	w20, w8, ne
	mov	w8, #960                        ; =0x3c0
	mov	w9, #968                        ; =0x3c8
	csel	x8, x9, x8, eq
	ldr	x21, [x19, x8]
	ldr	x23, [x19, #976]
	ldr	w22, [x19, #1020]
Lloh52:
	adrp	x0, _async_trace@TLVPPAGE
Lloh53:
	ldr	x0, [x0, _async_trace@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	w8, [x0, #56]
	cbz	w8, LBB17_15
; %bb.9:
	ldr	x8, [x0, #32]
	add	x24, x8, #1
	str	x24, [x0, #32]
	ldp	x8, x9, [x0, #8]
	cmp	x8, x9
	b.ne	LBB17_11
; %bb.10:
	ldr	x8, [x0, #40]
	add	x8, x8, #1
	str	x8, [x0, #40]
	b	LBB17_15
LBB17_11:
	mov	x25, x0
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB17_14
; %bb.12:
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp]
	madd	x8, x9, x8, x10
	cbz	x8, LBB17_14
; %bb.13:
	ldp	x9, x10, [x25]
	add	x11, x10, #1
	str	x11, [x25, #8]
	mov	w11, #40                        ; =0x28
	madd	x9, x10, x11, x9
	stp	x8, x24, [x9]
	stp	x23, x21, [x9, #16]
	stp	w20, w22, [x9, #32]
	b	LBB17_15
LBB17_14:
	ldr	x8, [x25, #40]
	add	x8, x8, #1
	str	x8, [x25, #40]
LBB17_15:
	ldr	x1, [x19, #1056]
	mov	x0, x19
	bl	_swapcontext
	cbnz	w0, LBB17_17
; %bb.16:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB17_17:
	bl	_abort
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh52, Lloh53
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_awaitunit_v1 ; -- Begin function neoclr_runtime_async_awaitunit_v1
	.p2align	2
_neoclr_runtime_async_awaitunit_v1:     ; @neoclr_runtime_async_awaitunit_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x2, x29, #4
	bl	_neoclr_runtime_async_waitcompletion_v1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_runtime_async_pump_v1
lCPI19_0:
	.long	8                               ; 0x8
	.long	0                               ; 0x0
lCPI19_1:
	.long	9                               ; 0x9
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_runtime_async_pump_v1
	.p2align	2
_neoclr_runtime_async_pump_v1:          ; @neoclr_runtime_async_pump_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	d9, d8, [sp, #80]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	cbz	x0, LBB19_2
; %bb.1:
	mov	x19, x0
	ldr	w8, [x0]
	cbz	w8, LBB19_4
LBB19_2:
	mov	w8, #3                          ; =0x3
LBB19_3:
	mov	x0, x8
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #80]               ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB19_4:
Lloh54:
	adrp	x0, _state@TLVPPAGE
Lloh55:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x9, [x0]
	cbnz	x9, LBB19_6
; %bb.5:
	str	x19, [x0]
	mov	x9, x19
LBB19_6:
	mov	w8, #3                          ; =0x3
	cbz	x2, LBB19_3
; %bb.7:
	cbz	x1, LBB19_3
; %bb.8:
	cmp	x9, x19
	b.ne	LBB19_3
; %bb.9:
	add	x23, x0, #34, lsl #12           ; =139264
	ldr	x8, [x23, #1056]
	cbnz	x8, LBB19_2
; %bb.10:
	ldr	w8, [x23, #1288]
	cbnz	w8, LBB19_2
; %bb.11:
	stp	x1, x2, [x0, #8]
	mov	w22, #1                         ; =0x1
	str	w22, [x23, #1288]
	str	xzr, [sp, #48]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #16]
	mov	x21, x0
	add	x0, sp, #16
	bl	_neoclr_roots_park_v1
	add	x24, x21, #3104
Lloh56:
	adrp	x0, _async_trace@TLVPPAGE
Lloh57:
	ldr	x0, [x0, _async_trace@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	add	x25, x21, #32
	mov	w26, #1072                      ; =0x430
Lloh58:
	adrp	x8, lCPI19_1@PAGE
Lloh59:
	ldr	d8, [x8, lCPI19_1@PAGEOFF]
Lloh60:
	adrp	x8, lCPI19_0@PAGE
Lloh61:
	ldr	d9, [x8, lCPI19_0@PAGEOFF]
	b	LBB19_14
LBB19_12:                               ;   in Loop: Header=BB19_14 Depth=1
	mov	w0, #3                          ; =0x3
LBB19_13:                               ;   in Loop: Header=BB19_14 Depth=1
	cbnz	w0, LBB19_80
LBB19_14:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB19_18 Depth 2
                                        ;       Child Loop BB19_22 Depth 3
                                        ;     Child Loop BB19_39 Depth 2
                                        ;       Child Loop BB19_43 Depth 3
	bl	_reap_expired
	mov	x28, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	b	LBB19_18
LBB19_15:                               ;   in Loop: Header=BB19_18 Depth=2
	ldr	w8, [x21, #1024]
	cmp	w8, #0
	cset	w8, ne
LBB19_16:                               ;   in Loop: Header=BB19_18 Depth=2
	orr	w27, w8, w27
LBB19_17:                               ;   in Loop: Header=BB19_18 Depth=2
	add	x28, x28, #1
	cmp	x28, #128
	b.eq	LBB19_30
LBB19_18:                               ;   Parent Loop BB19_14 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB19_22 Depth 3
	madd	x21, x28, x26, x24
	ldr	x8, [x21, #920]
	cbz	x8, LBB19_17
; %bb.19:                               ;   in Loop: Header=BB19_18 Depth=2
	ldr	w8, [x21, #1036]
	cbnz	w8, LBB19_17
; %bb.20:                               ;   in Loop: Header=BB19_18 Depth=2
	ldr	x8, [x21, #968]
	mov	x9, x25
	mov	w10, #128                       ; =0x80
	b	LBB19_22
LBB19_21:                               ;   in Loop: Header=BB19_22 Depth=3
	add	x9, x9, #24
	subs	x10, x10, #1
	b.eq	LBB19_27
LBB19_22:                               ;   Parent Loop BB19_14 Depth=1
                                        ;     Parent Loop BB19_18 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cbz	x8, LBB19_21
; %bb.23:                               ;   in Loop: Header=BB19_22 Depth=3
	ldur	x11, [x9, #-8]
	cmp	x11, x8
	b.ne	LBB19_21
; %bb.24:                               ;   in Loop: Header=BB19_18 Depth=2
	ldr	w8, [x9]
	cbz	w8, LBB19_27
; %bb.25:                               ;   in Loop: Header=BB19_18 Depth=2
	mov	x0, x21
	bl	_resume
	mov	x22, x0
	bl	_reap_expired
	cbnz	w22, LBB19_75
; %bb.26:                               ;   in Loop: Header=BB19_18 Depth=2
	mov	w22, #1                         ; =0x1
LBB19_27:                               ;   in Loop: Header=BB19_18 Depth=2
	ldr	x8, [x21, #920]
	cbz	x8, LBB19_16
; %bb.28:                               ;   in Loop: Header=BB19_18 Depth=2
	ldr	w8, [x21, #1036]
	cbz	w8, LBB19_15
; %bb.29:                               ;   in Loop: Header=BB19_18 Depth=2
	mov	w8, #0                          ; =0x0
	b	LBB19_16
LBB19_30:                               ;   in Loop: Header=BB19_14 Depth=1
	cbnz	w27, LBB19_35
; %bb.31:                               ;   in Loop: Header=BB19_14 Depth=1
	cbz	w22, LBB19_35
; %bb.32:                               ;   in Loop: Header=BB19_14 Depth=1
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w2, #1                          ; =0x1
	bl	_allocate_fiber
	cbz	x0, LBB19_79
; %bb.33:                               ;   in Loop: Header=BB19_14 Depth=1
	bl	_resume
	cbnz	w0, LBB19_80
; %bb.34:                               ;   in Loop: Header=BB19_14 Depth=1
	mov	w22, #0                         ; =0x0
LBB19_35:                               ;   in Loop: Header=BB19_14 Depth=1
	bl	_reap_expired
	str	xzr, [sp, #8]
	add	x1, sp, #8
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	bl	_neoclr_scheduler_acquire_v1
	mov	x21, x0
	bl	_reap_expired
	mov	x9, #0                          ; =0x0
	mov	w8, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	b	LBB19_39
LBB19_36:                               ;   in Loop: Header=BB19_39 Depth=2
	mov	w10, #0                         ; =0x0
LBB19_37:                               ;   in Loop: Header=BB19_39 Depth=2
	orr	w8, w10, w8
	mov	w10, #1                         ; =0x1
LBB19_38:                               ;   in Loop: Header=BB19_39 Depth=2
	add	x9, x9, #1
	cmp	x9, #128
	b.eq	LBB19_46
LBB19_39:                               ;   Parent Loop BB19_14 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB19_43 Depth 3
	madd	x11, x9, x26, x24
	ldr	x12, [x11, #920]
	cbz	x12, LBB19_38
; %bb.40:                               ;   in Loop: Header=BB19_39 Depth=2
	ldr	w12, [x11, #1036]
	cbnz	w12, LBB19_38
; %bb.41:                               ;   in Loop: Header=BB19_39 Depth=2
	ldr	x10, [x11, #968]
	mov	x11, x25
	mov	w12, #128                       ; =0x80
	b	LBB19_43
LBB19_42:                               ;   in Loop: Header=BB19_43 Depth=3
	add	x11, x11, #24
	subs	x12, x12, #1
	b.eq	LBB19_36
LBB19_43:                               ;   Parent Loop BB19_14 Depth=1
                                        ;     Parent Loop BB19_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cbz	x10, LBB19_42
; %bb.44:                               ;   in Loop: Header=BB19_43 Depth=3
	ldur	x13, [x11, #-8]
	cmp	x13, x10
	b.ne	LBB19_42
; %bb.45:                               ;   in Loop: Header=BB19_39 Depth=2
	ldr	w10, [x11]
	cmp	w10, #0
	cset	w10, ne
	b	LBB19_37
LBB19_46:                               ;   in Loop: Header=BB19_14 Depth=1
	cbz	w21, LBB19_57
; %bb.47:                               ;   in Loop: Header=BB19_14 Depth=1
	cmp	w21, #1
	b.eq	LBB19_52
; %bb.48:                               ;   in Loop: Header=BB19_14 Depth=1
	cmp	w21, #2
	b.ne	LBB19_12
; %bb.49:                               ;   in Loop: Header=BB19_14 Depth=1
	cbnz	w8, LBB19_58
; %bb.50:                               ;   in Loop: Header=BB19_14 Depth=1
	ldr	x8, [x23, #1056]
	cbz	x8, LBB19_59
; %bb.51:                               ;   in Loop: Header=BB19_14 Depth=1
	ldr	x21, [x8, #976]
	b	LBB19_60
LBB19_52:                               ;   in Loop: Header=BB19_14 Depth=1
	str	xzr, [sp, #64]
	str	xzr, [sp]
	ldr	x1, [sp, #8]
	add	x2, sp, #64
	mov	x0, x19
	bl	_neoclr_gc_host_root_read_v1
	cbnz	w0, LBB19_76
; %bb.53:                               ;   in Loop: Header=BB19_14 Depth=1
	ldr	x1, [sp, #64]
	mov	x2, sp
	mov	x0, x19
	bl	_neoclr_gc_host_root_create_v1
	cbnz	w0, LBB19_76
; %bb.54:                               ;   in Loop: Header=BB19_14 Depth=1
	ldr	x1, [sp, #8]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	bl	_neoclr_scheduler_complete_v1
	cbnz	w0, LBB19_81
; %bb.55:                               ;   in Loop: Header=BB19_14 Depth=1
	ldr	x0, [sp]
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	bl	_allocate_fiber
	cbz	x0, LBB19_78
; %bb.56:                               ;   in Loop: Header=BB19_14 Depth=1
	bl	_resume
	mov	w22, #1                         ; =0x1
	b	LBB19_13
LBB19_57:                               ;   in Loop: Header=BB19_14 Depth=1
	cbz	w8, LBB19_77
LBB19_58:                               ;   in Loop: Header=BB19_14 Depth=1
	mov	w0, #0                          ; =0x0
	b	LBB19_13
LBB19_59:                               ;   in Loop: Header=BB19_14 Depth=1
	mov	x21, #0                         ; =0x0
LBB19_60:                               ;   in Loop: Header=BB19_14 Depth=1
	ldr	w8, [x20, #56]
	cbz	w8, LBB19_66
; %bb.61:                               ;   in Loop: Header=BB19_14 Depth=1
	ldr	x8, [x20, #32]
	add	x27, x8, #1
	str	x27, [x20, #32]
	ldp	x8, x9, [x20, #8]
	cmp	x8, x9
	b.ne	LBB19_63
LBB19_62:                               ;   in Loop: Header=BB19_14 Depth=1
	ldr	x8, [x20, #40]
	add	x8, x8, #1
	str	x8, [x20, #40]
	b	LBB19_66
LBB19_63:                               ;   in Loop: Header=BB19_14 Depth=1
	add	x1, sp, #64
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB19_62
; %bb.64:                               ;   in Loop: Header=BB19_14 Depth=1
	ldp	x8, x9, [sp, #64]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x8, x8, x10, x9
	cbz	x8, LBB19_62
; %bb.65:                               ;   in Loop: Header=BB19_14 Depth=1
	ldp	x9, x10, [x20]
	add	x11, x10, #1
	str	x11, [x20, #8]
	mov	w11, #40                        ; =0x28
	madd	x9, x10, x11, x9
	stp	x8, x27, [x9]
	stp	x21, xzr, [x9, #16]
	str	d9, [x9, #32]
LBB19_66:                               ;   in Loop: Header=BB19_14 Depth=1
	mov	x0, x19
	bl	_neoclr_scheduler_wait_v1
	ldr	x8, [x23, #1056]
	cbz	x8, LBB19_68
; %bb.67:                               ;   in Loop: Header=BB19_14 Depth=1
	ldr	x21, [x8, #976]
	b	LBB19_69
LBB19_68:                               ;   in Loop: Header=BB19_14 Depth=1
	mov	x21, #0                         ; =0x0
LBB19_69:                               ;   in Loop: Header=BB19_14 Depth=1
	ldr	w8, [x20, #56]
	cbz	w8, LBB19_58
; %bb.70:                               ;   in Loop: Header=BB19_14 Depth=1
	ldr	x8, [x20, #32]
	add	x27, x8, #1
	str	x27, [x20, #32]
	ldp	x8, x9, [x20, #8]
	cmp	x8, x9
	b.ne	LBB19_72
LBB19_71:                               ;   in Loop: Header=BB19_14 Depth=1
	mov	w0, #0                          ; =0x0
	ldr	x8, [x20, #40]
	add	x8, x8, #1
	str	x8, [x20, #40]
	b	LBB19_13
LBB19_72:                               ;   in Loop: Header=BB19_14 Depth=1
	add	x1, sp, #64
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB19_71
; %bb.73:                               ;   in Loop: Header=BB19_14 Depth=1
	ldp	x8, x9, [sp, #64]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x8, x8, x10, x9
	cbz	x8, LBB19_71
; %bb.74:                               ;   in Loop: Header=BB19_14 Depth=1
	mov	w0, #0                          ; =0x0
	ldp	x9, x10, [x20]
	add	x11, x10, #1
	str	x11, [x20, #8]
	mov	w11, #40                        ; =0x28
	madd	x9, x10, x11, x9
	stp	x8, x27, [x9]
	stp	x21, xzr, [x9, #16]
	str	d8, [x9, #32]
	b	LBB19_13
LBB19_75:
	mov	x0, x22
	b	LBB19_80
LBB19_76:
	mov	w0, #3                          ; =0x3
	b	LBB19_80
LBB19_77:
	mov	w8, #3                          ; =0x3
	cmp	w10, #0
	csel	w0, wzr, w8, eq
	b	LBB19_80
LBB19_78:
	ldr	x1, [sp]
	mov	x0, x19
	bl	_neoclr_gc_host_root_release_v1
LBB19_79:
	mov	w0, #5                          ; =0x5
LBB19_80:
	mov	x19, x0
	add	x0, sp, #16
	bl	_neoclr_roots_resume_v1
	mov	x8, x19
	str	wzr, [x23, #1288]
	b	LBB19_3
LBB19_81:
	bl	_abort
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh56, Lloh57
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function resume
lCPI20_0:
	.long	3                               ; 0x3
	.long	0                               ; 0x0
lCPI20_1:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_resume:                                ; @resume
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	sub	sp, sp, #960
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	w8, [x0, #912]
	cbz	w8, LBB20_3
LBB20_1:
	mov	w0, #3                          ; =0x3
LBB20_2:
	add	sp, sp, #960
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB20_3:
	mov	x19, x0
	ldr	x8, [x0, #984]
Lloh62:
	adrp	x20, _state@TLVPPAGE
Lloh63:
	ldr	x20, [x20, _state@TLVPPAGEOFF]
	cbz	x8, LBB20_9
; %bb.4:
	str	xzr, [sp, #48]
	ldr	x8, [x20]
	mov	x0, x20
	blr	x8
	mov	x21, x0
	ldr	x0, [x0]
	ldr	x1, [x19, #952]
	add	x2, sp, #48
	bl	_neoclr_gc_host_root_read_v1
	cbnz	w0, LBB20_1
; %bb.5:
	ldr	x0, [x21]
	ldr	x1, [x19, #984]
	add	x22, x19, #992
	mov	x2, x22
	bl	_neoclr_gc_host_root_create_v1
	cbnz	w0, LBB20_2
; %bb.6:
	ldr	x0, [x21]
	ldr	x1, [sp, #48]
	add	x2, x19, #1000
	bl	_neoclr_gc_host_root_create_v1
	cbz	w0, LBB20_9
; %bb.7:
	mov	x19, x0
	ldr	x0, [x21]
	ldr	x1, [x22]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB20_52
; %bb.8:
	str	xzr, [x22]
	mov	x0, x19
	b	LBB20_2
LBB20_9:
	ldr	x1, [x19, #1008]
	ldr	x8, [x20]
	mov	x0, x20
	blr	x8
	mov	x21, x0
	cbz	x1, LBB20_12
; %bb.10:
	ldr	x0, [x21]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB20_52
; %bb.11:
	str	xzr, [x19, #1008]
LBB20_12:
	add	x22, x19, #880
	add	x24, x21, #34, lsl #12          ; =139264
Lloh64:
	adrp	x0, _statistics@TLVPPAGE
Lloh65:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	ldr	x8, [x0, #8]
	add	x8, x8, #1
	str	x8, [x0, #8]
	str	xzr, [sp, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	ldr	x25, [x24, #1056]
	mov	x0, sp
	bl	_neoclr_roots_park_v1
	ldr	w8, [x19, #1028]
	cbz	w8, LBB20_14
; %bb.13:
	mov	x0, x22
	bl	_neoclr_roots_resume_v1
	str	wzr, [x19, #1028]
LBB20_14:
	str	x19, [x24, #1056]
	add	x8, sp, #48
	str	x8, [x19, #1056]
	ldr	x0, [x19, #936]
	ldr	x1, [x19, #944]
	bl	_neoclr_native_stack_bounds_v1
Lloh66:
	adrp	x0, _async_trace@TLVPPAGE
Lloh67:
	ldr	x0, [x0, _async_trace@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x23, x0
	ldr	w8, [x0, #56]
	cbz	w8, LBB20_25
; %bb.15:
	ldr	x26, [x19, #976]
	cbnz	x26, LBB20_17
; %bb.16:
	ldr	x8, [x23, #48]
	add	x26, x8, #1
	str	x26, [x23, #48]
	str	x26, [x19, #976]
LBB20_17:
	cbz	x25, LBB20_19
; %bb.18:
	ldr	x27, [x25, #976]
	b	LBB20_20
LBB20_19:
	mov	x27, #0                         ; =0x0
LBB20_20:
	ldr	x8, [x23, #32]
	add	x28, x8, #1
	str	x28, [x23, #32]
	ldp	x8, x9, [x23, #8]
	cmp	x8, x9
	b.ne	LBB20_22
LBB20_21:
	ldr	x8, [x23, #40]
	add	x8, x8, #1
	str	x8, [x23, #40]
	b	LBB20_25
LBB20_22:
	sub	x1, x29, #104
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB20_21
; %bb.23:
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [x29, #-104]
	madd	x8, x9, x8, x10
	cbz	x8, LBB20_21
; %bb.24:
	ldp	x9, x10, [x23]
	add	x11, x10, #1
	str	x11, [x23, #8]
	mov	w11, #40                        ; =0x28
	madd	x9, x10, x11, x9
	stp	x8, x28, [x9]
	stp	x26, x27, [x9, #16]
Lloh68:
	adrp	x8, lCPI20_0@PAGE
Lloh69:
	ldr	d0, [x8, lCPI20_0@PAGEOFF]
	str	d0, [x9, #32]
LBB20_25:
	add	x0, sp, #48
	mov	x1, x19
	bl	_swapcontext
	cbnz	w0, LBB20_52
; %bb.26:
	cbz	x25, LBB20_28
; %bb.27:
	ldr	x26, [x25, #976]
	ldr	w8, [x23, #56]
	cbnz	w8, LBB20_29
	b	LBB20_31
LBB20_28:
	mov	x26, #0                         ; =0x0
	ldr	w8, [x23, #56]
	cbz	w8, LBB20_31
LBB20_29:
	ldr	x27, [x19, #976]
	ldr	x8, [x23, #32]
	add	x28, x8, #1
	str	x28, [x23, #32]
	ldp	x8, x9, [x23, #8]
	cmp	x8, x9
	b.ne	LBB20_33
LBB20_30:
	ldr	x8, [x23, #40]
	add	x8, x8, #1
	str	x8, [x23, #40]
LBB20_31:
	str	x25, [x24, #1056]
	cbz	x25, LBB20_36
LBB20_32:
	ldr	x0, [x25, #936]
	ldr	x1, [x25, #944]
	b	LBB20_37
LBB20_33:
	sub	x1, x29, #104
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB20_30
; %bb.34:
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [x29, #-104]
	madd	x8, x9, x8, x10
	cbz	x8, LBB20_30
; %bb.35:
	ldp	x9, x10, [x23]
	add	x11, x10, #1
	str	x11, [x23, #8]
	mov	w11, #40                        ; =0x28
	madd	x9, x10, x11, x9
	stp	x8, x28, [x9]
	stp	x27, x26, [x9, #16]
Lloh70:
	adrp	x8, lCPI20_1@PAGE
Lloh71:
	ldr	d0, [x8, lCPI20_1@PAGEOFF]
	str	d0, [x9, #32]
	str	x25, [x24, #1056]
	cbnz	x25, LBB20_32
LBB20_36:
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
LBB20_37:
	bl	_neoclr_native_stack_bounds_v1
	mov	x0, sp
	bl	_neoclr_roots_resume_v1
	ldr	w0, [x19, #1020]
	ldr	w8, [x19, #1016]
	cbz	w8, LBB20_2
; %bb.38:
	add	x25, x19, #984
	ldr	x8, [x25]
	cbz	x8, LBB20_40
; %bb.39:
	ldr	w8, [x24, #1284]
	sub	w8, w8, #1
	str	w8, [x24, #1284]
LBB20_40:
	mov	x23, x0
	ldr	w8, [x19, #1032]
	cbz	w8, LBB20_46
; %bb.41:
	ldr	x9, [x19, #960]
	add	x8, x21, #24
	b	LBB20_43
LBB20_42:                               ;   in Loop: Header=BB20_43 Depth=1
	add	x8, x8, #24
LBB20_43:                               ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB20_42
; %bb.44:                               ;   in Loop: Header=BB20_43 Depth=1
	ldr	x10, [x8]
	cmp	x10, x9
	b.ne	LBB20_42
; %bb.45:
	stp	xzr, xzr, [x8]
	str	xzr, [x8, #16]
LBB20_46:
	mov	x0, x22
	bl	_neoclr_roots_discard_v1
	cbnz	w23, LBB20_50
; %bb.47:
	ldr	x8, [x21]
	ldr	w8, [x8]
	cbnz	w8, LBB20_50
; %bb.48:
	ldr	w8, [x24, #1280]
	cmp	w8, #7
	b.hi	LBB20_50
; %bb.49:
	mov	x0, x23
	str	xzr, [x22, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x22]
	add	x8, x19, #952
	str	xzr, [x19, #1056]
	str	xzr, [x19, #976]
	str	xzr, [x19, #968]
	str	q0, [x8]
	stp	q0, q0, [x25]
	str	q0, [x25, #32]
	str	wzr, [x25, #48]
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #1036]
	ldr	w8, [x24, #1280]
	add	w8, w8, #1
	str	w8, [x24, #1280]
	b	LBB20_2
LBB20_50:
	ldr	x0, [x19, #920]
	ldr	x21, [x19, #928]
	mov	x1, x21
	bl	_munmap
	cbnz	w0, LBB20_52
; %bb.51:
	ldp	x8, x9, [x20, #24]
	add	x8, x8, #1
	sub	x9, x9, x21
	stp	x8, x9, [x20, #24]
	mov	x0, x19
	mov	w1, #1072                       ; =0x430
	bl	_bzero
	mov	x0, x23
	b	LBB20_2
LBB20_52:
	bl	_abort
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpLdr	Lloh70, Lloh71
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function allocate_fiber
_allocate_fiber:                        ; @allocate_fiber
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
Lloh72:
	adrp	x0, _state@TLVPPAGE
Lloh73:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	add	x20, x0, #3104
	mov	x8, x0
	mov	w10, #128                       ; =0x80
	mov	x0, x10
	mov	x9, x0
LBB21_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	w10, [x20, #1036]
	cbnz	w10, LBB21_6
; %bb.2:                                ;   in Loop: Header=BB21_1 Depth=1
	add	x20, x20, #1072
	subs	x9, x9, #1
	b.ne	LBB21_1
; %bb.3:
	mov	w9, #128                        ; =0x80
                                        ; kill: def $x9 killed $w9
	mov	x24, x8
LBB21_4:                                ; =>This Inner Loop Header: Depth=1
	mov	x8, x9
	ldr	x9, [x24, #4024]
	cbz	x9, LBB21_9
; %bb.5:                                ;   in Loop: Header=BB21_4 Depth=1
	add	x24, x24, #1072
	subs	x9, x8, #1
	b.ne	LBB21_4
	b	LBB21_16
LBB21_6:
	mov	w0, #0                          ; =0x0
	str	wzr, [x20, #1036]
	mov	w9, #9472                       ; =0x2500
	movk	w9, #2, lsl #16
                                        ; kill: def $x9 killed $w9
	ldr	w10, [x8, x9]
	sub	w10, w10, #1
	str	w10, [x8, x9]
	str	x19, [x20, #952]
	str	x1, [x20, #960]
	str	w2, [x20, #1024]
	mov	x1, #0                          ; =0x0
	add	x2, x20, #4
	bl	_sigprocmask
	cbnz	w0, LBB21_21
; %bb.7:
	add	x0, x20, #1040
	bl	_fegetenv
	cbnz	w0, LBB21_21
; %bb.8:
Lloh74:
	adrp	x0, _statistics@TLVPPAGE
Lloh75:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	add	x8, x8, #1
	str	x8, [x0]
	b	LBB21_17
LBB21_9:
	mov	x26, x1
	mov	x25, x2
	mov	w0, #29                         ; =0x1d
	bl	_sysconf
	cmp	x0, #1
	b.lt	LBB21_16
; %bb.10:
	mov	x21, x0
	lsl	x8, x0, #1
	add	x20, x8, #256, lsl #12          ; =1048576
	mov	w2, #0                          ; =0x0
	mov	x22, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	mov	x1, x20
	mov	w3, #4098                       ; =0x1002
	mov	w4, #-1                         ; =0xffffffff
	mov	x5, #0                          ; =0x0
	bl	_mmap
	cmn	x0, #1
	b.eq	LBB21_18
; %bb.11:
	mov	x8, x0
Lloh76:
	adrp	x0, _statistics@TLVPPAGE
Lloh77:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0, #16]
	add	x9, x9, #1
	str	x9, [x0, #16]
	ldp	x9, x10, [x0, #32]
	add	x9, x9, x20
	cmp	x9, x10
	str	x9, [x0, #32]
	mov	x27, x0
	b.ls	LBB21_13
; %bb.12:
	str	x9, [x27, #40]
LBB21_13:
	mov	x22, x20
	mov	x23, x8
	add	x21, x8, x21
	mov	w8, #1048576                    ; =0x100000
	mov	x1, x8
	mov	x0, x21
	mov	w2, #3                          ; =0x3
	bl	_mprotect
	cbz	w0, LBB21_19
; %bb.14:
	mov	x0, x23
	mov	x1, x22
	bl	_munmap
	cbnz	w0, LBB21_21
; %bb.15:
	ldp	x8, x9, [x27, #24]
	add	x8, x8, #1
	sub	x9, x9, x20
	stp	x8, x9, [x27, #24]
LBB21_16:
	mov	x20, #0                         ; =0x0
LBB21_17:
	mov	x0, x20
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB21_18:
	mov	x20, x22
	b	LBB21_17
LBB21_19:
	add	x20, x24, #3104
	mov	w8, #1072                       ; =0x430
	mov	x1, x8
	mov	x0, x20
	bl	_bzero
	str	x23, [x24, #4024]
	str	x22, [x24, #4032]
	str	x21, [x24, #4040]
	add	x8, x21, #256, lsl #12          ; =1048576
	str	x8, [x24, #4048]
	ldr	x8, [x27]
	add	x8, x8, #1
	str	x8, [x27]
	str	x19, [x24, #4056]
	str	x26, [x24, #4064]
	str	w25, [x24, #4128]
	mov	x0, x20
	bl	_getcontext
	cbnz	w0, LBB21_21
; %bb.20:
	ldr	x9, [x24, #4040]
	str	x9, [x24, #3112]
	mov	w9, #1048576                    ; =0x100000
                                        ; kill: def $x9 killed $w9
	str	x9, [x24, #3120]
	str	xzr, [x24, #3136]
	mov	w2, #0                          ; =0x0
Lloh78:
	adrp	x1, _body@PAGE
Lloh79:
	add	x1, x1, _body@PAGEOFF
	mov	x0, x20
	bl	_makecontext
	mov	w8, #4144                       ; =0x1030
                                        ; kill: def $x8 killed $w8
	add	x0, x24, x8
	bl	_fegetenv
	cbz	w0, LBB21_17
LBB21_21:
	bl	_abort
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpAdd	Lloh78, Lloh79
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_runtime_async_shutdown_v1
lCPI22_0:
	.long	7                               ; 0x7
	.long	2                               ; 0x2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_runtime_async_shutdown_v1
	.p2align	2
_neoclr_runtime_async_shutdown_v1:      ; @neoclr_runtime_async_shutdown_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #144
	stp	d9, d8, [sp, #32]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	mov	x19, x0
Lloh80:
	adrp	x0, _state@TLVPPAGE
Lloh81:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB22_30
; %bb.1:
	cmp	x8, x19
	b.ne	LBB22_5
; %bb.2:
	mov	x20, x0
	add	x8, x0, #34, lsl #12            ; =139264
	ldr	x9, [x8, #1056]
	cbnz	x9, LBB22_5
; %bb.3:
	ldr	w8, [x8, #1288]
	cbnz	w8, LBB22_5
; %bb.4:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB22_6
LBB22_5:
	mov	w0, #3                          ; =0x3
	b	LBB22_31
LBB22_6:
	bl	_reap_expired
Lloh82:
	adrp	x0, _async_trace@TLVPPAGE
Lloh83:
	ldr	x0, [x0, _async_trace@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x21, x0
Lloh84:
	adrp	x0, _statistics@TLVPPAGE
Lloh85:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x22, x0
	mov	x25, #0                         ; =0x0
	mov	x26, #0                         ; =0x0
	mov	w24, #0                         ; =0x0
Lloh86:
	adrp	x8, lCPI22_0@PAGE
Lloh87:
	ldr	d8, [x8, lCPI22_0@PAGEOFF]
	b	LBB22_8
LBB22_7:                                ;   in Loop: Header=BB22_8 Depth=1
	orr	w24, w24, w23
	add	x26, x26, #1072
	add	x25, x25, #24
	cmp	x25, #3072
	b.eq	LBB22_27
LBB22_8:                                ; =>This Inner Loop Header: Depth=1
	add	x23, x20, x26
	ldr	x8, [x23, #4024]
	cbz	x8, LBB22_24
; %bb.9:                                ;   in Loop: Header=BB22_8 Depth=1
	ldr	w8, [x23, #4140]
	cmp	w8, #0
	cset	w28, eq
	cbnz	w8, LBB22_16
; %bb.10:                               ;   in Loop: Header=BB22_8 Depth=1
	ldr	w8, [x21, #56]
	cbz	w8, LBB22_16
; %bb.11:                               ;   in Loop: Header=BB22_8 Depth=1
	add	x8, x20, x26
	ldr	x10, [x8, #4080]
	ldr	x11, [x8, #4072]
	ldr	x8, [x21, #32]
	add	x27, x8, #1
	str	x27, [x21, #32]
	ldp	x8, x9, [x21, #8]
	cmp	x8, x9
	b.ne	LBB22_13
LBB22_12:                               ;   in Loop: Header=BB22_8 Depth=1
	ldr	x8, [x21, #40]
	add	x8, x8, #1
	str	x8, [x21, #40]
	b	LBB22_16
LBB22_13:                               ;   in Loop: Header=BB22_8 Depth=1
	stp	x11, x10, [sp]                  ; 16-byte Folded Spill
	add	x1, sp, #16
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB22_12
; %bb.14:                               ;   in Loop: Header=BB22_8 Depth=1
	ldp	x8, x9, [sp, #16]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x8, x8, x10, x9
	cbz	x8, LBB22_12
; %bb.15:                               ;   in Loop: Header=BB22_8 Depth=1
	ldp	x9, x10, [x21]
	add	x11, x10, #1
	str	x11, [x21, #8]
	mov	w11, #40                        ; =0x28
	madd	x9, x10, x11, x9
	stp	x8, x27, [x9]
	ldp	x8, x10, [sp]                   ; 16-byte Folded Reload
	stp	x10, x8, [x9, #16]
	str	d8, [x9, #32]
LBB22_16:                               ;   in Loop: Header=BB22_8 Depth=1
	add	x27, x20, x26
	ldr	w8, [x27, #4132]
	cbz	w8, LBB22_18
; %bb.17:                               ;   in Loop: Header=BB22_8 Depth=1
	add	x0, x27, #3984
	bl	_neoclr_roots_discard_v1
LBB22_18:                               ;   in Loop: Header=BB22_8 Depth=1
	ldr	x1, [x27, #4056]
	cbz	x1, LBB22_20
; %bb.19:                               ;   in Loop: Header=BB22_8 Depth=1
	mov	x0, x19
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB22_26
LBB22_20:                               ;   in Loop: Header=BB22_8 Depth=1
	add	x27, x20, x26
	ldr	x1, [x27, #4112]
	cbz	x1, LBB22_22
; %bb.21:                               ;   in Loop: Header=BB22_8 Depth=1
	mov	x0, x19
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB22_26
LBB22_22:                               ;   in Loop: Header=BB22_8 Depth=1
	ldr	x0, [x23, #4024]
	ldr	x23, [x27, #4032]
	mov	x1, x23
	bl	_munmap
	cbnz	w0, LBB22_26
; %bb.23:                               ;   in Loop: Header=BB22_8 Depth=1
	orr	w24, w24, w28
	ldp	x8, x9, [x22, #24]
	add	x8, x8, #1
	sub	x9, x9, x23
	stp	x8, x9, [x22, #24]
LBB22_24:                               ;   in Loop: Header=BB22_8 Depth=1
	add	x8, x20, x25
	ldr	x9, [x8, #24]
	cmp	x9, #0
	cset	w23, ne
	ldr	x1, [x8, #40]
	cbz	x1, LBB22_7
; %bb.25:                               ;   in Loop: Header=BB22_8 Depth=1
	mov	x0, x19
	bl	_neoclr_gc_host_root_release_v1
	cbz	w0, LBB22_7
LBB22_26:
	bl	_abort
LBB22_27:
	ldr	x8, [x22, #32]
	cbnz	x8, LBB22_26
; %bb.28:
	mov	x0, x20
	mov	w1, #9488                       ; =0x2510
	movk	w1, #2, lsl #16
	bl	_bzero
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	bl	_neoclr_native_stack_bounds_v1
	cbz	w24, LBB22_30
; %bb.29:
	ldr	w8, [x19]
	mov	w9, #3                          ; =0x3
	cmp	w8, #0
	csel	w0, w9, wzr, eq
	b	LBB22_31
LBB22_30:
	mov	w0, #0                          ; =0x0
LBB22_31:
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpLdr	Lloh82, Lloh83
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function unmap_stack
_unmap_stack:                           ; @unmap_stack
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	bl	_munmap
	cbnz	w0, LBB23_2
; %bb.1:
Lloh88:
	adrp	x0, _statistics@TLVPPAGE
Lloh89:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldp	x8, x9, [x0, #24]
	add	x8, x8, #1
	sub	x9, x9, x19
	stp	x8, x9, [x0, #24]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB23_2:
	bl	_abort
	.loh AdrpLdr	Lloh88, Lloh89
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function body
lCPI24_0:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_body:                                  ; @body
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
Lloh90:
	adrp	x0, _state@TLVPPAGE
Lloh91:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x19, x0
	mov	w21, #9248                      ; =0x2420
	movk	w21, #2, lsl #16
	ldr	x22, [x0, x21]
	add	x0, x22, #1040
	bl	_fesetenv
	cbnz	w0, LBB24_21
; %bb.1:
Lloh92:
	adrp	x0, _async_trace@TLVPPAGE
Lloh93:
	ldr	x0, [x0, _async_trace@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	add	x23, x19, #32
	mov	w24, #1000                      ; =0x3e8
	mov	w25, #952                       ; =0x3b8
	mov	w26, #1                         ; =0x1
Lloh94:
	adrp	x8, lCPI24_0@PAGE
Lloh95:
	ldr	d8, [x8, lCPI24_0@PAGEOFF]
	b	LBB24_5
LBB24_2:                                ;   in Loop: Header=BB24_5 Depth=1
	ldr	x8, [x20, #40]
	add	x8, x8, #1
	str	x8, [x20, #40]
LBB24_3:                                ;   in Loop: Header=BB24_5 Depth=1
	mov	w24, #1000                      ; =0x3e8
LBB24_4:                                ;   in Loop: Header=BB24_5 Depth=1
	str	w26, [x22, #1016]
	bl	_yield
	ldr	x22, [x19, x21]
	add	x0, x22, #1040
	bl	_fesetenv
	cbnz	w0, LBB24_21
LBB24_5:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB24_13 Depth 2
	ldr	w8, [x22, #1024]
	cbz	w8, LBB24_7
; %bb.6:                                ;   in Loop: Header=BB24_5 Depth=1
	ldr	x8, [x19, #16]
	ldr	x0, [x19]
	blr	x8
	b	LBB24_8
LBB24_7:                                ;   in Loop: Header=BB24_5 Depth=1
	ldr	x8, [x22, #984]
	cmp	x8, #0
	csel	x8, x25, x24, eq
	ldr	x0, [x22, x8]
	ldp	x1, x8, [x19]
	blr	x8
LBB24_8:                                ;   in Loop: Header=BB24_5 Depth=1
	str	w0, [x22, #1020]
	bl	_neoclr_root_probe_head_v1
	cbnz	x0, LBB24_21
; %bb.9:                                ;   in Loop: Header=BB24_5 Depth=1
	ldr	x1, [x22, #952]
	cbz	x1, LBB24_11
; %bb.10:                               ;   in Loop: Header=BB24_5 Depth=1
	ldr	x0, [x19]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB24_21
LBB24_11:                               ;   in Loop: Header=BB24_5 Depth=1
	str	xzr, [x22, #952]
	ldr	x28, [x22, #960]
	mov	x8, x23
	mov	w9, #128                        ; =0x80
	b	LBB24_13
LBB24_12:                               ;   in Loop: Header=BB24_13 Depth=2
	add	x8, x8, #24
	subs	x9, x9, #1
	b.eq	LBB24_4
LBB24_13:                               ;   Parent Loop BB24_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cbz	x28, LBB24_12
; %bb.14:                               ;   in Loop: Header=BB24_13 Depth=2
	ldur	x10, [x8, #-8]
	cmp	x10, x28
	b.ne	LBB24_12
; %bb.15:                               ;   in Loop: Header=BB24_5 Depth=1
	ldr	w9, [x22, #1020]
	cbnz	w9, LBB24_4
; %bb.16:                               ;   in Loop: Header=BB24_5 Depth=1
	str	w26, [x8]
	ldr	w8, [x20, #56]
	cbz	w8, LBB24_4
; %bb.17:                               ;   in Loop: Header=BB24_5 Depth=1
	ldr	x27, [x22, #976]
	ldr	x8, [x20, #32]
	add	x24, x8, #1
	str	x24, [x20, #32]
	ldp	x8, x9, [x20, #8]
	cmp	x8, x9
	b.eq	LBB24_2
; %bb.18:                               ;   in Loop: Header=BB24_5 Depth=1
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB24_2
; %bb.19:                               ;   in Loop: Header=BB24_5 Depth=1
	ldp	x8, x9, [sp]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x8, x8, x10, x9
	cbz	x8, LBB24_2
; %bb.20:                               ;   in Loop: Header=BB24_5 Depth=1
	ldp	x9, x10, [x20]
	add	x11, x10, #1
	str	x11, [x20, #8]
	mov	w11, #40                        ; =0x28
	madd	x9, x10, x11, x9
	stp	x8, x24, [x9]
	stp	x27, x28, [x9, #16]
	str	d8, [x9, #32]
	b	LBB24_3
LBB24_21:
	bl	_abort
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpLdr	Lloh92, Lloh93
	.cfi_endproc
                                        ; -- End function
.tbss _statistics$tlv$init, 48, 3       ; @statistics

	.section	__DATA,__thread_vars,thread_local_variables
_statistics:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_statistics$tlv$init

.tbss _state$tlv$init, 140560, 4        ; @state

_state:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_state$tlv$init

.tbss _async_trace$tlv$init, 64, 3      ; @async_trace

_async_trace:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_async_trace$tlv$init

.tbss _next_id$tlv$init, 8, 3           ; @next_id

_next_id:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_next_id$tlv$init

.subsections_via_symbols
