	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 26, 2	sdk_version 26, 2
	.globl	_neoclr_runtime_async_statistics_v1 ; -- Begin function neoclr_runtime_async_statistics_v1
	.p2align	2
_neoclr_runtime_async_statistics_v1:    ; @neoclr_runtime_async_statistics_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh0:
	adrp	x0, _statistics@TLVPPAGE
Lloh1:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldp	q0, q1, [x0]
	stp	q0, q1, [x8]
	ldr	q0, [x0, #32]
	str	q0, [x8, #32]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_reap_v1   ; -- Begin function neoclr_runtime_async_reap_v1
	.p2align	2
_neoclr_runtime_async_reap_v1:          ; @neoclr_runtime_async_reap_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB1_6
; %bb.1:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh2:
	adrp	x0, _state@TLVPPAGE
Lloh3:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	x9, x8
	b.ne	LBB1_5
; %bb.2:
	add	x8, x0, #33, lsl #12            ; =135168
	ldr	x9, [x8, #3104]
	cbnz	x9, LBB1_5
; %bb.3:
	ldr	w8, [x8, #3336]
	cbnz	w8, LBB1_5
; %bb.4:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB1_7
LBB1_5:
	mov	w0, #3                          ; =0x3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB1_6:
	mov	w0, #3                          ; =0x3
	ret
LBB1_7:
	bl	_reap_expired
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function reap_expired
_reap_expired:                          ; @reap_expired
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
Lloh4:
	adrp	x0, _state@TLVPPAGE
Lloh5:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	add	x23, x0, #33, lsl #12           ; =135168
	ldr	w8, [x23, #3332]
	cbz	w8, LBB2_24
; %bb.1:
	mov	x19, x0
	add	x24, x0, #3104
Lloh6:
	adrp	x0, _statistics@TLVPPAGE
Lloh7:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	mov	x25, #0                         ; =0x0
	mov	w26, #1056                      ; =0x420
	b	LBB2_3
LBB2_2:                                 ;   in Loop: Header=BB2_3 Depth=1
	add	x25, x25, #1
	cmp	x25, #128
	b.eq	LBB2_17
LBB2_3:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_12 Depth 2
	madd	x21, x25, x26, x24
	ldr	x8, [x21, #920]
	cbz	x8, LBB2_2
; %bb.4:                                ;   in Loop: Header=BB2_3 Depth=1
	ldr	w8, [x21, #1020]
	cbz	w8, LBB2_2
; %bb.5:                                ;   in Loop: Header=BB2_3 Depth=1
	ldr	w8, [x21, #912]
	cbz	w8, LBB2_2
; %bb.6:                                ;   in Loop: Header=BB2_3 Depth=1
	ldr	x8, [x21, #976]
	ldr	x9, [x23, #3104]
	cmp	x8, #0
	ccmp	x21, x9, #4, ne
	b.eq	LBB2_25
; %bb.7:                                ;   in Loop: Header=BB2_3 Depth=1
	ldr	x8, [x21, #984]
	cbnz	x8, LBB2_25
; %bb.8:                                ;   in Loop: Header=BB2_3 Depth=1
	ldr	x8, [x21, #992]
	cbnz	x8, LBB2_25
; %bb.9:                                ;   in Loop: Header=BB2_3 Depth=1
	add	x0, x21, #880
	bl	_neoclr_roots_discard_v1
	ldr	x0, [x19]
	ldr	x1, [x21, #952]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB2_25
; %bb.10:                               ;   in Loop: Header=BB2_3 Depth=1
	ldr	x8, [x21, #960]
	mov	w9, #24                         ; =0x18
	b	LBB2_12
LBB2_11:                                ;   in Loop: Header=BB2_12 Depth=2
	add	x9, x9, #24
	cmp	x9, #3096
	b.eq	LBB2_15
LBB2_12:                                ;   Parent Loop BB2_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cbz	x8, LBB2_11
; %bb.13:                               ;   in Loop: Header=BB2_12 Depth=2
	ldr	x10, [x19, x9]
	cmp	x10, x8
	b.ne	LBB2_11
; %bb.14:                               ;   in Loop: Header=BB2_3 Depth=1
	add	x8, x19, x9
	stp	xzr, xzr, [x8]
	str	xzr, [x8, #16]
LBB2_15:                                ;   in Loop: Header=BB2_3 Depth=1
	ldr	x0, [x21, #920]
	ldr	x22, [x21, #928]
	mov	x1, x22
	bl	_munmap
	cbnz	w0, LBB2_25
; %bb.16:                               ;   in Loop: Header=BB2_3 Depth=1
	ldp	x8, x9, [x20, #24]
	add	x8, x8, #1
	sub	x9, x9, x22
	stp	x8, x9, [x20, #24]
	ldr	w8, [x23, #3332]
	sub	w8, w8, #1
	str	w8, [x23, #3332]
	mov	x0, x21
	mov	w1, #1056                       ; =0x420
	bl	_bzero
	b	LBB2_2
LBB2_17:
	mov	x20, #0                         ; =0x0
	b	LBB2_19
LBB2_18:                                ;   in Loop: Header=BB2_19 Depth=1
	add	x20, x20, #24
	cmp	x20, #3072
	b.eq	LBB2_24
LBB2_19:                                ; =>This Inner Loop Header: Depth=1
	add	x22, x19, x20
	mov	x21, x22
	ldr	x8, [x21, #24]!
	cbz	x8, LBB2_18
; %bb.20:                               ;   in Loop: Header=BB2_19 Depth=1
	ldr	x1, [x22, #40]
	cbz	x1, LBB2_18
; %bb.21:                               ;   in Loop: Header=BB2_19 Depth=1
	str	xzr, [sp, #8]
	ldr	x0, [x19]
	add	x2, sp, #8
	bl	_neoclr_gc_host_root_read_v1
	cbz	w0, LBB2_18
; %bb.22:                               ;   in Loop: Header=BB2_19 Depth=1
	ldr	x0, [x19]
	ldr	x1, [x22, #40]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB2_25
; %bb.23:                               ;   in Loop: Header=BB2_19 Depth=1
	stp	xzr, xzr, [x21]
	str	xzr, [x21, #16]
	ldr	w8, [x23, #3332]
	sub	w8, w8, #1
	str	w8, [x23, #3332]
	b	LBB2_18
LBB2_24:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB2_25:
	bl	_abort
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_create_v1 ; -- Begin function neoclr_runtime_async_create_v1
	.p2align	2
_neoclr_runtime_async_create_v1:        ; @neoclr_runtime_async_create_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB3_2
; %bb.1:
	ldr	w8, [x0]
	cbz	w8, LBB3_3
LBB3_2:
	mov	w0, #3                          ; =0x3
	ret
LBB3_3:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x11, x0
Lloh8:
	adrp	x0, _state@TLVPPAGE
Lloh9:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x9, x0
	ldr	x12, [x0]
	cbnz	x12, LBB3_5
; %bb.4:
	mov	x12, x11
	str	x11, [x9]
LBB3_5:
Lloh10:
	adrp	x0, _next_id@TLVPPAGE
Lloh11:
	ldr	x0, [x0, _next_id@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x1, LBB3_12
; %bb.6:
	ldr	x10, [x8]
	cmp	x12, x11
	mov	x11, #9223372036854775807       ; =0x7fffffffffffffff
	ccmp	x10, x11, #4, eq
	b.eq	LBB3_12
; %bb.7:
	add	x9, x9, #24
	mov	w11, #128                       ; =0x80
LBB3_8:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x9]
	cbz	x12, LBB3_11
; %bb.9:                                ;   in Loop: Header=BB3_8 Depth=1
	add	x9, x9, #24
	subs	x11, x11, #1
	b.ne	LBB3_8
; %bb.10:
	mov	w0, #5                          ; =0x5
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB3_11:
	mov	w0, #0                          ; =0x0
	add	x10, x10, #1
	str	x10, [x8]
	stp	xzr, xzr, [x9, #8]
	str	x10, [x9]
	str	x10, [x1]
LBB3_12:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_start_v1  ; -- Begin function neoclr_runtime_async_start_v1
	.p2align	2
_neoclr_runtime_async_start_v1:         ; @neoclr_runtime_async_start_v1
	.cfi_startproc
; %bb.0:
	mov	x4, x3
	mov	x3, x2
	mov	x2, x1
	mov	x1, x0
	mov	x0, #0                          ; =0x0
	mov	w5, #0                          ; =0x0
	b	_start
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function start
_start:                                 ; @start
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	cbz	x2, LBB5_2
; %bb.1:
	ldr	w8, [x2]
	cbz	w8, LBB5_4
LBB5_2:
	mov	w0, #3                          ; =0x3
LBB5_3:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB5_4:
	mov	x20, x0
Lloh12:
	adrp	x0, _state@TLVPPAGE
Lloh13:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ldr	x9, [x0]
	cbnz	x9, LBB5_6
; %bb.5:
	str	x2, [x8]
	mov	x9, x2
LBB5_6:
	mov	w0, #3                          ; =0x3
	cbz	x4, LBB5_3
; %bb.7:
	cbz	x3, LBB5_3
; %bb.8:
	cmp	x9, x2
	b.ne	LBB5_3
; %bb.9:
	ldr	x9, [x8, #8]
	cmp	x9, #0
	ccmp	x9, x4, #4, ne
	b.ne	LBB5_3
; %bb.10:
	mov	x24, x8
	str	x4, [x8, #8]
	str	xzr, [sp, #8]
Lloh14:
	adrp	x0, _next_id@TLVPPAGE
Lloh15:
	ldr	x0, [x0, _next_id@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	mov	x9, #9223372036854775807        ; =0x7fffffffffffffff
	cmp	x8, x9
	b.eq	LBB5_2
; %bb.11:
	add	x23, x24, #24
	mov	w11, #128                       ; =0x80
	mov	x9, x23
	mov	x10, x20
LBB5_12:                                ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x9]
	cbz	x12, LBB5_15
; %bb.13:                               ;   in Loop: Header=BB5_12 Depth=1
	add	x9, x9, #24
	subs	x11, x11, #1
	b.ne	LBB5_12
; %bb.14:
	mov	w0, #5                          ; =0x5
	b	LBB5_3
LBB5_15:
	mov	x26, x5
	mov	x25, x3
	add	x19, x8, #1
	str	x19, [x0]
	stp	xzr, xzr, [x9, #8]
	str	x19, [x9]
	cbz	x10, LBB5_17
; %bb.16:
	add	x3, sp, #8
	mov	x21, x2
	mov	x0, x2
	mov	x2, x1
	mov	x1, x20
	bl	_neoclr_gc_host_root_create_owned_v1
	b	LBB5_18
LBB5_17:
	mov	x0, x2
	add	x2, sp, #8
	mov	x21, x0
	bl	_neoclr_gc_host_root_create_v1
LBB5_18:
	cbnz	w0, LBB5_23
; %bb.19:
	ldr	x0, [sp, #8]
	mov	x1, x19
	mov	w2, #0                          ; =0x0
	bl	_allocate_fiber
	cbz	x0, LBB5_30
; %bb.20:
	mov	x22, x0
	str	x20, [x0, #976]
	str	w26, [x0, #1024]
	cbz	x20, LBB5_35
; %bb.21:
	mov	w8, #7428                       ; =0x1d04
	movk	w8, #2, lsl #16
	ldr	w10, [x24, x8]
	add	w10, w10, #1
	str	w10, [x24, x8]
	add	x8, x24, #36
	b	LBB5_27
LBB5_22:                                ;   in Loop: Header=BB5_23 Depth=1
	add	x23, x23, #24
LBB5_23:                                ; =>This Inner Loop Header: Depth=1
	cbz	x19, LBB5_22
; %bb.24:                               ;   in Loop: Header=BB5_23 Depth=1
	ldr	x8, [x23]
	cmp	x8, x19
	b.ne	LBB5_22
LBB5_25:
	str	xzr, [x23]
	b	LBB5_3
LBB5_26:                                ;   in Loop: Header=BB5_27 Depth=1
	add	x8, x8, #24
LBB5_27:                                ; =>This Inner Loop Header: Depth=1
	cbz	x19, LBB5_26
; %bb.28:                               ;   in Loop: Header=BB5_27 Depth=1
	ldur	x9, [x8, #-12]
	cmp	x9, x19
	b.ne	LBB5_26
; %bb.29:
	mov	w9, #1                          ; =0x1
	str	w9, [x8]
	b	LBB5_40
LBB5_30:
	ldr	x1, [sp, #8]
	mov	x0, x21
	bl	_neoclr_gc_host_root_release_v1
	b	LBB5_32
LBB5_31:                                ;   in Loop: Header=BB5_32 Depth=1
	add	x23, x23, #24
LBB5_32:                                ; =>This Inner Loop Header: Depth=1
	cbz	x19, LBB5_31
; %bb.33:                               ;   in Loop: Header=BB5_32 Depth=1
	ldr	x8, [x23]
	cmp	x8, x19
	b.ne	LBB5_31
; %bb.34:
	str	xzr, [x23]
	mov	w0, #5                          ; =0x5
	b	LBB5_3
LBB5_35:
	add	x8, x24, #36
	mov	x9, x25
	b	LBB5_37
LBB5_36:                                ;   in Loop: Header=BB5_37 Depth=1
	add	x8, x8, #24
LBB5_37:                                ; =>This Inner Loop Header: Depth=1
	cbz	x19, LBB5_36
; %bb.38:                               ;   in Loop: Header=BB5_37 Depth=1
	ldur	x10, [x8, #-12]
	cmp	x10, x19
	b.ne	LBB5_36
; %bb.39:
	mov	w10, #1                         ; =0x1
	str	w10, [x8]
	str	x19, [x9]
LBB5_40:
	mov	x0, x22
	bl	_resume
	cbz	w0, LBB5_43
; %bb.41:
	ldr	x8, [x22, #920]
	cbz	x8, LBB5_43
; %bb.42:
	ldr	w8, [x22, #1020]
	cbz	w8, LBB5_44
LBB5_43:
	str	x19, [x25]
	b	LBB5_3
LBB5_44:
	mov	x20, x0
	ldr	x1, [x22, #952]
	mov	x0, x21
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB5_49
; %bb.45:
	ldr	x0, [x22, #920]
	ldr	x1, [x22, #928]
	bl	_unmap_stack
	ldr	x8, [x22, #976]
	cbz	x8, LBB5_47
; %bb.46:
	mov	w8, #7428                       ; =0x1d04
	movk	w8, #2, lsl #16
	ldr	w9, [x24, x8]
	sub	w9, w9, #1
	str	w9, [x24, x8]
LBB5_47:
	mov	x0, x22
	mov	w1, #1056                       ; =0x420
	bl	_bzero
	ldr	x8, [x23]
	mov	x0, x20
	cmp	x8, x19
	b.eq	LBB5_25
LBB5_48:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x23, #24]!
	cmp	x8, x19
	b.ne	LBB5_48
	b	LBB5_25
LBB5_49:
	bl	_abort
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh14, Lloh15
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_start_owned_v1 ; -- Begin function neoclr_runtime_async_start_owned_v1
	.p2align	2
_neoclr_runtime_async_start_owned_v1:   ; @neoclr_runtime_async_start_owned_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB6_2
; %bb.1:
	mov	w5, #0                          ; =0x0
	b	_start
LBB6_2:
	mov	w0, #3                          ; =0x3
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_startmanaged_v1 ; -- Begin function neoclr_runtime_async_startmanaged_v1
	.p2align	2
_neoclr_runtime_async_startmanaged_v1:  ; @neoclr_runtime_async_startmanaged_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB7_2
; %bb.1:
	mov	w5, #1                          ; =0x1
	b	_start
LBB7_2:
	mov	w0, #3                          ; =0x3
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_currentowner_v1 ; -- Begin function neoclr_runtime_async_currentowner_v1
	.p2align	2
_neoclr_runtime_async_currentowner_v1:  ; @neoclr_runtime_async_currentowner_v1
	.cfi_startproc
; %bb.0:
	cbz	x0, LBB8_2
; %bb.1:
	ldr	w8, [x0]
	cbz	w8, LBB8_3
LBB8_2:
	mov	w0, #3                          ; =0x3
	ret
LBB8_3:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x9, x0
Lloh16:
	adrp	x0, _state@TLVPPAGE
Lloh17:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	ldr	x10, [x0]
	cbnz	x10, LBB8_5
; %bb.4:
	mov	x10, x9
	str	x9, [x8]
LBB8_5:
	mov	w0, #3                          ; =0x3
	cbz	x1, LBB8_10
; %bb.6:
	cmp	x10, x9
	b.ne	LBB8_10
; %bb.7:
	mov	w9, #7200                       ; =0x1c20
	movk	w9, #2, lsl #16
	ldr	x8, [x8, x9]
	cbz	x8, LBB8_9
; %bb.8:
	ldr	x8, [x8, #976]
LBB8_9:
	mov	w0, #0                          ; =0x0
	str	x8, [x1]
LBB8_10:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh16, Lloh17
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_createowned_v1 ; -- Begin function neoclr_runtime_async_createowned_v1
	.p2align	2
_neoclr_runtime_async_createowned_v1:   ; @neoclr_runtime_async_createowned_v1
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB9_2
; %bb.1:
	ldr	w8, [x1]
	cbz	w8, LBB9_3
LBB9_2:
	mov	w0, #3                          ; =0x3
	ret
LBB9_3:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x8, x0
Lloh18:
	adrp	x0, _state@TLVPPAGE
Lloh19:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x19, x0
	ldr	x9, [x0]
	cbnz	x9, LBB9_5
; %bb.4:
	str	x1, [x19]
	mov	x9, x1
LBB9_5:
	mov	w0, #3                          ; =0x3
	cbz	x2, LBB9_24
; %bb.6:
	cbz	x8, LBB9_24
; %bb.7:
	cmp	x9, x1
	b.ne	LBB9_24
; %bb.8:
Lloh20:
	adrp	x0, _next_id@TLVPPAGE
Lloh21:
	ldr	x0, [x0, _next_id@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	mov	x10, #9223372036854775807       ; =0x7fffffffffffffff
	cmp	x9, x10
	b.ne	LBB9_10
; %bb.9:
	mov	w0, #3                          ; =0x3
	b	LBB9_24
LBB9_10:
	mov	x22, x2
	add	x21, x19, #24
	mov	w11, #128                       ; =0x80
	mov	x10, x21
LBB9_11:                                ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x10]
	cbz	x12, LBB9_14
; %bb.12:                               ;   in Loop: Header=BB9_11 Depth=1
	add	x10, x10, #24
	subs	x11, x11, #1
	b.ne	LBB9_11
; %bb.13:
	mov	w0, #5                          ; =0x5
	b	LBB9_24
LBB9_14:
	add	x20, x9, #1
	str	x20, [x0]
	stp	xzr, xzr, [x10, #8]
	str	x20, [x10]
	add	x3, sp, #8
	mov	x0, x1
	mov	x1, x8
	mov	x2, x8
	bl	_neoclr_gc_host_root_create_owned_v1
	cbnz	w0, LBB9_17
; %bb.15:
	ldr	x8, [sp, #8]
	add	x9, x19, #40
	b	LBB9_21
LBB9_16:                                ;   in Loop: Header=BB9_17 Depth=1
	add	x21, x21, #24
LBB9_17:                                ; =>This Inner Loop Header: Depth=1
	cbz	x20, LBB9_16
; %bb.18:                               ;   in Loop: Header=BB9_17 Depth=1
	ldr	x8, [x21]
	cmp	x8, x20
	b.ne	LBB9_16
; %bb.19:
	stp	xzr, xzr, [x21]
	str	xzr, [x21, #16]
	b	LBB9_24
LBB9_20:                                ;   in Loop: Header=BB9_21 Depth=1
	add	x9, x9, #24
LBB9_21:                                ; =>This Inner Loop Header: Depth=1
	cbz	x20, LBB9_20
; %bb.22:                               ;   in Loop: Header=BB9_21 Depth=1
	ldur	x10, [x9, #-16]
	cmp	x10, x20
	b.ne	LBB9_20
; %bb.23:
	mov	w0, #0                          ; =0x0
	str	x8, [x9]
	mov	w8, #7428                       ; =0x1d04
	movk	w8, #2, lsl #16
	ldr	w9, [x19, x8]
	add	w9, w9, #1
	str	w9, [x19, x8]
	str	x20, [x22]
LBB9_24:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh20, Lloh21
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_completeunit_v1 ; -- Begin function neoclr_runtime_async_completeunit_v1
	.p2align	2
_neoclr_runtime_async_completeunit_v1:  ; @neoclr_runtime_async_completeunit_v1
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x1, LBB10_2
; %bb.1:
	ldr	w8, [x1]
	cbz	w8, LBB10_4
LBB10_2:
	mov	w19, #3                         ; =0x3
LBB10_3:
	mov	x0, x19
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB10_4:
	mov	x20, x0
Lloh22:
	adrp	x0, _state@TLVPPAGE
Lloh23:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbnz	x8, LBB10_6
; %bb.5:
	str	x1, [x0]
	mov	x8, x1
LBB10_6:
	mov	w19, #3                         ; =0x3
	cbz	x2, LBB10_3
; %bb.7:
	cmp	x8, x1
	b.ne	LBB10_3
; %bb.8:
	add	x22, x0, #36
	mov	w8, #128                        ; =0x80
	mov	x9, x20
	b	LBB10_10
LBB10_9:                                ;   in Loop: Header=BB10_10 Depth=1
	add	x22, x22, #24
	subs	x8, x8, #1
	b.eq	LBB10_13
LBB10_10:                               ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB10_9
; %bb.11:                               ;   in Loop: Header=BB10_10 Depth=1
	ldur	x10, [x22, #-12]
	cmp	x10, x9
	b.ne	LBB10_9
; %bb.12:
	ldur	w8, [x22, #-4]
	cbz	w8, LBB10_15
LBB10_13:
	mov	w19, #0                         ; =0x0
LBB10_14:
	str	wzr, [x2]
	b	LBB10_3
LBB10_15:
	ldr	w8, [x22]
	cmp	w8, #0
	cset	w10, eq
	str	w10, [x2]
	cbz	w8, LBB10_17
; %bb.16:
	mov	w19, #0                         ; =0x0
	b	LBB10_3
LBB10_17:
	mov	x23, #0                         ; =0x0
	mov	x21, #0                         ; =0x0
	mov	w8, #4104                       ; =0x1008
	add	x26, x0, x8
	b	LBB10_19
LBB10_18:                               ;   in Loop: Header=BB10_19 Depth=1
	add	x21, x21, #1
	add	x23, x23, #1056
	cmp	x23, #33, lsl #12               ; =135168
	b.eq	LBB10_26
LBB10_19:                               ; =>This Inner Loop Header: Depth=1
	add	x8, x0, x23
	ldr	x10, [x8, #4024]
	cbz	x10, LBB10_18
; %bb.20:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	x8, [x8, #4072]
	cmp	x8, x9
	b.ne	LBB10_18
; %bb.21:                               ;   in Loop: Header=BB10_19 Depth=1
	add	x10, x0, x23
	ldr	x8, [x10, #4080]
	cbz	x8, LBB10_18
; %bb.22:                               ;   in Loop: Header=BB10_19 Depth=1
	ldr	w10, [x10, #4016]
	cbnz	w10, LBB10_18
; %bb.23:                               ;   in Loop: Header=BB10_19 Depth=1
	mov	x24, x2
	add	x2, x26, x23
	mov	x27, x0
	mov	x0, x1
	mov	x25, x1
	mov	x1, x8
	bl	_neoclr_gc_host_root_create_v1
	mov	x1, x25
	mov	x2, x24
	mov	x19, x0
	mov	x0, x27
	mov	x9, x20
	cbz	w19, LBB10_18
; %bb.24:
	cbz	x23, LBB10_14
; %bb.25:
	mov	w8, #4104                       ; =0x1008
	add	x22, x0, x8
	b	LBB10_29
LBB10_26:
	mov	w19, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	stur	w8, [x22, #-4]
	b	LBB10_3
LBB10_27:                               ;   in Loop: Header=BB10_29 Depth=1
	str	xzr, [x22]
	mov	x2, x24
	mov	x1, x25
	mov	x9, x20
LBB10_28:                               ;   in Loop: Header=BB10_29 Depth=1
	add	x22, x22, #1056
	subs	x21, x21, #1
	b.eq	LBB10_14
LBB10_29:                               ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x22, #-32]
	cmp	x8, x9
	b.ne	LBB10_28
; %bb.30:                               ;   in Loop: Header=BB10_29 Depth=1
	ldr	x8, [x22]
	cbz	x8, LBB10_28
; %bb.31:                               ;   in Loop: Header=BB10_29 Depth=1
	mov	x0, x1
	mov	x1, x8
	bl	_neoclr_gc_host_root_release_v1
	cbz	w0, LBB10_27
; %bb.32:
	bl	_abort
	.loh AdrpLdr	Lloh22, Lloh23
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_iscompleted_v1 ; -- Begin function neoclr_runtime_async_iscompleted_v1
	.p2align	2
_neoclr_runtime_async_iscompleted_v1:   ; @neoclr_runtime_async_iscompleted_v1
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB11_2
; %bb.1:
	ldr	w8, [x1]
	cbz	w8, LBB11_3
LBB11_2:
	mov	w0, #3                          ; =0x3
	ret
LBB11_3:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x10, x0
Lloh24:
	adrp	x0, _state@TLVPPAGE
Lloh25:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x9, [x0]
	cbnz	x9, LBB11_5
; %bb.4:
	str	x1, [x0]
	mov	x9, x1
LBB11_5:
	mov	w8, #3                          ; =0x3
	cbz	x2, LBB11_15
; %bb.6:
	cmp	x9, x1
	b.ne	LBB11_15
; %bb.7:
	add	x9, x0, #24
	mov	w11, #24                        ; =0x18
	mov	x8, x10
	b	LBB11_9
LBB11_8:                                ;   in Loop: Header=BB11_9 Depth=1
	add	x11, x11, #24
	cmp	x11, #3096
	b.eq	LBB11_14
LBB11_9:                                ; =>This Inner Loop Header: Depth=1
	cbz	x8, LBB11_8
; %bb.10:                               ;   in Loop: Header=BB11_9 Depth=1
	ldr	x10, [x0, x11]
	cmp	x10, x8
	b.ne	LBB11_8
; %bb.11:
	ldr	x10, [x9]
	cmp	x10, x8
	b.eq	LBB11_13
LBB11_12:                               ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9, #24]!
	cmp	x10, x8
	b.ne	LBB11_12
LBB11_13:
	mov	w8, #0                          ; =0x0
	ldr	w9, [x9, #8]
	str	w9, [x2]
	b	LBB11_15
LBB11_14:
	mov	w8, #3                          ; =0x3
LBB11_15:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	mov	x0, x8
	ret
	.loh AdrpLdr	Lloh24, Lloh25
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_release_v1 ; -- Begin function neoclr_runtime_async_release_v1
	.p2align	2
_neoclr_runtime_async_release_v1:       ; @neoclr_runtime_async_release_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	cbz	x1, LBB12_2
; %bb.1:
	ldr	w8, [x1]
	cbz	w8, LBB12_4
LBB12_2:
	mov	w8, #3                          ; =0x3
LBB12_3:
	mov	x0, x8
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB12_4:
	mov	x19, x0
Lloh26:
	adrp	x0, _state@TLVPPAGE
Lloh27:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x9, [x0]
	cbnz	x9, LBB12_6
; %bb.5:
	str	x1, [x0]
	mov	x9, x1
LBB12_6:
	mov	w8, #3                          ; =0x3
	cbz	x2, LBB12_3
; %bb.7:
	cmp	x9, x1
	b.ne	LBB12_3
; %bb.8:
	str	wzr, [x2]
	add	x20, x0, #24
	mov	w9, #24                         ; =0x18
	mov	x8, x19
	b	LBB12_10
LBB12_9:                                ;   in Loop: Header=BB12_10 Depth=1
	add	x9, x9, #24
	cmp	x9, #3096
	b.eq	LBB12_22
LBB12_10:                               ; =>This Inner Loop Header: Depth=1
	cbz	x8, LBB12_9
; %bb.11:                               ;   in Loop: Header=BB12_10 Depth=1
	ldr	x10, [x0, x9]
	cmp	x10, x8
	b.ne	LBB12_9
; %bb.12:
	ldr	x9, [x20]
	mov	x10, x20
	cmp	x9, x8
	b.eq	LBB12_15
; %bb.13:
	mov	x10, x20
LBB12_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x10, #24]!
	cmp	x11, x8
	b.ne	LBB12_14
LBB12_15:
	ldr	w10, [x10, #8]
	cbz	w10, LBB12_22
; %bb.16:
	add	x10, x0, #4024
	mov	w11, #128                       ; =0x80
	b	LBB12_18
LBB12_17:                               ;   in Loop: Header=BB12_18 Depth=1
	add	x10, x10, #1056
	subs	x11, x11, #1
	b.eq	LBB12_23
LBB12_18:                               ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x10]
	cbz	x12, LBB12_17
; %bb.19:                               ;   in Loop: Header=BB12_18 Depth=1
	ldr	w12, [x10, #108]
	cbnz	w12, LBB12_17
; %bb.20:                               ;   in Loop: Header=BB12_18 Depth=1
	ldr	x12, [x10, #48]
	cmp	x12, x8
	b.eq	LBB12_22
; %bb.21:                               ;   in Loop: Header=BB12_18 Depth=1
	ldr	x12, [x10, #40]
	cmp	x12, x8
	b.ne	LBB12_17
LBB12_22:
	mov	w8, #0                          ; =0x0
	b	LBB12_3
LBB12_23:
	cmp	x9, x8
	b.ne	LBB12_25
; %bb.24:
	ldr	x11, [x0, #40]
	mov	x10, x20
	cbnz	x11, LBB12_31
	b	LBB12_34
LBB12_25:
	add	x10, x0, #48
LBB12_26:                               ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x10], #24
	cmp	x11, x8
	b.ne	LBB12_26
; %bb.27:
	ldur	x10, [x10, #-8]
	cbz	x10, LBB12_34
; %bb.28:
	mov	x10, x20
	cmp	x9, x8
	b.eq	LBB12_31
; %bb.29:
	mov	x10, x20
LBB12_30:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x10, #24]!
	cmp	x9, x8
	b.ne	LBB12_30
LBB12_31:
	mov	x22, x0
	mov	x21, x2
	ldr	x8, [x10, #16]
	mov	x0, x1
	mov	x1, x8
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB12_36
; %bb.32:
	mov	w8, #7428                       ; =0x1d04
	movk	w8, #2, lsl #16
	ldr	w9, [x22, x8]
	sub	w9, w9, #1
	str	w9, [x22, x8]
	ldr	x9, [x22, #24]
	mov	x2, x21
	mov	x8, x19
	b	LBB12_34
LBB12_33:                               ;   in Loop: Header=BB12_34 Depth=1
	ldr	x9, [x20, #24]!
LBB12_34:                               ; =>This Inner Loop Header: Depth=1
	cmp	x9, x8
	b.ne	LBB12_33
; %bb.35:
	mov	w8, #0                          ; =0x0
	stp	xzr, xzr, [x20]
	str	xzr, [x20, #16]
	mov	w9, #1                          ; =0x1
	str	w9, [x2]
	b	LBB12_3
LBB12_36:
	bl	_abort
	.loh AdrpLdr	Lloh26, Lloh27
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_waitcompletion_v1 ; -- Begin function neoclr_runtime_async_waitcompletion_v1
	.p2align	2
_neoclr_runtime_async_waitcompletion_v1: ; @neoclr_runtime_async_waitcompletion_v1
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB13_2
; %bb.1:
	ldr	w8, [x1]
	cbz	w8, LBB13_3
LBB13_2:
	mov	w0, #3                          ; =0x3
	ret
LBB13_3:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x0
Lloh28:
	adrp	x0, _state@TLVPPAGE
Lloh29:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x10, [x0]
	cbnz	x10, LBB13_5
; %bb.4:
	str	x1, [x0]
	mov	x10, x1
LBB13_5:
	mov	w8, #3                          ; =0x3
	cbz	x2, LBB13_20
; %bb.6:
	cmp	x10, x1
	b.ne	LBB13_20
; %bb.7:
	mov	x9, x20
	add	x19, x0, #24
	mov	w8, #24                         ; =0x18
	b	LBB13_9
LBB13_8:                                ;   in Loop: Header=BB13_9 Depth=1
	add	x8, x8, #24
	cmp	x8, #3096
	b.eq	LBB13_19
LBB13_9:                                ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB13_8
; %bb.10:                               ;   in Loop: Header=BB13_9 Depth=1
	ldr	x10, [x0, x8]
	cmp	x10, x9
	b.ne	LBB13_8
; %bb.11:
	ldr	x10, [x19]
	mov	x8, x19
	cmp	x10, x9
	b.eq	LBB13_14
; %bb.12:
	mov	x8, x19
LBB13_13:                               ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x8, #24]!
	cmp	x10, x9
	b.ne	LBB13_13
LBB13_14:
	ldr	w8, [x8, #8]
	cbz	w8, LBB13_16
LBB13_15:
	mov	w8, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	str	w9, [x2]
	b	LBB13_20
LBB13_16:
	mov	w8, #7200                       ; =0x1c20
	movk	w8, #2, lsl #16
	ldr	x21, [x0, x8]
	cbz	x21, LBB13_19
; %bb.17:
	ldr	x8, [x21, #960]
	cmp	x8, x9
	b.eq	LBB13_19
; %bb.18:
	mov	x22, x0
	mov	x23, x2
	str	x9, [x21, #968]
	mov	x24, x1
	bl	_yield
	str	xzr, [x21, #968]
	ldr	w8, [x24]
	cbz	w8, LBB13_21
LBB13_19:
	mov	w8, #3                          ; =0x3
LBB13_20:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	mov	x0, x8
	ret
LBB13_21:
	mov	w9, #24                         ; =0x18
	mov	x2, x23
	mov	x10, x22
LBB13_22:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x10, x9]
	cmp	x8, x20
	b.eq	LBB13_24
; %bb.23:                               ;   in Loop: Header=BB13_22 Depth=1
	add	x9, x9, #24
	mov	w8, #3                          ; =0x3
	cmp	x9, #3096
	b.ne	LBB13_22
	b	LBB13_20
LBB13_24:
	ldr	x8, [x19]
	cmp	x8, x20
	b.eq	LBB13_26
LBB13_25:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19, #24]!
	cmp	x8, x20
	b.ne	LBB13_25
LBB13_26:
	ldr	w8, [x19, #8]
	cbnz	w8, LBB13_15
	b	LBB13_19
	.loh AdrpLdr	Lloh28, Lloh29
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function yield
_yield:                                 ; @yield
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh30:
	adrp	x0, _state@TLVPPAGE
Lloh31:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	mov	w8, #7200                       ; =0x1c20
	movk	w8, #2, lsl #16
	ldr	x19, [x0, x8]
	ldr	x1, [x19, #992]
	cbz	x1, LBB14_2
; %bb.1:
	ldr	x0, [x20]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB14_10
LBB14_2:
	ldr	x1, [x19, #984]
	cbz	x1, LBB14_4
; %bb.3:
	ldr	x0, [x20]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB14_10
LBB14_4:
	add	x8, x19, #984
	stp	xzr, xzr, [x8]
	ldr	x1, [x19, #976]
	cbz	x1, LBB14_6
; %bb.5:
	ldr	w8, [x19, #1008]
	cbz	w8, LBB14_7
LBB14_6:
	add	x0, x19, #880
	bl	_neoclr_roots_park_v1
	b	LBB14_8
LBB14_7:
	ldr	x0, [x20]
	add	x2, x19, #880
	bl	_neoclr_gc_roots_park_owned_v1
	cbnz	w0, LBB14_10
LBB14_8:
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #1020]
	ldr	x1, [x19, #1048]
	mov	x0, x19
	bl	_swapcontext
	cbnz	w0, LBB14_10
; %bb.9:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB14_10:
	bl	_abort
	.loh AdrpLdr	Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_awaitunit_v1 ; -- Begin function neoclr_runtime_async_awaitunit_v1
	.p2align	2
_neoclr_runtime_async_awaitunit_v1:     ; @neoclr_runtime_async_awaitunit_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	sub	x2, x29, #4
	bl	_neoclr_runtime_async_waitcompletion_v1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_pump_v1   ; -- Begin function neoclr_runtime_async_pump_v1
	.p2align	2
_neoclr_runtime_async_pump_v1:          ; @neoclr_runtime_async_pump_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x28, x27, [sp, #80]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x0, LBB16_2
; %bb.1:
	mov	x19, x0
	ldr	w8, [x0]
	cbz	w8, LBB16_4
LBB16_2:
	mov	w8, #3                          ; =0x3
LBB16_3:
	mov	x0, x8
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
LBB16_4:
Lloh32:
	adrp	x0, _state@TLVPPAGE
Lloh33:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x9, [x0]
	cbnz	x9, LBB16_6
; %bb.5:
	str	x19, [x0]
	mov	x9, x19
LBB16_6:
	mov	w8, #3                          ; =0x3
	cbz	x2, LBB16_3
; %bb.7:
	cbz	x1, LBB16_3
; %bb.8:
	cmp	x9, x19
	b.ne	LBB16_3
; %bb.9:
	add	x22, x0, #33, lsl #12           ; =135168
	ldr	x8, [x22, #3104]
	cbnz	x8, LBB16_2
; %bb.10:
	ldr	w8, [x22, #3336]
	cbnz	w8, LBB16_2
; %bb.11:
	stp	x1, x2, [x0, #8]
	mov	w21, #1                         ; =0x1
	str	w21, [x22, #3336]
	str	xzr, [sp, #64]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #32]
	mov	x20, x0
	add	x0, sp, #32
	bl	_neoclr_roots_park_v1
	add	x23, x20, #3104
	add	x24, x20, #32
	mov	w25, #1056                      ; =0x420
	b	LBB16_14
LBB16_12:                               ;   in Loop: Header=BB16_14 Depth=1
	mov	w0, #3                          ; =0x3
LBB16_13:                               ;   in Loop: Header=BB16_14 Depth=1
	cbnz	w0, LBB16_63
LBB16_14:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB16_18 Depth 2
                                        ;       Child Loop BB16_22 Depth 3
                                        ;     Child Loop BB16_39 Depth 2
                                        ;       Child Loop BB16_43 Depth 3
	bl	_reap_expired
	mov	x26, #0                         ; =0x0
	mov	w27, #0                         ; =0x0
	b	LBB16_18
LBB16_15:                               ;   in Loop: Header=BB16_18 Depth=2
	ldr	w8, [x20, #1016]
	cmp	w8, #0
	cset	w8, ne
LBB16_16:                               ;   in Loop: Header=BB16_18 Depth=2
	orr	w27, w8, w27
LBB16_17:                               ;   in Loop: Header=BB16_18 Depth=2
	add	x26, x26, #1
	cmp	x26, #128
	b.eq	LBB16_30
LBB16_18:                               ;   Parent Loop BB16_14 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB16_22 Depth 3
	madd	x20, x26, x25, x23
	ldr	x8, [x20, #920]
	cbz	x8, LBB16_17
; %bb.19:                               ;   in Loop: Header=BB16_18 Depth=2
	ldr	w8, [x20, #1028]
	cbnz	w8, LBB16_17
; %bb.20:                               ;   in Loop: Header=BB16_18 Depth=2
	ldr	x8, [x20, #968]
	mov	x9, x24
	mov	w10, #128                       ; =0x80
	b	LBB16_22
LBB16_21:                               ;   in Loop: Header=BB16_22 Depth=3
	add	x9, x9, #24
	subs	x10, x10, #1
	b.eq	LBB16_27
LBB16_22:                               ;   Parent Loop BB16_14 Depth=1
                                        ;     Parent Loop BB16_18 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cbz	x8, LBB16_21
; %bb.23:                               ;   in Loop: Header=BB16_22 Depth=3
	ldur	x11, [x9, #-8]
	cmp	x11, x8
	b.ne	LBB16_21
; %bb.24:                               ;   in Loop: Header=BB16_18 Depth=2
	ldr	w8, [x9]
	cbz	w8, LBB16_27
; %bb.25:                               ;   in Loop: Header=BB16_18 Depth=2
	mov	x0, x20
	bl	_resume
	mov	x21, x0
	bl	_reap_expired
	cbnz	w21, LBB16_58
; %bb.26:                               ;   in Loop: Header=BB16_18 Depth=2
	mov	w21, #1                         ; =0x1
LBB16_27:                               ;   in Loop: Header=BB16_18 Depth=2
	ldr	x8, [x20, #920]
	cbz	x8, LBB16_16
; %bb.28:                               ;   in Loop: Header=BB16_18 Depth=2
	ldr	w8, [x20, #1028]
	cbz	w8, LBB16_15
; %bb.29:                               ;   in Loop: Header=BB16_18 Depth=2
	mov	w8, #0                          ; =0x0
	b	LBB16_16
LBB16_30:                               ;   in Loop: Header=BB16_14 Depth=1
	cbnz	w27, LBB16_35
; %bb.31:                               ;   in Loop: Header=BB16_14 Depth=1
	cbz	w21, LBB16_35
; %bb.32:                               ;   in Loop: Header=BB16_14 Depth=1
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w2, #1                          ; =0x1
	bl	_allocate_fiber
	cbz	x0, LBB16_62
; %bb.33:                               ;   in Loop: Header=BB16_14 Depth=1
	bl	_resume
	cbnz	w0, LBB16_63
; %bb.34:                               ;   in Loop: Header=BB16_14 Depth=1
	mov	w21, #0                         ; =0x0
LBB16_35:                               ;   in Loop: Header=BB16_14 Depth=1
	bl	_reap_expired
	str	xzr, [sp, #24]
	add	x1, sp, #24
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	bl	_neoclr_scheduler_acquire_v1
	mov	x20, x0
	bl	_reap_expired
	mov	x9, #0                          ; =0x0
	mov	w8, #0                          ; =0x0
	mov	w10, #0                         ; =0x0
	b	LBB16_39
LBB16_36:                               ;   in Loop: Header=BB16_39 Depth=2
	mov	w10, #0                         ; =0x0
LBB16_37:                               ;   in Loop: Header=BB16_39 Depth=2
	orr	w8, w10, w8
	mov	w10, #1                         ; =0x1
LBB16_38:                               ;   in Loop: Header=BB16_39 Depth=2
	add	x9, x9, #1
	cmp	x9, #128
	b.eq	LBB16_46
LBB16_39:                               ;   Parent Loop BB16_14 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB16_43 Depth 3
	madd	x11, x9, x25, x23
	ldr	x12, [x11, #920]
	cbz	x12, LBB16_38
; %bb.40:                               ;   in Loop: Header=BB16_39 Depth=2
	ldr	w12, [x11, #1028]
	cbnz	w12, LBB16_38
; %bb.41:                               ;   in Loop: Header=BB16_39 Depth=2
	ldr	x10, [x11, #968]
	mov	x11, x24
	mov	w12, #128                       ; =0x80
	b	LBB16_43
LBB16_42:                               ;   in Loop: Header=BB16_43 Depth=3
	add	x11, x11, #24
	subs	x12, x12, #1
	b.eq	LBB16_36
LBB16_43:                               ;   Parent Loop BB16_14 Depth=1
                                        ;     Parent Loop BB16_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cbz	x10, LBB16_42
; %bb.44:                               ;   in Loop: Header=BB16_43 Depth=3
	ldur	x13, [x11, #-8]
	cmp	x13, x10
	b.ne	LBB16_42
; %bb.45:                               ;   in Loop: Header=BB16_39 Depth=2
	ldr	w10, [x11]
	cmp	w10, #0
	cset	w10, ne
	b	LBB16_37
LBB16_46:                               ;   in Loop: Header=BB16_14 Depth=1
	cbz	w20, LBB16_56
; %bb.47:                               ;   in Loop: Header=BB16_14 Depth=1
	cmp	w20, #1
	b.eq	LBB16_51
; %bb.48:                               ;   in Loop: Header=BB16_14 Depth=1
	cmp	w20, #2
	b.ne	LBB16_12
; %bb.49:                               ;   in Loop: Header=BB16_14 Depth=1
	cbnz	w8, LBB16_57
; %bb.50:                               ;   in Loop: Header=BB16_14 Depth=1
	mov	x0, x19
	bl	_neoclr_scheduler_wait_v1
	mov	w0, #0                          ; =0x0
	b	LBB16_13
LBB16_51:                               ;   in Loop: Header=BB16_14 Depth=1
	stp	xzr, xzr, [sp, #8]
	ldr	x1, [sp, #24]
	add	x2, sp, #16
	mov	x0, x19
	bl	_neoclr_gc_host_root_read_v1
	cbnz	w0, LBB16_59
; %bb.52:                               ;   in Loop: Header=BB16_14 Depth=1
	ldr	x1, [sp, #16]
	add	x2, sp, #8
	mov	x0, x19
	bl	_neoclr_gc_host_root_create_v1
	cbnz	w0, LBB16_59
; %bb.53:                               ;   in Loop: Header=BB16_14 Depth=1
	ldr	x1, [sp, #24]
	mov	x0, x19
	mov	x2, #0                          ; =0x0
	bl	_neoclr_scheduler_complete_v1
	cbnz	w0, LBB16_64
; %bb.54:                               ;   in Loop: Header=BB16_14 Depth=1
	ldr	x0, [sp, #8]
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	bl	_allocate_fiber
	cbz	x0, LBB16_61
; %bb.55:                               ;   in Loop: Header=BB16_14 Depth=1
	bl	_resume
	mov	w21, #1                         ; =0x1
	b	LBB16_13
LBB16_56:                               ;   in Loop: Header=BB16_14 Depth=1
	cbz	w8, LBB16_60
LBB16_57:                               ;   in Loop: Header=BB16_14 Depth=1
	mov	w0, #0                          ; =0x0
	b	LBB16_13
LBB16_58:
	mov	x0, x21
	b	LBB16_63
LBB16_59:
	mov	w0, #3                          ; =0x3
	b	LBB16_63
LBB16_60:
	mov	w8, #3                          ; =0x3
	cmp	w10, #0
	csel	w0, wzr, w8, eq
	b	LBB16_63
LBB16_61:
	ldr	x1, [sp, #8]
	mov	x0, x19
	bl	_neoclr_gc_host_root_release_v1
LBB16_62:
	mov	w0, #5                          ; =0x5
LBB16_63:
	mov	x19, x0
	add	x0, sp, #32
	bl	_neoclr_roots_resume_v1
	mov	x8, x19
	str	wzr, [x22, #3336]
	b	LBB16_3
LBB16_64:
	bl	_abort
	.loh AdrpLdr	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function resume
_resume:                                ; @resume
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	sub	sp, sp, #928
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	ldr	w8, [x0, #912]
	cbz	w8, LBB17_3
LBB17_1:
	mov	w0, #3                          ; =0x3
LBB17_2:
	add	sp, sp, #928
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB17_3:
	mov	x19, x0
	ldr	x8, [x0, #976]
Lloh34:
	adrp	x20, _state@TLVPPAGE
Lloh35:
	ldr	x20, [x20, _state@TLVPPAGEOFF]
	cbz	x8, LBB17_9
; %bb.4:
	str	xzr, [sp, #48]
	ldr	x8, [x20]
	mov	x0, x20
	blr	x8
	mov	x21, x0
	ldr	x0, [x0]
	ldr	x1, [x19, #952]
	add	x2, sp, #48
	bl	_neoclr_gc_host_root_read_v1
	cbnz	w0, LBB17_1
; %bb.5:
	ldr	x0, [x21]
	ldr	x1, [x19, #976]
	add	x22, x19, #984
	mov	x2, x22
	bl	_neoclr_gc_host_root_create_v1
	cbnz	w0, LBB17_2
; %bb.6:
	ldr	x0, [x21]
	ldr	x1, [sp, #48]
	add	x2, x19, #992
	bl	_neoclr_gc_host_root_create_v1
	cbz	w0, LBB17_9
; %bb.7:
	mov	x19, x0
	ldr	x0, [x21]
	ldr	x1, [x22]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB17_33
; %bb.8:
	str	xzr, [x22]
	mov	x0, x19
	b	LBB17_2
LBB17_9:
	ldr	x1, [x19, #1000]
	ldr	x8, [x20]
	mov	x0, x20
	blr	x8
	mov	x21, x0
	cbz	x1, LBB17_12
; %bb.10:
	ldr	x0, [x21]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB17_33
; %bb.11:
	str	xzr, [x19, #1000]
LBB17_12:
	add	x22, x19, #880
	add	x23, x21, #33, lsl #12          ; =135168
Lloh36:
	adrp	x0, _statistics@TLVPPAGE
Lloh37:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	ldr	x8, [x0, #8]
	add	x8, x8, #1
	str	x8, [x0, #8]
	str	xzr, [sp, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
	ldr	x24, [x23, #3104]
	mov	x0, sp
	bl	_neoclr_roots_park_v1
	ldr	w8, [x19, #1020]
	cbz	w8, LBB17_14
; %bb.13:
	mov	x0, x22
	bl	_neoclr_roots_resume_v1
	str	wzr, [x19, #1020]
LBB17_14:
	str	x19, [x23, #3104]
	add	x8, sp, #48
	str	x8, [x19, #1048]
	ldr	x0, [x19, #936]
	ldr	x1, [x19, #944]
	bl	_neoclr_native_stack_bounds_v1
	add	x0, sp, #48
	mov	x1, x19
	bl	_swapcontext
	cbnz	w0, LBB17_33
; %bb.15:
	str	x24, [x23, #3104]
	cbz	x24, LBB17_17
; %bb.16:
	ldr	x0, [x24, #936]
	ldr	x1, [x24, #944]
	b	LBB17_18
LBB17_17:
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
LBB17_18:
	bl	_neoclr_native_stack_bounds_v1
	mov	x0, sp
	bl	_neoclr_roots_resume_v1
	ldr	w0, [x19, #1012]
	ldr	w8, [x19, #1008]
	cbz	w8, LBB17_2
; %bb.19:
	ldr	x8, [x19, #976]
	cbz	x8, LBB17_21
; %bb.20:
	ldr	w8, [x23, #3332]
	sub	w8, w8, #1
	str	w8, [x23, #3332]
LBB17_21:
	mov	x24, x0
	ldr	w8, [x19, #1024]
	cbz	w8, LBB17_27
; %bb.22:
	ldr	x9, [x19, #960]
	add	x8, x21, #24
	b	LBB17_24
LBB17_23:                               ;   in Loop: Header=BB17_24 Depth=1
	add	x8, x8, #24
LBB17_24:                               ; =>This Inner Loop Header: Depth=1
	cbz	x9, LBB17_23
; %bb.25:                               ;   in Loop: Header=BB17_24 Depth=1
	ldr	x10, [x8]
	cmp	x10, x9
	b.ne	LBB17_23
; %bb.26:
	stp	xzr, xzr, [x8]
	str	xzr, [x8, #16]
LBB17_27:
	mov	x0, x22
	bl	_neoclr_roots_discard_v1
	cbnz	w24, LBB17_31
; %bb.28:
	ldr	x8, [x21]
	ldr	w8, [x8]
	cbnz	w8, LBB17_31
; %bb.29:
	ldr	w8, [x23, #3328]
	cmp	w8, #7
	b.hi	LBB17_31
; %bb.30:
	mov	x0, x24
	str	xzr, [x22, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x22]
	add	x8, x19, #952
	str	xzr, [x19, #1048]
	stp	q0, q0, [x8]
	stp	q0, q0, [x8, #32]
	stur	q0, [x8, #60]
	mov	w8, #1                          ; =0x1
	str	w8, [x19, #1028]
	ldr	w8, [x23, #3328]
	add	w8, w8, #1
	str	w8, [x23, #3328]
	b	LBB17_2
LBB17_31:
	ldr	x0, [x19, #920]
	ldr	x21, [x19, #928]
	mov	x1, x21
	bl	_munmap
	cbnz	w0, LBB17_33
; %bb.32:
	ldp	x8, x9, [x20, #24]
	add	x8, x8, #1
	sub	x9, x9, x21
	stp	x8, x9, [x20, #24]
	mov	x0, x19
	mov	w1, #1056                       ; =0x420
	bl	_bzero
	mov	x0, x24
	b	LBB17_2
LBB17_33:
	bl	_abort
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh36, Lloh37
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function allocate_fiber
_allocate_fiber:                        ; @allocate_fiber
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x0
	mov	w8, #4096                       ; =0x1000
	movk	w8, #2, lsl #16
                                        ; kill: def $x8 killed $w8
Lloh38:
	adrp	x0, _state@TLVPPAGE
Lloh39:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x19, x0
	mov	x9, x0
	mov	x22, #0                         ; =0x0
LBB18_1:                                ; =>This Inner Loop Header: Depth=1
	add	x21, x19, x22
	ldr	w10, [x21, #4132]
	cbnz	w10, LBB18_6
; %bb.2:                                ;   in Loop: Header=BB18_1 Depth=1
	add	x10, x22, #1056
	mov	x22, x10
	cmp	x10, x8
	b.ne	LBB18_1
; %bb.3:
	mov	x27, #0                         ; =0x0
LBB18_4:                                ; =>This Inner Loop Header: Depth=1
	add	x28, x19, x27
	ldr	x9, [x28, #4024]
	cbz	x9, LBB18_9
; %bb.5:                                ;   in Loop: Header=BB18_4 Depth=1
	add	x9, x27, #1056
	mov	x27, x9
	cmp	x9, x8
	b.ne	LBB18_4
	b	LBB18_16
LBB18_6:
	mov	w0, #0                          ; =0x0
	str	wzr, [x21, #4132]
	mov	w8, #7424                       ; =0x1d00
	movk	w8, #2, lsl #16
                                        ; kill: def $x8 killed $w8
	ldr	w10, [x9, x8]
	sub	w10, w10, #1
	str	w10, [x9, x8]
	str	x20, [x21, #4056]
	str	x1, [x21, #4064]
	str	w2, [x21, #4120]
	mov	x1, #0                          ; =0x0
	add	x2, x21, #3108
	bl	_sigprocmask
	cbnz	w0, LBB18_21
; %bb.7:
	add	x8, x19, x22
	mov	w9, #4136                       ; =0x1028
                                        ; kill: def $x9 killed $w9
	add	x0, x8, x9
	bl	_fegetenv
	cbnz	w0, LBB18_21
; %bb.8:
	add	x21, x21, #3104
Lloh40:
	adrp	x0, _statistics@TLVPPAGE
Lloh41:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	add	x9, x9, #1
	str	x9, [x0]
	b	LBB18_17
LBB18_9:
	mov	x26, x1
	str	w2, [sp, #12]                   ; 4-byte Folded Spill
	mov	w0, #29                         ; =0x1d
	bl	_sysconf
	cmp	x0, #1
	b.lt	LBB18_16
; %bb.10:
	mov	x22, x0
	lsl	x8, x0, #1
	add	x21, x8, #256, lsl #12          ; =1048576
	mov	w2, #0                          ; =0x0
	mov	x23, #0                         ; =0x0
	mov	x0, #0                          ; =0x0
	mov	x1, x21
	mov	w3, #4098                       ; =0x1002
	mov	w4, #-1                         ; =0xffffffff
	mov	x5, #0                          ; =0x0
	bl	_mmap
	cmn	x0, #1
	b.eq	LBB18_18
; %bb.11:
	mov	x8, x0
Lloh42:
	adrp	x0, _statistics@TLVPPAGE
Lloh43:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x25, x0
	ldr	x9, [x0, #16]
	add	x9, x9, #1
	str	x9, [x0, #16]
	ldp	x9, x10, [x0, #32]
	add	x9, x9, x21
	cmp	x9, x10
	str	x9, [x0, #32]
	b.ls	LBB18_13
; %bb.12:
	str	x9, [x25, #40]
LBB18_13:
	mov	x23, x21
	mov	x24, x8
	add	x22, x8, x22
	mov	w8, #1048576                    ; =0x100000
	mov	x1, x8
	mov	x0, x22
	mov	w2, #3                          ; =0x3
	bl	_mprotect
	cbz	w0, LBB18_19
; %bb.14:
	mov	x0, x24
	mov	x1, x23
	bl	_munmap
	cbnz	w0, LBB18_21
; %bb.15:
	ldp	x8, x9, [x25, #24]
	add	x8, x8, #1
	sub	x9, x9, x21
	stp	x8, x9, [x25, #24]
LBB18_16:
	mov	x21, #0                         ; =0x0
LBB18_17:
	mov	x0, x21
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB18_18:
	mov	x21, x23
	b	LBB18_17
LBB18_19:
	add	x21, x28, #3104
	str	x22, [sp]                       ; 8-byte Folded Spill
	mov	w8, #1056                       ; =0x420
	mov	x1, x8
	mov	x0, x21
	bl	_bzero
	str	x24, [x28, #4024]
	add	x19, x19, x27
	str	x23, [x19, #4032]
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	str	x8, [x19, #4040]
	add	x8, x22, #256, lsl #12          ; =1048576
	str	x8, [x19, #4048]
	ldr	x8, [x25]
	add	x8, x8, #1
	str	x8, [x25]
	str	x20, [x19, #4056]
	str	x26, [x19, #4064]
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	str	w8, [x19, #4120]
	mov	x0, x21
	bl	_getcontext
	cbnz	w0, LBB18_21
; %bb.20:
	ldr	x9, [x19, #4040]
	str	x9, [x19, #3112]
	mov	w9, #1048576                    ; =0x100000
                                        ; kill: def $x9 killed $w9
	str	x9, [x19, #3120]
	str	xzr, [x19, #3136]
	mov	w2, #0                          ; =0x0
Lloh44:
	adrp	x1, _body@PAGE
Lloh45:
	add	x1, x1, _body@PAGEOFF
	mov	x0, x21
	bl	_makecontext
	mov	w8, #4136                       ; =0x1028
                                        ; kill: def $x8 killed $w8
	add	x0, x19, x8
	bl	_fegetenv
	cbz	w0, LBB18_17
LBB18_21:
	bl	_abort
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdd	Lloh44, Lloh45
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_runtime_async_shutdown_v1 ; -- Begin function neoclr_runtime_async_shutdown_v1
	.p2align	2
_neoclr_runtime_async_shutdown_v1:      ; @neoclr_runtime_async_shutdown_v1
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
Lloh46:
	adrp	x0, _state@TLVPPAGE
Lloh47:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB19_23
; %bb.1:
	cmp	x8, x19
	b.ne	LBB19_5
; %bb.2:
	mov	x20, x0
	add	x8, x0, #33, lsl #12            ; =135168
	ldr	x9, [x8, #3104]
	cbnz	x9, LBB19_5
; %bb.3:
	ldr	w8, [x8, #3336]
	cbnz	w8, LBB19_5
; %bb.4:
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB19_6
LBB19_5:
	mov	w0, #3                          ; =0x3
	b	LBB19_24
LBB19_6:
	bl	_reap_expired
Lloh48:
	adrp	x0, _statistics@TLVPPAGE
Lloh49:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x21, x0
	mov	x24, #0                         ; =0x0
	mov	w23, #0                         ; =0x0
	mov	w25, #24                        ; =0x18
	b	LBB19_8
LBB19_7:                                ;   in Loop: Header=BB19_8 Depth=1
	orr	w23, w23, w22
	add	x24, x24, #1056
	add	x25, x25, #24
	cmp	x24, #33, lsl #12               ; =135168
	b.eq	LBB19_20
LBB19_8:                                ; =>This Inner Loop Header: Depth=1
	add	x22, x20, x24
	ldr	x8, [x22, #4024]
	cbz	x8, LBB19_17
; %bb.9:                                ;   in Loop: Header=BB19_8 Depth=1
	ldr	w8, [x22, #4132]
	cmp	w8, #0
	cset	w26, eq
	ldr	w8, [x22, #4124]
	cbz	w8, LBB19_11
; %bb.10:                               ;   in Loop: Header=BB19_8 Depth=1
	add	x8, x20, x24
	add	x0, x8, #3984
	bl	_neoclr_roots_discard_v1
LBB19_11:                               ;   in Loop: Header=BB19_8 Depth=1
	add	x27, x20, x24
	ldr	x1, [x27, #4056]
	cbz	x1, LBB19_13
; %bb.12:                               ;   in Loop: Header=BB19_8 Depth=1
	mov	x0, x19
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB19_19
LBB19_13:                               ;   in Loop: Header=BB19_8 Depth=1
	ldr	x1, [x27, #4104]
	cbz	x1, LBB19_15
; %bb.14:                               ;   in Loop: Header=BB19_8 Depth=1
	mov	x0, x19
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB19_19
LBB19_15:                               ;   in Loop: Header=BB19_8 Depth=1
	ldr	x0, [x22, #4024]
	add	x8, x20, x24
	ldr	x22, [x8, #4032]
	mov	x1, x22
	bl	_munmap
	cbnz	w0, LBB19_19
; %bb.16:                               ;   in Loop: Header=BB19_8 Depth=1
	orr	w23, w23, w26
	ldp	x8, x9, [x21, #24]
	add	x8, x8, #1
	sub	x9, x9, x22
	stp	x8, x9, [x21, #24]
LBB19_17:                               ;   in Loop: Header=BB19_8 Depth=1
	add	x8, x20, x25
	ldr	x9, [x8]
	cmp	x9, #0
	cset	w22, ne
	ldr	x1, [x8, #16]
	cbz	x1, LBB19_7
; %bb.18:                               ;   in Loop: Header=BB19_8 Depth=1
	mov	x0, x19
	bl	_neoclr_gc_host_root_release_v1
	cbz	w0, LBB19_7
LBB19_19:
	bl	_abort
LBB19_20:
	ldr	x8, [x21, #32]
	cbnz	x8, LBB19_19
; %bb.21:
	mov	x0, x20
	mov	w1, #7440                       ; =0x1d10
	movk	w1, #2, lsl #16
	bl	_bzero
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	bl	_neoclr_native_stack_bounds_v1
	cbz	w23, LBB19_23
; %bb.22:
	ldr	w8, [x19]
	mov	w9, #3                          ; =0x3
	cmp	w8, #0
	csel	w0, w9, wzr, eq
	b	LBB19_24
LBB19_23:
	mov	w0, #0                          ; =0x0
LBB19_24:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpLdr	Lloh48, Lloh49
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function unmap_stack
_unmap_stack:                           ; @unmap_stack
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	bl	_munmap
	cbnz	w0, LBB20_2
; %bb.1:
Lloh50:
	adrp	x0, _statistics@TLVPPAGE
Lloh51:
	ldr	x0, [x0, _statistics@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldp	x8, x9, [x0, #24]
	add	x8, x8, #1
	sub	x9, x9, x19
	stp	x8, x9, [x0, #24]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB20_2:
	bl	_abort
	.loh AdrpLdr	Lloh50, Lloh51
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function body
_body:                                  ; @body
	.cfi_startproc
; %bb.0:
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
Lloh52:
	adrp	x0, _state@TLVPPAGE
Lloh53:
	ldr	x0, [x0, _state@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x19, x0
	mov	w20, #7200                      ; =0x1c20
	movk	w20, #2, lsl #16
	ldr	x21, [x0, x20]
	add	x0, x21, #1032
	bl	_fesetenv
	cbnz	w0, LBB21_15
; %bb.1:
	add	x22, x19, #32
	mov	w23, #992                       ; =0x3e0
	mov	w24, #952                       ; =0x3b8
	mov	w25, #1                         ; =0x1
	b	LBB21_3
LBB21_2:                                ;   in Loop: Header=BB21_3 Depth=1
	str	w25, [x21, #1008]
	bl	_yield
	ldr	x21, [x19, x20]
	add	x0, x21, #1032
	bl	_fesetenv
	cbnz	w0, LBB21_15
LBB21_3:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB21_11 Depth 2
	ldr	w8, [x21, #1016]
	cbz	w8, LBB21_5
; %bb.4:                                ;   in Loop: Header=BB21_3 Depth=1
	ldr	x8, [x19, #16]
	ldr	x0, [x19]
	blr	x8
	b	LBB21_6
LBB21_5:                                ;   in Loop: Header=BB21_3 Depth=1
	ldr	x8, [x21, #976]
	cmp	x8, #0
	csel	x8, x24, x23, eq
	ldr	x0, [x21, x8]
	ldp	x1, x8, [x19]
	blr	x8
LBB21_6:                                ;   in Loop: Header=BB21_3 Depth=1
	str	w0, [x21, #1012]
	bl	_neoclr_root_probe_head_v1
	cbnz	x0, LBB21_15
; %bb.7:                                ;   in Loop: Header=BB21_3 Depth=1
	ldr	x1, [x21, #952]
	cbz	x1, LBB21_9
; %bb.8:                                ;   in Loop: Header=BB21_3 Depth=1
	ldr	x0, [x19]
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB21_15
LBB21_9:                                ;   in Loop: Header=BB21_3 Depth=1
	str	xzr, [x21, #952]
	ldr	x9, [x21, #960]
	mov	x8, x22
	mov	w10, #128                       ; =0x80
	b	LBB21_11
LBB21_10:                               ;   in Loop: Header=BB21_11 Depth=2
	add	x8, x8, #24
	subs	x10, x10, #1
	b.eq	LBB21_2
LBB21_11:                               ;   Parent Loop BB21_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cbz	x9, LBB21_10
; %bb.12:                               ;   in Loop: Header=BB21_11 Depth=2
	ldur	x11, [x8, #-8]
	cmp	x11, x9
	b.ne	LBB21_10
; %bb.13:                               ;   in Loop: Header=BB21_3 Depth=1
	ldr	w9, [x21, #1012]
	cbnz	w9, LBB21_2
; %bb.14:                               ;   in Loop: Header=BB21_3 Depth=1
	str	w25, [x8]
	b	LBB21_2
LBB21_15:
	bl	_abort
	.loh AdrpLdr	Lloh52, Lloh53
	.cfi_endproc
                                        ; -- End function
.tbss _statistics$tlv$init, 48, 3       ; @statistics

	.section	__DATA,__thread_vars,thread_local_variables
_statistics:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_statistics$tlv$init

.tbss _state$tlv$init, 138512, 4        ; @state

_state:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_state$tlv$init

.tbss _next_id$tlv$init, 8, 3           ; @next_id

_next_id:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_next_id$tlv$init

.subsections_via_symbols
