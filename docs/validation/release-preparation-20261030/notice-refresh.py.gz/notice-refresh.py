from pathlib import Path
import hashlib, importlib.util, json, shutil, subprocess, tarfile
ROOT=Path('/Users/robert/Projects/neoclr')
OUT=Path('/tmp/neoclr-preview19-notice-refresh-verified')
OUT.mkdir(exist_ok=False)
ASSETS=OUT/'assets'; ASSETS.mkdir()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def verify(root,files):
 for n,d in files.items():
  p=(root/n).resolve()
  assert root.resolve() in p.parents and p.is_file() and sha(p)==d,n
spec=importlib.util.spec_from_file_location('notices',ROOT/'scripts/native_bundle_notices.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
allowed={'THIRD_PARTY_NOTICES.md','third-party/raven-tools/README.md',*[f'third-party/raven-tools/upstream/raven/{n}' for n in ('LICENSE','THIRD-PARTY-NOTICES.txt','source.json')]}
inputs=[('osx-arm64','/tmp/neoclr-preview19-final-macos/neoclr-preview19-osx-arm64.tar.gz','neoclr-native-poc',False),('win-x64','/tmp/neoclr-preview19-final-windows/jit-package/neoclr-native-poc.tar.gz','neoclr-native-poc',False),('build-kit','/tmp/neoclr-preview19-final-build-kit/neoclr-native-build-kit-osx-arm64.tar.gz','neoclr-native-build-kit',True)]
report=dict(passed=False,sourceRevision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),scriptSha256=sha(__file__),archives=[])
for label,original,prefix,kit in inputs:
 stage=OUT/label/'stage'; stage.mkdir(parents=True)
 with tarfile.open(original) as t:t.extractall(stage,filter='data')
 root=stage/prefix; bundle=root/'bundle' if kit else root
 original_manifest_sha=sha(bundle/'manifest.json'); manifest=json.loads((bundle/'manifest.json').read_text()); old=manifest['files']; verify(bundle,old)
 if kit:
  outer=json.loads((root/'native-build-kit.json').read_text());verify(root,outer['files']);old_outer=outer['files']
 for relative in sorted(allowed):
  dest=bundle/relative; dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/relative,dest)
 new={p.relative_to(bundle).as_posix():sha(p) for p in sorted(bundle.rglob('*')) if p.is_file() and p!=bundle/'manifest.json'}
 changes=[n for n in sorted(set(old)|set(new)) if old.get(n)!=new.get(n)]
 assert set(changes)==allowed,changes
 assert set(old)<=set(new)
 manifest['files']=new;(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 if kit:
  outer['bundleManifestSha256']=sha(bundle/'manifest.json')
  outer['files']={p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file() and p!=root/'native-build-kit.json'}
  outer_changes=[n for n in sorted(set(old_outer)|set(outer['files'])) if old_outer.get(n)!=outer['files'].get(n)]
  assert set(outer_changes)=={'bundle/'+n for n in allowed}|{'bundle/manifest.json'},outer_changes
  (root/'native-build-kit.json').write_text(json.dumps(outer,indent=2)+'\n')
 name='neoclr-native-build-kit-osx-arm64.tar.gz' if kit else f'neoclr-preview19-{label}.tar.gz'
 archive=ASSETS/name
 with tarfile.open(archive,'w:gz') as t:t.add(root,arcname=prefix)
 extracted=OUT/label/'extracted'
 with tarfile.open(archive) as t:t.extractall(extracted,filter='data')
 final=extracted/prefix;fb=final/'bundle' if kit else final
 verify(fb,json.loads((fb/'manifest.json').read_text())['files'])
 if kit:verify(final,json.loads((final/'native-build-kit.json').read_text())['files'])
 audit=subprocess.run(['/opt/homebrew/bin/python3',str(ROOT/'docs/experiments/raven-target/verify_tool_notices.py'),'--tools',str(fb)],capture_output=True,text=True,check=True)
 row=dict(name=name,originalArchive=original,originalArchiveSha256=sha(original),archiveSha256=sha(archive),bytes=archive.stat().st_size,originalManifestSha256=original_manifest_sha,unchangedOriginalFiles=len(old)-len(set(old)&allowed),changedFiles=changes,executableCompilerLibrarySamplePayloadUnchanged=True,noticeAudit=audit.stdout.strip(),extractedPath=str(final))
 report['archives'].append(row);(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(label,'PASS',flush=True)
report['passed']=True;(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
