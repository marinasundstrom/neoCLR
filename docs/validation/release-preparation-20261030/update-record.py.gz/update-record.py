from pathlib import Path
import json,gzip
base=Path('docs/validation/release-preparation-20261030')
assert json.loads((base/'release-manifest.json').read_text())['qualificationPassed']
p=base/'README.md';s=p.read_text()
s=s.replace('Status: **candidate preparation; not approved or published**.','Status: **qualified candidate assets assembled; not published**.')
start=s.index('| Source archive |');end=s.index('\n',start)
s=s[:start]+'| Source archive | Final canonical run 41137959122 passes on 0758082e4, including full tests, source/notices audit, strict Clippy, both host boundaries and all three minimum-Rust jobs. The exact CI source archive is assembled as a release asset. |'+s[end:]
s=s.replace('Notice-only archive refresh remains pending.','Notice-only archive and build-kit refreshes pass extraction, catalog and attribution checks; all executable/compiler/library/sample bytes are preserved.')
s=s.replace('Focused refreshed crypto/JSON/content-copy consumers remain pending.','Focused refreshed crypto/JSON/content-copy consumers and repeated console/client checks pass in 41137958975.')
s=s.replace('Fresh package consumers remain required.','Fresh package consumers now pass on both targets; exact reports are linked below.')
s=s.replace('Candidate archive/VSIX hashes are recorded; published asset identities remain unset.','All 12 final candidate assets are assembled with manifest/checksums; published asset identities remain unset.')
start=s.index('## Remaining work after source sync')
s=s[:start]+'''## Final source, consumer and archive gates

Source/harness/attribution revision `0758082e4ec78bbd9eada3d0a90fb33fb6601015`
passes [canonical run 41137959122](https://github.com/marinasundstrom/neoCLR/actions/runs/41137959122)
([source report](canonical-source-0758082e4.json.gz), [workflow receipt](canonicalSource-workflow.json)).
The release source asset is that exact CI archive. The later documentation/evidence
snapshot also passes [membership and attribution review](source-head-audit.json.gz);
it does not replace the independently tested source archive.

[Focused Windows run 41137958975](https://github.com/marinasundstrom/neoCLR/actions/runs/41137958975)
passes [console/faults](windows-focused-console.json.gz),
[14 HTTP-client cases](windows-focused-client.json.gz),
[public cryptography](windows-focused-crypto.json.gz),
[expanded JSON](windows-focused-json.json.gz) and
[all eight content-copy tests](windows-focused-content-copy.json.gz).
Content-copy interpreter execution takes 130.057 seconds within its 600-second budget;
assertions are unchanged. [Package provenance](windows-focused-package-run.json.gz)
and the [workflow receipt](windowsFocusedConsumers-workflow.json) identify the inputs.

The [notice-only refresh](notice-refresh.json.gz) of both native archives and the
macOS build kit passes fresh extraction, complete file-catalog verification and the
strengthened 27-NuGet/35-package-set plus Raven-upstream notice audit. Exactly five
attribution paths change or are added, plus the corresponding catalogs. Every
executable, compiler, library and sample byte remains equal to the qualified originals;
[Unix executable modes are preserved](archive-executable-modes.json). The original archives remain available under
the identities in the report. A [rejected first refresh](notice-refresh-rejected.log.gz)
changed Windows line endings beyond that scope and was not used.
The [retained refresh script](notice-refresh.py.gz) documents the corrected process.

Separate SDK archives, VSIX files and companion-notice archives pass
[asset assembly checks](asset-assembly.json.gz): each SDK's 469 files match the
qualified bundle, each VSIX retains its qualified hash and each notice archive
contains 61 verified files. [Assembly script](asset-assembly.py.gz).

The 12 candidate assets are assembled under the ignored local directory
`target/releases/preview19-20261030/`. The [release manifest](release-manifest.json)
records payload/source revisions, original-to-refreshed hashes, prerequisites,
platform limits and exact gates. [SHA256SUMS](SHA256SUMS) verifies all 11 other files;
[the inventory](candidate-artifact-hashes.json) also retains earlier candidates.
Source tests and runtime measurements apply to the explicitly identified original
payloads; attribution-only derivation is established by the file-hash comparison.
No tag, GitHub release, release-asset upload or website deployment has occurred.
Publication and its date remain unset. Python behavior-fixture migration remains
deferred until after release.
'''
p.write_text(s)
p=Path('docs/next-preview-release-notes.md');s=p.read_text().replace('for exact inputs, failures and remaining gates.','for exact inputs, preserved failures and completed qualification gates.')
s=s.replace('Windows execution and packaged reload\nqualification remain release gates.','Windows execution and packaged reload\nqualification pass on the matching candidate bundle.')
s=s.replace('Source validation, extracted packages,\neditor, HTTPS, Windows watcher/reload behavior and release measurements must pass\nbefore publication. Preserve optional PostgreSQL on macOS only if the matching\npackage passes its existing acceptance.','Source validation, extracted packages,\neditor, HTTPS, Windows watcher/reload behavior and five-round release measurements\npass. Optional PostgreSQL is preserved and qualified on macOS. Final notice-refreshed\narchives, separate SDK/VSIX assets and companion notices are assembled with verified\nchecksums; publication remains pending.')
p.write_text(s)
p=Path('docs/platform-roadmap.md');s=p.read_text().replace('Publication remains pending; this release task does not permanently reorder the roadmap.','The final source/package checks and notice-only archive refreshes pass; candidate assets and checksums are assembled. Publication remains pending; this release task does not permanently reorder the roadmap.',1);p.write_text(s)
p=Path('CHANGELOG.md');s=p.read_text().replace('for both targets; preserve timeout attempts and keep final attribution archive assembly pending.','for both targets; preserve timeout attempts. Complete the final canonical source and focused\n  Windows consumer checks, refresh license-notice archives with executable payload equality,\n  and assemble all 12 candidate assets with verified manifest/checksums; publication remains pending.')
s=s.replace('the final versioned macOS build kit passes console/HTTP checks; remaining\n  package and dependent checks stay under qualification before publication.','the final versioned macOS build kit passes console/HTTP checks; final\n  package and dependent checks now pass before publication.')
# Match capitalized existing sentence as well.
s=s.replace('The final versioned macOS build kit passes console/HTTP checks; remaining\n  package and dependent checks stay under qualification before publication.','The final versioned macOS build kit passes console/HTTP checks; final\n  package and dependent checks now pass before publication.')
p.write_text(s)
print('Updated release evidence, draft notes, roadmap and changelog')
