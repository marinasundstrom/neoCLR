from pathlib import Path
import json,hashlib,shutil,gzip,subprocess
root=Path('/Users/robert/Projects/neoclr')
base=Path('/tmp/neoclr-preview19-notice-refresh-verified')
assets=base/'assets'
evidence=root/'docs/validation/release-preparation-20261030'
canonical=Path('/tmp/neoclr-preview19-final-source-0758082e4')
revision='0758082e4ec78bbd9eada3d0a90fb33fb6601015'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
checks={}
for key,run in [('canonicalSource',41137959122),('windowsFocusedConsumers',41137958975)]:
 d=json.loads(subprocess.check_output(['gh','run','view',str(run),'--json','status,conclusion,headSha,url,jobs']))
 assert d['status']=='completed' and d['conclusion']=='success' and d['headSha']==revision,(key,d)
 checks[key]=run
 save(evidence/(key+'-workflow.json'),d)
r=read(canonical/'report.json');assert r['status']=='passed' and r['commit']==revision,r
assert sha(canonical/'neoclr-source.tar')==r['archive_sha256']
shutil.copy2(canonical/'neoclr-source.tar',assets/'neoclr-preview19-qualified-source.tar')
(evidence/'canonical-source-0758082e4.json.gz').write_bytes(gzip.compress((canonical/'report.json').read_bytes(),mtime=0))
refresh=read(base/'report.json');assembly=read(base/'asset-assembly.json')
assert refresh['passed'] and assembly['passed']
for a in refresh['archives']:assert sha(assets/a['name'])==a['archiveSha256']
checks.update(windowsPackageQualification=41130221734,windowsConsole=41130577126,windowsHttps=41130576963,windowsClient=41135630963,windowsBenchmarks=41130708329)
manifest={
 'release':'v0.1.0-preview.19','status':'qualified candidate; not published','qualificationPassed':True,'releaseDate':None,
 'packageVersion':'0.1.19-neoclr.20261030.1','ravenRevision':'6ceeb1be8790e105a1394cb99fded41fafad5b4c',
 'runtimeCodeRevision':'a079cffdffea9d9c69f7eb8c55a7b24981281c72','qualifiedSourceRevision':revision,'windowsQualificationRevision':revision,
 'macOSBenchmarkRevision':'5ccf78581d45e633b3990aaf3acb6273117fef72','windowsBenchmarkRevision':'4ca2b990bc2356ae159735976091495c9e793af0',
 'sourceDelta':'Runtime payloads built from a079cffd; later source changes repair release harnesses/consumer fixtures and add attribution. The source asset is the exact canonical CI archive at 0758082e4. Current preparation commits only add documentation/evidence. Refreshed archives retain every executable, compiler, library and sample byte of the qualified original archives.',
 'assetsSha256':{p.name:sha(p) for p in sorted(assets.iterdir()) if p.is_file() and p.name not in ('release-manifest.json','SHA256SUMS')},
 'platforms':{p['platform']:{'manifestSha256':p['bundleManifestSha256'],'manifestFilesVerified':2593 if p['platform']=='osx-arm64' else 2588,'includesPostgreSQL':p['platform']=='osx-arm64','sdkMatchedFiles':p['sdkFilesVerified'],'companionNoticeFiles':p['noticeFilesVerified']} for p in assembly['platforms']},
 'checks':checks,'noticeRefresh':refresh['archives'],
 'prerequisites':{'sdk':'.NET 10 and .NET 11 SDKs; packaged tool runtime is Microsoft.NETCore.App 11.0.0-rc.1.26425.128','nativeBuilds':{'osx-arm64':'Xcode command-line tools','win-x64':'MSVC x64 developer environment'}},
 'macOSMeasurements':'docs/validation/release-preparation-20261030/macos-final-benchmarks.json.gz',
 'windowsMeasurements':'docs/validation/release-preparation-20261030/windows-final-benchmarks.json.gz',
 'evidence':'docs/validation/release-preparation-20261030/README.md',
 'limitations':[
 'Eager JIT and synchronous GC remain defaults; concurrent/shared-worker and lazy-JIT experiments do not establish general performance claims.',
 'macOS measurements use a loaded development host; cross-host measurements are not controlled speedup comparisons.',
 'Windows native file output remains unsupported. PostgreSQL is included and qualified on macOS only.',
 'Expanded native JSON mapper consumers currently require HTTP host bindings; minimal-host retention remains a gap.',
 'Native signal execution remains blocked by unit boxing; Neo.Signals is excluded from the standard library bundle.',
 'HTTP callback faults allow only the two documented native entry callers after shared inner frames; causal async stack stitching remains limited.',
 'Separate SDK and VSIX dependency attribution is supplied in the matching companion raven-tool-notices archives.'
 ]}
assert len(manifest['assetsSha256'])==10
save(assets/'release-manifest.json',manifest)
(assets/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(assets.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
dest=root/'target/releases/preview19-20261030';assert not dest.exists(),dest
shutil.copytree(assets,dest)
for p in assets.iterdir():assert sha(p)==sha(dest/p.name)
subprocess.run(['shasum','-a','256','-c','SHA256SUMS'],cwd=dest,check=True)
shutil.copy2(dest/'release-manifest.json',evidence/'release-manifest.json');shutil.copy2(dest/'SHA256SUMS',evidence/'SHA256SUMS')
inventory=read(evidence/'candidate-artifact-hashes.json')
inventory['status']='Final qualified candidate assets assembled; original qualification archives preserved; not published'
inventory['finalAssets']=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(dest.iterdir())]
save(evidence/'candidate-artifact-hashes.json',inventory)
print('PASS: 12 candidate release assets assembled and verified at',dest)
