from pathlib import Path
import hashlib,json,shutil,tarfile
OUT=Path('/tmp/neoclr-preview19-notice-refresh-verified');assets=OUT/'assets';version='0.1.19-neoclr.20261030.1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
report=dict(passed=False,platforms=[])
for host in ['osx-arm64','win-x64']:
 bundle=OUT/host/'extracted/neoclr-native-poc';manifest=json.loads((bundle/'manifest.json').read_text());assert (bundle/'sdk/VERSION').read_text().strip()==version
 prefix=f'raven-sdk-{version}-{host}';archive=assets/(prefix+'.tar.gz')
 with tarfile.open(archive,'w:gz') as t:t.add(bundle/'sdk',arcname=prefix)
 verify=OUT/host/'sdk-extracted'
 with tarfile.open(archive) as t:t.extractall(verify,filter='data')
 expected={n.removeprefix('sdk/'):h for n,h in manifest['files'].items() if n.startswith('sdk/')}
 actual={p.relative_to(verify/prefix).as_posix():sha(p) for p in (verify/prefix).rglob('*') if p.is_file()}
 assert actual==expected
 vsix=assets/f'raven-{version}-{host}.vsix';shutil.copy2(bundle/'editor/raven-vscode.vsix',vsix);assert sha(vsix)==manifest['files']['editor/raven-vscode.vsix']
 notice=OUT/host/'companion/raven-tool-notices';notice.mkdir(parents=True)
 shutil.copytree(bundle/'third-party/raven-tools',notice/'third-party/raven-tools')
 for n in ['LICENSE','THIRD-PARTY-NOTICES.txt']:shutil.copy2(bundle/'third-party/raven-tools/upstream/raven'/n,notice/n)
 (notice/'provenance.json').write_text(json.dumps(dict(platform=host,packageVersion=version,compilerRevision='6ceeb1be8790e105a1394cb99fded41fafad5b4c',bundleManifestSha256=sha(bundle/'manifest.json')),indent=2)+'\n')
 narchive=assets/f'raven-tool-notices-{host}.tar.gz'
 with tarfile.open(narchive,'w:gz') as t:t.add(notice,arcname='raven-tool-notices')
 nv=OUT/host/'companion-extracted'
 with tarfile.open(narchive) as t:t.extractall(nv,filter='data')
 nfiles={p.relative_to(notice).as_posix():sha(p) for p in notice.rglob('*') if p.is_file()}
 assert nfiles=={p.relative_to(nv/'raven-tool-notices').as_posix():sha(p) for p in (nv/'raven-tool-notices').rglob('*') if p.is_file()}
 report['platforms'].append(dict(platform=host,sdkFilesVerified=len(actual),sdkArchiveSha256=sha(archive),vsixSha256=sha(vsix),noticeFilesVerified=len(nfiles),noticeArchiveSha256=sha(narchive),bundleManifestSha256=sha(bundle/'manifest.json')))
 print(host,'SDK/VSIX/notices passed',flush=True)
report['passed']=True;(OUT/'asset-assembly.json').write_text(json.dumps(report,indent=2)+'\n')
