from pathlib import Path
import hashlib, importlib.util, json, subprocess, tarfile
root=Path('/Users/robert/Projects/neoclr'); out=Path('/tmp/neoclr-preview19-source-review');out.mkdir(exist_ok=False)
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();base='0758082e4ec78bbd9eada3d0a90fb33fb6601015'
delta=subprocess.check_output(['git','diff','--name-only',base,revision],cwd=root,text=True).splitlines()
assert all(n.endswith('.md') or n.startswith('docs/validation/release-preparation-20261030/') for n in delta),delta
archive=Path('/tmp/neoclr-preview19-notice-refresh-verified/assets/neoclr-preview19-qualified-source.tar')
subprocess.run(['git','archive','--format=tar','--prefix=neoclr-source/','--output='+str(archive),revision],cwd=root,check=True)
expected=set(subprocess.check_output(['git','ls-tree','-r','--name-only',revision],cwd=root,text=True).splitlines())
with tarfile.open(archive) as t:
 actual=set()
 for m in t.getmembers():
  p=Path(m.name); assert not p.is_absolute() and '..' not in p.parts and p.parts[0]=='neoclr-source'
  assert m.isfile() or m.isdir()
  if m.isfile(): actual.add(p.relative_to('neoclr-source').as_posix())
 assert actual==expected
 t.extractall(out,filter='data')
source=(out/'neoclr-source').resolve();spec=importlib.util.spec_from_file_location('release_validation',source/'scripts/validate-release.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);packages,notices=mod.audit_notices(source)
r=subprocess.run(['/opt/homebrew/bin/python3',str(source/'docs/experiments/raven-target/verify_tool_notices.py'),'--root',str(source),'--tools','/tmp/neoclr-preview19-final-macos/extracted/neoclr-native-poc/sdk'],capture_output=True,text=True,check=True)
h=hashlib.sha256()
with archive.open('rb') as f:
 for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
report=dict(passed=True,scope='Source archive membership, attribution and documentation-only delta; full executable tests belong to the separately identified canonical run',revision=revision,canonicalRevision=base,canonicalRun=41137959122,documentationOnlyDelta=delta,archive=str(archive),archiveSha256=h.hexdigest(),trackedFiles=len(actual),registryPackages=packages,noticeFiles=notices,toolNotices=r.stdout.strip())
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('Source archive audit passed',len(actual))
