	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 27, 0	sdk_version 27, 0
	.globl	_neoclr_socket_deadline_after_v1 ; -- Begin function neoclr_socket_deadline_after_v1
	.p2align	2
_neoclr_socket_deadline_after_v1:       ; @neoclr_socket_deadline_after_v1
	.cfi_startproc
; %bb.0:
	mov	w8, #-60001                     ; =0xffff159f
	mov	w9, #-60000                     ; =0xffff15a0
	add	w8, w0, w8
	cmp	w8, w9
	ccmp	x1, #0, #4, hs
	ccmp	x2, #0, #4, ne
	b.ne	LBB0_2
; %bb.1:
	mov	w0, #3                          ; =0x3
	ret
LBB0_2:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x0
	mov	x19, x2
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbnz	w8, LBB0_9
; %bb.3:
	mov	w21, #51712                     ; =0xca00
	movk	w21, #15258, lsl #16
	ldp	x8, x9, [sp]
	madd	x8, x8, x21, x9
	cbz	x8, LBB0_9
; %bb.4:
Lloh0:
	adrp	x9, _network_origin@PAGE
Lloh1:
	ldr	x22, [x9, _network_origin@PAGEOFF]
	cbnz	x22, LBB0_6
; %bb.5:
	mov	x9, #0                          ; =0x0
Lloh2:
	adrp	x10, _network_origin@PAGE
Lloh3:
	add	x10, x10, _network_origin@PAGEOFF
	cas	x9, x8, [x10]
	cmp	x9, #0
	csel	x22, x8, x9, eq
LBB0_6:
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x8, x9, [sp]
	madd	x8, x8, x21, x9
	cmp	w0, #0
	csel	x8, x8, xzr, eq
	cmp	x8, #0
	ccmp	x8, x22, #0, ne
	b.hs	LBB0_8
; %bb.7:
	mov	w0, #3                          ; =0x3
	b	LBB0_9
LBB0_8:
	mov	w0, #0                          ; =0x0
	sub	x8, x8, x22
	mov	x9, #13531                      ; =0x34db
	movk	x9, #55222, lsl #16
	movk	x9, #56962, lsl #32
	movk	x9, #17179, lsl #48
	umulh	x9, x8, x9
	lsr	x9, x9, #18
	mov	w10, #16960                     ; =0x4240
	movk	w10, #15, lsl #16
	msub	x8, x9, x10, x8
	cmp	x8, #0
	add	x8, x9, w20, uxtw
	cinc	x8, x8, ne
	str	x8, [x19]
LBB0_9:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function monotonic_ns
_monotonic_ns:                          ; @monotonic_ns
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp]
	madd	x8, x9, x8, x10
	cmp	w0, #0
	csel	x0, x8, xzr, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_deadline_expired_v1 ; -- Begin function neoclr_socket_deadline_expired_v1
	.p2align	2
_neoclr_socket_deadline_expired_v1:     ; @neoclr_socket_deadline_expired_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x0
	mov	w0, #3                          ; =0x3
	cbz	x1, LBB2_10
; %bb.1:
	mov	x19, x2
	cbz	x2, LBB2_10
; %bb.2:
	mov	w21, #51712                     ; =0xca00
	movk	w21, #15258, lsl #16
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x8, x9, [sp]
	madd	x8, x8, x21, x9
	cmp	w0, #0
	csel	x8, x8, xzr, eq
	mov	w0, #3                          ; =0x3
	tbnz	x20, #63, LBB2_10
; %bb.3:
	cbz	x8, LBB2_10
; %bb.4:
Lloh4:
	adrp	x9, _network_origin@PAGE
Lloh5:
	ldr	x22, [x9, _network_origin@PAGEOFF]
	cbnz	x22, LBB2_6
; %bb.5:
	mov	x9, #0                          ; =0x0
Lloh6:
	adrp	x10, _network_origin@PAGE
Lloh7:
	add	x10, x10, _network_origin@PAGEOFF
	cas	x9, x8, [x10]
	cmp	x9, #0
	csel	x22, x8, x9, eq
LBB2_6:
	mvn	x8, x22
	mov	x9, #13531                      ; =0x34db
	movk	x9, #55222, lsl #16
	movk	x9, #56962, lsl #32
	movk	x9, #17179, lsl #48
	umulh	x8, x8, x9
	cmp	x20, x8, lsr #18
	b.hi	LBB2_10
; %bb.7:
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbnz	w8, LBB2_10
; %bb.8:
	ldp	x8, x9, [sp]
	madd	x8, x8, x21, x9
	cbz	x8, LBB2_10
; %bb.9:
	mov	w0, #0                          ; =0x0
	mov	w9, #16960                      ; =0x4240
	movk	w9, #15, lsl #16
	madd	x9, x20, x9, x22
	cmp	x8, x9
	cset	w8, hs
	str	w8, [x19]
LBB2_10:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_scope_enter_v1   ; -- Begin function neoclr_socket_scope_enter_v1
	.p2align	2
_neoclr_socket_scope_enter_v1:          ; @neoclr_socket_scope_enter_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB3_11
; %bb.1:
	cbz	x1, LBB3_11
; %bb.2:
Lloh8:
	adrp	x0, _head@TLVPPAGE
Lloh9:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x20, x0
	ldr	x8, [x0]
	cbz	x8, LBB3_9
; %bb.3:
	mov	x9, x8
LBB3_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9]
	cmp	x10, x1
	b.eq	LBB3_10
; %bb.5:                                ;   in Loop: Header=BB3_4 Depth=1
	ldr	x9, [x9, #8]
	cbnz	x9, LBB3_4
; %bb.6:
	cbz	x8, LBB3_9
LBB3_7:                                 ; =>This Inner Loop Header: Depth=1
	cmp	x8, x19
	b.eq	LBB3_10
; %bb.8:                                ;   in Loop: Header=BB3_7 Depth=1
	ldr	x8, [x8, #8]
	cbnz	x8, LBB3_7
LBB3_9:
	mov	x0, x19
	mov	x21, x1
	mov	w1, #12384                      ; =0x3060
	bl	_bzero
	mov	w0, #0                          ; =0x0
	str	x21, [x19]
	ldr	x8, [x20]
	str	x8, [x19, #8]
	str	x19, [x20]
	b	LBB3_11
LBB3_10:
	mov	w0, #3                          ; =0x3
LBB3_11:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_scope_leave_v1   ; -- Begin function neoclr_socket_scope_leave_v1
	.p2align	2
_neoclr_socket_scope_leave_v1:          ; @neoclr_socket_scope_leave_v1
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cbz	x0, LBB4_6
; %bb.1:
	mov	x19, x0
Lloh10:
	adrp	x0, _head@TLVPPAGE
Lloh11:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	mov	w21, #3                         ; =0x3
	cmp	x8, x19
	b.ne	LBB4_31
; %bb.2:
	mov	x20, x0
	mov	x23, #0                         ; =0x0
	mov	w22, #0                         ; =0x0
	b	LBB4_4
LBB4_3:                                 ;   in Loop: Header=BB4_4 Depth=1
	str	xzr, [x24, #16]
	add	x23, x23, #16
	cmp	x23, #1024
	b.eq	LBB4_7
LBB4_4:                                 ; =>This Inner Loop Header: Depth=1
	add	x24, x19, x23
	ldr	x8, [x24, #16]
	cbz	x8, LBB4_3
; %bb.5:                                ;   in Loop: Header=BB4_4 Depth=1
	ldr	w0, [x24, #24]
	bl	_close
	cmp	w0, #0
	csel	w22, w22, w21, eq
	b	LBB4_3
LBB4_6:
	mov	w21, #3                         ; =0x3
	b	LBB4_31
LBB4_7:
	ldr	x21, [x19, #12304]
	cbz	x21, LBB4_10
; %bb.8:
	mov	w23, #3                         ; =0x3
LBB4_9:                                 ; =>This Inner Loop Header: Depth=1
	ldp	x8, x1, [x21]
	str	x8, [x19, #12304]
	ldr	x0, [x19]
	bl	_neoclr_gc_host_root_release_v1
	cmp	w0, #0
	csel	w22, w22, w23, eq
	mov	x0, x21
	bl	_free
	ldr	x21, [x19, #12304]
	cbnz	x21, LBB4_9
LBB4_10:
	str	xzr, [x19, #12312]
	ldr	x1, [x19, #12320]
	cbz	x1, LBB4_12
; %bb.11:
	ldr	x0, [x19]
	bl	_neoclr_gc_host_root_release_v1
	mov	w8, #3                          ; =0x3
	cmp	w0, #0
	csel	w22, w22, w8, eq
LBB4_12:
	str	xzr, [x19, #12320]
	ldr	x1, [x19, #12336]
	cbz	x1, LBB4_14
; %bb.13:
	ldr	x0, [x19]
	bl	_neoclr_gc_host_root_release_v1
	mov	w8, #3                          ; =0x3
	cmp	w0, #0
	csel	w22, w22, w8, eq
LBB4_14:
	str	xzr, [x19, #12336]
	mov	w8, #12352                      ; =0x3040
	add	x21, x19, x8
	ldr	x1, [x19, #12352]
	cbz	x1, LBB4_16
; %bb.15:
	ldr	x0, [x19]
	bl	_neoclr_gc_host_root_release_v1
	mov	w8, #3                          ; =0x3
	cmp	w0, #0
	csel	w22, w22, w8, eq
LBB4_16:
	stp	xzr, xzr, [x21]
	mov	x23, #-11264                    ; =0xffffffffffffd400
	mov	w24, #12304                     ; =0x3010
	mov	w25, #-1                        ; =0xffffffff
	mov	w26, #3                         ; =0x3
	mov	x21, x22
	b	LBB4_18
LBB4_17:                                ;   in Loop: Header=BB4_18 Depth=1
	add	x8, x22, x24
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
	adds	x23, x23, #176
	b.eq	LBB4_30
LBB4_18:                                ; =>This Inner Loop Header: Depth=1
	add	x22, x19, x23
	ldr	x1, [x22, #12320]
	cbz	x1, LBB4_20
; %bb.19:                               ;   in Loop: Header=BB4_18 Depth=1
	ldr	x0, [x19]
	bl	_neoclr_gc_host_root_release_v1
	cmp	w0, #0
	csel	w21, w21, w26, eq
LBB4_20:                                ;   in Loop: Header=BB4_18 Depth=1
	ldr	x0, [x22, #12384]
	cbz	x0, LBB4_23
; %bb.21:                               ;   in Loop: Header=BB4_18 Depth=1
	ldaddal	w25, w8, [x0]
	cmp	w8, #1
	b.ne	LBB4_23
; %bb.22:                               ;   in Loop: Header=BB4_18 Depth=1
	bl	_free
LBB4_23:                                ;   in Loop: Header=BB4_18 Depth=1
	str	xzr, [x22, #12384]
	add	x27, x19, x23
	ldr	w8, [x27, #12364]
	cmp	w8, #4
	b.ne	LBB4_26
; %bb.24:                               ;   in Loop: Header=BB4_18 Depth=1
	ldr	w0, [x27, #12392]
	cmn	w0, #1
	b.eq	LBB4_26
; %bb.25:                               ;   in Loop: Header=BB4_18 Depth=1
	bl	_close
	str	w25, [x27, #12392]
LBB4_26:                                ;   in Loop: Header=BB4_18 Depth=1
	ldr	x1, [x27, #12344]
	cbz	x1, LBB4_28
; %bb.27:                               ;   in Loop: Header=BB4_18 Depth=1
	ldr	x0, [x19]
	bl	_neoclr_gc_host_root_release_v1
	str	xzr, [x27, #12344]
LBB4_28:                                ;   in Loop: Header=BB4_18 Depth=1
	add	x27, x19, x23
	ldr	x0, [x27, #12376]
	cbz	x0, LBB4_17
; %bb.29:                               ;   in Loop: Header=BB4_18 Depth=1
	bl	_free
	str	xzr, [x27, #12376]
	ldr	w8, [x27, #12372]
	ldr	x9, [x19, #12368]
	sub	x8, x9, x8
	str	x8, [x19, #12368]
	b	LBB4_17
LBB4_30:
	ldr	x8, [x19, #8]
	str	x8, [x20]
	stp	xzr, xzr, [x19]
LBB4_31:
	mov	x0, x21
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function release_client
_release_client:                        ; @release_client
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w1, w8, x0
	add	x19, x8, #1040
	ldr	x0, [x8, #1120]
	cbz	x0, LBB5_3
; %bb.1:
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x0]
	cmp	w8, #1
	b.ne	LBB5_3
; %bb.2:
	bl	_free
LBB5_3:
	str	xzr, [x19, #80]
	ldr	w8, [x19, #60]
	cmp	w8, #4
	b.ne	LBB5_6
; %bb.4:
	ldr	w0, [x19, #88]
	cmn	w0, #1
	b.eq	LBB5_6
; %bb.5:
	bl	_close
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x19, #88]
LBB5_6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function release_transfer
_release_transfer:                      ; @release_transfer
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w1, w8, x0
	add	x20, x8, #1040
	ldr	x1, [x8, #1080]
	cbz	x1, LBB6_2
; %bb.1:
	ldr	x0, [x19]
	bl	_neoclr_gc_host_root_release_v1
	str	xzr, [x20, #40]
LBB6_2:
	ldr	x0, [x20, #72]
	cbz	x0, LBB6_4
; %bb.3:
	bl	_free
	str	xzr, [x20, #72]
	ldr	w8, [x20, #68]
	ldr	x9, [x19, #12368]
	sub	x8, x9, x8
	str	x8, [x19, #12368]
LBB6_4:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function neoclr_socket_listen_v1
lCPI7_0:
	.quad	2                               ; 0x2
	.quad	6                               ; 0x6
lCPI7_1:
	.quad	2                               ; 0x2
	.quad	4                               ; 0x4
lCPI7_2:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_socket_listen_v1
	.p2align	2
_neoclr_socket_listen_v1:               ; @neoclr_socket_listen_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x8, x0
Lloh12:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh13:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh14:
	ldr	x9, [x9]
	str	x9, [sp, #40]
Lloh15:
	adrp	x0, _head@TLVPPAGE
Lloh16:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cbz	x9, LBB7_3
LBB7_1:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9]
	cmp	x10, x3
	b.eq	LBB7_6
; %bb.2:                                ;   in Loop: Header=BB7_1 Depth=1
	ldr	x9, [x9, #8]
	cbnz	x9, LBB7_1
LBB7_3:
	mov	w0, #3                          ; =0x3
LBB7_4:
	ldr	x8, [sp, #40]
Lloh17:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh18:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh19:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB7_44
; %bb.5:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB7_6:
	mov	w0, #3                          ; =0x3
	cbz	x8, LBB7_4
; %bb.7:
	cbz	x4, LBB7_4
; %bb.8:
	ldr	x10, [x8]
	sub	x11, x10, #16
	cmn	x11, #16
	b.hi	LBB7_10
; %bb.9:
	mov	w0, #0                          ; =0x0
Lloh20:
	adrp	x8, lCPI7_0@PAGE
Lloh21:
	ldr	q0, [x8, lCPI7_0@PAGEOFF]
	str	q0, [x4]
	b	LBB7_4
LBB7_10:
	mov	w12, #0                         ; =0x0
	mov	w13, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	add	x8, x8, #8
	add	x15, sp, #24
	mov	w16, #10                        ; =0xa
	b	LBB7_13
LBB7_11:                                ;   in Loop: Header=BB7_13 Depth=1
	add	w14, w14, #1
LBB7_12:                                ;   in Loop: Header=BB7_13 Depth=1
	add	x11, x11, #1
	cmp	x11, x10
	b.hi	LBB7_22
LBB7_13:                                ; =>This Inner Loop Header: Depth=1
	cmp	x10, x11
	b.eq	LBB7_15
; %bb.14:                               ;   in Loop: Header=BB7_13 Depth=1
	ldrb	w17, [x8, x11]
	cmp	w17, #46
	b.ne	LBB7_18
LBB7_15:                                ;   in Loop: Header=BB7_13 Depth=1
	cbz	w14, LBB7_29
; %bb.16:                               ;   in Loop: Header=BB7_13 Depth=1
	cmp	w12, #4
	b.eq	LBB7_29
; %bb.17:                               ;   in Loop: Header=BB7_13 Depth=1
	mov	w14, #0                         ; =0x0
	str	w13, [x15, w12, uxtw #2]
	add	w12, w12, #1
	mov	w13, #0                         ; =0x0
	b	LBB7_12
LBB7_18:                                ;   in Loop: Header=BB7_13 Depth=1
	sub	w0, w17, #58
	cmn	w0, #10
	b.lo	LBB7_29
; %bb.19:                               ;   in Loop: Header=BB7_13 Depth=1
	cmp	w14, #0
	ccmp	w13, #0, #0, ne
	cset	w0, eq
	cmp	w14, #3
	b.eq	LBB7_29
; %bb.20:                               ;   in Loop: Header=BB7_13 Depth=1
	cbnz	w0, LBB7_29
; %bb.21:                               ;   in Loop: Header=BB7_13 Depth=1
	madd	w13, w13, w16, w17
	sub	w13, w13, #48
	cmp	w13, #256
	b.lo	LBB7_11
	b	LBB7_29
LBB7_22:
	cmp	w12, #4
	b.ne	LBB7_29
; %bb.23:
	lsr	w8, w1, #16
	cbnz	w8, LBB7_32
; %bb.24:
	sub	w8, w2, #129
	cmn	w8, #128
	b.lo	LBB7_32
; %bb.25:
	add	x22, x9, #16
	mov	w8, #64                         ; =0x40
LBB7_26:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x22]
	cbz	x9, LBB7_33
; %bb.27:                               ;   in Loop: Header=BB7_26 Depth=1
	add	x22, x22, #16
	subs	x8, x8, #1
	b.ne	LBB7_26
LBB7_28:
Lloh22:
	adrp	x8, lCPI7_1@PAGE
Lloh23:
	ldr	q0, [x8, lCPI7_1@PAGEOFF]
	b	LBB7_30
LBB7_29:
Lloh24:
	adrp	x8, lCPI7_0@PAGE
Lloh25:
	ldr	q0, [x8, lCPI7_0@PAGEOFF]
LBB7_30:
	str	q0, [x4]
LBB7_31:
	mov	w0, #0                          ; =0x0
	b	LBB7_4
LBB7_32:
Lloh26:
	adrp	x8, lCPI7_2@PAGE
Lloh27:
	ldr	q0, [x8, lCPI7_2@PAGEOFF]
	b	LBB7_30
LBB7_33:
Lloh28:
	adrp	x8, _next_id@PAGE
Lloh29:
	ldr	x10, [x8, _next_id@PAGEOFF]
	mov	x8, #9223372036854775807        ; =0x7fffffffffffffff
Lloh30:
	adrp	x9, _next_id@PAGE
Lloh31:
	add	x9, x9, _next_id@PAGEOFF
LBB7_34:                                ; =>This Inner Loop Header: Depth=1
	cmp	x10, x8
	b.hs	LBB7_28
; %bb.35:                               ;   in Loop: Header=BB7_34 Depth=1
	mov	x19, x10
	add	x11, x10, #1
	cas	x10, x11, [x9]
	cmp	x10, x19
	b.ne	LBB7_34
; %bb.36:
	mov	x24, x1
	mov	x21, x2
	mov	x23, x4
	mov	w25, #2                         ; =0x2
	mov	w0, #2                          ; =0x2
	mov	w1, #1                          ; =0x1
	mov	w2, #6                          ; =0x6
	bl	_socket
	cmn	w0, #1
	b.eq	LBB7_42
; %bb.37:
	mov	x20, x0
	stp	xzr, xzr, [sp, #8]
	strb	w25, [sp, #9]
	rev	w8, w24
	lsr	w8, w8, #16
	strh	w8, [sp, #10]
	ldp	w9, w8, [sp, #24]
	lsl	w8, w8, #16
	orr	w8, w8, w9, lsl #24
	ldp	w9, w10, [sp, #32]
	orr	w8, w8, w9, lsl #8
	orr	w8, w8, w10
	rev	w8, w8
	str	w8, [sp, #12]
	bl	_neoclr_os_configure
	cbnz	w0, LBB7_40
; %bb.38:
	add	x1, sp, #8
	mov	x0, x20
	mov	w2, #16                         ; =0x10
	bl	_bind
	cbnz	w0, LBB7_40
; %bb.39:
	mov	x0, x20
	mov	x1, x21
	bl	_listen
	cbz	w0, LBB7_43
LBB7_40:
	bl	___error
	ldr	w19, [x0]
	mov	x0, x20
	bl	_close
	mov	x0, x19
	bl	_error_code
	mov	x19, x0
	mov	w8, #2                          ; =0x2
LBB7_41:
	stp	x8, x19, [x23]
	b	LBB7_31
LBB7_42:
	bl	___error
	ldr	w0, [x0]
	bl	_error_code
	mov	w8, #2                          ; =0x2
	stp	x8, x0, [x23]
	b	LBB7_31
LBB7_43:
	str	x19, [x22]
	mov	w8, #1                          ; =0x1
	stp	w20, w8, [x22, #8]
	mov	w8, #5                          ; =0x5
	b	LBB7_41
LBB7_44:
	bl	___stack_chk_fail
	.loh AdrpLdr	Lloh15, Lloh16
	.loh AdrpLdrGotLdr	Lloh12, Lloh13, Lloh14
	.loh AdrpLdrGotLdr	Lloh17, Lloh18, Lloh19
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpLdr	Lloh28, Lloh29
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function error_code
_error_code:                            ; @error_code
	.cfi_startproc
; %bb.0:
	cmp	w0, #47
	b.le	LBB8_4
; %bb.1:
	cmp	w0, #59
	b.gt	LBB8_8
; %bb.2:
	cmp	w0, #48
	b.eq	LBB8_13
; %bb.3:
	cmp	w0, #54
	b.eq	LBB8_7
	b	LBB8_12
LBB8_4:
	cmp	w0, #1
	b.eq	LBB8_11
; %bb.5:
	cmp	w0, #13
	b.eq	LBB8_11
; %bb.6:
	cmp	w0, #32
	b.ne	LBB8_12
LBB8_7:
	mov	w0, #8                          ; =0x8
	ret
LBB8_8:
	cmp	w0, #60
	b.eq	LBB8_14
; %bb.9:
	cmp	w0, #61
	b.ne	LBB8_12
; %bb.10:
	mov	w0, #7                          ; =0x7
	ret
LBB8_11:
	mov	w0, #9                          ; =0x9
	ret
LBB8_12:
	mov	w0, #11                         ; =0xb
	ret
LBB8_13:
	mov	w0, #13                         ; =0xd
	ret
LBB8_14:
	mov	w0, #10                         ; =0xa
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function neoclr_os_configure
_neoclr_os_configure:                   ; @neoclr_os_configure
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	mov	w1, #3                          ; =0x3
	bl	_fcntl
	mov	x21, x0
	mov	x0, x19
	mov	w1, #1                          ; =0x1
	bl	_fcntl
	mov	x20, x0
	mov	w0, #-1                         ; =0xffffffff
	tbnz	w21, #31, LBB9_5
; %bb.1:
	tbnz	w20, #31, LBB9_5
; %bb.2:
	orr	w8, w21, #0x4
	str	x8, [sp]
	mov	x0, x19
	mov	w1, #4                          ; =0x4
	bl	_fcntl
	tbnz	w0, #31, LBB9_4
; %bb.3:
	orr	w8, w20, #0x1
	str	x8, [sp]
	mov	x0, x19
	mov	w1, #2                          ; =0x2
	bl	_fcntl
	asr	w0, w0, #31
	b	LBB9_5
LBB9_4:
	mov	w0, #-1                         ; =0xffffffff
LBB9_5:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function neoclr_socket_local_port_v1
lCPI10_0:
	.quad	2                               ; 0x2
	.quad	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_socket_local_port_v1
	.p2align	2
_neoclr_socket_local_port_v1:           ; @neoclr_socket_local_port_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh32:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh33:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh34:
	ldr	x9, [x9]
	str	x9, [sp, #24]
Lloh35:
	adrp	x0, _head@TLVPPAGE
Lloh36:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cbz	x9, LBB10_13
LBB10_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9]
	cmp	x10, x1
	b.eq	LBB10_3
; %bb.2:                                ;   in Loop: Header=BB10_1 Depth=1
	ldr	x9, [x9, #8]
	cbnz	x9, LBB10_1
	b	LBB10_13
LBB10_3:
	cbz	x2, LBB10_13
; %bb.4:
	add	x9, x9, #24
	mov	w10, #64                        ; =0x40
	b	LBB10_6
LBB10_5:                                ;   in Loop: Header=BB10_6 Depth=1
	add	x9, x9, #16
	subs	x10, x10, #1
	b.eq	LBB10_16
LBB10_6:                                ; =>This Inner Loop Header: Depth=1
	cbz	x8, LBB10_5
; %bb.7:                                ;   in Loop: Header=BB10_6 Depth=1
	ldur	x11, [x9, #-8]
	cmp	x11, x8
	b.ne	LBB10_5
; %bb.8:
	mov	x19, x2
	mov	w8, #16                         ; =0x10
	str	w8, [sp, #4]
	ldr	w0, [x9]
	add	x1, sp, #8
	add	x2, sp, #4
	bl	_getsockname
	cbz	w0, LBB10_17
; %bb.9:
	bl	___error
	ldr	w9, [x0]
	cmp	w9, #47
	b.le	LBB10_18
; %bb.10:
	cmp	w9, #59
	b.gt	LBB10_22
; %bb.11:
	cmp	w9, #48
	mov	x8, x19
	b.eq	LBB10_27
; %bb.12:
	cmp	w9, #54
	b.eq	LBB10_21
	b	LBB10_26
LBB10_13:
	mov	w0, #3                          ; =0x3
LBB10_14:
	ldr	x8, [sp, #24]
Lloh37:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh38:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh39:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB10_31
; %bb.15:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB10_16:
	mov	w0, #0                          ; =0x0
Lloh40:
	adrp	x8, lCPI10_0@PAGE
Lloh41:
	ldr	q0, [x8, lCPI10_0@PAGEOFF]
	str	q0, [x2]
	b	LBB10_14
LBB10_17:
	ldrh	w8, [sp, #10]
	rev	w8, w8
	lsr	w9, w8, #16
	mov	w10, #1                         ; =0x1
	mov	x8, x19
	b	LBB10_30
LBB10_18:
	cmp	w9, #1
	mov	x8, x19
	b.eq	LBB10_25
; %bb.19:
	cmp	w9, #13
	b.eq	LBB10_25
; %bb.20:
	cmp	w9, #32
	b.ne	LBB10_26
LBB10_21:
	mov	w9, #8                          ; =0x8
	b	LBB10_29
LBB10_22:
	cmp	w9, #60
	mov	x8, x19
	b.eq	LBB10_28
; %bb.23:
	cmp	w9, #61
	b.ne	LBB10_26
; %bb.24:
	mov	w9, #7                          ; =0x7
	b	LBB10_29
LBB10_25:
	mov	w9, #9                          ; =0x9
	b	LBB10_29
LBB10_26:
	mov	w9, #11                         ; =0xb
	b	LBB10_29
LBB10_27:
	mov	w9, #13                         ; =0xd
	b	LBB10_29
LBB10_28:
	mov	w9, #10                         ; =0xa
LBB10_29:
	mov	w10, #2                         ; =0x2
LBB10_30:
	mov	w0, #0                          ; =0x0
	stp	x10, x9, [x8]
	b	LBB10_14
LBB10_31:
	bl	___stack_chk_fail
	.loh AdrpLdr	Lloh35, Lloh36
	.loh AdrpLdrGotLdr	Lloh32, Lloh33, Lloh34
	.loh AdrpLdrGotLdr	Lloh37, Lloh38, Lloh39
	.loh AdrpLdr	Lloh40, Lloh41
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function neoclr_socket_close_v1
lCPI11_0:
	.quad	2                               ; 0x2
	.quad	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_socket_close_v1
	.p2align	2
_neoclr_socket_close_v1:                ; @neoclr_socket_close_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x0
Lloh42:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh43:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh44:
	ldr	x8, [x8]
	str	x8, [sp, #40]
Lloh45:
	adrp	x0, _head@TLVPPAGE
Lloh46:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x20, [x0]
	cbz	x20, LBB11_16
LBB11_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20]
	cmp	x8, x1
	b.eq	LBB11_3
; %bb.2:                                ;   in Loop: Header=BB11_1 Depth=1
	ldr	x20, [x20, #8]
	cbnz	x20, LBB11_1
	b	LBB11_16
LBB11_3:
	cbz	x2, LBB11_16
; %bb.4:
	mov	x21, #0                         ; =0x0
	b	LBB11_6
LBB11_5:                                ;   in Loop: Header=BB11_6 Depth=1
	add	x21, x21, #16
	cmp	x21, #1024
	b.eq	LBB11_20
LBB11_6:                                ; =>This Inner Loop Header: Depth=1
	cbz	x19, LBB11_5
; %bb.7:                                ;   in Loop: Header=BB11_6 Depth=1
	add	x8, x20, x21
	ldr	x9, [x8, #16]
	cmp	x9, x19
	b.ne	LBB11_5
; %bb.8:
	mov	x22, x2
	str	xzr, [x8, #16]
	mov	x23, #-11264                    ; =0xffffffffffffd400
	mov	w24, #2                         ; =0x2
Lloh47:
	adrp	x8, lCPI11_0@PAGE
Lloh48:
	ldr	q0, [x8, lCPI11_0@PAGEOFF]
	str	q0, [sp]                        ; 16-byte Folded Spill
	mov	w25, #12328                     ; =0x3028
	b	LBB11_10
LBB11_9:                                ;   in Loop: Header=BB11_10 Depth=1
	adds	x23, x23, #176
	b.eq	LBB11_19
LBB11_10:                               ; =>This Inner Loop Header: Depth=1
	add	x8, x20, x23
	ldr	w9, [x8, #12360]
	cmp	w9, #1
	b.ne	LBB11_9
; %bb.11:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	x9, [x8, #12312]
	cmp	x9, x19
	b.ne	LBB11_9
; %bb.12:                               ;   in Loop: Header=BB11_10 Depth=1
	str	w24, [x8, #12360]
	add	x26, x20, x23
	ldr	q0, [sp]                        ; 16-byte Folded Reload
	str	q0, [x26, x25]
	ldr	x1, [x26, #12344]
	cbz	x1, LBB11_14
; %bb.13:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	x0, [x20]
	bl	_neoclr_gc_host_root_release_v1
	str	xzr, [x26, #12344]
LBB11_14:                               ;   in Loop: Header=BB11_10 Depth=1
	ldr	x0, [x26, #12376]
	cbz	x0, LBB11_9
; %bb.15:                               ;   in Loop: Header=BB11_10 Depth=1
	bl	_free
	str	xzr, [x26, #12376]
	add	x8, x20, x23
	ldr	w8, [x8, #12372]
	ldr	x9, [x20, #12368]
	sub	x8, x9, x8
	str	x8, [x20, #12368]
	b	LBB11_9
LBB11_16:
	mov	w0, #3                          ; =0x3
LBB11_17:
	ldr	x8, [sp, #40]
Lloh49:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh50:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh51:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB11_21
; %bb.18:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB11_19:
	add	x8, x20, x21
	ldr	w0, [x8, #24]
	bl	_close
	mov	x2, x22
LBB11_20:
	mov	w0, #0                          ; =0x0
	stp	xzr, xzr, [sp, #24]
	ldur	q0, [sp, #24]
	str	q0, [x2]
	b	LBB11_17
LBB11_21:
	bl	___stack_chk_fail
	.loh AdrpLdr	Lloh45, Lloh46
	.loh AdrpLdrGotLdr	Lloh42, Lloh43, Lloh44
	.loh AdrpLdr	Lloh47, Lloh48
	.loh AdrpLdrGotLdr	Lloh49, Lloh50, Lloh51
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_dns_lookup_v1           ; -- Begin function neoclr_dns_lookup_v1
	.p2align	2
_neoclr_dns_lookup_v1:                  ; @neoclr_dns_lookup_v1
	.cfi_startproc
; %bb.0:
	mov	x4, x3
	mov	x3, x2
	mov	x2, x1
	mov	x1, #0                          ; =0x0
	b	_dns_lookup
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function dns_lookup
lCPI13_0:
	.quad	2                               ; 0x2
	.quad	1                               ; 0x1
lCPI13_1:
	.quad	2                               ; 0x2
	.quad	4                               ; 0x4
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI13_2:
	.long	2                               ; 0x2
	.long	0                               ; 0x0
lCPI13_3:
	.long	1                               ; 0x1
	.long	5                               ; 0x5
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_dns_lookup:                            ; @dns_lookup
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
Lloh52:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh53:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh54:
	ldr	x8, [x8]
	str	x8, [sp, #88]
Lloh55:
	adrp	x0, _head@TLVPPAGE
Lloh56:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB13_3
LBB13_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x3
	b.eq	LBB13_3
; %bb.2:                                ;   in Loop: Header=BB13_1 Depth=1
	ldr	x8, [x8, #8]
	cbnz	x8, LBB13_1
LBB13_3:
	mov	w0, #3                          ; =0x3
	cbz	x4, LBB13_14
; %bb.4:
	cbz	x2, LBB13_14
; %bb.5:
	cbz	x19, LBB13_14
; %bb.6:
	cbz	x8, LBB13_14
; %bb.7:
	ldr	x9, [x19]
	sub	x10, x9, #254
	cmn	x10, #254
	b.ls	LBB13_12
; %bb.8:
	mov	w10, #8                         ; =0x8
	b	LBB13_10
LBB13_9:                                ;   in Loop: Header=BB13_10 Depth=1
	add	x10, x10, #1
	sub	w11, w10, #8
	cmp	w11, w9
	b.hs	LBB13_16
LBB13_10:                               ; =>This Inner Loop Header: Depth=1
	ldrb	w11, [x19, x10]
	and	w12, w11, #0xffffffdf
	sub	w12, w12, #65
	cmp	w12, #26
	b.lo	LBB13_9
; %bb.11:                               ;   in Loop: Header=BB13_10 Depth=1
	sub	w12, w11, #48
	sub	w11, w11, #45
	cmp	w12, #10
	ccmp	w11, #2, #0, hs
	b.lo	LBB13_9
LBB13_12:
	mov	w0, #0                          ; =0x0
Lloh57:
	adrp	x8, lCPI13_0@PAGE
Lloh58:
	ldr	q0, [x8, lCPI13_0@PAGEOFF]
LBB13_13:
	str	q0, [x4]
LBB13_14:
	ldr	x8, [sp, #88]
Lloh59:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh60:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh61:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB13_50
; %bb.15:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB13_16:
	mov	x24, #0                         ; =0x0
	add	x23, x8, #1040
	add	x9, x8, #1096
LBB13_17:                               ; =>This Inner Loop Header: Depth=1
	ldr	w10, [x9], #176
	cbz	w10, LBB13_19
; %bb.18:                               ;   in Loop: Header=BB13_17 Depth=1
	add	x24, x24, #1
	cmp	x24, #64
	b.ne	LBB13_17
LBB13_19:
	mov	w9, #0                          ; =0x0
	add	x8, x8, #1100
	mov	w10, #64                        ; =0x40
	b	LBB13_21
LBB13_20:                               ;   in Loop: Header=BB13_21 Depth=1
	add	w9, w11, w9
	add	x8, x8, #176
	subs	x10, x10, #1
	b.eq	LBB13_23
LBB13_21:                               ; =>This Inner Loop Header: Depth=1
	ldur	w11, [x8, #-4]
	cbz	w11, LBB13_20
; %bb.22:                               ;   in Loop: Header=BB13_21 Depth=1
	ldr	w11, [x8]
	cmp	w11, #5
	cset	w11, eq
	b	LBB13_20
LBB13_23:
	cmp	w24, #64
	b.eq	LBB13_27
; %bb.24:
	cmp	w9, #7
	b.hi	LBB13_27
; %bb.25:
	mov	x26, x1
	mov	x21, x2
	mov	x20, x3
	mov	x25, x4
	mov	w22, #51712                     ; =0xca00
	movk	w22, #15258, lsl #16
	add	x1, sp, #24
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x8, x9, [sp, #24]
	madd	x8, x8, x22, x9
	mov	x9, #61952                      ; =0xf200
	movk	x9, #10757, lsl #16
	movk	x9, #1, lsl #32
	add	x8, x8, x9
	cmp	w0, #0
	csel	x8, x8, x9, eq
	orr	x9, x9, #0x1
	cmp	x8, x9
	b.hs	LBB13_28
; %bb.26:
	mov	w0, #3                          ; =0x3
	b	LBB13_14
LBB13_27:
	mov	w0, #0                          ; =0x0
	mov	w8, #2                          ; =0x2
	dup.2d	v0, x8
	b	LBB13_13
LBB13_28:
	cmp	x8, x26
	csel	x9, x8, x26, lo
	cmp	x26, #0
	csel	x27, x8, x9, eq
	add	x1, sp, #24
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	ldp	x8, x9, [sp, #24]
	madd	x8, x8, x22, x9
	cmp	w0, #0
	csel	x8, x8, xzr, eq
	cmp	x8, x27
	b.hs	LBB13_39
; %bb.29:
Lloh62:
	adrp	x8, _resolver_workers@PAGE
Lloh63:
	ldr	w9, [x8, _resolver_workers@PAGEOFF]
Lloh64:
	adrp	x26, _resolver_workers@PAGE
Lloh65:
	add	x26, x26, _resolver_workers@PAGEOFF
	mov	x8, x25
LBB13_30:                               ; =>This Inner Loop Header: Depth=1
	cmp	w9, #4
	b.hs	LBB13_40
; %bb.31:                               ;   in Loop: Header=BB13_30 Depth=1
	add	w10, w9, #1
	mov	x11, x9
	casal	w11, w10, [x26]
	cmp	w11, w9
	mov	x9, x11
	b.ne	LBB13_30
; %bb.32:
	mov	w0, #1                          ; =0x1
	mov	w1, #336                        ; =0x150
	bl	_calloc
Lloh66:
	adrp	x8, _next_id@PAGE
Lloh67:
	ldr	x11, [x8, _next_id@PAGEOFF]
	mov	x9, #9223372036854775807        ; =0x7fffffffffffffff
Lloh68:
	adrp	x10, _next_id@PAGE
Lloh69:
	add	x10, x10, _next_id@PAGEOFF
	mov	x8, x20
LBB13_33:                               ; =>This Inner Loop Header: Depth=1
	cmp	x11, x9
	b.hs	LBB13_41
; %bb.34:                               ;   in Loop: Header=BB13_33 Depth=1
	mov	x28, x11
	add	x12, x11, #1
	cas	x11, x12, [x10]
	cmp	x11, x28
	b.ne	LBB13_33
; %bb.35:
	str	xzr, [sp, #16]
	cbz	x0, LBB13_42
; %bb.36:
	cbz	x28, LBB13_42
; %bb.37:
	mov	x22, x0
	add	x2, sp, #16
	mov	x0, x8
	mov	x1, x21
	bl	_neoclr_gc_host_root_create_v1
	cbz	w0, LBB13_43
; %bb.38:
	mov	x19, x0
	mov	x0, x22
	bl	_free
	mov	x0, x19
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x26]
	b	LBB13_14
LBB13_39:
	mov	w0, #0                          ; =0x0
Lloh70:
	adrp	x8, lCPI13_1@PAGE
Lloh71:
	ldr	q0, [x8, lCPI13_1@PAGEOFF]
	str	q0, [x25]
	b	LBB13_14
LBB13_40:
	mov	w0, #0                          ; =0x0
	mov	w9, #2                          ; =0x2
	dup.2d	v0, x9
	str	q0, [x8]
	b	LBB13_14
LBB13_41:
	str	xzr, [sp, #16]
LBB13_42:
	bl	_free
	mov	w0, #0                          ; =0x0
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x26]
	mov	w8, #2                          ; =0x2
	dup.2d	v0, x8
	str	q0, [x25]
	b	LBB13_14
LBB13_43:
Lloh72:
	adrp	x8, lCPI13_2@PAGE
Lloh73:
	ldr	d0, [x8, lCPI13_2@PAGEOFF]
	mov	x0, x22
	str	d0, [x0], #8
	ldr	x2, [x19]
	add	x1, x19, #8
	mov	w3, #328                        ; =0x148
	bl	___memcpy_chk
	add	x0, sp, #24
	bl	_pthread_attr_init
	cbnz	w0, LBB13_47
; %bb.44:
	add	x0, sp, #24
	mov	w1, #2                          ; =0x2
	bl	_pthread_attr_setdetachstate
	cbz	w0, LBB13_46
; %bb.45:
	add	x0, sp, #24
	bl	_pthread_attr_destroy
	b	LBB13_47
LBB13_46:
Lloh74:
	adrp	x2, _dns_worker@PAGE
Lloh75:
	add	x2, x2, _dns_worker@PAGEOFF
	add	x0, sp, #8
	add	x1, sp, #24
	mov	x3, x22
	bl	_pthread_create
	mov	x19, x0
	add	x0, sp, #24
	bl	_pthread_attr_destroy
	cbz	w19, LBB13_49
LBB13_47:
	mov	x0, x22
	bl	_free
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x26]
	ldr	x1, [sp, #16]
	mov	x0, x20
	bl	_neoclr_gc_host_root_release_v1
	mov	w8, #2                          ; =0x2
	dup.2d	v0, x8
	str	q0, [x25]
LBB13_48:
	mov	w0, #0                          ; =0x0
	b	LBB13_14
LBB13_49:
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w24, w8, x23
	str	x28, [x8]
Lloh76:
	adrp	x9, lCPI13_3@PAGE
Lloh77:
	ldr	d0, [x9, lCPI13_3@PAGEOFF]
	str	d0, [x8, #56]
	str	x27, [x8, #48]
	str	x22, [x8, #80]
	ldr	x9, [sp, #16]
	str	x9, [x8, #16]
	mov	w8, #5                          ; =0x5
	stp	x8, x28, [x25]
	b	LBB13_48
LBB13_50:
	bl	___stack_chk_fail
	.loh AdrpLdr	Lloh55, Lloh56
	.loh AdrpLdrGotLdr	Lloh52, Lloh53, Lloh54
	.loh AdrpLdr	Lloh57, Lloh58
	.loh AdrpLdrGotLdr	Lloh59, Lloh60, Lloh61
	.loh AdrpAdd	Lloh64, Lloh65
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdd	Lloh68, Lloh69
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpAdd	Lloh74, Lloh75
	.loh AdrpLdr	Lloh76, Lloh77
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_dns_lookup_until_v1     ; -- Begin function neoclr_dns_lookup_until_v1
	.p2align	2
_neoclr_dns_lookup_until_v1:            ; @neoclr_dns_lookup_until_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x4
	mov	x20, x3
	mov	x21, x2
	mov	x23, x1
	mov	x22, x0
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp]
	madd	x8, x9, x8, x10
	cmp	w0, #0
	csel	x8, x8, xzr, eq
	mov	w0, #3                          ; =0x3
	tbnz	x23, #63, LBB14_6
; %bb.1:
	cbz	x8, LBB14_6
; %bb.2:
Lloh78:
	adrp	x9, _network_origin@PAGE
Lloh79:
	ldr	x9, [x9, _network_origin@PAGEOFF]
	cbnz	x9, LBB14_4
; %bb.3:
Lloh80:
	adrp	x10, _network_origin@PAGE
Lloh81:
	add	x10, x10, _network_origin@PAGEOFF
	cas	x9, x8, [x10]
	cmp	x9, #0
	csel	x9, x8, x9, eq
LBB14_4:
	mvn	x8, x9
	mov	x10, #13531                     ; =0x34db
	movk	x10, #55222, lsl #16
	movk	x10, #56962, lsl #32
	movk	x10, #17179, lsl #48
	umulh	x8, x8, x10
	cmp	x23, x8, lsr #18
	b.hi	LBB14_6
; %bb.5:
	mov	w8, #16960                      ; =0x4240
	movk	w8, #15, lsl #16
	madd	x1, x23, x8, x9
	mov	x0, x22
	mov	x2, x21
	mov	x3, x20
	mov	x4, x19
	bl	_dns_lookup
LBB14_6:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpAdd	Lloh80, Lloh81
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function neoclr_dns_cancel_v1
lCPI15_0:
	.quad	2                               ; 0x2
	.quad	5                               ; 0x5
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_dns_cancel_v1
	.p2align	2
_neoclr_dns_cancel_v1:                  ; @neoclr_dns_cancel_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh82:
	adrp	x0, _head@TLVPPAGE
Lloh83:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cbz	x9, LBB15_16
LBB15_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9]
	cmp	x10, x1
	b.eq	LBB15_3
; %bb.2:                                ;   in Loop: Header=BB15_1 Depth=1
	ldr	x9, [x9, #8]
	cbnz	x9, LBB15_1
	b	LBB15_16
LBB15_3:
	cbz	x2, LBB15_16
; %bb.4:
	add	x19, x9, #1128
	mov	w9, #64                         ; =0x40
	b	LBB15_6
LBB15_5:                                ;   in Loop: Header=BB15_6 Depth=1
	add	x19, x19, #176
	subs	x9, x9, #1
	b.eq	LBB15_16
LBB15_6:                                ; =>This Inner Loop Header: Depth=1
	cbz	x8, LBB15_5
; %bb.7:                                ;   in Loop: Header=BB15_6 Depth=1
	ldur	x10, [x19, #-88]
	cmp	x10, x8
	b.ne	LBB15_5
; %bb.8:                                ;   in Loop: Header=BB15_6 Depth=1
	ldur	w10, [x19, #-28]
	cmp	w10, #5
	b.ne	LBB15_5
; %bb.9:
	ldur	w8, [x19, #-32]
	cmp	w8, #1
	cset	w8, eq
	str	w8, [x2]
	b.ne	LBB15_18
; %bb.10:
	mov	w8, #2                          ; =0x2
	stur	w8, [x19, #-32]
Lloh84:
	adrp	x8, lCPI15_0@PAGE
Lloh85:
	ldr	q0, [x8, lCPI15_0@PAGEOFF]
	stur	q0, [x19, #-64]
	ldur	x0, [x19, #-8]
	cbz	x0, LBB15_13
; %bb.11:
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x0]
	cmp	w8, #1
	b.ne	LBB15_13
; %bb.12:
	bl	_free
LBB15_13:
	stur	xzr, [x19, #-8]
	ldur	w8, [x19, #-28]
	cmp	w8, #4
	b.ne	LBB15_18
; %bb.14:
	ldr	w0, [x19]
	cmn	w0, #1
	b.eq	LBB15_18
; %bb.15:
	bl	_close
	mov	w0, #0                          ; =0x0
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x19]
	b	LBB15_17
LBB15_16:
	mov	w0, #3                          ; =0x3
LBB15_17:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB15_18:
	mov	w0, #0                          ; =0x0
	b	LBB15_17
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpLdr	Lloh84, Lloh85
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_dns_result_v1           ; -- Begin function neoclr_dns_result_v1
	.p2align	2
_neoclr_dns_result_v1:                  ; @neoclr_dns_result_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #176
	stp	x28, x27, [sp, #80]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	add	x29, sp, #160
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x8, x0
Lloh86:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh87:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh88:
	ldr	x9, [x9]
	str	x9, [sp, #72]
Lloh89:
	adrp	x0, _head@TLVPPAGE
Lloh90:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x19, [x0]
	cbz	x19, LBB16_13
LBB16_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	cmp	x9, x1
	b.eq	LBB16_3
; %bb.2:                                ;   in Loop: Header=BB16_1 Depth=1
	ldr	x19, [x19, #8]
	cbnz	x19, LBB16_1
	b	LBB16_13
LBB16_3:
	cbz	x2, LBB16_13
; %bb.4:
	mov	x22, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	b	LBB16_6
LBB16_5:                                ;   in Loop: Header=BB16_6 Depth=1
	add	x20, x20, #1
	add	x22, x22, #176
	cmp	x20, #64
	b.eq	LBB16_13
LBB16_6:                                ; =>This Inner Loop Header: Depth=1
	cbz	x8, LBB16_5
; %bb.7:                                ;   in Loop: Header=BB16_6 Depth=1
	add	x9, x19, x22
	ldr	x10, [x9, #1040]
	cmp	x10, x8
	b.ne	LBB16_5
; %bb.8:                                ;   in Loop: Header=BB16_6 Depth=1
	ldr	w9, [x9, #1100]
	cmp	w9, #5
	b.ne	LBB16_5
; %bb.9:
	add	x24, x19, x22
	ldr	w8, [x24, #1096]
	cmp	w8, #3
	b.ne	LBB16_13
; %bb.10:
	ldr	x8, [x24, #1064]
	mov	x23, x2
	cmp	x8, #2
	b.ne	LBB16_16
; %bb.11:
	ldr	x21, [x24, #1072]
	mov	w26, #2                         ; =0x2
LBB16_12:
	add	x8, x19, x22
	ldr	x8, [x8, #1056]
	mov	x0, x1
	mov	x1, x8
	bl	_neoclr_gc_host_root_release_v1
	cbz	w0, LBB16_23
LBB16_13:
	mov	w0, #3                          ; =0x3
LBB16_14:
	ldr	x8, [sp, #72]
Lloh91:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh92:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh93:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB16_26
; %bb.15:
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
LBB16_16:
	add	x8, x19, x22
	ldr	x26, [x8, #1120]
	ldr	w8, [x26, #264]
	mov	x25, x1
	add	x0, x1, #1048
	add	x3, sp, #32
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	bl	_neoclr_allocate_strings_v1
	cbnz	w0, LBB16_14
; %bb.17:
	ldr	w8, [x26, #264]
	cbz	w8, LBB16_24
; %bb.18:
	mov	x27, #0                         ; =0x0
	add	x28, x26, #272
LBB16_19:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x28, x27, lsl #2]
	rev	w8, w8
	lsr	w9, w8, #24
	ubfx	w10, w8, #16, #8
	ubfx	w11, w8, #8, #8
	and	w8, w8, #0xff
	stp	x11, x8, [sp, #16]
	add	x0, sp, #56
	stp	x9, x10, [sp]
	mov	w1, #16                         ; =0x10
Lloh94:
	adrp	x2, l_.str@PAGE
Lloh95:
	add	x2, x2, l_.str@PAGEOFF
	bl	_snprintf
	stp	xzr, xzr, [sp, #40]
	sub	w8, w0, #16
	cmn	w8, #15
	b.lo	LBB16_13
; %bb.20:                               ;   in Loop: Header=BB16_19 Depth=1
	mov	w1, w0
	add	x0, sp, #56
	add	x2, x25, #1048
	add	x3, sp, #40
	bl	_neoclr_text_decode_utf8_bytes_v1
	cbnz	w0, LBB16_14
; %bb.21:                               ;   in Loop: Header=BB16_19 Depth=1
	ldr	x8, [sp, #40]
	cmp	x8, #4
	b.ne	LBB16_13
; %bb.22:                               ;   in Loop: Header=BB16_19 Depth=1
	ldr	x8, [sp, #48]
	ldr	x21, [sp, #32]
	add	w9, w27, #2
	str	x8, [x21, w9, uxtw #3]
	add	x27, x27, #1
	ldr	w8, [x26, #264]
	cmp	x27, x8
	b.lo	LBB16_19
	b	LBB16_25
LBB16_23:
	add	x22, x24, #1040
	mov	x0, x19
	mov	x1, x20
	bl	_release_client
	mov	w0, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x22, #144]
	stp	q0, q0, [x22, #112]
	stp	q0, q0, [x22, #80]
	stp	q0, q0, [x22, #48]
	stp	q0, q0, [x22, #16]
	str	q0, [x22]
	stp	x26, x21, [x23]
	b	LBB16_14
LBB16_24:
	ldr	x21, [sp, #32]
LBB16_25:
	mov	w26, #7                         ; =0x7
	mov	x1, x25
	b	LBB16_12
LBB16_26:
	bl	___stack_chk_fail
	.loh AdrpLdr	Lloh89, Lloh90
	.loh AdrpLdrGotLdr	Lloh86, Lloh87, Lloh88
	.loh AdrpLdrGotLdr	Lloh91, Lloh92, Lloh93
	.loh AdrpAdd	Lloh94, Lloh95
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_dns_addresses_v1        ; -- Begin function neoclr_dns_addresses_v1
	.p2align	2
_neoclr_dns_addresses_v1:               ; @neoclr_dns_addresses_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x8, x0
Lloh96:
	adrp	x0, _head@TLVPPAGE
Lloh97:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cbz	x9, LBB17_3
LBB17_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9]
	cmp	x10, x2
	b.eq	LBB17_5
; %bb.2:                                ;   in Loop: Header=BB17_1 Depth=1
	ldr	x9, [x9, #8]
	cbnz	x9, LBB17_1
LBB17_3:
	mov	w0, #3                          ; =0x3
LBB17_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB17_5:
	mov	w0, #3                          ; =0x3
	cbz	x1, LBB17_4
; %bb.6:
	cmp	w8, #7
	b.ne	LBB17_4
; %bb.7:
	cbz	x3, LBB17_4
; %bb.8:
	ldr	x8, [x1]
	mov	w9, #-2147483645                ; =0x80000003
	cmp	x8, x9
	b.ne	LBB17_4
; %bb.9:
	ldr	x8, [x1, #8]
	cmp	x8, #16
	b.hi	LBB17_4
; %bb.10:
	mov	x20, x1
	mov	x19, x3
	add	x0, x2, #1048
	add	x3, sp, #8
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	bl	_neoclr_allocate_strings_v1
	cbnz	w0, LBB17_4
; %bb.11:
	ldr	x21, [sp, #8]
	mov	x8, x20
	ldr	x9, [x20, #8]
	lsl	x2, x9, #3
	mov	x20, x0
	add	x0, x21, #16
	add	x1, x8, #16
	bl	_memcpy
	mov	x0, x20
	str	x21, [x19]
	b	LBB17_4
	.loh AdrpLdr	Lloh96, Lloh97
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_connect_v1       ; -- Begin function neoclr_socket_connect_v1
	.p2align	2
_neoclr_socket_connect_v1:              ; @neoclr_socket_connect_v1
	.cfi_startproc
; %bb.0:
	mov	x6, x4
	mov	x5, x3
	mov	x4, x2
	mov	x2, x1
	mov	x1, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	b	_connect_addresses
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function connect_addresses
lCPI19_0:
	.quad	2                               ; 0x2
	.quad	4                               ; 0x4
lCPI19_1:
	.quad	2                               ; 0x2
	.quad	10                              ; 0xa
lCPI19_3:
	.quad	2                               ; 0x2
	.quad	6                               ; 0x6
lCPI19_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI19_2:
	.long	1                               ; 0x1
	.long	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_connect_addresses:                     ; @connect_addresses
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x8, x0
Lloh98:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh99:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh100:
	ldr	x9, [x9]
	stur	x9, [x29, #-72]
Lloh101:
	adrp	x0, _head@TLVPPAGE
Lloh102:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cbz	x9, LBB19_3
LBB19_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9]
	cmp	x10, x5
	b.eq	LBB19_6
; %bb.2:                                ;   in Loop: Header=BB19_1 Depth=1
	ldr	x9, [x9, #8]
	cbnz	x9, LBB19_1
LBB19_3:
	mov	w0, #3                          ; =0x3
LBB19_4:
	ldur	x8, [x29, #-72]
Lloh103:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh104:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh105:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB19_96
; %bb.5:
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
LBB19_6:
	mov	w0, #3                          ; =0x3
	orr	x10, x8, x1
	cbz	x10, LBB19_4
; %bb.7:
	cbz	x4, LBB19_4
; %bb.8:
	cbz	x6, LBB19_4
; %bb.9:
	cbz	x8, LBB19_12
; %bb.10:
	sub	w10, w2, #16, lsl #12           ; =65536
	cmn	w10, #16, lsl #12               ; =65536
	b.hi	LBB19_17
LBB19_11:
	mov	w0, #0                          ; =0x0
Lloh106:
	adrp	x8, lCPI19_4@PAGE
Lloh107:
	ldr	q0, [x8, lCPI19_4@PAGEOFF]
	str	q0, [x6]
	b	LBB19_4
LBB19_12:
	ldr	w10, [x1]
	mov	w11, #65533                     ; =0xfffd
	movk	w11, #32767, lsl #16
	add	w10, w10, w11
	cmp	w10, #1
	b.hi	LBB19_4
; %bb.13:
	sub	w10, w2, #16, lsl #12           ; =65536
	mov	w11, #-65535                    ; =0xffff0001
	cmp	w10, w11
	b.lo	LBB19_11
; %bb.14:
	ldr	x10, [x1, #8]
	cbz	x10, LBB19_11
; %bb.15:
	cmp	x10, #17
	b.lo	LBB19_18
LBB19_16:
	mov	w0, #0                          ; =0x0
Lloh108:
	adrp	x8, lCPI19_0@PAGE
Lloh109:
	ldr	q0, [x8, lCPI19_0@PAGEOFF]
	str	q0, [x6]
	b	LBB19_4
LBB19_17:
	mov	w10, #1                         ; =0x1
LBB19_18:
	mov	x11, #0                         ; =0x0
	mov	w19, #0                         ; =0x0
	add	x12, x1, #16
	add	x13, x12, x10, lsl #3
	mov	w14, #10                        ; =0xa
	add	x15, sp, #56
	mov	w16, #4                         ; =0x4
	movk	w16, #32768, lsl #16
LBB19_19:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB19_25 Depth 2
                                        ;     Child Loop BB19_36 Depth 2
                                        ;     Child Loop BB19_47 Depth 2
                                        ;     Child Loop BB19_57 Depth 2
                                        ;     Child Loop BB19_68 Depth 2
	mov	x0, x8
	cbnz	x8, LBB19_23
; %bb.20:                               ;   in Loop: Header=BB19_19 Depth=1
	ldr	w17, [x1]
	cmp	w17, w16
	b.ne	LBB19_22
; %bb.21:                               ;   in Loop: Header=BB19_19 Depth=1
	ldrb	w17, [x13, x11]
	cbz	w17, LBB19_3
LBB19_22:                               ;   in Loop: Header=BB19_19 Depth=1
	ldr	x0, [x12, w11, uxtw #3]
	cbz	x0, LBB19_78
LBB19_23:                               ;   in Loop: Header=BB19_19 Depth=1
	ldr	x17, [x0]
	sub	x7, x17, #16
	cmn	x7, #15
	b.lo	LBB19_78
; %bb.24:                               ;   in Loop: Header=BB19_19 Depth=1
	mov	x20, #0                         ; =0x0
	mov	w7, #0                          ; =0x0
	add	x0, x0, #8
	add	w21, w17, #1
LBB19_25:                               ;   Parent Loop BB19_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	w17, w20
	b.eq	LBB19_28
; %bb.26:                               ;   in Loop: Header=BB19_25 Depth=2
	ldrb	w22, [x0, x20]
	sub	w23, w22, #48
	cmp	w23, #9
	b.hi	LBB19_32
; %bb.27:                               ;   in Loop: Header=BB19_25 Depth=2
	madd	w7, w7, w14, w22
	sub	w7, w7, #48
	add	x20, x20, #1
	cmp	w7, #255
	b.ls	LBB19_25
	b	LBB19_78
LBB19_28:                               ;   in Loop: Header=BB19_19 Depth=1
	mov	x22, x17
	cmp	w22, #1
	b.eq	LBB19_33
LBB19_29:                               ;   in Loop: Header=BB19_19 Depth=1
	cbz	w22, LBB19_78
; %bb.30:                               ;   in Loop: Header=BB19_19 Depth=1
	cmp	x17, x20
	b.eq	LBB19_78
; %bb.31:                               ;   in Loop: Header=BB19_19 Depth=1
	ldrb	w23, [x0]
	cmp	w23, #48
	b.ne	LBB19_34
	b	LBB19_78
LBB19_32:                               ;   in Loop: Header=BB19_19 Depth=1
	add	w21, w20, #1
	mov	x22, x20
	cmp	w22, #1
	b.ne	LBB19_29
LBB19_33:                               ;   in Loop: Header=BB19_19 Depth=1
	cmp	x17, x20
	b.eq	LBB19_78
LBB19_34:                               ;   in Loop: Header=BB19_19 Depth=1
	ldrb	w20, [x0, x20]
	cmp	w20, #46
	b.ne	LBB19_78
; %bb.35:                               ;   in Loop: Header=BB19_19 Depth=1
	mov	w20, #0                         ; =0x0
	add	w23, w22, #1
	cmp	w21, w17
	csel	w22, w21, w17, hi
	mov	x21, x23
LBB19_36:                               ;   Parent Loop BB19_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x21, x17
	b.hs	LBB19_40
; %bb.37:                               ;   in Loop: Header=BB19_36 Depth=2
	ldrb	w24, [x0, x21]
	sub	w25, w24, #48
	cmp	w25, #10
	b.hs	LBB19_39
; %bb.38:                               ;   in Loop: Header=BB19_36 Depth=2
	add	x21, x21, #1
	madd	w20, w20, w14, w24
	sub	w20, w20, #48
	cmp	w20, #255
	b.ls	LBB19_36
	b	LBB19_78
LBB19_39:                               ;   in Loop: Header=BB19_19 Depth=1
	mov	x22, x21
LBB19_40:                               ;   in Loop: Header=BB19_19 Depth=1
	subs	w24, w22, w23
	b.eq	LBB19_78
; %bb.41:                               ;   in Loop: Header=BB19_19 Depth=1
	cmp	w24, #2
	b.lo	LBB19_44
; %bb.42:                               ;   in Loop: Header=BB19_19 Depth=1
	cmp	x17, x21
	b.eq	LBB19_78
; %bb.43:                               ;   in Loop: Header=BB19_19 Depth=1
	ldrb	w23, [x0, x23]
	cmp	w23, #48
	b.ne	LBB19_45
	b	LBB19_78
LBB19_44:                               ;   in Loop: Header=BB19_19 Depth=1
	cmp	x17, x21
	b.eq	LBB19_78
LBB19_45:                               ;   in Loop: Header=BB19_19 Depth=1
	ldrb	w21, [x0, x21]
	cmp	w21, #46
	b.ne	LBB19_78
; %bb.46:                               ;   in Loop: Header=BB19_19 Depth=1
	mov	w21, #0                         ; =0x0
	add	w24, w22, #1
	cmp	w24, w17
	csel	w23, w24, w17, hi
	mov	x22, x24
LBB19_47:                               ;   Parent Loop BB19_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x22, x17
	b.hs	LBB19_51
; %bb.48:                               ;   in Loop: Header=BB19_47 Depth=2
	ldrb	w25, [x0, x22]
	sub	w26, w25, #48
	cmp	w26, #10
	b.hs	LBB19_50
; %bb.49:                               ;   in Loop: Header=BB19_47 Depth=2
	add	x22, x22, #1
	madd	w21, w21, w14, w25
	sub	w21, w21, #48
	cmp	w21, #255
	b.ls	LBB19_47
	b	LBB19_78
LBB19_50:                               ;   in Loop: Header=BB19_19 Depth=1
	mov	x23, x22
LBB19_51:                               ;   in Loop: Header=BB19_19 Depth=1
	subs	w25, w23, w24
	b.eq	LBB19_78
; %bb.52:                               ;   in Loop: Header=BB19_19 Depth=1
	cmp	w25, #2
	b.lo	LBB19_54
; %bb.53:                               ;   in Loop: Header=BB19_19 Depth=1
	ldrb	w24, [x0, x24]
	cmp	w24, #48
	b.eq	LBB19_78
LBB19_54:                               ;   in Loop: Header=BB19_19 Depth=1
	cmp	x17, x22
	b.eq	LBB19_78
; %bb.55:                               ;   in Loop: Header=BB19_19 Depth=1
	ldrb	w22, [x0, x22]
	cmp	w22, #46
	b.ne	LBB19_78
; %bb.56:                               ;   in Loop: Header=BB19_19 Depth=1
	mov	w22, #0                         ; =0x0
	lsl	w20, w20, #8
	orr	w7, w20, w7, lsl #16
	orr	w7, w21, w7
	add	w20, w23, #1
	cmp	w20, w17
	csel	w23, w20, w17, hi
	mov	x21, x20
LBB19_57:                               ;   Parent Loop BB19_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x21, x17
	b.hs	LBB19_61
; %bb.58:                               ;   in Loop: Header=BB19_57 Depth=2
	ldrb	w24, [x0, x21]
	sub	w25, w24, #48
	cmp	w25, #10
	b.hs	LBB19_60
; %bb.59:                               ;   in Loop: Header=BB19_57 Depth=2
	add	x21, x21, #1
	madd	w22, w22, w14, w24
	sub	w22, w22, #48
	cmp	w22, #255
	b.ls	LBB19_57
	b	LBB19_78
LBB19_60:                               ;   in Loop: Header=BB19_19 Depth=1
	mov	x23, x21
LBB19_61:                               ;   in Loop: Header=BB19_19 Depth=1
	subs	w23, w23, w20
	b.eq	LBB19_78
; %bb.62:                               ;   in Loop: Header=BB19_19 Depth=1
	cmp	w23, #2
	b.lo	LBB19_65
; %bb.63:                               ;   in Loop: Header=BB19_19 Depth=1
	cmp	x17, x21
	b.ne	LBB19_78
; %bb.64:                               ;   in Loop: Header=BB19_19 Depth=1
	ldrb	w17, [x0, x20]
	cmp	w17, #48
	b.ne	LBB19_66
	b	LBB19_78
LBB19_65:                               ;   in Loop: Header=BB19_19 Depth=1
	cmp	x17, x21
	b.ne	LBB19_78
LBB19_66:                               ;   in Loop: Header=BB19_19 Depth=1
	orr	w17, w22, w7, lsl #8
	rev	w17, w17
	cbz	w19, LBB19_70
; %bb.67:                               ;   in Loop: Header=BB19_19 Depth=1
	mov	x0, #0                          ; =0x0
	mov	w7, w19
LBB19_68:                               ;   Parent Loop BB19_19 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w20, [x15, x0, lsl #2]
	cmp	w20, w17
	b.eq	LBB19_71
; %bb.69:                               ;   in Loop: Header=BB19_68 Depth=2
	add	x0, x0, #1
	cmp	x7, x0
	b.ne	LBB19_68
	b	LBB19_72
LBB19_70:                               ;   in Loop: Header=BB19_19 Depth=1
	mov	w0, #0                          ; =0x0
LBB19_71:                               ;   in Loop: Header=BB19_19 Depth=1
	cmp	w0, w19
	b.ne	LBB19_73
LBB19_72:                               ;   in Loop: Header=BB19_19 Depth=1
	str	w17, [x15, w19, uxtw #2]
	add	w17, w19, #1
	mov	x19, x17
LBB19_73:                               ;   in Loop: Header=BB19_19 Depth=1
	add	w11, w11, #1
	cmp	w11, w10
	b.lo	LBB19_19
; %bb.74:
	mov	x22, #0                         ; =0x0
	add	x8, x9, #1040
	mov	w11, #1096                      ; =0x448
LBB19_75:                               ; =>This Inner Loop Header: Depth=1
	ldr	w12, [x9, x11]
	cbz	w12, LBB19_77
; %bb.76:                               ;   in Loop: Header=BB19_75 Depth=1
	add	x22, x22, #1
	add	x11, x11, #176
	cmp	x22, #64
	b.ne	LBB19_75
LBB19_77:
	mov	x11, #0                         ; =0x0
	mov	w14, #0                         ; =0x0
	mov	w12, #16                        ; =0x10
	mov	w13, #1                         ; =0x1
	b	LBB19_81
LBB19_78:
	mov	w0, #0                          ; =0x0
Lloh110:
	adrp	x8, lCPI19_3@PAGE
Lloh111:
	ldr	q0, [x8, lCPI19_3@PAGEOFF]
	str	q0, [x6]
	b	LBB19_4
LBB19_79:                               ;   in Loop: Header=BB19_81 Depth=1
	ldr	w15, [x15, #1100]
	cmp	w15, #4
	cset	w16, eq
	cmp	w15, #1
	csel	w15, w13, w16, eq
LBB19_80:                               ;   in Loop: Header=BB19_81 Depth=1
	add	x12, x12, #16
	add	w14, w14, w15
	add	x11, x11, #176
	cmp	x12, #1040
	b.eq	LBB19_83
LBB19_81:                               ; =>This Inner Loop Header: Depth=1
	ldr	x15, [x9, x12]
	cmp	x15, #0
	cinc	w14, w14, ne
	add	x15, x9, x11
	ldr	w16, [x15, #1096]
	cmp	w16, #1
	b.eq	LBB19_79
; %bb.82:                               ;   in Loop: Header=BB19_81 Depth=1
	mov	w15, #0                         ; =0x0
	b	LBB19_80
LBB19_83:
	cmp	w22, #64
	b.eq	LBB19_16
; %bb.84:
	cmp	w14, #63
	b.hi	LBB19_16
; %bb.85:
	mov	x23, x8
	stp	x5, x4, [sp, #16]               ; 16-byte Folded Spill
	mov	x20, x2
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	str	x6, [sp, #32]                   ; 8-byte Folded Spill
	add	x1, sp, #48
	mov	x0, x3
	bl	_client_deadline
	cbnz	w0, LBB19_3
; %bb.86:
	bl	_monotonic_ns
	ldr	x24, [sp, #48]
	cmp	x0, x24
	b.hs	LBB19_93
; %bb.87:
Lloh112:
	adrp	x8, _next_id@PAGE
Lloh113:
	ldr	x10, [x8, _next_id@PAGEOFF]
	mov	x8, #9223372036854775807        ; =0x7fffffffffffffff
Lloh114:
	adrp	x9, _next_id@PAGE
Lloh115:
	add	x9, x9, _next_id@PAGEOFF
LBB19_88:                               ; =>This Inner Loop Header: Depth=1
	cmp	x10, x8
	b.hs	LBB19_94
; %bb.89:                               ;   in Loop: Header=BB19_88 Depth=1
	mov	x21, x10
	add	x11, x10, #1
	cas	x10, x11, [x9]
	cmp	x10, x21
	b.ne	LBB19_88
; %bb.90:
	cbz	x21, LBB19_94
; %bb.91:
	add	x2, sp, #40
	ldp	x0, x1, [sp, #16]               ; 16-byte Folded Reload
	bl	_neoclr_gc_host_root_create_v1
	cbnz	w0, LBB19_4
; %bb.92:
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w22, w8, x23
	str	x21, [x8]
	ldr	x9, [sp, #40]
	str	x9, [x8, #16]
Lloh116:
	adrp	x9, lCPI19_2@PAGE
Lloh117:
	ldr	d0, [x9, lCPI19_2@PAGEOFF]
	str	d0, [x8, #56]
	mov	w9, #-1                         ; =0xffffffff
	str	w9, [x8, #88]
	str	x24, [x8, #48]
	strh	w20, [x8, #164]
	str	w19, [x8, #156]
	ubfiz	x2, x19, #2, #32
	add	x0, x8, #92
	add	x1, sp, #56
	bl	_memcpy
	bl	_monotonic_ns
	mov	x2, x0
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	mov	x1, x22
	bl	_connect_next
	mov	w0, #0                          ; =0x0
	mov	w8, #5                          ; =0x5
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	stp	x8, x21, [x9]
	b	LBB19_4
LBB19_93:
	mov	w0, #0                          ; =0x0
Lloh118:
	adrp	x8, lCPI19_1@PAGE
Lloh119:
	ldr	q0, [x8, lCPI19_1@PAGEOFF]
	b	LBB19_95
LBB19_94:
	mov	w0, #0                          ; =0x0
Lloh120:
	adrp	x8, lCPI19_0@PAGE
Lloh121:
	ldr	q0, [x8, lCPI19_0@PAGEOFF]
LBB19_95:
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	q0, [x8]
	b	LBB19_4
LBB19_96:
	bl	___stack_chk_fail
	.loh AdrpLdr	Lloh101, Lloh102
	.loh AdrpLdrGotLdr	Lloh98, Lloh99, Lloh100
	.loh AdrpLdrGotLdr	Lloh103, Lloh104, Lloh105
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpLdr	Lloh108, Lloh109
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpAdd	Lloh114, Lloh115
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpLdr	Lloh120, Lloh121
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_connect_addresses_v1 ; -- Begin function neoclr_socket_connect_addresses_v1
	.p2align	2
_neoclr_socket_connect_addresses_v1:    ; @neoclr_socket_connect_addresses_v1
	.cfi_startproc
; %bb.0:
	mov	x6, x4
	mov	x5, x3
	mov	x4, x2
	mov	x2, x1
	mov	x1, x0
	mov	x0, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	b	_connect_addresses
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_connect_addresses_until_v1 ; -- Begin function neoclr_socket_connect_addresses_until_v1
	.p2align	2
_neoclr_socket_connect_addresses_until_v1: ; @neoclr_socket_connect_addresses_until_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x5
	mov	x20, x4
	mov	x21, x3
	mov	x24, x2
	mov	x22, x1
	mov	x23, x0
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp]
	madd	x8, x9, x8, x10
	cmp	w0, #0
	csel	x8, x8, xzr, eq
	mov	w0, #3                          ; =0x3
	tbnz	x24, #63, LBB21_6
; %bb.1:
	cbz	x8, LBB21_6
; %bb.2:
Lloh122:
	adrp	x9, _network_origin@PAGE
Lloh123:
	ldr	x9, [x9, _network_origin@PAGEOFF]
	cbnz	x9, LBB21_4
; %bb.3:
Lloh124:
	adrp	x10, _network_origin@PAGE
Lloh125:
	add	x10, x10, _network_origin@PAGEOFF
	cas	x9, x8, [x10]
	cmp	x9, #0
	csel	x9, x8, x9, eq
LBB21_4:
	mvn	x8, x9
	mov	x10, #13531                     ; =0x34db
	movk	x10, #55222, lsl #16
	movk	x10, #56962, lsl #32
	movk	x10, #17179, lsl #48
	umulh	x8, x8, x10
	cmp	x24, x8, lsr #18
	b.hi	LBB21_6
; %bb.5:
	mov	w8, #16960                      ; =0x4240
	movk	w8, #15, lsl #16
	madd	x3, x24, x8, x9
	mov	x0, #0                          ; =0x0
	mov	x1, x23
	mov	x2, x22
	mov	x4, x21
	mov	x5, x20
	mov	x6, x19
	bl	_connect_addresses
LBB21_6:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpAdd	Lloh124, Lloh125
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_timer_start_v1
lCPI22_0:
	.long	1                               ; 0x1
	.long	6                               ; 0x6
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_timer_start_v1
	.p2align	2
_neoclr_timer_start_v1:                 ; @neoclr_timer_start_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
Lloh126:
	adrp	x0, _head@TLVPPAGE
Lloh127:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB22_3
LBB22_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x2
	b.eq	LBB22_3
; %bb.2:                                ;   in Loop: Header=BB22_1 Depth=1
	ldr	x8, [x8, #8]
	cbnz	x8, LBB22_1
LBB22_3:
	mov	w0, #3                          ; =0x3
	tbnz	w19, #31, LBB22_18
; %bb.4:
	cbz	x3, LBB22_18
; %bb.5:
	cbz	x1, LBB22_18
; %bb.6:
	cbz	x8, LBB22_18
; %bb.7:
	add	x21, x8, #1096
	mov	w8, #64                         ; =0x40
LBB22_8:                                ; =>This Inner Loop Header: Depth=1
	ldr	w9, [x21]
	cbz	w9, LBB22_10
; %bb.9:                                ;   in Loop: Header=BB22_8 Depth=1
	add	x21, x21, #176
	subs	x8, x8, #1
	b.ne	LBB22_8
	b	LBB22_17
LBB22_10:
	mov	x20, x2
	mov	x24, x1
	mov	x22, x3
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp]
	madd	x8, x9, x8, x10
	cmp	w0, #0
	csel	x23, x8, xzr, eq
	mov	w8, #16960                      ; =0x4240
	movk	w8, #15, lsl #16
	umull	x19, w19, w8
	neg	x8, x23
	cmp	x19, x8
	b.hs	LBB22_17
; %bb.11:
Lloh128:
	adrp	x8, _next_id@PAGE
Lloh129:
	ldr	x10, [x8, _next_id@PAGEOFF]
	mov	x8, #9223372036854775807        ; =0x7fffffffffffffff
Lloh130:
	adrp	x9, _next_id@PAGE
Lloh131:
	add	x9, x9, _next_id@PAGEOFF
	mov	x1, x24
LBB22_12:                               ; =>This Inner Loop Header: Depth=1
	cmp	x10, x8
	b.hs	LBB22_17
; %bb.13:                               ;   in Loop: Header=BB22_12 Depth=1
	mov	x24, x10
	add	x11, x10, #1
	cas	x10, x11, [x9]
	cmp	x10, x24
	b.ne	LBB22_12
; %bb.14:
	str	xzr, [sp]
	cbz	x24, LBB22_17
; %bb.15:
	mov	x2, sp
	mov	x0, x20
	bl	_neoclr_gc_host_root_create_v1
	cbnz	w0, LBB22_18
; %bb.16:
	stur	x24, [x21, #-56]
	ldr	x8, [sp]
	stur	x8, [x21, #-40]
	add	x8, x23, x19
	stur	x8, [x21, #-8]
Lloh132:
	adrp	x8, lCPI22_0@PAGE
Lloh133:
	ldr	d0, [x8, lCPI22_0@PAGEOFF]
	str	d0, [x21]
	str	x24, [x22]
	b	LBB22_18
LBB22_17:
	mov	w0, #3                          ; =0x3
LBB22_18:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpAdd	Lloh130, Lloh131
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpLdr	Lloh132, Lloh133
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_timer_cancel_v1         ; -- Begin function neoclr_timer_cancel_v1
	.p2align	2
_neoclr_timer_cancel_v1:                ; @neoclr_timer_cancel_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh134:
	adrp	x0, _head@TLVPPAGE
Lloh135:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cbz	x9, LBB23_11
LBB23_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9]
	cmp	x10, x1
	b.eq	LBB23_3
; %bb.2:                                ;   in Loop: Header=BB23_1 Depth=1
	ldr	x9, [x9, #8]
	cbnz	x9, LBB23_1
	b	LBB23_11
LBB23_3:
	cbz	x2, LBB23_11
; %bb.4:
	add	x19, x9, #1040
	mov	w9, #64                         ; =0x40
	b	LBB23_6
LBB23_5:                                ;   in Loop: Header=BB23_6 Depth=1
	add	x19, x19, #176
	subs	x9, x9, #1
	b.eq	LBB23_13
LBB23_6:                                ; =>This Inner Loop Header: Depth=1
	cbz	x8, LBB23_5
; %bb.7:                                ;   in Loop: Header=BB23_6 Depth=1
	ldr	x10, [x19]
	cmp	x10, x8
	b.ne	LBB23_5
; %bb.8:                                ;   in Loop: Header=BB23_6 Depth=1
	ldr	w10, [x19, #60]
	cmp	w10, #6
	b.ne	LBB23_5
; %bb.9:                                ;   in Loop: Header=BB23_6 Depth=1
	ldr	w10, [x19, #56]
	sub	w10, w10, #1
	cmp	w10, #1
	b.hi	LBB23_5
; %bb.10:
	mov	x20, x2
	ldr	x8, [x19, #16]
	mov	x0, x1
	mov	x1, x8
	bl	_neoclr_gc_host_root_release_v1
	cbz	w0, LBB23_15
LBB23_11:
	mov	w0, #3                          ; =0x3
LBB23_12:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB23_13:
	mov	w8, #0                          ; =0x0
LBB23_14:
	mov	w0, #0                          ; =0x0
	str	w8, [x2]
	b	LBB23_12
LBB23_15:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	mov	w8, #1                          ; =0x1
	str	q0, [x19]
	mov	x2, x20
	b	LBB23_14
	.loh AdrpLdr	Lloh134, Lloh135
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function neoclr_socket_accept_v1
lCPI24_0:
	.quad	2                               ; 0x2
	.quad	4                               ; 0x4
lCPI24_1:
	.quad	2                               ; 0x2
	.quad	12                              ; 0xc
lCPI24_2:
	.quad	2                               ; 0x2
	.quad	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_socket_accept_v1
	.p2align	2
_neoclr_socket_accept_v1:               ; @neoclr_socket_accept_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh136:
	adrp	x0, _head@TLVPPAGE
Lloh137:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB24_3
LBB24_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x2
	b.eq	LBB24_5
; %bb.2:                                ;   in Loop: Header=BB24_1 Depth=1
	ldr	x8, [x8, #8]
	cbnz	x8, LBB24_1
LBB24_3:
	mov	w0, #3                          ; =0x3
LBB24_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB24_5:
	mov	w0, #3                          ; =0x3
	cbz	x1, LBB24_4
; %bb.6:
	cbz	x3, LBB24_4
; %bb.7:
	add	x9, x8, #16
	add	x10, x8, #28
	mov	w11, #64                        ; =0x40
LBB24_8:                                ; =>This Inner Loop Header: Depth=1
	ldur	x12, [x10, #-12]
	cmp	x12, x19
	b.eq	LBB24_10
; %bb.9:                                ;   in Loop: Header=BB24_8 Depth=1
	add	x10, x10, #16
	subs	x11, x11, #1
	b.ne	LBB24_8
	b	LBB24_19
LBB24_10:
	cbz	x19, LBB24_19
; %bb.11:
	cbz	x11, LBB24_19
; %bb.12:
	ldr	w10, [x10]
	cbz	w10, LBB24_24
; %bb.13:
	mov	x11, #0                         ; =0x0
	mov	w10, #0                         ; =0x0
	add	x12, x8, #1100
	b	LBB24_15
LBB24_14:                               ;   in Loop: Header=BB24_15 Depth=1
	add	x11, x11, #16
	add	x12, x12, #176
	cmp	x11, #1024
	b.eq	LBB24_21
LBB24_15:                               ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x9, x11]
	cmp	x13, #0
	cinc	w10, w10, ne
	ldur	w13, [x12, #-4]
	cmp	w13, #1
	b.ne	LBB24_14
; %bb.16:                               ;   in Loop: Header=BB24_15 Depth=1
	ldr	w13, [x12]
	cmp	w13, #1
	cset	w14, eq
	cmp	w13, #4
	csinc	w14, w14, wzr, ne
	add	w10, w10, w14
	cmp	w13, #1
	b.ne	LBB24_14
; %bb.17:                               ;   in Loop: Header=BB24_15 Depth=1
	ldur	x13, [x12, #-52]
	cmp	x13, x19
	b.ne	LBB24_14
; %bb.18:
	mov	w0, #0                          ; =0x0
	mov	w8, #2                          ; =0x2
	dup.2d	v0, x8
	b	LBB24_20
LBB24_19:
	mov	w0, #0                          ; =0x0
Lloh138:
	adrp	x8, lCPI24_2@PAGE
Lloh139:
	ldr	q0, [x8, lCPI24_2@PAGEOFF]
LBB24_20:
	str	q0, [x3]
	b	LBB24_4
LBB24_21:
	add	x20, x8, #1096
	mov	w8, #64                         ; =0x40
LBB24_22:                               ; =>This Inner Loop Header: Depth=1
	ldr	w9, [x20]
	cbz	w9, LBB24_25
; %bb.23:                               ;   in Loop: Header=BB24_22 Depth=1
	add	x20, x20, #176
	subs	x8, x8, #1
	b.ne	LBB24_22
	b	LBB24_33
LBB24_24:
	mov	w0, #0                          ; =0x0
Lloh140:
	adrp	x8, lCPI24_1@PAGE
Lloh141:
	ldr	q0, [x8, lCPI24_1@PAGEOFF]
	b	LBB24_20
LBB24_25:
	cbz	x8, LBB24_33
; %bb.26:
	cmp	w10, #64
	b.hs	LBB24_33
; %bb.27:
Lloh142:
	adrp	x8, _next_id@PAGE
Lloh143:
	ldr	x10, [x8, _next_id@PAGEOFF]
	mov	x8, #9223372036854775807        ; =0x7fffffffffffffff
Lloh144:
	adrp	x9, _next_id@PAGE
Lloh145:
	add	x9, x9, _next_id@PAGEOFF
LBB24_28:                               ; =>This Inner Loop Header: Depth=1
	cmp	x10, x8
	b.hs	LBB24_33
; %bb.29:                               ;   in Loop: Header=BB24_28 Depth=1
	mov	x21, x10
	add	x11, x10, #1
	cas	x10, x11, [x9]
	cmp	x10, x21
	b.ne	LBB24_28
; %bb.30:
	cbz	x21, LBB24_33
; %bb.31:
	mov	x22, x3
	mov	x0, x2
	add	x2, sp, #8
	bl	_neoclr_gc_host_root_create_v1
	cbnz	w0, LBB24_4
; %bb.32:
	stp	x21, x19, [x20, #-56]
	ldr	x8, [sp, #8]
	stur	x8, [x20, #-40]
	movi.2s	v0, #1
	str	d0, [x20]
	mov	w8, #5                          ; =0x5
	stp	x8, x21, [x22]
	b	LBB24_4
LBB24_33:
	mov	w0, #0                          ; =0x0
Lloh146:
	adrp	x8, lCPI24_0@PAGE
Lloh147:
	ldr	q0, [x8, lCPI24_0@PAGEOFF]
	b	LBB24_20
	.loh AdrpLdr	Lloh136, Lloh137
	.loh AdrpLdr	Lloh138, Lloh139
	.loh AdrpLdr	Lloh140, Lloh141
	.loh AdrpAdd	Lloh144, Lloh145
	.loh AdrpLdr	Lloh142, Lloh143
	.loh AdrpLdr	Lloh146, Lloh147
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function neoclr_socket_cancel_v1
lCPI25_0:
	.quad	2                               ; 0x2
	.quad	5                               ; 0x5
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_socket_cancel_v1
	.p2align	2
_neoclr_socket_cancel_v1:               ; @neoclr_socket_cancel_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x8, x0
Lloh148:
	adrp	x0, _head@TLVPPAGE
Lloh149:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x19, [x0]
	cbz	x19, LBB25_9
LBB25_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	cmp	x9, x1
	b.eq	LBB25_3
; %bb.2:                                ;   in Loop: Header=BB25_1 Depth=1
	ldr	x19, [x19, #8]
	cbnz	x19, LBB25_1
	b	LBB25_9
LBB25_3:
	cbz	x2, LBB25_9
; %bb.4:
	mov	x20, #-11264                    ; =0xffffffffffffd400
	b	LBB25_6
LBB25_5:                                ;   in Loop: Header=BB25_6 Depth=1
	adds	x20, x20, #176
	b.eq	LBB25_9
LBB25_6:                                ; =>This Inner Loop Header: Depth=1
	cbz	x8, LBB25_5
; %bb.7:                                ;   in Loop: Header=BB25_6 Depth=1
	add	x21, x19, x20
	ldr	x9, [x21, #12304]
	cmp	x9, x8
	b.ne	LBB25_5
; %bb.8:
	ldr	w8, [x21, #12364]
	cmp	w8, #4
	b.ls	LBB25_11
LBB25_9:
	mov	w0, #3                          ; =0x3
LBB25_10:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB25_11:
	add	x22, x19, x20
	ldr	w8, [x22, #12360]
	cmp	w8, #1
	cset	w8, eq
	str	w8, [x2]
	b.ne	LBB25_22
; %bb.12:
	mov	w8, #2                          ; =0x2
	str	w8, [x22, #12360]
Lloh150:
	adrp	x8, lCPI25_0@PAGE
Lloh151:
	ldr	q0, [x8, lCPI25_0@PAGEOFF]
	mov	w8, #12328                      ; =0x3028
	str	q0, [x22, x8]
	ldr	x0, [x22, #12384]
	cbz	x0, LBB25_15
; %bb.13:
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x0]
	cmp	w8, #1
	b.ne	LBB25_15
; %bb.14:
	bl	_free
LBB25_15:
	str	xzr, [x22, #12384]
	ldr	w8, [x21, #12364]
	cmp	w8, #4
	b.ne	LBB25_18
; %bb.16:
	add	x21, x19, x20
	ldr	w0, [x21, #12392]
	cmn	w0, #1
	b.eq	LBB25_18
; %bb.17:
	bl	_close
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x21, #12392]
LBB25_18:
	add	x21, x19, x20
	ldr	x1, [x21, #12344]
	cbz	x1, LBB25_20
; %bb.19:
	ldr	x0, [x19]
	bl	_neoclr_gc_host_root_release_v1
	str	xzr, [x21, #12344]
LBB25_20:
	ldr	x0, [x21, #12376]
	cbz	x0, LBB25_10
; %bb.21:
	bl	_free
	mov	w0, #0                          ; =0x0
	str	xzr, [x21, #12376]
	add	x8, x19, x20
	ldr	w8, [x8, #12372]
	ldr	x9, [x19, #12368]
	sub	x8, x9, x8
	str	x8, [x19, #12368]
	b	LBB25_10
LBB25_22:
	mov	w0, #0                          ; =0x0
	b	LBB25_10
	.loh AdrpLdr	Lloh148, Lloh149
	.loh AdrpLdr	Lloh150, Lloh151
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_connect_result_v1 ; -- Begin function neoclr_socket_connect_result_v1
	.p2align	2
_neoclr_socket_connect_result_v1:       ; @neoclr_socket_connect_result_v1
	.cfi_startproc
; %bb.0:
	mov	w3, #1                          ; =0x1
	b	_take_result
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function take_result
_take_result:                           ; @take_result
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x8, x0
Lloh152:
	adrp	x0, _head@TLVPPAGE
Lloh153:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x19, [x0]
	cbz	x19, LBB27_11
LBB27_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	cmp	x9, x1
	b.eq	LBB27_3
; %bb.2:                                ;   in Loop: Header=BB27_1 Depth=1
	ldr	x19, [x19, #8]
	cbnz	x19, LBB27_1
	b	LBB27_11
LBB27_3:
	cbz	x2, LBB27_11
; %bb.4:
	mov	x21, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	b	LBB27_6
LBB27_5:                                ;   in Loop: Header=BB27_6 Depth=1
	add	x20, x20, #1
	add	x21, x21, #176
	cmp	x20, #64
	b.eq	LBB27_11
LBB27_6:                                ; =>This Inner Loop Header: Depth=1
	cbz	x8, LBB27_5
; %bb.7:                                ;   in Loop: Header=BB27_6 Depth=1
	add	x22, x19, x21
	ldr	x9, [x22, #1040]
	cmp	x9, x8
	b.ne	LBB27_5
; %bb.8:
	ldr	w8, [x22, #1096]
	cmp	w8, #3
	b.ne	LBB27_11
; %bb.9:
	add	x8, x19, x21
	ldr	w9, [x8, #1100]
	cmp	w9, #1
	cset	w10, eq
	cmp	w9, #4
	csinc	w9, w10, wzr, ne
	ccmp	w9, w3, #0, ls
	b.ne	LBB27_11
; %bb.10:
	mov	x23, x2
	ldr	x8, [x8, #1056]
	mov	x0, x1
	mov	x1, x8
	bl	_neoclr_gc_host_root_release_v1
	cbz	w0, LBB27_13
LBB27_11:
	mov	w0, #3                          ; =0x3
LBB27_12:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB27_13:
	add	x22, x22, #1040
	add	x8, x19, x21
	add	x8, x8, #1064
	ldr	q0, [x8]
	str	q0, [x23]
	mov	x0, x19
	mov	x1, x20
	bl	_release_client
	mov	x0, x19
	mov	x1, x20
	bl	_release_transfer
	mov	w0, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x22, #144]
	stp	q0, q0, [x22, #112]
	stp	q0, q0, [x22, #80]
	stp	q0, q0, [x22, #48]
	stp	q0, q0, [x22, #16]
	str	q0, [x22]
	b	LBB27_12
	.loh AdrpLdr	Lloh152, Lloh153
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_transfer_result_v1 ; -- Begin function neoclr_socket_transfer_result_v1
	.p2align	2
_neoclr_socket_transfer_result_v1:      ; @neoclr_socket_transfer_result_v1
	.cfi_startproc
; %bb.0:
	mov	w3, #0                          ; =0x0
	b	_take_result
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_receive_v1       ; -- Begin function neoclr_socket_receive_v1
	.p2align	2
_neoclr_socket_receive_v1:              ; @neoclr_socket_receive_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x7, x4
	mov	x8, x3
	mov	x9, x2
	mov	x4, x1
	mov	x3, x0
	stp	x5, x6, [sp]
	mov	w0, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x5, x9
	mov	x6, x8
	bl	_transfer
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function transfer
lCPI30_0:
	.quad	2                               ; 0x2
	.quad	12                              ; 0xc
lCPI30_1:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI30_2:
	.quad	2                               ; 0x2
	.quad	4                               ; 0x4
lCPI30_3:
	.quad	2                               ; 0x2
	.quad	10                              ; 0xa
lCPI30_4:
	.quad	2                               ; 0x2
	.quad	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_transfer:                              ; @transfer
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #208
	stp	x28, x27, [sp, #112]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	add	x29, sp, #192
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x6
	mov	x22, x0
Lloh154:
	adrp	x0, _head@TLVPPAGE
Lloh155:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x28, [x0]
	cbz	x28, LBB30_4
; %bb.1:
	ldp	x20, x27, [x29, #16]
LBB30_2:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x28]
	cmp	x8, x20
	b.eq	LBB30_6
; %bb.3:                                ;   in Loop: Header=BB30_2 Depth=1
	ldr	x28, [x28, #8]
	cbnz	x28, LBB30_2
LBB30_4:
	mov	w0, #3                          ; =0x3
LBB30_5:
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
LBB30_6:
	cmp	x4, #0
	ccmp	w22, #0, #0, eq
	mov	w0, #3                          ; =0x3
	b.eq	LBB30_5
; %bb.7:
	cbz	x7, LBB30_5
; %bb.8:
	cbz	x27, LBB30_5
; %bb.9:
	add	x8, x28, #28
	mov	w9, #64                         ; =0x40
LBB30_10:                               ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x8, #-12]
	cmp	x10, x3
	b.eq	LBB30_12
; %bb.11:                               ;   in Loop: Header=BB30_10 Depth=1
	add	x8, x8, #16
	subs	x9, x9, #1
	b.ne	LBB30_10
	b	LBB30_16
LBB30_12:
	cbz	x3, LBB30_16
; %bb.13:
	cbz	x9, LBB30_16
; %bb.14:
	ldr	w8, [x8]
	cbz	w8, LBB30_18
; %bb.15:
	mov	w0, #0                          ; =0x0
Lloh156:
	adrp	x8, lCPI30_0@PAGE
Lloh157:
	ldr	q0, [x8, lCPI30_0@PAGEOFF]
	b	LBB30_17
LBB30_16:
	mov	w0, #0                          ; =0x0
Lloh158:
	adrp	x8, lCPI30_4@PAGE
Lloh159:
	ldr	q0, [x8, lCPI30_4@PAGEOFF]
LBB30_17:
	str	q0, [x27]
	b	LBB30_5
LBB30_18:
	cmp	w1, #0
	mov	w8, #2                          ; =0x2
	cinc	w21, w8, ne
	add	x8, x28, #1100
	mov	w9, #64                         ; =0x40
	b	LBB30_20
LBB30_19:                               ;   in Loop: Header=BB30_20 Depth=1
	add	x8, x8, #176
	subs	x9, x9, #1
	b.eq	LBB30_24
LBB30_20:                               ; =>This Inner Loop Header: Depth=1
	ldur	w10, [x8, #-4]
	cmp	w10, #1
	b.ne	LBB30_19
; %bb.21:                               ;   in Loop: Header=BB30_20 Depth=1
	ldr	w10, [x8]
	cmp	w10, w21
	b.ne	LBB30_19
; %bb.22:                               ;   in Loop: Header=BB30_20 Depth=1
	ldur	x10, [x8, #-52]
	cmp	x10, x3
	b.ne	LBB30_19
; %bb.23:
	mov	w0, #0                          ; =0x0
	mov	w8, #2                          ; =0x2
	dup.2d	v0, x8
	b	LBB30_17
LBB30_24:
	stp	xzr, xzr, [sp, #88]
	str	xzr, [sp, #104]
	stp	x3, x4, [sp, #32]               ; 16-byte Folded Spill
	cbz	w22, LBB30_27
; %bb.25:
	mov	x25, x7
	mov	x26, x1
	mov	x23, x2
	mov	x24, x5
	add	x5, sp, #88
	mov	x0, x20
	mov	x1, x4
	mov	x2, x24
	mov	x3, x19
	mov	x4, x21
	bl	_neoclr_byte_view_create_v1
	cbnz	w0, LBB30_5
; %bb.26:
	mov	x5, x24
	cmp	w19, #16, lsl #12               ; =65536
	b.le	LBB30_32
	b	LBB30_37
LBB30_27:
	ldr	x8, [x4]
	mov	x9, #-3                         ; =0xfffffffffffffffd
	movk	x9, #32767, lsl #16
	add	x8, x8, x9
	mov	w0, #3                          ; =0x3
	cmn	x8, #2
	b.lo	LBB30_5
; %bb.28:
	ldr	x8, [x4, #8]
	cmp	x8, #16, lsl #12                ; =65536
	b.hi	LBB30_5
; %bb.29:
	orr	w9, w19, w5
	tbnz	w9, #31, LBB30_35
; %bb.30:
	mov	w9, w5
	subs	x8, x8, x9
	b.lo	LBB30_35
; %bb.31:
	mov	x25, x7
	mov	x26, x1
	mov	x23, x2
	mov	w9, w19
	cmp	x8, x9
	b.lo	LBB30_35
LBB30_32:
	mov	x24, #-11264                    ; =0xffffffffffffd400
LBB30_33:                               ; =>This Inner Loop Header: Depth=1
	add	x8, x28, x24
	ldr	w8, [x8, #12360]
	cbz	w8, LBB30_36
; %bb.34:                               ;   in Loop: Header=BB30_33 Depth=1
	adds	x24, x24, #176
	b.ne	LBB30_33
	b	LBB30_37
LBB30_35:
	mov	w0, #0                          ; =0x0
Lloh160:
	adrp	x8, lCPI30_1@PAGE
Lloh161:
	ldr	q0, [x8, lCPI30_1@PAGEOFF]
	b	LBB30_17
LBB30_36:
	sxtw	x10, w19
	ldr	x8, [x28, #12368]
	mov	w9, #262144                     ; =0x40000
	sub	x8, x9, x8
	cmp	x8, x10
	b.hs	LBB30_39
LBB30_37:
	mov	w0, #0                          ; =0x0
LBB30_38:
Lloh162:
	adrp	x8, lCPI30_2@PAGE
Lloh163:
	ldr	q0, [x8, lCPI30_2@PAGEOFF]
	b	LBB30_17
LBB30_39:
	str	x10, [sp, #16]                  ; 8-byte Folded Spill
	str	w5, [sp, #28]                   ; 4-byte Folded Spill
	bl	_monotonic_ns
Lloh164:
	adrp	x8, _next_id@PAGE
Lloh165:
	ldr	x11, [x8, _next_id@PAGEOFF]
	mov	x9, #9223372036854775806        ; =0x7ffffffffffffffe
Lloh166:
	adrp	x10, _next_id@PAGE
Lloh167:
	add	x10, x10, _next_id@PAGEOFF
	mov	x8, x26
LBB30_40:                               ; =>This Inner Loop Header: Depth=1
	cmp	x11, x9
	b.hi	LBB30_42
; %bb.41:                               ;   in Loop: Header=BB30_40 Depth=1
	mov	x26, x11
	add	x12, x11, #1
	cas	x11, x12, [x10]
	cmp	x11, x26
	b.ne	LBB30_40
	b	LBB30_43
LBB30_42:
	mov	x26, #0                         ; =0x0
LBB30_43:
	stp	xzr, xzr, [sp, #72]
	cbz	x0, LBB30_4
; %bb.44:
	sub	x9, x23, #1
	cmp	x9, x0
	b.hs	LBB30_46
; %bb.45:
	mov	w0, #0                          ; =0x0
Lloh168:
	adrp	x8, lCPI30_3@PAGE
Lloh169:
	ldr	q0, [x8, lCPI30_3@PAGEOFF]
	b	LBB30_17
LBB30_46:
	stp	x0, x23, [sp]                   ; 16-byte Folded Spill
	cbz	w22, LBB30_48
; %bb.47:
	mov	x22, x8
	cmp	w8, #0
	cset	w2, eq
	add	x1, sp, #88
	add	x3, sp, #48
	mov	x0, x20
	bl	_neoclr_byte_view_access_v1
	cbnz	w0, LBB30_5
	b	LBB30_50
LBB30_48:
	mov	x22, x8
	cbz	w8, LBB30_50
; %bb.49:
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	ldr	w1, [sp, #28]                   ; 4-byte Folded Reload
	mov	x2, x19
	bl	_neoclr_check_bytes_initialized_v1
	cbnz	w0, LBB30_4
LBB30_50:
	cbz	x26, LBB30_37
; %bb.51:
	cbz	w19, LBB30_53
; %bb.52:
	ldr	x0, [sp, #16]                   ; 8-byte Folded Reload
	bl	_malloc
	mov	x23, x0
	cbnz	x0, LBB30_54
	b	LBB30_38
LBB30_53:
	mov	x23, #0                         ; =0x0
LBB30_54:
	add	x2, sp, #80
	mov	x0, x20
	mov	x1, x25
	bl	_neoclr_gc_host_root_create_v1
	mov	x25, x0
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	cbz	x8, LBB30_57
; %bb.55:
	orr	w8, w25, w22
	cbnz	w8, LBB30_57
; %bb.56:
	add	x2, sp, #72
	mov	x0, x20
	ldr	x1, [sp, #40]                   ; 8-byte Folded Reload
	bl	_neoclr_gc_host_root_create_v1
	mov	x25, x0
LBB30_57:
	cbz	w25, LBB30_61
; %bb.58:
	ldr	x1, [sp, #80]
	cbz	x1, LBB30_60
; %bb.59:
	mov	x0, x20
	bl	_neoclr_gc_host_root_release_v1
LBB30_60:
	mov	x0, x23
	bl	_free
	mov	x0, x25
	b	LBB30_5
LBB30_61:
	cbz	w22, LBB30_64
; %bb.62:
	cbz	w19, LBB30_64
; %bb.63:
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	add	x8, x9, w8, sxtw
	add	x1, x8, #16
	mov	x0, x23
	ldr	x2, [sp, #16]                   ; 8-byte Folded Reload
	bl	_memcpy
LBB30_64:
	mov	w0, #0                          ; =0x0
	add	x9, x28, x24
	str	x26, [x9, #12304]
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x8, [x9, #12312]
	ldr	x8, [sp, #80]
	str	x8, [x9, #12320]
	ldr	x8, [sp, #72]
	str	x8, [x9, #12344]
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #12360]
	str	w21, [x9, #12364]
	ldr	w8, [sp, #28]                   ; 4-byte Folded Reload
	str	w8, [x9, #12368]
	str	w19, [x9, #12372]
	str	x23, [x9, #12376]
	mov	x10, #61952                     ; =0xf200
	movk	x10, #10757, lsl #16
	movk	x10, #1, lsl #32
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	add	x8, x8, x10
	ldr	x10, [sp, #8]                   ; 8-byte Folded Reload
	cmp	x8, x10
	csel	x11, x8, x10, lo
	cmp	x10, #0
	csel	x8, x8, x11, eq
	str	x8, [x9, #12352]
	ldr	x8, [x28, #12368]
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	add	x8, x8, x9
	str	x8, [x28, #12368]
	mov	w8, #5                          ; =0x5
	stp	x8, x26, [x27]
	b	LBB30_5
	.loh AdrpLdr	Lloh154, Lloh155
	.loh AdrpLdr	Lloh156, Lloh157
	.loh AdrpLdr	Lloh158, Lloh159
	.loh AdrpLdr	Lloh160, Lloh161
	.loh AdrpLdr	Lloh162, Lloh163
	.loh AdrpAdd	Lloh166, Lloh167
	.loh AdrpLdr	Lloh164, Lloh165
	.loh AdrpLdr	Lloh168, Lloh169
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_send_v1          ; -- Begin function neoclr_socket_send_v1
	.p2align	2
_neoclr_socket_send_v1:                 ; @neoclr_socket_send_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x7, x4
	mov	x8, x3
	mov	x9, x2
	mov	x4, x1
	mov	x3, x0
	stp	x5, x6, [sp]
	mov	w0, #0                          ; =0x0
	mov	w1, #1                          ; =0x1
	mov	x2, #0                          ; =0x0
	mov	x5, x9
	mov	x6, x8
	bl	_transfer
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_receive_until_v1 ; -- Begin function neoclr_socket_receive_until_v1
	.p2align	2
_neoclr_socket_receive_until_v1:        ; @neoclr_socket_receive_until_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x24, x7
	mov	x23, x6
	mov	x19, x5
	mov	x26, x4
	mov	x20, x3
	mov	x21, x2
	mov	x22, x1
	mov	x25, x0
	add	x1, sp, #16
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp, #16]
	madd	x8, x9, x8, x10
	cmp	w0, #0
	csel	x8, x8, xzr, eq
	mov	w0, #3                          ; =0x3
	tbnz	x26, #63, LBB32_6
; %bb.1:
	cbz	x8, LBB32_6
; %bb.2:
Lloh170:
	adrp	x9, _network_origin@PAGE
Lloh171:
	ldr	x9, [x9, _network_origin@PAGEOFF]
	cbnz	x9, LBB32_4
; %bb.3:
Lloh172:
	adrp	x10, _network_origin@PAGE
Lloh173:
	add	x10, x10, _network_origin@PAGEOFF
	cas	x9, x8, [x10]
	cmp	x9, #0
	csel	x9, x8, x9, eq
LBB32_4:
	mvn	x8, x9
	mov	x10, #13531                     ; =0x34db
	movk	x10, #55222, lsl #16
	movk	x10, #56962, lsl #32
	movk	x10, #17179, lsl #48
	umulh	x8, x8, x10
	cmp	x26, x8, lsr #18
	b.hi	LBB32_6
; %bb.5:
	mov	w8, #16960                      ; =0x4240
	movk	w8, #15, lsl #16
	madd	x2, x26, x8, x9
	stp	x23, x24, [sp]
	mov	w0, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	x3, x25
	mov	x4, x22
	mov	x5, x21
	mov	x6, x20
	mov	x7, x19
	bl	_transfer
LBB32_6:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.loh AdrpLdr	Lloh170, Lloh171
	.loh AdrpAdd	Lloh172, Lloh173
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_send_until_v1    ; -- Begin function neoclr_socket_send_until_v1
	.p2align	2
_neoclr_socket_send_until_v1:           ; @neoclr_socket_send_until_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x24, x7
	mov	x23, x6
	mov	x19, x5
	mov	x26, x4
	mov	x20, x3
	mov	x21, x2
	mov	x22, x1
	mov	x25, x0
	add	x1, sp, #16
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp, #16]
	madd	x8, x9, x8, x10
	cmp	w0, #0
	csel	x8, x8, xzr, eq
	mov	w0, #3                          ; =0x3
	tbnz	x26, #63, LBB33_6
; %bb.1:
	cbz	x8, LBB33_6
; %bb.2:
Lloh174:
	adrp	x9, _network_origin@PAGE
Lloh175:
	ldr	x9, [x9, _network_origin@PAGEOFF]
	cbnz	x9, LBB33_4
; %bb.3:
Lloh176:
	adrp	x10, _network_origin@PAGE
Lloh177:
	add	x10, x10, _network_origin@PAGEOFF
	cas	x9, x8, [x10]
	cmp	x9, #0
	csel	x9, x8, x9, eq
LBB33_4:
	mvn	x8, x9
	mov	x10, #13531                     ; =0x34db
	movk	x10, #55222, lsl #16
	movk	x10, #56962, lsl #32
	movk	x10, #17179, lsl #48
	umulh	x8, x8, x10
	cmp	x26, x8, lsr #18
	b.hi	LBB33_6
; %bb.5:
	mov	w8, #16960                      ; =0x4240
	movk	w8, #15, lsl #16
	madd	x2, x26, x8, x9
	stp	x23, x24, [sp]
	mov	w0, #0                          ; =0x0
	mov	w1, #1                          ; =0x1
	mov	x3, x25
	mov	x4, x22
	mov	x5, x21
	mov	x6, x20
	mov	x7, x19
	bl	_transfer
LBB33_6:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.loh AdrpLdr	Lloh174, Lloh175
	.loh AdrpAdd	Lloh176, Lloh177
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_receive_memory_v1 ; -- Begin function neoclr_socket_receive_memory_v1
	.p2align	2
_neoclr_socket_receive_memory_v1:       ; @neoclr_socket_receive_memory_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x7, x4
	mov	x8, x3
	mov	x9, x2
	mov	x4, x1
	mov	x3, x0
	stp	x5, x6, [sp]
	mov	w0, #1                          ; =0x1
	mov	w1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x5, x9
	mov	x6, x8
	bl	_transfer
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_receive_until_memory_v1 ; -- Begin function neoclr_socket_receive_until_memory_v1
	.p2align	2
_neoclr_socket_receive_until_memory_v1: ; @neoclr_socket_receive_until_memory_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x24, x7
	mov	x23, x6
	mov	x19, x5
	mov	x26, x4
	mov	x20, x3
	mov	x21, x2
	mov	x22, x1
	mov	x25, x0
	add	x1, sp, #16
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp, #16]
	madd	x8, x9, x8, x10
	cmp	w0, #0
	csel	x8, x8, xzr, eq
	mov	w0, #3                          ; =0x3
	tbnz	x26, #63, LBB35_6
; %bb.1:
	cbz	x8, LBB35_6
; %bb.2:
Lloh178:
	adrp	x9, _network_origin@PAGE
Lloh179:
	ldr	x9, [x9, _network_origin@PAGEOFF]
	cbnz	x9, LBB35_4
; %bb.3:
Lloh180:
	adrp	x10, _network_origin@PAGE
Lloh181:
	add	x10, x10, _network_origin@PAGEOFF
	cas	x9, x8, [x10]
	cmp	x9, #0
	csel	x9, x8, x9, eq
LBB35_4:
	mvn	x8, x9
	mov	x10, #13531                     ; =0x34db
	movk	x10, #55222, lsl #16
	movk	x10, #56962, lsl #32
	movk	x10, #17179, lsl #48
	umulh	x8, x8, x10
	cmp	x26, x8, lsr #18
	b.hi	LBB35_6
; %bb.5:
	mov	w8, #16960                      ; =0x4240
	movk	w8, #15, lsl #16
	madd	x2, x26, x8, x9
	stp	x23, x24, [sp]
	mov	w0, #1                          ; =0x1
	mov	w1, #0                          ; =0x0
	mov	x3, x25
	mov	x4, x22
	mov	x5, x21
	mov	x6, x20
	mov	x7, x19
	bl	_transfer
LBB35_6:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.loh AdrpLdr	Lloh178, Lloh179
	.loh AdrpAdd	Lloh180, Lloh181
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_send_memory_v1   ; -- Begin function neoclr_socket_send_memory_v1
	.p2align	2
_neoclr_socket_send_memory_v1:          ; @neoclr_socket_send_memory_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x7, x4
	mov	x8, x3
	mov	x9, x2
	mov	x4, x1
	mov	x3, x0
	stp	x5, x6, [sp]
	mov	w0, #1                          ; =0x1
	mov	w1, #1                          ; =0x1
	mov	x2, #0                          ; =0x0
	mov	x5, x9
	mov	x6, x8
	bl	_transfer
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_send_until_memory_v1 ; -- Begin function neoclr_socket_send_until_memory_v1
	.p2align	2
_neoclr_socket_send_until_memory_v1:    ; @neoclr_socket_send_until_memory_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	add	x29, sp, #96
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x24, x7
	mov	x23, x6
	mov	x19, x5
	mov	x26, x4
	mov	x20, x3
	mov	x21, x2
	mov	x22, x1
	mov	x25, x0
	add	x1, sp, #16
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp, #16]
	madd	x8, x9, x8, x10
	cmp	w0, #0
	csel	x8, x8, xzr, eq
	mov	w0, #3                          ; =0x3
	tbnz	x26, #63, LBB37_6
; %bb.1:
	cbz	x8, LBB37_6
; %bb.2:
Lloh182:
	adrp	x9, _network_origin@PAGE
Lloh183:
	ldr	x9, [x9, _network_origin@PAGEOFF]
	cbnz	x9, LBB37_4
; %bb.3:
Lloh184:
	adrp	x10, _network_origin@PAGE
Lloh185:
	add	x10, x10, _network_origin@PAGEOFF
	cas	x9, x8, [x10]
	cmp	x9, #0
	csel	x9, x8, x9, eq
LBB37_4:
	mvn	x8, x9
	mov	x10, #13531                     ; =0x34db
	movk	x10, #55222, lsl #16
	movk	x10, #56962, lsl #32
	movk	x10, #17179, lsl #48
	umulh	x8, x8, x10
	cmp	x26, x8, lsr #18
	b.hi	LBB37_6
; %bb.5:
	mov	w8, #16960                      ; =0x4240
	movk	w8, #15, lsl #16
	madd	x2, x26, x8, x9
	stp	x23, x24, [sp]
	mov	w0, #1                          ; =0x1
	mov	w1, #1                          ; =0x1
	mov	x3, x25
	mov	x4, x22
	mov	x5, x21
	mov	x6, x20
	mov	x7, x19
	bl	_transfer
LBB37_6:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.loh AdrpLdr	Lloh182, Lloh183
	.loh AdrpAdd	Lloh184, Lloh185
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_scheduler_wait_v1       ; -- Begin function neoclr_scheduler_wait_v1
	.p2align	2
_neoclr_scheduler_wait_v1:              ; @neoclr_scheduler_wait_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	sub	sp, sp, #544
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh186:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh187:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh188:
	ldr	x9, [x9]
	stur	x9, [x29, #-24]
Lloh189:
	adrp	x0, _head@TLVPPAGE
Lloh190:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x19, [x0]
	cbz	x19, LBB38_24
LBB38_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	cmp	x9, x8
	b.eq	LBB38_3
; %bb.2:                                ;   in Loop: Header=BB38_1 Depth=1
	ldr	x19, [x19, #8]
	cbnz	x19, LBB38_1
	b	LBB38_24
LBB38_3:
	ldr	w8, [x8]
	cbnz	w8, LBB38_24
; %bb.4:
	ldr	x8, [x19, #12352]
	cbnz	x8, LBB38_24
; %bb.5:
	ldr	x8, [x19, #12304]
	cbnz	x8, LBB38_24
; %bb.6:
	add	x1, sp, #16
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB38_22
; %bb.7:
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp, #16]
	madd	x8, x9, x8, x10
	cbz	x8, LBB38_22
; %bb.8:
	mov	x10, #0                         ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w9, #16959                      ; =0x423f
	movk	w9, #15, lsl #16
	add	x12, x19, #1040
	add	x13, x19, #24
	add	x11, x9, #1
	mov	w14, #176                       ; =0xb0
	add	x15, sp, #16
	mov	w16, #4                         ; =0x4
	b	LBB38_10
LBB38_9:                                ;   in Loop: Header=BB38_10 Depth=1
	add	x10, x10, #1
	cmp	x10, #64
	b.eq	LBB38_26
LBB38_10:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB38_16 Depth 2
	madd	x0, x10, x14, x12
	ldr	w2, [x0, #56]
	cmp	w2, #2
	b.eq	LBB38_24
; %bb.11:                               ;   in Loop: Header=BB38_10 Depth=1
	ldr	w17, [x0, #60]
	cmp	w2, #1
	ccmp	w17, #8, #4, eq
	b.eq	LBB38_9
; %bb.12:                               ;   in Loop: Header=BB38_10 Depth=1
	sub	w2, w17, #2
	cmp	w2, #4
	b.hi	LBB38_14
; %bb.13:                               ;   in Loop: Header=BB38_10 Depth=1
	ldr	x2, [x0, #48]
	subs	x3, x2, x8
	cmp	x3, x11
	csel	x11, x3, x11, lo
	cmp	x2, x8
	b.ls	LBB38_24
LBB38_14:                               ;   in Loop: Header=BB38_10 Depth=1
	sub	w2, w17, #1
	cmp	w2, #2
	b.hi	LBB38_18
; %bb.15:                               ;   in Loop: Header=BB38_10 Depth=1
	ldr	x2, [x0, #8]
	mov	w3, #64                         ; =0x40
	mov	x0, x13
LBB38_16:                               ;   Parent Loop BB38_10 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x4, [x0, #-8]
	cmp	x4, x2
	b.eq	LBB38_20
; %bb.17:                               ;   in Loop: Header=BB38_16 Depth=2
	add	x0, x0, #16
	subs	x3, x3, #1
	b.ne	LBB38_16
	b	LBB38_24
LBB38_18:                               ;   in Loop: Header=BB38_10 Depth=1
	cmp	w17, #4
	b.ne	LBB38_9
; %bb.19:                               ;   in Loop: Header=BB38_10 Depth=1
	add	x0, x0, #88
LBB38_20:                               ;   in Loop: Header=BB38_10 Depth=1
	ldr	w0, [x0]
	cmn	w0, #1
	b.eq	LBB38_9
; %bb.21:                               ;   in Loop: Header=BB38_10 Depth=1
	add	x2, x15, w1, uxtw #3
	cmp	w17, #3
	str	w0, [x2]
	csinc	w17, w16, wzr, hs
	strh	w17, [x2, #4]
	strh	wzr, [x2, #6]
	add	w1, w1, #1
	b	LBB38_9
LBB38_22:
Lloh191:
	adrp	x8, l___const.neoclr_os_pause.pause@PAGE
Lloh192:
	add	x8, x8, l___const.neoclr_os_pause.pause@PAGEOFF
Lloh193:
	ldr	q0, [x8]
	str	q0, [sp, #16]
	add	x0, sp, #16
LBB38_23:
	mov	x1, #0                          ; =0x0
	bl	_nanosleep
LBB38_24:
	ldur	x8, [x29, #-24]
Lloh194:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh195:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh196:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB38_30
; %bb.25:
	add	sp, sp, #544
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB38_26:
	cbz	w1, LBB38_29
; %bb.27:
	add	x8, x11, x9
	mov	x9, #13531                      ; =0x34db
	movk	x9, #55222, lsl #16
	movk	x9, #56962, lsl #32
	movk	x9, #17179, lsl #48
	umulh	x8, x8, x9
	lsr	x2, x8, #18
	add	x0, sp, #16
                                        ; kill: def $w2 killed $w2 killed $x2
	bl	_poll
	tbz	w0, #31, LBB38_24
; %bb.28:
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.eq	LBB38_24
LBB38_29:
Lloh197:
	adrp	x8, l___const.neoclr_os_pause.pause@PAGE
Lloh198:
	add	x8, x8, l___const.neoclr_os_pause.pause@PAGEOFF
Lloh199:
	ldr	q0, [x8]
	str	q0, [sp]
	mov	x0, sp
	b	LBB38_23
LBB38_30:
	bl	___stack_chk_fail
	.loh AdrpLdr	Lloh189, Lloh190
	.loh AdrpLdrGotLdr	Lloh186, Lloh187, Lloh188
	.loh AdrpAddLdr	Lloh191, Lloh192, Lloh193
	.loh AdrpLdrGotLdr	Lloh194, Lloh195, Lloh196
	.loh AdrpAddLdr	Lloh197, Lloh198, Lloh199
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_poll_v1          ; -- Begin function neoclr_socket_poll_v1
	.p2align	2
_neoclr_socket_poll_v1:                 ; @neoclr_socket_poll_v1
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB39_3
LBB39_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x20
	b.eq	LBB39_4
; %bb.2:                                ;   in Loop: Header=BB39_1 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB39_1
LBB39_3:
	mov	x0, x20
	mov	x1, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_socket_poll
LBB39_4:
	mov	w0, #-3                         ; =0xfffffffd
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function socket_poll
lCPI40_0:
	.quad	2                               ; 0x2
	.quad	10                              ; 0xa
lCPI40_1:
	.quad	2                               ; 0x2
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_socket_poll:                           ; @socket_poll
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #496
	stp	x28, x27, [sp, #400]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #416]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #432]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #448]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #464]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #480]            ; 16-byte Folded Spill
	add	x29, sp, #480
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x0
Lloh200:
	adrp	x0, _head@TLVPPAGE
Lloh201:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x19, [x0]
	cbz	x19, LBB40_7
; %bb.1:
	add	x24, sp, #128
LBB40_2:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x19]
	cmp	x8, x20
	b.eq	LBB40_4
; %bb.3:                                ;   in Loop: Header=BB40_2 Depth=1
	ldr	x19, [x19, #8]
	cbnz	x19, LBB40_2
	b	LBB40_7
LBB40_4:
	cbz	x1, LBB40_7
; %bb.5:
	ldr	w8, [x20]
	cbnz	w8, LBB40_7
; %bb.6:
	ldr	x8, [x19, #12352]
	cbz	x8, LBB40_9
LBB40_7:
	mov	w0, #-3                         ; =0xfffffffd
LBB40_8:
	ldp	x29, x30, [sp, #480]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #464]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #448]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #432]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #416]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #400]            ; 16-byte Folded Reload
	add	sp, sp, #496
	ret
LBB40_9:
	ldr	x8, [x19, #12320]
	str	x1, [sp, #96]                   ; 8-byte Folded Spill
	cbz	x8, LBB40_12
; %bb.10:
	mov	x0, x20
	mov	x1, x8
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB40_7
; %bb.11:
	str	xzr, [x19, #12320]
	ldr	x1, [sp, #96]                   ; 8-byte Folded Reload
LBB40_12:
	ldr	x8, [x19, #12336]
	cbz	x8, LBB40_15
; %bb.13:
	mov	x0, x20
	mov	x1, x8
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB40_7
; %bb.14:
	str	xzr, [x19, #12336]
	ldr	x1, [sp, #96]                   ; 8-byte Folded Reload
LBB40_15:
	mov	x8, #0                          ; =0x0
	add	x13, x19, #1040
	add	x9, x19, #1100
	mov	w27, #64                        ; =0x40
	mov	w10, #176                       ; =0xb0
	b	LBB40_18
LBB40_16:                               ;   in Loop: Header=BB40_18 Depth=1
	mov	x27, x8
LBB40_17:                               ;   in Loop: Header=BB40_18 Depth=1
	add	x8, x8, #1
	add	x9, x9, #176
	cmp	x8, #64
	b.eq	LBB40_22
LBB40_18:                               ; =>This Inner Loop Header: Depth=1
	ldr	w11, [x9]
	cmp	w11, #7
	b.ne	LBB40_17
; %bb.19:                               ;   in Loop: Header=BB40_18 Depth=1
	ldur	w11, [x9, #-4]
	cmp	w11, #2
	b.ne	LBB40_17
; %bb.20:                               ;   in Loop: Header=BB40_18 Depth=1
	cmp	w27, #64
	b.eq	LBB40_16
; %bb.21:                               ;   in Loop: Header=BB40_18 Depth=1
	ldur	x11, [x9, #-60]
	umull	x12, w27, w10
	ldr	x12, [x13, x12]
	cmp	x11, x12
	b.lo	LBB40_16
	b	LBB40_17
LBB40_22:
	ldr	x8, [x19, #12304]
	str	x13, [sp, #88]                  ; 8-byte Folded Spill
	cbz	x8, LBB40_27
; %bb.23:
	cmp	w27, #64
	b.eq	LBB40_25
; %bb.24:
	ldr	x8, [x8, #16]
	mov	w9, #176                        ; =0xb0
	umull	x9, w27, w9
	ldr	x9, [x13, x9]
	cmp	x8, x9
	b.hs	LBB40_27
LBB40_25:
	ldr	w8, [x19, #12328]
	cbz	w8, LBB40_28
; %bb.26:
	mov	x0, x19
	ldp	x29, x30, [sp, #480]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #464]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #448]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #432]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #416]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #400]            ; 16-byte Folded Reload
	add	sp, sp, #496
	b	_take_runnable
LBB40_27:
	str	wzr, [sp, #84]                  ; 4-byte Folded Spill
	b	LBB40_29
LBB40_28:
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #84]                   ; 4-byte Folded Spill
LBB40_29:
	bl	_monotonic_ns
	cbz	x0, LBB40_7
; %bb.30:
	mov	x8, #0                          ; =0x0
	add	x11, x19, #1100
	mov	w28, #64                        ; =0x40
	mov	w9, #176                        ; =0xb0
	mov	x10, x11
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	b	LBB40_33
LBB40_31:                               ;   in Loop: Header=BB40_33 Depth=1
	mov	x28, x8
LBB40_32:                               ;   in Loop: Header=BB40_33 Depth=1
	add	x8, x8, #1
	mov	x11, x10
	cmp	x8, #64
	b.eq	LBB40_40
LBB40_33:                               ; =>This Inner Loop Header: Depth=1
	ldr	w12, [x10], #176
	cmp	w12, #6
	b.ne	LBB40_32
; %bb.34:                               ;   in Loop: Header=BB40_33 Depth=1
	ldur	w12, [x11, #-4]
	cbz	w12, LBB40_32
; %bb.35:                               ;   in Loop: Header=BB40_33 Depth=1
	ldur	x12, [x11, #-12]
	cmp	x12, x0
	b.hi	LBB40_32
; %bb.36:                               ;   in Loop: Header=BB40_33 Depth=1
	cmp	w28, #64
	b.eq	LBB40_31
; %bb.37:                               ;   in Loop: Header=BB40_33 Depth=1
	umaddl	x13, w28, w9, x15
	ldr	x14, [x13, #48]
	cmp	x12, x14
	b.lo	LBB40_31
; %bb.38:                               ;   in Loop: Header=BB40_33 Depth=1
	b.ne	LBB40_32
; %bb.39:                               ;   in Loop: Header=BB40_33 Depth=1
	ldur	x11, [x11, #-60]
	ldr	x12, [x13]
	cmp	x11, x12
	b.lo	LBB40_31
	b	LBB40_32
LBB40_40:
	mov	w25, #0                         ; =0x0
	add	x9, x19, #16
	mov	w22, #176                       ; =0xb0
	umaddl	x8, w28, w22, x15
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	add	x8, x19, #24
	stp	x9, x8, [sp, #16]               ; 16-byte Folded Spill
Lloh202:
	adrp	x8, lCPI40_1@PAGE
Lloh203:
	ldr	q0, [x8, lCPI40_1@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
Lloh204:
	adrp	x8, lCPI40_0@PAGE
Lloh205:
	ldr	q0, [x8, lCPI40_0@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Folded Spill
	b	LBB40_42
LBB40_41:                               ;   in Loop: Header=BB40_42 Depth=1
	add	w25, w25, #1
	cmp	w25, #64
	b.eq	LBB40_146
LBB40_42:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB40_96 Depth 2
                                        ;     Child Loop BB40_117 Depth 2
                                        ;     Child Loop BB40_124 Depth 2
                                        ;     Child Loop BB40_132 Depth 2
	ldr	w8, [x19, #12376]
	add	w12, w8, w25
	and	w21, w12, #0x3f
	cmp	w21, w28
	b.ne	LBB40_44
; %bb.43:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	mov	w9, #2                          ; =0x2
	stur	w9, [x8, #56]
LBB40_44:                               ;   in Loop: Header=BB40_42 Depth=1
	umaddl	x23, w21, w22, x15
	ldr	w8, [x23, #56]
	cmp	w8, #1
	b.ne	LBB40_119
; %bb.45:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	w8, [x23, #60]
	and	w8, w8, #0xfffffffe
	cmp	w8, #4
	b.ne	LBB40_93
; %bb.46:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	x26, x12
	sub	x1, x29, #224
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	x8, x0
	mov	w0, #-3                         ; =0xfffffffd
	cbnz	w8, LBB40_8
; %bb.47:                               ;   in Loop: Header=BB40_42 Depth=1
	ldp	x8, x9, [x29, #-224]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x22, x8, x10, x9
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	cbz	x22, LBB40_8
; %bb.48:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	x12, x26
	ldr	w8, [x23, #60]
	cmp	w8, #5
	b.ne	LBB40_52
; %bb.49:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	x0, [x23, #80]
	ldr	x8, [x23, #48]
	cmp	x22, x8
	b.hs	LBB40_61
; %bb.50:                               ;   in Loop: Header=BB40_42 Depth=1
	add	x8, x0, #4
	ldapr	w8, [x8]
	mov	w22, #176                       ; =0xb0
	cbz	w8, LBB40_93
; %bb.51:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	w8, [x0, #268]
	cmp	x8, #0
	mov	w10, #2                         ; =0x2
	mov	w9, #7                          ; =0x7
	csel	x9, x9, x10, eq
	stp	x9, x8, [x23, #24]
	str	w10, [x23, #56]
	b	LBB40_120
LBB40_52:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	x8, [x23, #48]
	cmp	x22, x8
	b.hs	LBB40_67
; %bb.53:                               ;   in Loop: Header=BB40_42 Depth=1
	ldrsw	x0, [x23, #88]
	cmp	w0, #1024
	b.lt	LBB40_74
; %bb.54:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	x0, [x23, #80]
	cbz	x0, LBB40_57
; %bb.55:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x0]
	cmp	w8, #1
	b.ne	LBB40_57
; %bb.56:                               ;   in Loop: Header=BB40_42 Depth=1
	bl	_free
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	mov	x12, x26
LBB40_57:                               ;   in Loop: Header=BB40_42 Depth=1
	str	xzr, [x23, #80]
	ldr	w8, [x23, #60]
	cmp	w8, #4
	mov	w22, #176                       ; =0xb0
	b.ne	LBB40_60
; %bb.58:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	w0, [x23, #88]
	cmn	w0, #1
	b.eq	LBB40_60
; %bb.59:                               ;   in Loop: Header=BB40_42 Depth=1
	bl	_close
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	mov	x12, x26
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x23, #88]
LBB40_60:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	w8, #2                          ; =0x2
	str	w8, [x23, #56]
	ldr	q0, [sp, #48]                   ; 16-byte Folded Reload
	stur	q0, [x23, #24]
	b	LBB40_120
LBB40_61:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	q0, [sp, #48]                   ; 16-byte Folded Reload
	stur	q0, [x23, #24]
	mov	w8, #2                          ; =0x2
	str	w8, [x23, #56]
	mov	w22, #176                       ; =0xb0
	cbz	x0, LBB40_64
; %bb.62:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x0]
	cmp	w8, #1
	b.ne	LBB40_64
; %bb.63:                               ;   in Loop: Header=BB40_42 Depth=1
	bl	_free
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	mov	x12, x26
LBB40_64:                               ;   in Loop: Header=BB40_42 Depth=1
	str	xzr, [x23, #80]
	ldr	w8, [x23, #60]
	cmp	w8, #4
	b.ne	LBB40_93
; %bb.65:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	w0, [x23, #88]
	cmn	w0, #1
	b.eq	LBB40_93
; %bb.66:                               ;   in Loop: Header=BB40_42 Depth=1
	bl	_close
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	mov	x12, x26
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x23, #88]
	b	LBB40_93
LBB40_67:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	x0, [x23, #80]
	cbz	x0, LBB40_70
; %bb.68:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x0]
	cmp	w8, #1
	b.ne	LBB40_70
; %bb.69:                               ;   in Loop: Header=BB40_42 Depth=1
	bl	_free
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	mov	x12, x26
LBB40_70:                               ;   in Loop: Header=BB40_42 Depth=1
	str	xzr, [x23, #80]
	ldr	w8, [x23, #60]
	cmp	w8, #4
	mov	w22, #176                       ; =0xb0
	b.ne	LBB40_73
; %bb.71:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	w0, [x23, #88]
	cmn	w0, #1
	b.eq	LBB40_73
; %bb.72:                               ;   in Loop: Header=BB40_42 Depth=1
	bl	_close
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	mov	x12, x26
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x23, #88]
LBB40_73:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	w8, #2                          ; =0x2
	str	w8, [x23, #56]
	ldr	q0, [sp, #32]                   ; 16-byte Folded Reload
	stur	q0, [x23, #24]
	b	LBB40_120
LBB40_74:                               ;   in Loop: Header=BB40_42 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24, #144]
	stp	q0, q0, [x24, #176]
	stp	q0, q0, [x24, #208]
	str	q0, [x24, #240]
	stp	q0, q0, [sp, #128]
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #192]
	str	q0, [sp, #224]
	stp	q0, q0, [x24, #112]
	sub	x1, x29, #224
	mov	w2, #0                          ; =0x0
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	bl	___darwin_check_fd_set_overflow
	ldr	x12, [sp, #8]                   ; 8-byte Folded Reload
	cbz	w0, LBB40_76
; %bb.75:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w12
	lsr	x9, x12, #3
	and	x9, x9, #0x1ffffffffffffffc
	sub	x11, x29, #224
	ldr	w10, [x11, x9]
	orr	w8, w10, w8
	str	w8, [x11, x9]
LBB40_76:                               ;   in Loop: Header=BB40_42 Depth=1
	add	x1, sp, #128
	mov	x0, x12
	mov	w2, #0                          ; =0x0
	bl	___darwin_check_fd_set_overflow
	ldr	x12, [sp, #8]                   ; 8-byte Folded Reload
	cbz	w0, LBB40_78
; %bb.77:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	w8, #1                          ; =0x1
	lsl	w8, w8, w12
	lsr	x9, x12, #3
	and	x9, x9, #0x1ffffffffffffffc
	add	x11, sp, #128
	ldr	w10, [x11, x9]
	orr	w8, w10, w8
	str	w8, [x11, x9]
LBB40_78:                               ;   in Loop: Header=BB40_42 Depth=1
	stp	xzr, xzr, [sp, #112]
	add	w0, w12, #1
	sub	x2, x29, #224
	add	x3, sp, #128
	add	x4, sp, #112
	mov	x1, #0                          ; =0x0
	bl	_select
	tbnz	w0, #31, LBB40_82
; %bb.79:                               ;   in Loop: Header=BB40_42 Depth=1
	cbz	w0, LBB40_85
; %bb.80:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	w8, #4                          ; =0x4
	stp	w8, wzr, [sp, #104]
	add	x3, sp, #108
	add	x4, sp, #104
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
                                        ; kill: def $w0 killed $w0 killed $x0
	mov	w1, #65535                      ; =0xffff
	mov	w2, #4103                       ; =0x1007
	bl	_getsockopt
	cbz	w0, LBB40_86
; %bb.81:                               ;   in Loop: Header=BB40_42 Depth=1
	bl	___error
	ldr	w0, [x0]
	str	w0, [sp, #108]
	b	LBB40_87
LBB40_82:                               ;   in Loop: Header=BB40_42 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.eq	LBB40_92
; %bb.83:                               ;   in Loop: Header=BB40_42 Depth=1
	cmp	w8, #35
	b.eq	LBB40_92
; %bb.84:                               ;   in Loop: Header=BB40_42 Depth=1
	bl	___error
	ldr	w0, [x0]
	b	LBB40_89
LBB40_85:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	x8, [x23, #168]
	cmp	x22, x8
	b.lo	LBB40_92
	b	LBB40_90
LBB40_86:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	w0, [sp, #108]
LBB40_87:                               ;   in Loop: Header=BB40_42 Depth=1
	cbz	w0, LBB40_91
; %bb.88:                               ;   in Loop: Header=BB40_42 Depth=1
	ldp	w9, w8, [x23, #156]
	cmp	w8, w9
	b.ne	LBB40_90
LBB40_89:                               ;   in Loop: Header=BB40_42 Depth=1
	bl	_error_code
	mov	x2, x0
	mov	x0, x19
	mov	x1, x21
	bl	_connect_settle
	b	LBB40_92
LBB40_90:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	x0, x19
	mov	x1, x21
	mov	x2, x22
	bl	_connect_next
	b	LBB40_92
LBB40_91:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	x0, x19
	mov	x1, x21
	bl	_connect_success
LBB40_92:                               ;   in Loop: Header=BB40_42 Depth=1
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	mov	w22, #176                       ; =0xb0
	mov	x12, x26
LBB40_93:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	w8, [x23, #56]
	cmp	w8, #1
	b.ne	LBB40_119
; %bb.94:                               ;   in Loop: Header=BB40_42 Depth=1
	ldr	w8, [x23, #60]
	and	w9, w8, #0xfffffffe
	cmp	w9, #2
	b.ne	LBB40_115
; %bb.95:                               ;   in Loop: Header=BB40_42 Depth=1
	mov	x22, #0                         ; =0x0
	ldr	x8, [x23, #8]
LBB40_96:                               ;   Parent Loop BB40_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x19, x22
	ldr	x9, [x9, #16]
	cmp	x9, x8
	b.eq	LBB40_98
; %bb.97:                               ;   in Loop: Header=BB40_96 Depth=2
	add	x22, x22, #16
	mov	w0, #-3                         ; =0xfffffffd
	cmp	x22, #1024
	b.ne	LBB40_96
	b	LBB40_8
LBB40_98:                               ;   in Loop: Header=BB40_42 Depth=1
	str	w12, [sp, #8]                   ; 4-byte Folded Spill
	sub	x1, x29, #224
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	x8, x0
	mov	w0, #-3                         ; =0xfffffffd
	cbnz	w8, LBB40_8
; %bb.99:                               ;   in Loop: Header=BB40_42 Depth=1
	ldp	x8, x9, [x29, #-224]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x8, x8, x10, x9
	cbz	x8, LBB40_8
; %bb.100:                              ;   in Loop: Header=BB40_42 Depth=1
	ldr	w2, [x23, #68]
	ldr	w26, [x23, #60]
	cmp	w26, #3
	cset	w3, eq
	cbz	w2, LBB40_109
; %bb.101:                              ;   in Loop: Header=BB40_42 Depth=1
	ldr	x9, [x23, #48]
	cmp	x8, x9
	b.hs	LBB40_111
; %bb.102:                              ;   in Loop: Header=BB40_42 Depth=1
	add	x8, x19, x22
	ldr	w0, [x8, #24]
	ldr	x1, [x23, #72]
	bl	_neoclr_os_transfer
	cmn	x0, #2
	b.eq	LBB40_7
; %bb.103:                              ;   in Loop: Header=BB40_42 Depth=1
	tbnz	x0, #63, LBB40_142
; %bb.104:                              ;   in Loop: Header=BB40_42 Depth=1
	cmp	w26, #3
	cset	w8, eq
	cmp	x0, #0
	cset	w9, eq
	tst	w9, w8
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	mov	w9, #11                         ; =0xb
	csel	x22, x9, x0, ne
	cmp	w26, #3
	b.eq	LBB40_113
; %bb.105:                              ;   in Loop: Header=BB40_42 Depth=1
	cbz	x22, LBB40_113
; %bb.106:                              ;   in Loop: Header=BB40_42 Depth=1
	stur	xzr, [x29, #-224]
	ldr	x1, [x23, #40]
	sub	x2, x29, #224
	mov	x0, x20
	bl	_neoclr_gc_host_root_read_v1
	cbnz	w0, LBB40_7
; %bb.107:                              ;   in Loop: Header=BB40_42 Depth=1
	ldur	x8, [x29, #-224]
	ldp	x9, x26, [x8]
	str	x9, [sp]                        ; 8-byte Folded Spill
	ldr	w9, [x23, #64]
	add	x8, x8, x9
	ldr	x1, [x23, #72]
	add	x0, x8, #16
	mov	x2, x22
	bl	_memcpy
	mov	w8, #2                          ; =0x2
	movk	w8, #32768, lsl #16
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	cmp	x9, x8
	b.ne	LBB40_110
; %bb.108:                              ;   in Loop: Header=BB40_42 Depth=1
	ldur	x8, [x29, #-224]
	ldr	w9, [x23, #64]
	add	x8, x8, x9
	add	x8, x8, x26
	add	x0, x8, #16
	mov	w1, #1                          ; =0x1
	mov	x2, x22
	bl	_memset
	b	LBB40_110
LBB40_109:                              ;   in Loop: Header=BB40_42 Depth=1
	mov	x22, #0                         ; =0x0
LBB40_110:                              ;   in Loop: Header=BB40_42 Depth=1
	mov	w8, #1                          ; =0x1
	b	LBB40_113
LBB40_111:                              ;   in Loop: Header=BB40_42 Depth=1
	mov	w22, #10                        ; =0xa
LBB40_112:                              ;   in Loop: Header=BB40_42 Depth=1
	mov	w8, #2                          ; =0x2
LBB40_113:                              ;   in Loop: Header=BB40_42 Depth=1
	stp	x8, x22, [x23, #24]
	mov	w8, #2                          ; =0x2
	str	w8, [x23, #56]
	mov	x0, x19
	mov	x1, x21
	bl	_release_transfer
	ldr	w8, [x23, #56]
	cmp	w8, #1
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	mov	w22, #176                       ; =0xb0
	ldr	w12, [sp, #8]                   ; 4-byte Folded Reload
	b.ne	LBB40_119
; %bb.114:                              ;   in Loop: Header=BB40_42 Depth=1
	ldr	w8, [x23, #60]
LBB40_115:                              ;   in Loop: Header=BB40_42 Depth=1
	cmp	w8, #1
	b.ne	LBB40_41
; %bb.116:                              ;   in Loop: Header=BB40_42 Depth=1
	ldr	x8, [x23, #8]
	mov	w10, #64                        ; =0x40
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
LBB40_117:                              ;   Parent Loop BB40_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x11, [x9, #-8]
	cmp	x11, x8
	b.eq	LBB40_122
; %bb.118:                              ;   in Loop: Header=BB40_117 Depth=2
	add	x9, x9, #16
	mov	w0, #-3                         ; =0xfffffffd
	subs	x10, x10, #1
	b.ne	LBB40_117
	b	LBB40_8
LBB40_119:                              ;   in Loop: Header=BB40_42 Depth=1
	cmp	w8, #2
	b.ne	LBB40_41
LBB40_120:                              ;   in Loop: Header=BB40_42 Depth=1
	ldr	w8, [x23, #60]
	cmp	w21, w27
	ldr	w9, [sp, #84]                   ; 4-byte Folded Reload
	csinc	w9, w9, wzr, eq
	cmp	w8, #7
	b.ne	LBB40_147
; %bb.121:                              ;   in Loop: Header=BB40_42 Depth=1
	tbnz	w9, #0, LBB40_41
	b	LBB40_147
LBB40_122:                              ;   in Loop: Header=BB40_42 Depth=1
	mov	x26, x12
	ldr	w0, [x9]
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	bl	_accept
	cmn	w0, #1
	b.eq	LBB40_127
; %bb.123:                              ;   in Loop: Header=BB40_42 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	mov	x11, #9223372036854775806       ; =0x7ffffffffffffffe
Lloh206:
	adrp	x12, _next_id@PAGE
Lloh207:
	add	x12, x12, _next_id@PAGEOFF
LBB40_124:                              ;   Parent Loop BB40_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x10, [x9], #16
	cbz	x10, LBB40_130
; %bb.125:                              ;   in Loop: Header=BB40_124 Depth=2
	add	x8, x8, #1
	cmp	x8, #64
	b.ne	LBB40_124
; %bb.126:                              ;   in Loop: Header=BB40_42 Depth=1
	mov	w10, #64                        ; =0x40
	b	LBB40_131
LBB40_127:                              ;   in Loop: Header=BB40_42 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	mov	w22, #176                       ; =0xb0
	b.eq	LBB40_41
; %bb.128:                              ;   in Loop: Header=BB40_42 Depth=1
	cmp	w8, #35
	b.eq	LBB40_41
; %bb.129:                              ;   in Loop: Header=BB40_42 Depth=1
	bl	___error
	ldr	w0, [x0]
	bl	_error_code
	mov	x22, x0
	b	LBB40_140
LBB40_130:                              ;   in Loop: Header=BB40_42 Depth=1
	mov	w10, w8
LBB40_131:                              ;   in Loop: Header=BB40_42 Depth=1
Lloh208:
	adrp	x8, _next_id@PAGE
Lloh209:
	ldr	x8, [x8, _next_id@PAGEOFF]
LBB40_132:                              ;   Parent Loop BB40_42 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x8, x11
	b.hi	LBB40_138
; %bb.133:                              ;   in Loop: Header=BB40_132 Depth=2
	mov	x22, x8
	add	x9, x8, #1
	cas	x8, x9, [x12]
	cmp	x8, x22
	b.ne	LBB40_132
; %bb.134:                              ;   in Loop: Header=BB40_42 Depth=1
	cmp	x10, #64
	b.eq	LBB40_138
; %bb.135:                              ;   in Loop: Header=BB40_42 Depth=1
	str	x10, [sp]                       ; 8-byte Folded Spill
	mov	w8, #4                          ; =0x4
	cbz	x22, LBB40_139
; %bb.136:                              ;   in Loop: Header=BB40_42 Depth=1
	str	w0, [sp, #8]                    ; 4-byte Folded Spill
	bl	_neoclr_os_configure
	cbz	w0, LBB40_145
; %bb.137:                              ;   in Loop: Header=BB40_42 Depth=1
	bl	___error
	ldr	w0, [x0]
	bl	_error_code
	mov	x8, x0
	ldr	w0, [sp, #8]                    ; 4-byte Folded Reload
	b	LBB40_139
LBB40_138:                              ;   in Loop: Header=BB40_42 Depth=1
	mov	w8, #4                          ; =0x4
LBB40_139:                              ;   in Loop: Header=BB40_42 Depth=1
	mov	x22, x8
	bl	_close
LBB40_140:                              ;   in Loop: Header=BB40_42 Depth=1
	mov	w8, #2                          ; =0x2
LBB40_141:                              ;   in Loop: Header=BB40_42 Depth=1
	stp	x8, x22, [x23, #24]
	mov	w8, #2                          ; =0x2
	str	w8, [x23, #56]
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	mov	w22, #176                       ; =0xb0
	mov	x12, x26
	b	LBB40_120
LBB40_142:                              ;   in Loop: Header=BB40_42 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	ldp	x15, x1, [sp, #88]              ; 16-byte Folded Reload
	mov	w22, #176                       ; =0xb0
	b.eq	LBB40_41
; %bb.143:                              ;   in Loop: Header=BB40_42 Depth=1
	cmp	w8, #35
	b.eq	LBB40_41
; %bb.144:                              ;   in Loop: Header=BB40_42 Depth=1
	bl	___error
	ldr	w0, [x0]
	bl	_error_code
	mov	x22, x0
	b	LBB40_112
LBB40_145:                              ;   in Loop: Header=BB40_42 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x9, [sp]                        ; 8-byte Folded Reload
	add	x9, x8, x9, lsl #4
	str	x22, [x9]
	ldr	w8, [sp, #8]                    ; 4-byte Folded Reload
	stp	w8, wzr, [x9, #8]
	mov	w8, #5                          ; =0x5
	b	LBB40_141
LBB40_146:
	mov	x0, x19
	bl	_take_runnable
	b	LBB40_8
LBB40_147:
	mov	w9, #3                          ; =0x3
	str	w9, [x23, #56]
	add	w9, w12, #1
	and	w9, w9, #0x3f
	str	w9, [x19, #12376]
	mov	w0, #1                          ; =0x1
	str	w0, [x19, #12328]
	ldr	x9, [x23, #16]
	str	x9, [x1]
	and	w8, w8, #0xfffffffe
	cmp	w8, #6
	b.ne	LBB40_8
; %bb.148:
	str	x9, [x19, #12336]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x23]
	stp	q0, q0, [x23, #32]
	stp	q0, q0, [x23, #64]
	stp	q0, q0, [x23, #96]
	stp	q0, q0, [x23, #128]
	str	q0, [x23, #160]
	b	LBB40_8
	.loh AdrpLdr	Lloh200, Lloh201
	.loh AdrpLdr	Lloh204, Lloh205
	.loh AdrpAdrp	Lloh202, Lloh204
	.loh AdrpLdr	Lloh202, Lloh203
	.loh AdrpAdd	Lloh206, Lloh207
	.loh AdrpLdr	Lloh208, Lloh209
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_socket_poll_suspended_v1 ; -- Begin function neoclr_socket_poll_suspended_v1
	.p2align	2
_neoclr_socket_poll_suspended_v1:       ; @neoclr_socket_poll_suspended_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	cbz	x2, LBB41_3
; %bb.1:
	mov	x21, x2
	mov	x19, x1
	mov	x20, x0
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x21
	b.ne	LBB41_3
; %bb.2:
	ldr	x8, [x21, #8]
	cmp	x8, x20
	b.eq	LBB41_4
LBB41_3:
	mov	w0, #-3                         ; =0xfffffffd
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB41_4:
	mov	x0, x20
	mov	x1, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_socket_poll
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_scheduler_step_v1       ; -- Begin function neoclr_scheduler_step_v1
	.p2align	2
_neoclr_scheduler_step_v1:              ; @neoclr_scheduler_step_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x2
	mov	x20, x1
	mov	x19, x0
	bl	_neoclr_root_probe_head_v1
	cbz	x21, LBB42_4
; %bb.1:
	cmp	x0, x21
	b.ne	LBB42_3
; %bb.2:
	ldr	x8, [x21, #8]
	cmp	x8, x19
	b.eq	LBB42_7
LBB42_3:
	mov	w0, #-3                         ; =0xfffffffd
	b	LBB42_17
LBB42_4:
	cbz	x0, LBB42_7
LBB42_5:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x19
	b.eq	LBB42_3
; %bb.6:                                ;   in Loop: Header=BB42_5 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB42_5
LBB42_7:
	mov	x0, x19
	mov	x1, x20
	bl	_socket_poll
	cbnz	w0, LBB42_17
; %bb.8:
Lloh210:
	adrp	x0, _head@TLVPPAGE
Lloh211:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB42_11
LBB42_9:                                ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x19
	b.eq	LBB42_11
; %bb.10:                               ;   in Loop: Header=BB42_9 Depth=1
	ldr	x8, [x8, #8]
	cbnz	x8, LBB42_9
LBB42_11:
	add	x8, x8, #1100
	mov	w9, #64                         ; =0x40
	b	LBB42_13
LBB42_12:                               ;   in Loop: Header=BB42_13 Depth=1
	add	x8, x8, #176
	subs	x9, x9, #1
	b.eq	LBB42_16
LBB42_13:                               ; =>This Inner Loop Header: Depth=1
	ldur	w10, [x8, #-4]
	cbz	w10, LBB42_12
; %bb.14:                               ;   in Loop: Header=BB42_13 Depth=1
	ldr	w10, [x8]
	cmp	w10, #8
	b.eq	LBB42_12
; %bb.15:
	mov	w0, #2                          ; =0x2
	b	LBB42_17
LBB42_16:
	mov	w0, #0                          ; =0x0
LBB42_17:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh210, Lloh211
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_scheduler_capture_v1    ; -- Begin function neoclr_scheduler_capture_v1
	.p2align	2
_neoclr_scheduler_capture_v1:           ; @neoclr_scheduler_capture_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh212:
	adrp	x0, _head@TLVPPAGE
Lloh213:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x20, [x0]
	cbz	x20, LBB43_7
LBB43_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20]
	cmp	x8, x19
	b.eq	LBB43_3
; %bb.2:                                ;   in Loop: Header=BB43_1 Depth=1
	ldr	x20, [x20, #8]
	cbnz	x20, LBB43_1
	b	LBB43_7
LBB43_3:
	cbz	x1, LBB43_7
; %bb.4:
	mov	x21, x1
	mov	x22, x2
	bl	_neoclr_root_probe_head_v1
	cbz	x22, LBB43_9
; %bb.5:
	mov	x8, x22
	cmp	x0, x22
	b.ne	LBB43_7
; %bb.6:
	ldr	x8, [x8, #8]
	cmp	x8, x19
	mov	x8, x21
	b.eq	LBB43_12
LBB43_7:
	mov	w0, #3                          ; =0x3
LBB43_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB43_9:
	mov	x8, x21
	cbz	x0, LBB43_12
LBB43_10:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x0, #8]
	cmp	x9, x19
	b.eq	LBB43_7
; %bb.11:                               ;   in Loop: Header=BB43_10 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB43_10
LBB43_12:
	ldr	x9, [x20, #12344]
	cbnz	x9, LBB43_17
; %bb.13:
Lloh214:
	adrp	x9, _next_scheduler_destination@PAGE
Lloh215:
	ldr	x12, [x9, _next_scheduler_destination@PAGEOFF]
	mov	x10, #9223372036854775806       ; =0x7ffffffffffffffe
Lloh216:
	adrp	x11, _next_scheduler_destination@PAGE
Lloh217:
	add	x11, x11, _next_scheduler_destination@PAGEOFF
LBB43_14:                               ; =>This Inner Loop Header: Depth=1
	cmp	x12, x10
	b.hi	LBB43_7
; %bb.15:                               ;   in Loop: Header=BB43_14 Depth=1
	mov	x9, x12
	add	x13, x12, #1
	cas	x12, x13, [x11]
	cmp	x12, x9
	b.ne	LBB43_14
; %bb.16:
	str	x9, [x20, #12344]
LBB43_17:
	mov	w0, #0                          ; =0x0
	str	x9, [x8]
	b	LBB43_8
	.loh AdrpLdr	Lloh212, Lloh213
	.loh AdrpAdd	Lloh216, Lloh217
	.loh AdrpLdr	Lloh214, Lloh215
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_scheduler_submit_to_v1  ; -- Begin function neoclr_scheduler_submit_to_v1
	.p2align	2
_neoclr_scheduler_submit_to_v1:         ; @neoclr_scheduler_submit_to_v1
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh218:
	adrp	x0, _head@TLVPPAGE
Lloh219:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cbz	x9, LBB44_6
LBB44_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9]
	cmp	x10, x8
	b.eq	LBB44_3
; %bb.2:                                ;   in Loop: Header=BB44_1 Depth=1
	ldr	x9, [x9, #8]
	cbnz	x9, LBB44_1
	b	LBB44_6
LBB44_3:
	cmp	x1, #1
	b.lt	LBB44_6
; %bb.4:
	ldr	x9, [x9, #12344]
	cmp	x9, x1
	b.ne	LBB44_6
; %bb.5:
	mov	x0, x8
	mov	x1, x2
	mov	x2, x3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	b	_neoclr_scheduler_submit_v1
LBB44_6:
	mov	w0, #3                          ; =0x3
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh218, Lloh219
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_scheduler_submit_v1     ; -- Begin function neoclr_scheduler_submit_v1
	.p2align	2
_neoclr_scheduler_submit_v1:            ; @neoclr_scheduler_submit_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x3, x2
	mov	x19, x0
Lloh220:
	adrp	x0, _head@TLVPPAGE
Lloh221:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x21, [x0]
	cbz	x21, LBB45_3
LBB45_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x21]
	cmp	x8, x19
	b.eq	LBB45_5
; %bb.2:                                ;   in Loop: Header=BB45_1 Depth=1
	ldr	x21, [x21, #8]
	cbnz	x21, LBB45_1
LBB45_3:
	mov	w0, #3                          ; =0x3
LBB45_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB45_5:
	str	xzr, [sp, #8]
	add	x2, sp, #8
	mov	x0, x19
	cbz	x3, LBB45_7
; %bb.6:
	bl	_neoclr_gc_callback_read_suspended_v1
	cbnz	w0, LBB45_4
	b	LBB45_8
LBB45_7:
	bl	_neoclr_gc_callback_read_v1
	cbnz	w0, LBB45_4
LBB45_8:
Lloh222:
	adrp	x8, _next_id@PAGE
Lloh223:
	ldr	x10, [x8, _next_id@PAGEOFF]
	mov	x8, #9223372036854775806        ; =0x7ffffffffffffffe
Lloh224:
	adrp	x9, _next_id@PAGE
Lloh225:
	add	x9, x9, _next_id@PAGEOFF
LBB45_9:                                ; =>This Inner Loop Header: Depth=1
	cmp	x10, x8
	b.hi	LBB45_3
; %bb.10:                               ;   in Loop: Header=BB45_9 Depth=1
	mov	x22, x10
	add	x11, x10, #1
	cas	x10, x11, [x9]
	cmp	x10, x22
	b.ne	LBB45_9
; %bb.11:
	cbz	x22, LBB45_3
; %bb.12:
	mov	w0, #24                         ; =0x18
	bl	_malloc
	cbz	x0, LBB45_15
; %bb.13:
	mov	x20, x0
	str	xzr, [sp]
	ldr	x1, [sp, #8]
	mov	x2, sp
	mov	x0, x19
	bl	_neoclr_gc_host_root_create_v1
	cbz	w0, LBB45_16
; %bb.14:
	mov	x19, x0
	mov	x0, x20
	bl	_free
	mov	x0, x19
	b	LBB45_4
LBB45_15:
	mov	w0, #5                          ; =0x5
	b	LBB45_4
LBB45_16:
	ldr	x8, [sp]
	stp	xzr, x8, [x20]
	str	x22, [x20, #16]
	ldr	x8, [x21, #12312]
	mov	w9, #12304                      ; =0x3010
	add	x9, x21, x9
	cmp	x8, #0
	csel	x8, x9, x8, eq
	str	x20, [x8]
	str	x20, [x21, #12312]
	b	LBB45_4
	.loh AdrpLdr	Lloh220, Lloh221
	.loh AdrpAdd	Lloh224, Lloh225
	.loh AdrpLdr	Lloh222, Lloh223
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_scheduler_capture_managed_v1 ; -- Begin function neoclr_scheduler_capture_managed_v1
	.p2align	2
_neoclr_scheduler_capture_managed_v1:   ; @neoclr_scheduler_capture_managed_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x1
	mov	x20, x0
	bl	_neoclr_root_probe_head_v1
	mov	x21, x0
Lloh226:
	adrp	x0, _head@TLVPPAGE
Lloh227:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x21, LBB46_8
; %bb.1:
	ldr	x22, [x8]
	cbz	x22, LBB46_8
LBB46_2:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x22]
	cmp	x8, x20
	b.eq	LBB46_4
; %bb.3:                                ;   in Loop: Header=BB46_2 Depth=1
	ldr	x22, [x22, #8]
	cbnz	x22, LBB46_2
	b	LBB46_7
LBB46_4:
	cbz	x19, LBB46_7
; %bb.5:
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x21
	b.ne	LBB46_7
; %bb.6:
	ldr	x8, [x21, #8]
	cmp	x8, x20
	b.eq	LBB46_9
LBB46_7:
	mov	w0, #3                          ; =0x3
LBB46_8:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB46_9:
	ldr	x8, [x22, #12344]
	cbnz	x8, LBB46_14
; %bb.10:
Lloh228:
	adrp	x8, _next_scheduler_destination@PAGE
Lloh229:
	ldr	x11, [x8, _next_scheduler_destination@PAGEOFF]
	mov	x9, #9223372036854775806        ; =0x7ffffffffffffffe
Lloh230:
	adrp	x10, _next_scheduler_destination@PAGE
Lloh231:
	add	x10, x10, _next_scheduler_destination@PAGEOFF
LBB46_11:                               ; =>This Inner Loop Header: Depth=1
	cmp	x11, x9
	b.hi	LBB46_7
; %bb.12:                               ;   in Loop: Header=BB46_11 Depth=1
	mov	x8, x11
	add	x12, x11, #1
	cas	x11, x12, [x10]
	cmp	x11, x8
	b.ne	LBB46_11
; %bb.13:
	str	x8, [x22, #12344]
LBB46_14:
	mov	w0, #0                          ; =0x0
	str	x8, [x19]
	b	LBB46_8
	.loh AdrpLdr	Lloh226, Lloh227
	.loh AdrpAdd	Lloh230, Lloh231
	.loh AdrpLdr	Lloh228, Lloh229
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_scheduler_submit_to_managed_v1 ; -- Begin function neoclr_scheduler_submit_to_managed_v1
	.p2align	2
_neoclr_scheduler_submit_to_managed_v1: ; @neoclr_scheduler_submit_to_managed_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x8, x0
Lloh232:
	adrp	x0, _head@TLVPPAGE
Lloh233:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cbz	x9, LBB47_10
LBB47_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x9]
	cmp	x10, x2
	b.eq	LBB47_3
; %bb.2:                                ;   in Loop: Header=BB47_1 Depth=1
	ldr	x9, [x9, #8]
	cbnz	x9, LBB47_1
	b	LBB47_10
LBB47_3:
	cmp	x8, #1
	b.lt	LBB47_10
; %bb.4:
	ldr	x9, [x9, #12344]
	cmp	x9, x8
	b.ne	LBB47_10
; %bb.5:
	mov	x20, x1
	mov	x22, x2
	mov	x21, x3
	bl	_neoclr_root_probe_head_v1
	mov	x19, x0
	mov	w0, #3                          ; =0x3
	cbz	x21, LBB47_11
; %bb.6:
	cbz	x19, LBB47_11
; %bb.7:
	ldr	x8, [x19, #8]
	cmp	x8, x22
	b.ne	LBB47_11
; %bb.8:
	mov	x0, x22
	str	xzr, [sp, #8]
	add	x2, sp, #8
	mov	x1, x20
	bl	_neoclr_gc_host_root_create_v1
	cbnz	w0, LBB47_11
; %bb.9:
	ldr	x1, [sp, #8]
	mov	x0, x22
	mov	x2, x19
	bl	_neoclr_scheduler_submit_v1
	mov	x19, x0
	ldr	x1, [sp, #8]
	mov	x0, x22
	bl	_neoclr_gc_host_root_release_v1
	cbz	w0, LBB47_12
LBB47_10:
	mov	w0, #3                          ; =0x3
LBB47_11:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB47_12:
	mov	x0, x19
	cbnz	w19, LBB47_11
; %bb.13:
	str	wzr, [x21]
	b	LBB47_11
	.loh AdrpLdr	Lloh232, Lloh233
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_scheduler_submit_managed_v1 ; -- Begin function neoclr_scheduler_submit_managed_v1
	.p2align	2
_neoclr_scheduler_submit_managed_v1:    ; @neoclr_scheduler_submit_managed_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x1
	mov	x22, x0
	bl	_neoclr_root_probe_head_v1
	mov	x21, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB48_8
; %bb.1:
	cbz	x21, LBB48_8
; %bb.2:
	ldr	x8, [x21, #8]
	cmp	x8, x20
	b.ne	LBB48_8
; %bb.3:
	str	xzr, [sp, #8]
	add	x2, sp, #8
	mov	x0, x20
	mov	x1, x22
	bl	_neoclr_gc_host_root_create_v1
	cbnz	w0, LBB48_8
; %bb.4:
	ldr	x1, [sp, #8]
	mov	x0, x20
	mov	x2, x21
	bl	_neoclr_scheduler_submit_v1
	mov	x21, x0
	ldr	x1, [sp, #8]
	mov	x0, x20
	bl	_neoclr_gc_host_root_release_v1
	cbz	w0, LBB48_6
; %bb.5:
	mov	w0, #3                          ; =0x3
	b	LBB48_8
LBB48_6:
	mov	x0, x21
	cbnz	w21, LBB48_8
; %bb.7:
	str	wzr, [x19]
LBB48_8:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_scheduler_register_managed_v1
lCPI49_0:
	.long	1                               ; 0x1
	.long	8                               ; 0x8
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_scheduler_register_managed_v1
	.p2align	2
_neoclr_scheduler_register_managed_v1:  ; @neoclr_scheduler_register_managed_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x3
	mov	x20, x2
	mov	x21, x1
	mov	x23, x0
Lloh234:
	adrp	x0, _head@TLVPPAGE
Lloh235:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x24, [x0]
	cbz	x24, LBB49_3
LBB49_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x24]
	cmp	x8, x20
	b.eq	LBB49_3
; %bb.2:                                ;   in Loop: Header=BB49_1 Depth=1
	ldr	x24, [x24, #8]
	cbnz	x24, LBB49_1
LBB49_3:
	bl	_neoclr_root_probe_head_v1
	mov	x22, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB49_8
; %bb.4:
	cbz	x24, LBB49_8
; %bb.5:
	cbz	x22, LBB49_8
; %bb.6:
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x22
	b.eq	LBB49_9
LBB49_7:
	mov	w0, #3                          ; =0x3
LBB49_8:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB49_9:
	mov	w0, #3                          ; =0x3
	cmp	x23, #1
	b.lt	LBB49_8
; %bb.10:
	ldr	x8, [x22, #8]
	cmp	x8, x20
	b.ne	LBB49_8
; %bb.11:
	ldr	x8, [x24, #12344]
	cmp	x8, x23
	b.ne	LBB49_8
; %bb.12:
	add	x23, x24, #1096
	mov	w8, #64                         ; =0x40
	mov	w0, #5                          ; =0x5
LBB49_13:                               ; =>This Inner Loop Header: Depth=1
	ldr	w9, [x23]
	cbz	w9, LBB49_15
; %bb.14:                               ;   in Loop: Header=BB49_13 Depth=1
	add	x23, x23, #176
	subs	x8, x8, #1
	b.ne	LBB49_13
	b	LBB49_8
LBB49_15:
Lloh236:
	adrp	x8, _next_id@PAGE
Lloh237:
	ldr	x10, [x8, _next_id@PAGEOFF]
	mov	x8, #9223372036854775807        ; =0x7fffffffffffffff
Lloh238:
	adrp	x9, _next_id@PAGE
Lloh239:
	add	x9, x9, _next_id@PAGEOFF
LBB49_16:                               ; =>This Inner Loop Header: Depth=1
	cmp	x10, x8
	b.hs	LBB49_7
; %bb.17:                               ;   in Loop: Header=BB49_16 Depth=1
	mov	x24, x10
	add	x11, x10, #1
	cas	x10, x11, [x9]
	cmp	x10, x24
	b.ne	LBB49_16
; %bb.18:
	str	xzr, [sp, #8]
	cbz	x24, LBB49_7
; %bb.19:
	add	x2, sp, #8
	mov	x0, x20
	mov	x1, x21
	bl	_neoclr_gc_host_root_create_v1
	cbnz	w0, LBB49_8
; %bb.20:
	str	xzr, [sp]
	ldr	x1, [sp, #8]
	mov	x2, sp
	mov	x0, x20
	mov	x3, x22
	bl	_neoclr_gc_callback_read_suspended_v1
	cbz	w0, LBB49_22
; %bb.21:
	ldr	x1, [sp, #8]
	mov	x19, x0
	mov	x0, x20
	bl	_neoclr_gc_host_root_release_v1
	mov	x0, x19
	b	LBB49_8
LBB49_22:
	stur	x24, [x23, #-56]
	ldr	x8, [sp, #8]
	stur	x8, [x23, #-40]
Lloh240:
	adrp	x8, lCPI49_0@PAGE
Lloh241:
	ldr	d0, [x8, lCPI49_0@PAGEOFF]
	str	d0, [x23]
	str	x24, [x19]
	b	LBB49_8
	.loh AdrpLdr	Lloh234, Lloh235
	.loh AdrpAdd	Lloh238, Lloh239
	.loh AdrpLdr	Lloh236, Lloh237
	.loh AdrpLdr	Lloh240, Lloh241
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_scheduler_activate_managed_v1 ; -- Begin function neoclr_scheduler_activate_managed_v1
	.p2align	2
_neoclr_scheduler_activate_managed_v1:  ; @neoclr_scheduler_activate_managed_v1
	.cfi_startproc
; %bb.0:
	mov	w3, #1                          ; =0x1
	b	_scheduler_registration_transition
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function scheduler_registration_transition
lCPI51_0:
	.long	2                               ; 0x2
	.long	7                               ; 0x7
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_scheduler_registration_transition:     ; @scheduler_registration_transition
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x21, x3
	mov	x19, x2
	mov	x20, x1
	mov	x22, x0
Lloh242:
	adrp	x0, _head@TLVPPAGE
Lloh243:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x24, [x0]
	cbz	x24, LBB51_3
LBB51_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x24]
	cmp	x8, x20
	b.eq	LBB51_3
; %bb.2:                                ;   in Loop: Header=BB51_1 Depth=1
	ldr	x24, [x24, #8]
	cbnz	x24, LBB51_1
LBB51_3:
	bl	_neoclr_root_probe_head_v1
	mov	x23, x0
	mov	w0, #3                          ; =0x3
	cbz	x19, LBB51_9
; %bb.4:
	cbz	x24, LBB51_9
; %bb.5:
	cbz	x23, LBB51_9
; %bb.6:
	bl	_neoclr_root_probe_head_v1
	cmp	x0, x23
	b.ne	LBB51_8
; %bb.7:
	ldr	x8, [x23, #8]
	cmp	x8, x20
	b.eq	LBB51_10
LBB51_8:
	mov	w0, #3                          ; =0x3
LBB51_9:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB51_10:
	add	x23, x24, #1040
	mov	w8, #64                         ; =0x40
	b	LBB51_12
LBB51_11:                               ;   in Loop: Header=BB51_12 Depth=1
	add	x23, x23, #176
	subs	x8, x8, #1
	b.eq	LBB51_24
LBB51_12:                               ; =>This Inner Loop Header: Depth=1
	cmp	x22, #1
	b.lt	LBB51_11
; %bb.13:                               ;   in Loop: Header=BB51_12 Depth=1
	ldr	x9, [x23]
	cmp	x9, x22
	b.ne	LBB51_11
; %bb.14:                               ;   in Loop: Header=BB51_12 Depth=1
	ldr	w9, [x23, #60]
	cmp	w9, #8
	b.ne	LBB51_11
; %bb.15:                               ;   in Loop: Header=BB51_12 Depth=1
	ldr	w9, [x23, #56]
	cmp	w9, #1
	b.ne	LBB51_11
; %bb.16:
	cbz	w21, LBB51_22
; %bb.17:
Lloh244:
	adrp	x8, _next_id@PAGE
Lloh245:
	ldr	x11, [x8, _next_id@PAGEOFF]
	mov	x8, #9223372036854775806        ; =0x7ffffffffffffffe
Lloh246:
	adrp	x10, _next_id@PAGE
Lloh247:
	add	x10, x10, _next_id@PAGEOFF
LBB51_18:                               ; =>This Inner Loop Header: Depth=1
	cmp	x11, x8
	b.hi	LBB51_8
; %bb.19:                               ;   in Loop: Header=BB51_18 Depth=1
	mov	x9, x11
	add	x12, x11, #1
	cas	x11, x12, [x10]
	cmp	x11, x9
	b.ne	LBB51_18
; %bb.20:
	cbz	x9, LBB51_8
; %bb.21:
	str	x9, [x23]
Lloh248:
	adrp	x8, lCPI51_0@PAGE
Lloh249:
	ldr	d0, [x8, lCPI51_0@PAGEOFF]
	str	d0, [x23, #56]
	mov	w8, #1                          ; =0x1
	b	LBB51_24
LBB51_22:
	ldr	x1, [x23, #16]
	mov	x0, x20
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB51_9
; %bb.23:
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x23, #144]
	stp	q0, q0, [x23, #112]
	stp	q0, q0, [x23, #80]
	stp	q0, q0, [x23, #48]
	stp	q0, q0, [x23, #16]
	mov	w8, #1                          ; =0x1
	str	q0, [x23]
LBB51_24:
	mov	w0, #0                          ; =0x0
	str	w8, [x19]
	b	LBB51_9
	.loh AdrpLdr	Lloh242, Lloh243
	.loh AdrpAdd	Lloh246, Lloh247
	.loh AdrpLdr	Lloh244, Lloh245
	.loh AdrpLdr	Lloh248, Lloh249
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_scheduler_cancel_managed_v1 ; -- Begin function neoclr_scheduler_cancel_managed_v1
	.p2align	2
_neoclr_scheduler_cancel_managed_v1:    ; @neoclr_scheduler_cancel_managed_v1
	.cfi_startproc
; %bb.0:
	mov	w3, #0                          ; =0x0
	b	_scheduler_registration_transition
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_schedule_task_managed_v1 ; -- Begin function neoclr_schedule_task_managed_v1
	.p2align	2
_neoclr_schedule_task_managed_v1:       ; @neoclr_schedule_task_managed_v1
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x1
	mov	x21, x0
	bl	_neoclr_root_probe_head_v1
	cbz	x0, LBB53_2
; %bb.1:
	ldr	x8, [x0, #8]
	cmp	x8, x19
	b.eq	LBB53_4
LBB53_2:
	mov	w0, #3                          ; =0x3
LBB53_3:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB53_4:
	mov	x20, x0
	str	xzr, [sp, #8]
	add	x2, sp, #8
	mov	x0, x19
	mov	x1, x21
	bl	_neoclr_gc_host_root_create_v1
	cbnz	w0, LBB53_3
; %bb.5:
	ldr	x1, [sp, #8]
	mov	x0, x19
	mov	x2, x20
	bl	_neoclr_scheduler_submit_v1
	mov	x20, x0
	ldr	x1, [sp, #8]
	mov	x0, x19
	bl	_neoclr_gc_host_root_release_v1
	mov	w8, #3                          ; =0x3
	cmp	w0, #0
	csel	w0, w20, w8, eq
	b	LBB53_3
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_scheduler_acquire_v1    ; -- Begin function neoclr_scheduler_acquire_v1
	.p2align	2
_neoclr_scheduler_acquire_v1:           ; @neoclr_scheduler_acquire_v1
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB54_4
; %bb.1:
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	x20, x0
	mov	x21, x1
	stp	xzr, xzr, [sp, #16]
	bl	_neoclr_root_probe_head_v1
	cbz	x19, LBB54_5
; %bb.2:
	cmp	x0, x19
	b.ne	LBB54_28
; %bb.3:
	ldr	x8, [x19, #8]
	cmp	x8, x20
	b.ne	LBB54_28
	b	LBB54_8
LBB54_4:
	mov	w0, #-3                         ; =0xfffffffd
	ret
LBB54_5:
	cbz	x0, LBB54_8
LBB54_6:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x20
	b.eq	LBB54_28
; %bb.7:                                ;   in Loop: Header=BB54_6 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB54_6
LBB54_8:
	add	x1, sp, #24
	mov	x0, x20
	bl	_socket_poll
	cmp	w0, #1
	b.eq	LBB54_17
; %bb.9:
	cbnz	w0, LBB54_22
; %bb.10:
Lloh250:
	adrp	x0, _head@TLVPPAGE
Lloh251:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB54_13
LBB54_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x8]
	cmp	x9, x20
	b.eq	LBB54_13
; %bb.12:                               ;   in Loop: Header=BB54_11 Depth=1
	ldr	x8, [x8, #8]
	cbnz	x8, LBB54_11
LBB54_13:
	add	x8, x8, #1100
	mov	w9, #64                         ; =0x40
	b	LBB54_15
LBB54_14:                               ;   in Loop: Header=BB54_15 Depth=1
	add	x8, x8, #176
	subs	x9, x9, #1
	b.eq	LBB54_24
LBB54_15:                               ; =>This Inner Loop Header: Depth=1
	ldur	w10, [x8, #-4]
	cbz	w10, LBB54_14
; %bb.16:                               ;   in Loop: Header=BB54_15 Depth=1
	ldr	w10, [x8]
	cmp	w10, #8
	b.eq	LBB54_14
	b	LBB54_23
LBB54_17:
Lloh252:
	adrp	x0, _head@TLVPPAGE
Lloh253:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
LBB54_18:                               ; =>This Inner Loop Header: Depth=1
	ldr	x22, [x0]
	mov	x0, x22
	ldr	x8, [x0], #8
	cmp	x8, x20
	b.ne	LBB54_18
; %bb.19:
	ldr	x8, [x22, #12320]
	ldr	x1, [sp, #24]
	cmp	x8, x1
	b.ne	LBB54_26
; %bb.20:
	str	xzr, [x22, #12320]
LBB54_21:
	str	x8, [x22, #12352]
	str	x19, [x22, #12360]
	mov	w0, #1                          ; =0x1
	str	x8, [x21]
	b	LBB54_29
LBB54_22:
	tst	w0, #0xfffffffd
	b.ne	LBB54_29
LBB54_23:
	mov	w21, #2                         ; =0x2
	b	LBB54_25
LBB54_24:
	mov	w21, #0                         ; =0x0
LBB54_25:
	mov	x0, x20
	mov	x1, x19
	bl	_neoclr_gc_idle_v1
	mov	x8, x0
	mov	x0, x21
	cbnz	w8, LBB54_28
	b	LBB54_29
LBB54_26:
	str	xzr, [sp, #8]
	add	x2, sp, #8
	mov	x0, x20
	bl	_neoclr_gc_host_root_read_v1
	cbnz	w0, LBB54_28
; %bb.27:
	ldr	x1, [sp, #8]
	add	x2, sp, #16
	mov	x0, x20
	bl	_neoclr_gc_host_root_create_v1
	cbz	w0, LBB54_30
LBB54_28:
	mov	w0, #-3                         ; =0xfffffffd
LBB54_29:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB54_30:
	ldr	x8, [sp, #16]
	b	LBB54_21
	.loh AdrpLdr	Lloh250, Lloh251
	.loh AdrpLdr	Lloh252, Lloh253
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_scheduler_complete_v1   ; -- Begin function neoclr_scheduler_complete_v1
	.p2align	2
_neoclr_scheduler_complete_v1:          ; @neoclr_scheduler_complete_v1
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh254:
	adrp	x0, _head@TLVPPAGE
Lloh255:
	ldr	x0, [x0, _head@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x20, [x0]
	cbz	x20, LBB55_6
LBB55_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x20]
	cmp	x8, x19
	b.eq	LBB55_3
; %bb.2:                                ;   in Loop: Header=BB55_1 Depth=1
	ldr	x20, [x20, #8]
	cbnz	x20, LBB55_1
	b	LBB55_6
LBB55_3:
	cbz	x1, LBB55_6
; %bb.4:
	ldr	x8, [x20, #12352]
	cmp	x8, x1
	b.ne	LBB55_6
; %bb.5:
	ldr	x8, [x20, #12360]
	cmp	x8, x2
	b.eq	LBB55_8
LBB55_6:
	mov	w0, #3                          ; =0x3
LBB55_7:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB55_8:
	mov	x21, x1
	mov	x22, x2
	bl	_neoclr_root_probe_head_v1
	cbz	x22, LBB55_11
; %bb.9:
	mov	x8, x22
	cmp	x0, x22
	b.ne	LBB55_6
; %bb.10:
	mov	x1, x21
	ldr	x8, [x8, #8]
	cmp	x8, x19
	b.ne	LBB55_6
	b	LBB55_14
LBB55_11:
	mov	x1, x21
	cbz	x0, LBB55_14
LBB55_12:                               ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x0, #8]
	cmp	x8, x19
	b.eq	LBB55_6
; %bb.13:                               ;   in Loop: Header=BB55_12 Depth=1
	ldr	x0, [x0]
	cbnz	x0, LBB55_12
LBB55_14:
	mov	x0, x19
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB55_6
; %bb.15:
	mov	w8, #12352                      ; =0x3040
	add	x8, x20, x8
	stp	xzr, xzr, [x8]
	b	LBB55_7
	.loh AdrpLdr	Lloh254, Lloh255
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function client_deadline
_client_deadline:                       ; @client_deadline
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp]
	madd	x8, x9, x8, x10
	mov	x9, #61952                      ; =0xf200
	movk	x9, #10757, lsl #16
	movk	x9, #1, lsl #32
	add	x8, x8, x9
	cmp	w0, #0
	csel	x8, x8, x9, eq
	orr	x9, x9, #0x1
	cmp	x8, x9
	b.hs	LBB56_2
; %bb.1:
	mov	w0, #3                          ; =0x3
	b	LBB56_3
LBB56_2:
	mov	w0, #0                          ; =0x0
	cmp	x8, x20
	csel	x9, x8, x20, lo
	cmp	x20, #0
	csel	x8, x8, x9, eq
	str	x8, [x19]
LBB56_3:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function dns_worker
lCPI57_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_dns_worker:                            ; @dns_worker
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #96
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #32]
	str	q0, [sp, #16]
	str	xzr, [sp, #8]
Lloh256:
	adrp	x8, lCPI57_0@PAGE
Lloh257:
	ldr	d0, [x8, lCPI57_0@PAGEOFF]
	stur	d0, [sp, #20]
	add	x0, x0, #8
	add	x2, sp, #16
	add	x3, sp, #8
	mov	x1, #0                          ; =0x0
	bl	_getaddrinfo
	cbz	w0, LBB57_2
; %bb.1:
	mov	w8, #6                          ; =0x6
	str	w8, [x19, #268]
	b	LBB57_21
LBB57_2:
	ldr	x0, [sp, #8]
	cbz	x0, LBB57_17
; %bb.3:
	mov	w8, #0                          ; =0x0
	add	x9, x19, #272
	mov	x10, x0
	b	LBB57_7
LBB57_4:                                ;   in Loop: Header=BB57_7 Depth=1
	cmp	w12, #16
	b.eq	LBB57_16
; %bb.5:                                ;   in Loop: Header=BB57_7 Depth=1
	add	w13, w12, #1
	str	w13, [x19, #264]
	str	w11, [x9, x12, lsl #2]
LBB57_6:                                ;   in Loop: Header=BB57_7 Depth=1
	add	w8, w8, #1
	ldr	x10, [x10, #40]
	cbz	x10, LBB57_17
LBB57_7:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB57_12 Depth 2
	cmp	w8, #256
	b.eq	LBB57_16
; %bb.8:                                ;   in Loop: Header=BB57_7 Depth=1
	ldr	w11, [x10, #4]
	cmp	w11, #2
	b.ne	LBB57_6
; %bb.9:                                ;   in Loop: Header=BB57_7 Depth=1
	ldr	w11, [x10, #16]
	cmp	w11, #16
	b.lo	LBB57_6
; %bb.10:                               ;   in Loop: Header=BB57_7 Depth=1
	ldr	x11, [x10, #32]
	ldr	w11, [x11, #4]
	ldr	w12, [x19, #264]
	cbz	w12, LBB57_14
; %bb.11:                               ;   in Loop: Header=BB57_7 Depth=1
	mov	x13, #0                         ; =0x0
LBB57_12:                               ;   Parent Loop BB57_7 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w14, [x9, x13, lsl #2]
	cmp	w14, w11
	b.eq	LBB57_15
; %bb.13:                               ;   in Loop: Header=BB57_12 Depth=2
	add	x13, x13, #1
	cmp	x12, x13
	b.ne	LBB57_12
	b	LBB57_4
LBB57_14:                               ;   in Loop: Header=BB57_7 Depth=1
	mov	w13, #0                         ; =0x0
LBB57_15:                               ;   in Loop: Header=BB57_7 Depth=1
	cmp	w13, w12
	b.eq	LBB57_4
	b	LBB57_6
LBB57_16:
	mov	w8, #2                          ; =0x2
	str	w8, [x19, #268]
LBB57_17:
	ldr	w8, [x19, #264]
	cbnz	w8, LBB57_20
; %bb.18:
	ldr	w8, [x19, #268]
	cbnz	w8, LBB57_20
; %bb.19:
	mov	w8, #3                          ; =0x3
	str	w8, [x19, #268]
LBB57_20:
	bl	_freeaddrinfo
LBB57_21:
Lloh258:
	adrp	x8, _resolver_workers@PAGE
Lloh259:
	add	x8, x8, _resolver_workers@PAGEOFF
	mov	w9, #-1                         ; =0xffffffff
	ldaddal	w9, w8, [x8]
	add	x8, x19, #4
	mov	w10, #1                         ; =0x1
	stlr	w10, [x8]
	ldaddal	w9, w8, [x19]
	cmp	w8, #1
	b.ne	LBB57_23
; %bb.22:
	mov	x0, x19
	bl	_free
LBB57_23:
	mov	x0, #0                          ; =0x0
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.loh AdrpLdr	Lloh256, Lloh257
	.loh AdrpAdd	Lloh258, Lloh259
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function connect_next
lCPI58_0:
	.quad	2                               ; 0x2
	.quad	10                              ; 0xa
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_connect_next:                          ; @connect_next
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	add	x29, sp, #112
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
Lloh260:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh261:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh262:
	ldr	x8, [x8]
	str	x8, [sp, #24]
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w1, w8, x0
	add	x25, x8, #1040
	ldr	x0, [x8, #1120]
	cbz	x0, LBB58_3
; %bb.1:
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x0]
	cmp	w8, #1
	b.ne	LBB58_3
; %bb.2:
	bl	_free
LBB58_3:
	str	xzr, [x25, #80]
	ldr	w8, [x25, #60]
	cmp	w8, #4
	b.ne	LBB58_6
; %bb.4:
	ldr	w0, [x25, #88]
	cmn	w0, #1
	b.eq	LBB58_6
; %bb.5:
	bl	_close
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x25, #88]
LBB58_6:
	ldp	w9, w8, [x25, #156]
	cmp	w8, w9
	b.hs	LBB58_60
; %bb.7:
	add	x26, x25, #92
	mov	w27, #2                         ; =0x2
	mov	w28, #-1                        ; =0xffffffff
	b	LBB58_9
LBB58_8:                                ;   in Loop: Header=BB58_9 Depth=1
	ldp	w9, w8, [x25, #156]
	cmp	w8, w9
	b.hs	LBB58_60
LBB58_9:                                ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x25, #48]
	cmp	x8, x19
	b.ls	LBB58_29
; %bb.10:                               ;   in Loop: Header=BB58_9 Depth=1
	mov	w0, #2                          ; =0x2
	mov	w1, #1                          ; =0x1
	mov	w2, #6                          ; =0x6
	bl	_socket
	mov	x22, x0
	str	w0, [x25, #88]
	cmn	w0, #1
	b.eq	LBB58_12
; %bb.11:                               ;   in Loop: Header=BB58_9 Depth=1
	mov	w8, #0                          ; =0x0
	b	LBB58_13
LBB58_12:                               ;   in Loop: Header=BB58_9 Depth=1
	bl	___error
	ldr	w8, [x0]
LBB58_13:                               ;   in Loop: Header=BB58_9 Depth=1
	stp	xzr, xzr, [sp, #8]
	strb	w27, [sp, #9]
	ldrh	w9, [x25, #164]
	rev	w9, w9
	lsr	w9, w9, #16
	strh	w9, [sp, #10]
	ldr	w10, [x25, #160]
	add	w9, w10, #1
	str	w9, [x25, #160]
	ldr	w10, [x26, x10, lsl #2]
	str	w10, [sp, #12]
	cbnz	w8, LBB58_22
; %bb.14:                               ;   in Loop: Header=BB58_9 Depth=1
	mov	x0, x22
	mov	w1, #3                          ; =0x3
	bl	_fcntl
	mov	x24, x0
	mov	x0, x22
	mov	w1, #1                          ; =0x1
	bl	_fcntl
	tbnz	w24, #31, LBB58_18
; %bb.15:                               ;   in Loop: Header=BB58_9 Depth=1
	mov	x23, x0
	tbnz	w0, #31, LBB58_18
; %bb.16:                               ;   in Loop: Header=BB58_9 Depth=1
	orr	w8, w24, #0x4
	str	x8, [sp]
	mov	x0, x22
	mov	w1, #4                          ; =0x4
	bl	_fcntl
	tbnz	w0, #31, LBB58_18
; %bb.17:                               ;   in Loop: Header=BB58_9 Depth=1
	orr	w8, w23, #0x1
	str	x8, [sp]
	mov	x0, x22
	mov	w1, #2                          ; =0x2
	bl	_fcntl
	tbz	w0, #31, LBB58_20
LBB58_18:                               ;   in Loop: Header=BB58_9 Depth=1
	bl	___error
	ldr	w8, [x0]
	cbz	w8, LBB58_20
; %bb.19:                               ;   in Loop: Header=BB58_9 Depth=1
	ldr	w9, [x25, #160]
	b	LBB58_22
LBB58_20:                               ;   in Loop: Header=BB58_9 Depth=1
	add	x1, sp, #8
	mov	x0, x22
	mov	w2, #16                         ; =0x10
	bl	_connect
	cbz	w0, LBB58_48
; %bb.21:                               ;   in Loop: Header=BB58_9 Depth=1
	bl	___error
	ldr	w8, [x0]
	sub	w10, w8, #37
	ldr	w9, [x25, #160]
	cmn	w10, #2
	b.hs	LBB58_49
LBB58_22:                               ;   in Loop: Header=BB58_9 Depth=1
	ldr	w10, [x25, #156]
	cmp	w9, w10
	b.eq	LBB58_36
; %bb.23:                               ;   in Loop: Header=BB58_9 Depth=1
	ldr	x0, [x25, #80]
	cbz	x0, LBB58_26
; %bb.24:                               ;   in Loop: Header=BB58_9 Depth=1
	ldaddal	w28, w8, [x0]
	cmp	w8, #1
	b.ne	LBB58_26
; %bb.25:                               ;   in Loop: Header=BB58_9 Depth=1
	bl	_free
LBB58_26:                               ;   in Loop: Header=BB58_9 Depth=1
	str	xzr, [x25, #80]
	ldr	w8, [x25, #60]
	cmp	w8, #4
	b.ne	LBB58_8
; %bb.27:                               ;   in Loop: Header=BB58_9 Depth=1
	ldr	w0, [x25, #88]
	cmn	w0, #1
	b.eq	LBB58_8
; %bb.28:                               ;   in Loop: Header=BB58_9 Depth=1
	bl	_close
	str	w28, [x25, #88]
	b	LBB58_8
LBB58_29:
	ldr	x0, [x25, #80]
	cbz	x0, LBB58_32
; %bb.30:
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x0]
	cmp	w8, #1
	b.ne	LBB58_32
; %bb.31:
	bl	_free
LBB58_32:
	str	xzr, [x25, #80]
	ldr	w8, [x25, #60]
	cmp	w8, #4
	b.ne	LBB58_35
; %bb.33:
	ldr	w0, [x25, #88]
	cmn	w0, #1
	b.eq	LBB58_35
; %bb.34:
	bl	_close
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x25, #88]
LBB58_35:
	mov	w8, #2                          ; =0x2
	str	w8, [x25, #56]
Lloh263:
	adrp	x8, lCPI58_0@PAGE
Lloh264:
	ldr	q0, [x8, lCPI58_0@PAGEOFF]
	stur	q0, [x25, #24]
	b	LBB58_60
LBB58_36:
	cmp	w8, #47
	b.le	LBB58_40
; %bb.37:
	cmp	w8, #59
	b.gt	LBB58_44
; %bb.38:
	cmp	w8, #48
	b.eq	LBB58_51
; %bb.39:
	cmp	w8, #54
	b.eq	LBB58_43
	b	LBB58_50
LBB58_40:
	cmp	w8, #1
	b.eq	LBB58_47
; %bb.41:
	cmp	w8, #13
	b.eq	LBB58_47
; %bb.42:
	cmp	w8, #32
	b.ne	LBB58_50
LBB58_43:
	mov	w19, #8                         ; =0x8
	b	LBB58_53
LBB58_44:
	cmp	w8, #60
	b.eq	LBB58_52
; %bb.45:
	cmp	w8, #61
	b.ne	LBB58_50
; %bb.46:
	mov	w19, #7                         ; =0x7
	b	LBB58_53
LBB58_47:
	mov	w19, #9                         ; =0x9
	b	LBB58_53
LBB58_48:
	mov	x0, x21
	mov	x1, x20
	bl	_connect_success
	b	LBB58_60
LBB58_49:
	ldr	w8, [x25, #156]
	ldr	x10, [x25, #48]
	mov	w11, #51712                     ; =0xca00
	movk	w11, #15258, lsl #16
	add	x11, x19, x11
	cmp	x11, x10
	csel	x11, x11, x10, lo
	cmp	w9, w8
	csel	x8, x11, x10, lo
	str	x8, [x25, #168]
	b	LBB58_60
LBB58_50:
	mov	w19, #11                        ; =0xb
	b	LBB58_53
LBB58_51:
	mov	w19, #13                        ; =0xd
	b	LBB58_53
LBB58_52:
	mov	w19, #10                        ; =0xa
LBB58_53:
	ldr	x0, [x25, #80]
	cbz	x0, LBB58_56
; %bb.54:
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x0]
	cmp	w8, #1
	b.ne	LBB58_56
; %bb.55:
	bl	_free
LBB58_56:
	str	xzr, [x25, #80]
	ldr	w8, [x25, #60]
	cmp	w8, #4
	b.ne	LBB58_59
; %bb.57:
	ldr	w0, [x25, #88]
	cmn	w0, #1
	b.eq	LBB58_59
; %bb.58:
	bl	_close
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x25, #88]
LBB58_59:
	mov	w8, #2                          ; =0x2
	str	w8, [x25, #56]
	stp	x8, x19, [x25, #24]
LBB58_60:
	ldr	x8, [sp, #24]
Lloh265:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh266:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh267:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB58_62
; %bb.61:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB58_62:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh260, Lloh261, Lloh262
	.loh AdrpLdr	Lloh263, Lloh264
	.loh AdrpLdrGotLdr	Lloh265, Lloh266, Lloh267
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function connect_settle
_connect_settle:                        ; @connect_settle
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x2
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w1, w8, x0
	add	x20, x8, #1040
	ldr	x0, [x8, #1120]
	cbz	x0, LBB59_3
; %bb.1:
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x0]
	cmp	w8, #1
	b.ne	LBB59_3
; %bb.2:
	bl	_free
LBB59_3:
	str	xzr, [x20, #80]
	ldr	w8, [x20, #60]
	cmp	w8, #4
	b.ne	LBB59_6
; %bb.4:
	ldr	w0, [x20, #88]
	cmn	w0, #1
	b.eq	LBB59_6
; %bb.5:
	bl	_close
	mov	w8, #-1                         ; =0xffffffff
	str	w8, [x20, #88]
LBB59_6:
	mov	w8, #2                          ; =0x2
	str	w8, [x20, #56]
	stp	x8, x19, [x20, #24]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function connect_success
_connect_success:                       ; @connect_success
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x10, #0                         ; =0x0
	add	x9, x0, #16
	mov	x8, x9
LBB60_1:                                ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x8], #16
	cbz	x11, LBB60_3
; %bb.2:                                ;   in Loop: Header=BB60_1 Depth=1
	add	x10, x10, #1
	cmp	x10, #64
	b.ne	LBB60_1
LBB60_3:
Lloh268:
	adrp	x8, _next_id@PAGE
Lloh269:
	ldr	x13, [x8, _next_id@PAGEOFF]
	mov	x11, #9223372036854775806       ; =0x7ffffffffffffffe
Lloh270:
	adrp	x12, _next_id@PAGE
Lloh271:
	add	x12, x12, _next_id@PAGEOFF
LBB60_4:                                ; =>This Inner Loop Header: Depth=1
	cmp	x13, x11
	b.hi	LBB60_9
; %bb.5:                                ;   in Loop: Header=BB60_4 Depth=1
	mov	x8, x13
	add	x14, x13, #1
	cas	x13, x14, [x12]
	cmp	x13, x8
	b.ne	LBB60_4
; %bb.6:
	cmp	w10, #64
	b.eq	LBB60_9
; %bb.7:
	cbz	x8, LBB60_9
; %bb.8:
	add	x9, x9, w10, uxtw #4
	str	x8, [x9]
	mov	w10, #176                       ; =0xb0
	umaddl	x10, w1, w10, x0
	ldr	w11, [x10, #1128]
	add	x19, x10, #1040
	stp	w11, wzr, [x9, #8]
	mov	w9, #5                          ; =0x5
	b	LBB60_15
LBB60_9:
	mov	w8, #176                        ; =0xb0
	umaddl	x8, w1, w8, x0
	add	x19, x8, #1040
	ldr	x0, [x8, #1120]
	cbz	x0, LBB60_12
; %bb.10:
	mov	w8, #-1                         ; =0xffffffff
	ldaddal	w8, w8, [x0]
	cmp	w8, #1
	b.ne	LBB60_12
; %bb.11:
	bl	_free
LBB60_12:
	str	xzr, [x19, #80]
	ldr	w8, [x19, #60]
	cmp	w8, #4
	b.ne	LBB60_16
; %bb.13:
	ldr	w0, [x19, #88]
	cmn	w0, #1
	b.eq	LBB60_16
; %bb.14:
	bl	_close
	mov	w8, #4                          ; =0x4
	mov	w9, #2                          ; =0x2
LBB60_15:
	mov	w10, #-1                        ; =0xffffffff
	str	w10, [x19, #88]
	b	LBB60_17
LBB60_16:
	mov	w8, #4                          ; =0x4
	mov	w9, #2                          ; =0x2
LBB60_17:
	mov	w10, #2                         ; =0x2
	str	w10, [x19, #56]
	stp	x9, x8, [x19, #24]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh270, Lloh271
	.loh AdrpLdr	Lloh268, Lloh269
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function take_runnable
_take_runnable:                         ; @take_runnable
	.cfi_startproc
; %bb.0:
	mov	x8, x0
	ldr	x0, [x0, #12304]
	cbz	x0, LBB61_4
; %bb.1:
	ldr	x9, [x0]
	str	x9, [x8, #12304]
	cbnz	x9, LBB61_3
; %bb.2:
	str	xzr, [x8, #12312]
LBB61_3:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x9, [x0, #8]
	str	x9, [x8, #12320]
	str	wzr, [x8, #12328]
	str	x9, [x1]
	bl	_free
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB61_4:
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function neoclr_os_transfer
_neoclr_os_transfer:                    ; @neoclr_os_transfer
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x2
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #12]
	cbz	w3, LBB62_3
; %bb.1:
	mov	x20, x1
	add	x3, sp, #12
	mov	x21, x0
	mov	w1, #65535                      ; =0xffff
	mov	w2, #4130                       ; =0x1022
	mov	w4, #4                          ; =0x4
	bl	_setsockopt
	cbz	w0, LBB62_4
; %bb.2:
	mov	x0, #-2                         ; =0xfffffffffffffffe
	b	LBB62_5
LBB62_3:
	mov	w2, w19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	b	_recv
LBB62_4:
	mov	w2, w19
	mov	x0, x21
	mov	x1, x20
	mov	w3, #524288                     ; =0x80000
	bl	_send
LBB62_5:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
.tbss _head$tlv$init, 8, 3              ; @head

	.section	__DATA,__thread_vars,thread_local_variables
_head:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_head$tlv$init

	.section	__DATA,__data
	.p2align	3, 0x0                          ; @next_id
_next_id:
	.quad	1                               ; 0x1

	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"%u.%u.%u.%u"

	.section	__DATA,__data
	.p2align	3, 0x0                          ; @next_scheduler_destination
_next_scheduler_destination:
	.quad	1                               ; 0x1

.zerofill __DATA,__bss,_network_origin,8,3 ; @network_origin
.zerofill __DATA,__bss,_resolver_workers,4,2 ; @resolver_workers
	.section	__TEXT,__literal16,16byte_literals
	.p2align	3, 0x0                          ; @__const.neoclr_os_pause.pause
l___const.neoclr_os_pause.pause:
	.quad	0                               ; 0x0
	.quad	1000000                         ; 0xf4240

.subsections_via_symbols
