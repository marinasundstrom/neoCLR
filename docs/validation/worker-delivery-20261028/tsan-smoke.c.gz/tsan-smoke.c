#include <stdio.h>
int main(void) { fputs("entered main\n", stderr); return 0; }
