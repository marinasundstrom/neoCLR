	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 26, 2	sdk_version 26, 2
	.globl	_neoclr_workers_trace_view      ; -- Begin function neoclr_workers_trace_view
	.p2align	2
_neoclr_workers_trace_view:             ; @neoclr_workers_trace_view
	.cfi_startproc
; %bb.0:
	cbz	x2, LBB0_7
; %bb.1:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x0
	mov	x22, x2
	ldr	x21, [x0, #24]
	bl	_pthread_self
	mov	x1, x0
	mov	x0, x21
	bl	_pthread_equal
	cbz	w0, LBB0_6
; %bb.2:
	ldr	w8, [x19, #456]
	cbz	w8, LBB0_5
; %bb.3:
	ldr	x9, [x19, #128]
	cbz	x9, LBB0_5
; %bb.4:
	ldr	w8, [x19, #432]
	cmp	w8, w20
	b.hs	LBB0_8
LBB0_5:
	mov	w0, #0                          ; =0x0
LBB0_6:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB0_7:
	mov	w0, #0                          ; =0x0
	ret
LBB0_8:
	mov	w10, w20
	ldp	x11, x12, [x19, #136]
	mul	x10, x11, x10
	mov	w13, #40                        ; =0x28
	madd	x9, x10, x13, x9
	mov	w10, #24                        ; =0x18
	umaddl	x10, w20, w10, x19
	ldr	x13, [x19]
	ldr	x14, [x10, #152]
	ldr	q0, [x10, #160]
	stp	x9, x13, [x22]
	str	x12, [x22, #16]
	stur	q0, [x22, #24]
	stp	x14, x11, [x22, #40]
	str	w8, [x22, #56]
	mov	w0, #1                          ; =0x1
	b	LBB0_6
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_create          ; -- Begin function neoclr_workers_create
	.p2align	2
_neoclr_workers_create:                 ; @neoclr_workers_create
	.cfi_startproc
; %bb.0:
	mov	x3, #0                          ; =0x0
	b	_neoclr_workers_create_traced
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_create_traced   ; -- Begin function neoclr_workers_create_traced
	.p2align	2
_neoclr_workers_create_traced:          ; @neoclr_workers_create_traced
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cmp	x3, #16, lsl #12                ; =65536
	b.hi	LBB2_15
; %bb.1:
	mov	x8, x0
	mov	x0, #0                          ; =0x0
	tst	x2, #0x7
	b.ne	LBB2_16
; %bb.2:
	cmp	x2, #256
	b.lo	LBB2_16
; %bb.3:
	sub	w9, w8, #1
	cmp	w9, #3
	b.hi	LBB2_16
; %bb.4:
	sub	w9, w1, #1
	cmp	w9, #15
	b.hi	LBB2_16
; %bb.5:
	mov	x19, x2
	mov	x23, x3
	mov	x22, x1
	mov	x20, x8
	mov	w0, #1                          ; =0x1
	mov	w1, #21392                      ; =0x5390
	bl	_calloc
	cbz	x0, LBB2_16
; %bb.6:
	mov	x21, x0
	mov	w0, #1                          ; =0x1
	mov	x1, x19
	bl	_calloc
	mov	x8, x0
	mov	x0, x21
	str	x8, [x21, #1512]
	cbz	x8, LBB2_14
; %bb.7:
Lloh0:
	adrp	x8, _next_identity@PAGE
Lloh1:
	add	x8, x8, _next_identity@PAGEOFF
	str	x19, [x0, #1520]
	mov	w9, #1                          ; =0x1
	ldaddal	x9, x8, [x8]
	str	x8, [x0]
	add	x8, x8, #1
	cmp	x8, #1
	b.ls	LBB2_35
; %bb.8:
	bl	_pthread_self
	str	x0, [x21, #24]
	str	w22, [x21, #436]
	add	x0, x21, #272
	mov	x1, #0                          ; =0x0
	bl	_pthread_mutex_init
	cbnz	w0, LBB2_13
; %bb.9:
	add	x0, x21, #336
	mov	x1, #0                          ; =0x0
	bl	_pthread_cond_init
	cbnz	w0, LBB2_12
; %bb.10:
	add	x0, x21, #384
	mov	x1, #0                          ; =0x0
	bl	_pthread_cond_init
	cbz	w0, LBB2_17
; %bb.11:
	add	x0, x21, #336
	bl	_pthread_cond_destroy
LBB2_12:
	add	x0, x21, #272
	bl	_pthread_mutex_destroy
LBB2_13:
	ldr	x0, [x21, #1512]
	bl	_free
	mov	x0, x21
LBB2_14:
	bl	_free
LBB2_15:
	mov	x0, #0                          ; =0x0
LBB2_16:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB2_17:
	cbz	x23, LBB2_21
; %bb.18:
	bl	_trace_now
	mov	x19, x0
	str	x0, [x21, #144]
	add	w8, w20, #1
	mul	x0, x8, x23
	mov	w1, #40                         ; =0x28
	bl	_calloc
	mov	x8, x21
	str	x0, [x21, #128]
	cbz	x19, LBB2_32
; %bb.19:
	cbz	x0, LBB2_32
; %bb.20:
	str	x23, [x8, #136]
LBB2_21:
	mov	w9, w22
	cmp	w22, #3
	b.hi	LBB2_23
; %bb.22:
	mov	x10, #0                         ; =0x0
	mov	x0, x21
	mov	x8, x20
	b	LBB2_26
LBB2_23:
	and	x10, x9, #0x1c
	mov	w11, #4832                      ; =0x12e0
	mov	x12, x10
	mov	x0, x21
	mov	x13, x21
	mov	x8, x20
LBB2_24:                                ; =>This Inner Loop Header: Depth=1
	str	x0, [x13, #1552]
	str	x0, [x13, #2760]
	str	x0, [x13, #3968]
	str	x0, [x13, #5176]
	add	x13, x13, x11
	subs	x12, x12, #4
	b.ne	LBB2_24
; %bb.25:
	cmp	x10, x9
	b.eq	LBB2_28
LBB2_26:
	mov	w11, #1208                      ; =0x4b8
	umull	x11, w10, w11
	add	x11, x11, #1552
	sub	x9, x9, x10
LBB2_27:                                ; =>This Inner Loop Header: Depth=1
	str	x0, [x0, x11]
	add	x11, x11, #1208
	subs	x9, x9, #1
	b.ne	LBB2_27
LBB2_28:
	ldr	w9, [x0, #432]
	cmp	w9, w8
	b.hs	LBB2_16
; %bb.29:
	add	x22, x0, #64
	add	x23, x0, #32
Lloh2:
	adrp	x19, _run@PAGE
Lloh3:
	add	x19, x19, _run@PAGEOFF
LBB2_30:                                ; =>This Inner Loop Header: Depth=1
	add	x3, x22, w9, uxtw #4
	add	w8, w9, #1
	str	x0, [x3]
	str	w8, [x3, #8]
	add	x0, x23, w9, uxtw #3
	mov	x1, #0                          ; =0x0
	mov	x2, x19
	bl	_pthread_create
	cbnz	w0, LBB2_33
; %bb.31:                               ;   in Loop: Header=BB2_30 Depth=1
	mov	x0, x21
	ldr	w8, [x21, #432]
	add	w9, w8, #1
	str	w9, [x21, #432]
	cmp	w9, w20
	b.lo	LBB2_30
	b	LBB2_16
LBB2_32:
	mov	x19, x8
	mov	x0, x8
	bl	_neoclr_workers_close
	mov	x0, x19
	b	LBB2_34
LBB2_33:
	mov	x0, x21
	bl	_neoclr_workers_close
	mov	x0, x21
LBB2_34:
	bl	_neoclr_workers_destroy
	b	LBB2_15
LBB2_35:
	bl	_abort
	.loh AdrpAdd	Lloh0, Lloh1
	.loh AdrpAdd	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function trace_now
_trace_now:                             ; @trace_now
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp]
	madd	x8, x9, x8, x10
	cmp	w0, #0
	csel	x0, x8, xzr, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_close           ; -- Begin function neoclr_workers_close
	.p2align	2
_neoclr_workers_close:                  ; @neoclr_workers_close
	.cfi_startproc
; %bb.0:
	stp	d9, d8, [sp, #-80]!             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	mov	x19, x0
	ldr	x20, [x0, #24]
	bl	_pthread_self
	mov	x1, x0
	mov	x0, x20
	bl	_pthread_equal
	mov	x8, x0
Lloh4:
	adrp	x0, _entered@TLVPPAGE
Lloh5:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	w8, #0
	ccmp	x9, #0, #0, ne
	b.eq	LBB4_2
; %bb.1:
	mov	w0, #0                          ; =0x0
	b	LBB4_24
LBB4_2:
Lloh6:
	adrp	x0, _reading@TLVPPAGE
Lloh7:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh8:
	adrp	x0, _mutating@TLVPPAGE
Lloh9:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	orr	x8, x8, x9
	cbnz	x8, LBB4_25
; %bb.3:
	add	x0, x19, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB4_25
; %bb.4:
	ldr	w8, [x19, #456]
	cbz	w8, LBB4_7
; %bb.5:
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB4_25
; %bb.6:
	mov	w0, #1                          ; =0x1
	b	LBB4_24
LBB4_7:
	mov	w21, #1                         ; =0x1
	str	w21, [x19, #452]
	ldr	w8, [x19, #436]
	cbz	w8, LBB4_18
; %bb.8:
	mov	x22, #0                         ; =0x0
	add	x20, x19, #1552
	movi.2s	v8, #1
	mov	w23, #3                         ; =0x3
	b	LBB4_10
LBB4_9:                                 ;   in Loop: Header=BB4_10 Depth=1
	add	x22, x22, #1
	ldr	w8, [x19, #436]
	add	x20, x20, #1208
	cmp	x22, x8
	b.hs	LBB4_18
LBB4_10:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x20, #32]
	sub	w9, w8, #1
	cmp	w9, #1
	b.hi	LBB4_9
; %bb.11:                               ;   in Loop: Header=BB4_10 Depth=1
	ldr	w9, [x20, #36]
	cbz	w9, LBB4_15
; %bb.12:                               ;   in Loop: Header=BB4_10 Depth=1
	cmp	w8, #1
	b.eq	LBB4_16
LBB4_13:                                ;   in Loop: Header=BB4_10 Depth=1
	cmp	w8, #2
	b.ne	LBB4_9
; %bb.14:                               ;   in Loop: Header=BB4_10 Depth=1
	str	w21, [x20, #36]
	b	LBB4_9
LBB4_15:                                ;   in Loop: Header=BB4_10 Depth=1
	mov	x0, x19
	mov	w1, #9                          ; =0x9
	mov	x2, x20
	mov	w3, #1                          ; =0x1
	bl	_trace_emit
	ldr	w8, [x20, #32]
	cmp	w8, #1
	b.ne	LBB4_13
LBB4_16:                                ;   in Loop: Header=BB4_10 Depth=1
	str	xzr, [x20, #48]
	stur	d8, [x20, #36]
	ldr	x0, [x20]
	ldr	x8, [x0, #16]
	cmn	x8, #1
	b.eq	LBB4_25
; %bb.17:                               ;   in Loop: Header=BB4_10 Depth=1
	add	x8, x8, #1
	str	x8, [x0, #16]
	str	x8, [x20, #24]
	str	w23, [x20, #32]
	mov	w1, #8                          ; =0x8
	mov	x2, x20
	mov	w3, #1                          ; =0x1
	bl	_trace_emit
	ldr	x8, [x20]
	add	x0, x8, #384
	bl	_pthread_cond_broadcast
	b	LBB4_9
LBB4_18:
	add	x0, x19, #336
	bl	_pthread_cond_broadcast
	add	x0, x19, #384
	bl	_pthread_cond_broadcast
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB4_25
; %bb.19:
	ldr	w8, [x19, #432]
	cbz	w8, LBB4_23
; %bb.20:
	mov	x20, #0                         ; =0x0
	add	x21, x19, #32
LBB4_21:                                ; =>This Inner Loop Header: Depth=1
	ldr	x0, [x21, x20, lsl #3]
	mov	x1, #0                          ; =0x0
	bl	_pthread_join
	cbnz	w0, LBB4_25
; %bb.22:                               ;   in Loop: Header=BB4_21 Depth=1
	add	x20, x20, #1
	ldr	w8, [x19, #432]
	cmp	x20, x8
	b.lo	LBB4_21
LBB4_23:
	mov	w0, #1                          ; =0x1
	str	w0, [x19, #456]
LBB4_24:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #80               ; 16-byte Folded Reload
	ret
LBB4_25:
	bl	_abort
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_destroy         ; -- Begin function neoclr_workers_destroy
	.p2align	2
_neoclr_workers_destroy:                ; @neoclr_workers_destroy
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	ldr	x20, [x0, #24]
	bl	_pthread_self
	mov	x1, x0
	mov	x0, x20
	bl	_pthread_equal
	cbz	w0, LBB5_5
; %bb.1:
	ldr	w9, [x19, #456]
Lloh10:
	adrp	x0, _entered@TLVPPAGE
Lloh11:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w9, LBB5_5
; %bb.2:
	ldr	x8, [x8]
	cbnz	x8, LBB5_5
; %bb.3:
	ldr	w8, [x19, #460]
	cbz	w8, LBB5_6
LBB5_4:
	mov	w0, #0                          ; =0x0
LBB5_5:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB5_6:
	ldr	w8, [x19, #436]
	cbz	w8, LBB5_10
; %bb.7:
	add	x9, x19, #1584
LBB5_8:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w10, [x9]
	cbnz	w10, LBB5_4
; %bb.9:                                ;   in Loop: Header=BB5_8 Depth=1
	add	x9, x9, #1208
	subs	x8, x8, #1
	b.ne	LBB5_8
LBB5_10:
	mov	x8, #-512                       ; =0xfffffffffffffe00
LBB5_11:                                ; =>This Inner Loop Header: Depth=1
	add	x9, x19, x8
	ldr	x9, [x9, #21400]
	cbnz	x9, LBB5_4
; %bb.12:                               ;   in Loop: Header=BB5_11 Depth=1
	adds	x8, x8, #16
	b.ne	LBB5_11
; %bb.13:
	ldr	x8, [x19, #1544]
	cbz	x8, LBB5_16
; %bb.14:
	add	x0, x19, #464
	bl	_neoclr_gc_complete_invocation_v1
	cbnz	w0, LBB5_4
; %bb.15:
	add	x0, x19, #464
	mov	w1, #1048                       ; =0x418
	bl	_bzero
LBB5_16:
	add	x1, sp, #8
	mov	x0, x19
	bl	_neoclr_workers_collect
	mov	x8, x0
	mov	w0, #0                          ; =0x0
	cbz	w8, LBB5_5
; %bb.17:
	ldr	x8, [sp, #8]
	cbnz	x8, LBB5_5
; %bb.18:
	add	x0, x19, #384
	bl	_pthread_cond_destroy
	add	x0, x19, #336
	bl	_pthread_cond_destroy
	add	x0, x19, #272
	bl	_pthread_mutex_destroy
	ldr	x0, [x19, #128]
	bl	_free
	ldr	x0, [x19, #1512]
	bl	_free
	mov	x0, x19
	bl	_free
	mov	w0, #1                          ; =0x1
	b	LBB5_5
	.loh AdrpLdr	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function run
lCPI6_0:
	.long	1                               ; 0x1
	.long	4294967295                      ; 0xffffffff
lCPI6_1:
	.long	3                               ; 0x3
	.long	4294967295                      ; 0xffffffff
lCPI6_2:
	.long	4                               ; 0x4
	.long	4294967295                      ; 0xffffffff
lCPI6_3:
	.long	2                               ; 0x2
	.long	4294967295                      ; 0xffffffff
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_run:                                   ; @run
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #240
	stp	d9, d8, [sp, #128]              ; 16-byte Folded Spill
	stp	x28, x27, [sp, #144]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #160]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #176]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #192]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #208]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	add	x29, sp, #224
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	mov	x8, x0
	ldr	x19, [x0]
Lloh12:
	adrp	x0, _trace_pool@TLVPPAGE
Lloh13:
	ldr	x0, [x0, _trace_pool@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	str	x0, [sp, #80]                   ; 8-byte Folded Spill
	str	x19, [x0]
	ldr	w20, [x8, #8]
Lloh14:
	adrp	x0, _trace_worker@TLVPPAGE
Lloh15:
	ldr	x0, [x0, _trace_worker@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	x0, [sp, #72]                   ; 8-byte Folded Spill
	str	w20, [x0]
	ldr	x8, [x19, #128]
	cbz	x8, LBB6_6
; %bb.1:
	mov	w8, #24                         ; =0x18
	umaddl	x21, w20, w8, x19
	ldp	x8, x9, [x21, #152]!
	add	x22, x9, #1
	str	x22, [x21, #8]
	ldr	x9, [x19, #136]
	cmp	x8, x9
	b.ne	LBB6_3
LBB6_2:
	ldr	x8, [x21, #16]
	add	x8, x8, #1
	str	x8, [x21, #16]
	b	LBB6_6
LBB6_3:
	add	x1, sp, #112
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB6_2
; %bb.4:
	ldp	x8, x9, [sp, #112]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x8, x8, x10, x9
	cbz	x8, LBB6_2
; %bb.5:
	ldp	x9, x10, [x19, #128]
	mul	x10, x10, x20
	ldr	x11, [x21]
	add	x12, x11, #1
	str	x12, [x21]
	mov	w12, #40                        ; =0x28
	madd	x9, x10, x12, x9
	madd	x9, x11, x12, x9
	stp	x8, x22, [x9]
	str	xzr, [x9, #16]
Lloh16:
	adrp	x8, lCPI6_0@PAGE
Lloh17:
	ldr	d0, [x8, lCPI6_0@PAGEOFF]
	str	d0, [x9, #24]
	str	wzr, [x9, #32]
LBB6_6:
Lloh18:
	adrp	x0, _entered@TLVPPAGE
Lloh19:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x9, x0
Lloh20:
	adrp	x0, _reading@TLVPPAGE
Lloh21:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x10, x0
Lloh22:
	adrp	x0, _mutating@TLVPPAGE
Lloh23:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	mov	x11, x0
	add	x8, x19, #152
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
Lloh24:
	adrp	x0, _executing@TLVPPAGE
Lloh25:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	x0, [sp, #8]                    ; 8-byte Folded Spill
	mov	w8, #10008                      ; =0x2718
	add	x25, x19, x8
	mov	w8, #8800                       ; =0x2260
	add	x21, x19, x8
	mov	w8, #7592                       ; =0x1da8
	add	x8, x19, x8
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	mov	w8, #6384                       ; =0x18f0
	add	x8, x19, x8
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	mov	w8, #5176                       ; =0x1438
	add	x8, x19, x8
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	add	x8, x19, #1552
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
Lloh26:
	adrp	x8, lCPI6_2@PAGE
Lloh27:
	ldr	d8, [x8, lCPI6_2@PAGEOFF]
Lloh28:
	adrp	x8, lCPI6_1@PAGE
Lloh29:
	ldr	d9, [x8, lCPI6_1@PAGEOFF]
	mov	w20, #9664                      ; =0x25c0
	mov	w22, #26952                     ; =0x6948
	mov	w23, #25744                     ; =0x6490
	mov	w24, #24536                     ; =0x5fd8
	mov	w28, #23328                     ; =0x5b20
	mov	w27, #22120                     ; =0x5668
	stp	x25, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x10, x9, [sp, #24]              ; 16-byte Folded Spill
	str	x11, [sp, #16]                  ; 8-byte Folded Spill
LBB6_7:                                 ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB6_12 Depth 2
                                        ;       Child Loop BB6_29 Depth 3
                                        ;       Child Loop BB6_19 Depth 3
	ldr	x8, [x9]
	ldr	x9, [x10]
	ldr	x10, [x11]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB6_93
; %bb.8:                                ;   in Loop: Header=BB6_7 Depth=1
	add	x0, x19, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB6_93
; %bb.9:                                ;   in Loop: Header=BB6_7 Depth=1
	ldr	w8, [x19, #452]
	ldp	x17, x16, [sp, #96]             ; 16-byte Folded Reload
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	mov	w1, #29368                      ; =0x72b8
	mov	w2, #28160                      ; =0x6e00
	cbz	w8, LBB6_12
	b	LBB6_85
LBB6_10:                                ;   in Loop: Header=BB6_12 Depth=2
	ldr	x8, [x26, #16]
	add	x8, x8, #1
	str	x8, [x26, #16]
	ldr	x21, [sp, #56]                  ; 8-byte Folded Reload
LBB6_11:                                ;   in Loop: Header=BB6_12 Depth=2
	ldr	w8, [x19, #452]
	ldr	x25, [sp, #48]                  ; 8-byte Folded Reload
	cbnz	w8, LBB6_85
LBB6_12:                                ;   Parent Loop BB6_7 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB6_29 Depth 3
                                        ;       Child Loop BB6_19 Depth 3
	ldr	w8, [x19, #436]
	cbz	w8, LBB6_23
; %bb.13:                               ;   in Loop: Header=BB6_12 Depth=2
	cmp	w8, #8
	b.hs	LBB6_26
; %bb.14:                               ;   in Loop: Header=BB6_12 Depth=2
	mov	x9, #0                          ; =0x0
	mov	x26, #0                         ; =0x0
LBB6_15:                                ;   in Loop: Header=BB6_12 Depth=2
	and	x8, x8, #0x7
	cbz	x8, LBB6_22
; %bb.16:                               ;   in Loop: Header=BB6_12 Depth=2
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	mov	w11, #1208                      ; =0x4b8
	madd	x9, x9, x11, x10
	b	LBB6_19
LBB6_17:                                ;   in Loop: Header=BB6_19 Depth=3
	mov	x26, x9
LBB6_18:                                ;   in Loop: Header=BB6_19 Depth=3
	add	x9, x9, #1208
	subs	x8, x8, #1
	b.eq	LBB6_22
LBB6_19:                                ;   Parent Loop BB6_7 Depth=1
                                        ;     Parent Loop BB6_12 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x9, #32]
	cmp	w10, #1
	b.ne	LBB6_18
; %bb.20:                               ;   in Loop: Header=BB6_19 Depth=3
	cbz	x26, LBB6_17
; %bb.21:                               ;   in Loop: Header=BB6_19 Depth=3
	ldr	x10, [x9, #16]
	ldr	x11, [x26, #16]
	cmp	x10, x11
	b.lo	LBB6_17
	b	LBB6_18
LBB6_22:                                ;   in Loop: Header=BB6_12 Depth=2
	cbnz	x26, LBB6_72
LBB6_23:                                ;   in Loop: Header=BB6_12 Depth=2
	ldr	x8, [x19, #128]
	cbz	x8, LBB6_64
; %bb.24:                               ;   in Loop: Header=BB6_12 Depth=2
	ldp	x9, x8, [sp, #72]               ; 16-byte Folded Reload
	ldr	x8, [x8]
	ldr	w9, [x9]
	cmp	x8, x19
	csel	x21, x9, xzr, eq
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w9, #24                         ; =0x18
	umaddl	x26, w21, w9, x8
	ldp	x9, x8, [x26]
	add	x25, x8, #1
	str	x25, [x26, #8]
	ldr	x8, [x19, #136]
	cmp	x9, x8
	b.ne	LBB6_60
LBB6_25:                                ;   in Loop: Header=BB6_12 Depth=2
	ldr	x8, [x26, #16]
	add	x8, x8, #1
	str	x8, [x26, #16]
	b	LBB6_63
LBB6_26:                                ;   in Loop: Header=BB6_12 Depth=2
	mov	x10, #0                         ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x26, #0                         ; =0x0
	lsr	x11, x8, #3
	umull	x11, w11, w20
	b	LBB6_29
LBB6_27:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x26, x25, x10
LBB6_28:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x9, x9, #8
	add	x10, x10, x20
	cmp	x11, x10
	b.eq	LBB6_15
LBB6_29:                                ;   Parent Loop BB6_7 Depth=1
                                        ;     Parent Loop BB6_12 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x12, x19, x10
	prfm	pldl1keep, [x12, #20912]
	ldr	w13, [x12, #1584]
	cmp	w13, #1
	b.ne	LBB6_33
; %bb.30:                               ;   in Loop: Header=BB6_29 Depth=3
	cbz	x26, LBB6_32
; %bb.31:                               ;   in Loop: Header=BB6_29 Depth=3
	add	x13, x19, x10
	ldr	x13, [x13, #1568]
	ldr	x14, [x26, #16]
	cmp	x13, x14
	b.hs	LBB6_33
LBB6_32:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x26, x12, #1552
LBB6_33:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x13, x12, x27
	prfm	pldl1keep, [x13]
	ldr	w13, [x12, #2792]
	cmp	w13, #1
	b.ne	LBB6_37
; %bb.34:                               ;   in Loop: Header=BB6_29 Depth=3
	cbz	x26, LBB6_36
; %bb.35:                               ;   in Loop: Header=BB6_29 Depth=3
	add	x13, x19, x10
	ldr	x13, [x13, #2776]
	ldr	x14, [x26, #16]
	cmp	x13, x14
	b.hs	LBB6_37
LBB6_36:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x26, x12, #2760
LBB6_37:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x14, x12, x28
	add	x13, x19, x10
	prfm	pldl1keep, [x14]
	ldr	w14, [x13, #4000]
	cmp	w14, #1
	b.ne	LBB6_41
; %bb.38:                               ;   in Loop: Header=BB6_29 Depth=3
	cbz	x26, LBB6_40
; %bb.39:                               ;   in Loop: Header=BB6_29 Depth=3
	add	x14, x19, x10
	ldr	x14, [x14, #3984]
	ldr	x15, [x26, #16]
	cmp	x14, x15
	b.hs	LBB6_41
LBB6_40:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x26, x13, #3968
LBB6_41:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x14, x12, x24
	prfm	pldl1keep, [x14]
	ldr	w13, [x13, #5208]
	cmp	w13, #1
	b.ne	LBB6_45
; %bb.42:                               ;   in Loop: Header=BB6_29 Depth=3
	cbz	x26, LBB6_44
; %bb.43:                               ;   in Loop: Header=BB6_29 Depth=3
	add	x13, x19, x10
	ldr	x13, [x13, #5192]
	ldr	x14, [x26, #16]
	cmp	x13, x14
	b.hs	LBB6_45
LBB6_44:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x26, x0, x10
LBB6_45:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x14, x12, x23
	add	x13, x19, x10
	prfm	pldl1keep, [x14]
	ldr	w14, [x13, #6416]
	cmp	w14, #1
	b.ne	LBB6_49
; %bb.46:                               ;   in Loop: Header=BB6_29 Depth=3
	cbz	x26, LBB6_48
; %bb.47:                               ;   in Loop: Header=BB6_29 Depth=3
	add	x14, x19, x10
	ldr	x14, [x14, #6400]
	ldr	x15, [x26, #16]
	cmp	x14, x15
	b.hs	LBB6_49
LBB6_48:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x26, x17, x10
LBB6_49:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x14, x12, x22
	prfm	pldl1keep, [x14]
	ldr	w13, [x13, #7624]
	cmp	w13, #1
	b.ne	LBB6_53
; %bb.50:                               ;   in Loop: Header=BB6_29 Depth=3
	cbz	x26, LBB6_52
; %bb.51:                               ;   in Loop: Header=BB6_29 Depth=3
	add	x13, x19, x10
	ldr	x13, [x13, #7608]
	ldr	x14, [x26, #16]
	cmp	x13, x14
	b.hs	LBB6_53
LBB6_52:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x26, x16, x10
LBB6_53:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x14, x12, x2
	add	x13, x19, x10
	prfm	pldl1keep, [x14]
	ldr	w14, [x13, #8832]
	cmp	w14, #1
	b.ne	LBB6_57
; %bb.54:                               ;   in Loop: Header=BB6_29 Depth=3
	cbz	x26, LBB6_56
; %bb.55:                               ;   in Loop: Header=BB6_29 Depth=3
	add	x14, x19, x10
	ldr	x14, [x14, #8816]
	ldr	x15, [x26, #16]
	cmp	x14, x15
	b.hs	LBB6_57
LBB6_56:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x26, x21, x10
LBB6_57:                                ;   in Loop: Header=BB6_29 Depth=3
	add	x12, x12, x1
	prfm	pldl1keep, [x12]
	ldr	w12, [x13, #10040]
	cmp	w12, #1
	b.ne	LBB6_28
; %bb.58:                               ;   in Loop: Header=BB6_29 Depth=3
	cbz	x26, LBB6_27
; %bb.59:                               ;   in Loop: Header=BB6_29 Depth=3
	add	x12, x19, x10
	ldr	x12, [x12, #10024]
	ldr	x13, [x26, #16]
	cmp	x12, x13
	b.lo	LBB6_27
	b	LBB6_28
LBB6_60:                                ;   in Loop: Header=BB6_12 Depth=2
	add	x1, sp, #112
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB6_25
; %bb.61:                               ;   in Loop: Header=BB6_12 Depth=2
	ldp	x8, x9, [sp, #112]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x8, x8, x10, x9
	cbz	x8, LBB6_25
; %bb.62:                               ;   in Loop: Header=BB6_12 Depth=2
	ldp	x9, x10, [x19, #128]
	mul	x10, x10, x21
	ldr	x11, [x26]
	add	x12, x11, #1
	str	x12, [x26]
	mov	w12, #40                        ; =0x28
	madd	x9, x10, x12, x9
	madd	x9, x11, x12, x9
	stp	x8, x25, [x9]
	str	xzr, [x9, #16]
	str	d9, [x9, #24]
	str	wzr, [x9, #32]
LBB6_63:                                ;   in Loop: Header=BB6_12 Depth=2
	ldr	x21, [sp, #56]                  ; 8-byte Folded Reload
LBB6_64:                                ;   in Loop: Header=BB6_12 Depth=2
	add	x0, x19, #336
	add	x1, x19, #272
	bl	_pthread_cond_wait
	cbnz	w0, LBB6_93
; %bb.65:                               ;   in Loop: Header=BB6_12 Depth=2
	ldr	x8, [x19, #128]
	ldp	x17, x16, [sp, #96]             ; 16-byte Folded Reload
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	mov	w1, #29368                      ; =0x72b8
	mov	w2, #28160                      ; =0x6e00
	cbz	x8, LBB6_11
; %bb.66:                               ;   in Loop: Header=BB6_12 Depth=2
	ldp	x9, x8, [sp, #72]               ; 16-byte Folded Reload
	ldr	x8, [x8]
	ldr	w9, [x9]
	cmp	x8, x19
	csel	x21, x9, xzr, eq
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	mov	w9, #24                         ; =0x18
	umaddl	x26, w21, w9, x8
	ldp	x9, x8, [x26]
	add	x25, x8, #1
	str	x25, [x26, #8]
	ldr	x8, [x19, #136]
	cmp	x9, x8
	b.eq	LBB6_10
; %bb.67:                               ;   in Loop: Header=BB6_12 Depth=2
	add	x1, sp, #112
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB6_70
; %bb.68:                               ;   in Loop: Header=BB6_12 Depth=2
	ldp	x8, x9, [sp, #112]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x8, x8, x10, x9
	cbz	x8, LBB6_70
; %bb.69:                               ;   in Loop: Header=BB6_12 Depth=2
	ldp	x9, x10, [x19, #128]
	mul	x10, x10, x21
	ldr	x11, [x26]
	add	x12, x11, #1
	str	x12, [x26]
	mov	w12, #40                        ; =0x28
	madd	x9, x10, x12, x9
	madd	x9, x11, x12, x9
	stp	x8, x25, [x9]
	str	xzr, [x9, #16]
	str	d8, [x9, #24]
	str	wzr, [x9, #32]
	b	LBB6_71
LBB6_70:                                ;   in Loop: Header=BB6_12 Depth=2
	ldr	x8, [x26, #16]
	add	x8, x8, #1
	str	x8, [x26, #16]
LBB6_71:                                ;   in Loop: Header=BB6_12 Depth=2
	ldr	x21, [sp, #56]                  ; 8-byte Folded Reload
	ldp	x17, x16, [sp, #96]             ; 16-byte Folded Reload
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	mov	w1, #29368                      ; =0x72b8
	mov	w2, #28160                      ; =0x6e00
	b	LBB6_11
LBB6_72:                                ;   in Loop: Header=BB6_7 Depth=1
	mov	w8, #2                          ; =0x2
	str	w8, [x26, #32]
	mov	x0, x19
	mov	w1, #6                          ; =0x6
	mov	x2, x26
	mov	w3, #0                          ; =0x0
	bl	_trace_emit
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB6_93
; %bb.73:                               ;   in Loop: Header=BB6_7 Depth=1
	ldr	x21, [sp, #8]                   ; 8-byte Folded Reload
	str	x26, [x21]
	ldr	x8, [x26, #1192]
	ldr	x1, [x26, #1200]
	mov	x0, x26
	blr	x8
	str	w0, [sp, #4]                    ; 4-byte Folded Spill
	mov	x0, x19
	mov	w1, #7                          ; =0x7
	mov	x2, x26
	mov	w3, #0                          ; =0x0
	bl	_trace_emit
	str	xzr, [x21]
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB6_93
; %bb.74:                               ;   in Loop: Header=BB6_7 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB6_93
; %bb.75:                               ;   in Loop: Header=BB6_7 Depth=1
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB6_93
; %bb.76:                               ;   in Loop: Header=BB6_7 Depth=1
	add	x0, x19, #272
	bl	_pthread_mutex_lock
	ldr	x21, [sp, #56]                  ; 8-byte Folded Reload
	cbnz	w0, LBB6_93
; %bb.77:                               ;   in Loop: Header=BB6_7 Depth=1
	ldr	w8, [x26, #36]
	cbz	w8, LBB6_79
; %bb.78:                               ;   in Loop: Header=BB6_7 Depth=1
	mov	w8, #1                          ; =0x1
	str	w8, [x26, #40]
	stp	xzr, xzr, [x26, #128]
	str	xzr, [x26, #120]
	add	x0, x26, #144
	mov	w1, #1048                       ; =0x418
	bl	_bzero
	b	LBB6_82
LBB6_79:                                ;   in Loop: Header=BB6_7 Depth=1
	ldr	w8, [sp, #4]                    ; 4-byte Folded Reload
	cbnz	w8, LBB6_81
; %bb.80:                               ;   in Loop: Header=BB6_7 Depth=1
	ldr	w8, [x26, #144]
	cbz	w8, LBB6_84
LBB6_81:                                ;   in Loop: Header=BB6_7 Depth=1
	mov	w8, #2                          ; =0x2
	str	w8, [x26, #40]
	stp	xzr, xzr, [x26, #128]
	str	xzr, [x26, #120]
LBB6_82:                                ;   in Loop: Header=BB6_7 Depth=1
	str	xzr, [x26, #48]
	movi.2d	v0, #0000000000000000
	stur	q0, [x26, #56]
	stur	q0, [x26, #72]
	stur	q0, [x26, #88]
	stur	q0, [x26, #104]
	ldr	x0, [x26]
	ldr	x8, [x0, #16]
	cmn	x8, #1
	b.eq	LBB6_93
; %bb.83:                               ;   in Loop: Header=BB6_7 Depth=1
	add	x8, x8, #1
	str	x8, [x0, #16]
	str	x8, [x26, #24]
	mov	w8, #3                          ; =0x3
	str	w8, [x26, #32]
	ldr	w3, [x26, #40]
	mov	w1, #8                          ; =0x8
	mov	x2, x26
	bl	_trace_emit
	ldr	x8, [x26]
	add	x0, x8, #384
	bl	_pthread_cond_broadcast
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	ldp	x10, x9, [sp, #24]              ; 16-byte Folded Reload
	ldr	x11, [sp, #16]                  ; 8-byte Folded Reload
	cbz	w0, LBB6_7
	b	LBB6_93
LBB6_84:                                ;   in Loop: Header=BB6_7 Depth=1
	str	wzr, [x26, #40]
	b	LBB6_82
LBB6_85:
	ldr	x8, [x19, #128]
	cbz	x8, LBB6_91
; %bb.86:
	ldp	x9, x8, [sp, #72]               ; 16-byte Folded Reload
	ldr	x8, [x8]
	ldr	w9, [x9]
	cmp	x8, x19
	csel	x21, x9, xzr, eq
	mov	w8, #24                         ; =0x18
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	umaddl	x20, w21, w8, x9
	ldp	x9, x8, [x20]
	add	x22, x8, #1
	str	x22, [x20, #8]
	ldr	x8, [x19, #136]
	cmp	x9, x8
	b.ne	LBB6_88
LBB6_87:
	ldr	x8, [x20, #16]
	add	x8, x8, #1
	str	x8, [x20, #16]
	b	LBB6_91
LBB6_88:
	add	x1, sp, #112
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB6_87
; %bb.89:
	ldp	x8, x9, [sp, #112]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	madd	x8, x8, x10, x9
	cbz	x8, LBB6_87
; %bb.90:
	ldp	x9, x10, [x19, #128]
	mul	x10, x10, x21
	ldr	x11, [x20]
	add	x12, x11, #1
	str	x12, [x20]
	mov	w12, #40                        ; =0x28
	madd	x9, x10, x12, x9
	madd	x9, x11, x12, x9
	stp	x8, x22, [x9]
	str	xzr, [x9, #16]
Lloh30:
	adrp	x8, lCPI6_3@PAGE
Lloh31:
	ldr	d0, [x8, lCPI6_3@PAGEOFF]
	str	d0, [x9, #24]
	str	wzr, [x9, #32]
LBB6_91:
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB6_93
; %bb.92:
	mov	x0, #0                          ; =0x0
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #208]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #192]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #176]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #160]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #144]            ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #128]              ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
LBB6_93:
	bl	_abort
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_bootstrap       ; -- Begin function neoclr_workers_bootstrap
	.p2align	2
_neoclr_workers_bootstrap:              ; @neoclr_workers_bootstrap
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x21, x4
	mov	x22, x3
	mov	x20, x2
	mov	x23, x1
	mov	x19, x0
	ldr	x24, [x0, #24]
	bl	_pthread_self
	mov	x1, x0
	mov	x0, x24
	bl	_pthread_equal
	mov	x8, x0
	mov	w0, #3                          ; =0x3
	cbz	x21, LBB7_11
; %bb.1:
	cbz	x20, LBB7_11
; %bb.2:
	cbz	x23, LBB7_11
; %bb.3:
	cbz	w8, LBB7_11
; %bb.4:
	mov	x0, x19
	bl	_heap_lock
	ldr	w8, [x19, #452]
	cbnz	w8, LBB7_9
; %bb.5:
	ldr	x8, [x19, #1544]
	cbnz	x8, LBB7_9
; %bb.6:
	ldr	x8, [x19, #1528]
	cbnz	x8, LBB7_9
; %bb.7:
	bl	_neoclr_root_probe_head_v1
	cbnz	x0, LBB7_9
; %bb.8:
	bl	_neoclr_roots_parked_v1
	cbz	x0, LBB7_12
LBB7_9:
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB7_20
; %bb.10:
	mov	w0, #3                          ; =0x3
LBB7_11:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB7_12:
	str	xzr, [sp, #8]
	add	x24, sp, #8
	add	x1, sp, #8
	add	x2, x19, #464
	mov	x0, x22
	blr	x23
	mov	x22, x0
	ldr	x8, [sp, #8]
	cmp	x8, #0
	csel	x1, x24, xzr, ne
	cset	w2, ne
	add	x0, x19, #464
	bl	_neoclr_gc_owned_roots_check_v1
	cbnz	w0, LBB7_20
; %bb.13:
	cbnz	w22, LBB7_16
; %bb.14:
	str	xzr, [sp]
	ldr	x1, [sp, #8]
	add	x0, x19, #464
	mov	x2, sp
	bl	_neoclr_gc_callback_read_v1
	mov	x22, x0
	cbnz	w0, LBB7_16
; %bb.15:
	ldr	x1, [sp]
	mov	x0, x19
	mov	x2, x21
	bl	_adopt
	mov	w8, #5                          ; =0x5
	cmp	w0, #0
	csel	w22, w8, wzr, eq
LBB7_16:
	ldr	x1, [sp, #8]
	cbz	x1, LBB7_18
; %bb.17:
	add	x0, x19, #464
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB7_20
LBB7_18:
	str	x20, [x19, #1544]
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB7_20
; %bb.19:
	mov	x0, x22
	b	LBB7_11
LBB7_20:
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function heap_lock
_heap_lock:                             ; @heap_lock
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh32:
	adrp	x0, _entered@TLVPPAGE
Lloh33:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh34:
	adrp	x0, _reading@TLVPPAGE
Lloh35:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh36:
	adrp	x0, _mutating@TLVPPAGE
Lloh37:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB8_7
; %bb.1:
	add	x0, x19, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB8_7
; %bb.2:
	ldr	w8, [x19, #448]
	add	w8, w8, #1
	str	w8, [x19, #448]
	b	LBB8_4
LBB8_3:                                 ;   in Loop: Header=BB8_4 Depth=1
	add	x0, x19, #384
	add	x1, x19, #272
	bl	_pthread_cond_wait
	cbnz	w0, LBB8_7
LBB8_4:                                 ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x19, #440]
	cbnz	w8, LBB8_3
; %bb.5:                                ;   in Loop: Header=BB8_4 Depth=1
	ldr	w8, [x19, #444]
	cbnz	w8, LBB8_3
; %bb.6:
	ldr	w8, [x19, #448]
	sub	w8, w8, #1
	str	w8, [x19, #448]
	add	x0, x19, #384
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_pthread_cond_broadcast
LBB8_7:
	bl	_abort
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function adopt
_adopt:                                 ; @adopt
	.cfi_startproc
; %bb.0:
	cbz	x1, LBB9_7
; %bb.1:
	mov	x8, #0                          ; =0x0
	mov	w9, #20888                      ; =0x5198
	add	x10, x0, x9
	mov	w9, #1                          ; =0x1
	b	LBB9_3
LBB9_2:                                 ;   in Loop: Header=BB9_3 Depth=1
	cmp	x8, #31
	add	x11, x8, #1
	cset	w9, lo
	add	x10, x10, #16
	mov	x8, x11
	cmp	x11, #32
	b.eq	LBB9_6
LBB9_3:                                 ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x10]
	cbnz	x11, LBB9_2
; %bb.4:                                ;   in Loop: Header=BB9_3 Depth=1
	ldur	x11, [x10, #-8]
	cmn	x11, #1
	b.eq	LBB9_2
; %bb.5:
	add	x11, x11, #1
	stp	x11, x1, [x10, #-8]
	ldr	x10, [x0]
	stp	x10, x11, [x2]
	mov	w10, #1                         ; =0x1
	stp	w8, w10, [x2, #16]
	and	w0, w9, #0x1
	ret
LBB9_6:
	mov	w0, #0                          ; =0x0
	ret
LBB9_7:
	stp	xzr, xzr, [x2]
	mov	w0, #1                          ; =0x1
	str	xzr, [x2, #16]
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_invoke_capture   ; -- Begin function neoclr_worker_invoke_capture
	.p2align	2
_neoclr_worker_invoke_capture:          ; @neoclr_worker_invoke_capture
	.cfi_startproc
; %bb.0:
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	mov	w9, #20960                      ; =0x51e0
Lloh38:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh39:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #5, lsl #12             ; =20480
	sub	sp, sp, #480
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
Lloh40:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh41:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh42:
	ldr	x8, [x8]
	stur	x8, [x29, #-88]
Lloh43:
	adrp	x0, _executing@TLVPPAGE
Lloh44:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x8, x19
	b.ne	LBB10_26
; %bb.1:
	ldr	x20, [x19]
	mov	x0, x20
	bl	_heap_lock
Lloh45:
	adrp	x0, _entered@TLVPPAGE
Lloh46:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	x19, [x0]
	ldr	x8, [x20, #1544]
	cbz	x8, LBB10_6
; %bb.2:
	mov	x21, x19
	ldr	w8, [x21, #144]!
	cbnz	w8, LBB10_6
; %bb.3:
	ldr	w8, [x20, #464]
	cbnz	w8, LBB10_6
; %bb.4:
	mov	x22, x0
	bl	_neoclr_root_probe_head_v1
	mov	x8, x0
	mov	x0, x22
	cbnz	x8, LBB10_6
; %bb.5:
	bl	_neoclr_roots_parked_v1
	mov	x8, x0
	mov	x0, x22
	cbz	x8, LBB10_11
LBB10_6:
	ldr	x8, [x0]
	cmp	x8, x19
	b.ne	LBB10_26
; %bb.7:
	str	xzr, [x0]
	ldr	x8, [x19]
	add	x0, x8, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB10_26
; %bb.8:
	mov	w0, #3                          ; =0x3
LBB10_9:
	ldur	x8, [x29, #-88]
Lloh47:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh48:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh49:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB10_27
; %bb.10:
	add	sp, sp, #5, lsl #12             ; =20480
	add	sp, sp, #480
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB10_11:
	add	x22, sp, #160
	add	x0, sp, #160
	mov	w1, #1048                       ; =0x418
	bl	_bzero
	add	x23, x22, #1048
	add	x24, x20, #1512
	ldr	q0, [x24]
	str	q0, [x23]
	ldr	x8, [x24, #16]
	str	x8, [sp, #1224]
	ldr	x8, [x20, #1536]
	str	x8, [sp, #1232]
	ldr	x26, [sp, #1208]
	ldr	x25, [sp, #1216]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24]
	str	xzr, [sp, #152]
	ldr	x1, [x19, #48]
	add	x0, sp, #160
	add	x2, sp, #152
	bl	_neoclr_gc_host_root_create_v1
	mov	x22, x0
	cbnz	w0, LBB10_16
; %bb.12:
	add	x1, sp, #1240
	mov	x0, x20
	bl	_pool_slots
	mov	x4, x0
	str	xzr, [sp, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp]
Lloh50:
	adrp	x5, l_.str@PAGE
Lloh51:
	add	x5, x5, l_.str@PAGEOFF
	add	x0, sp, #48
	add	x1, sp, #160
	add	x3, sp, #1240
	mov	w2, #0                          ; =0x0
	mov	w6, #2                          ; =0x2
	bl	_neoclr_gc_enter_v1
	mov	x27, sp
	mov	x0, sp
	bl	_neoclr_roots_park_v1
	ldr	x8, [x20, #1544]
	ldr	x0, [sp, #152]
	add	x1, sp, #160
	blr	x8
	mov	x22, x0
	bl	_neoclr_root_probe_head_v1
	cbnz	x0, LBB10_26
; %bb.13:
	bl	_neoclr_roots_parked_v1
	cmp	x0, x27
	b.ne	LBB10_26
; %bb.14:
	mov	x0, sp
	bl	_neoclr_roots_resume_v1
	add	x0, sp, #48
	bl	_neoclr_gc_leave_v1
	add	x0, sp, #160
	add	x1, sp, #152
	mov	w2, #1                          ; =0x1
	bl	_neoclr_gc_owned_roots_check_v1
	cbnz	w0, LBB10_26
; %bb.15:
	ldr	x1, [sp, #152]
	add	x0, sp, #160
	bl	_neoclr_gc_host_root_release_v1
	cbnz	w0, LBB10_26
LBB10_16:
	ldr	x8, [sp, #1208]
	cmp	x8, x26
	b.ne	LBB10_26
; %bb.17:
	ldr	x8, [sp, #1216]
	cmp	x8, x25
	b.ne	LBB10_26
; %bb.18:
	ldr	x8, [sp, #1224]
	cmp	x8, x25
	b.hi	LBB10_26
; %bb.19:
	ldr	x8, [x24]
	cbnz	x8, LBB10_26
; %bb.20:
	ldr	x8, [x20, #1520]
	cbnz	x8, LBB10_26
; %bb.21:
	ldr	x8, [x20, #1528]
	cbnz	x8, LBB10_26
; %bb.22:
	ldr	x8, [x20, #1536]
	cbnz	x8, LBB10_26
; %bb.23:
	ldr	q0, [x23]
	str	q0, [x24]
	ldr	x8, [x23, #16]
	str	x8, [x24, #16]
	ldr	x8, [sp, #1232]
	str	x8, [x20, #1536]
	ldr	w8, [sp, #160]
	cbz	w8, LBB10_25
; %bb.24:
	add	x1, sp, #160
	mov	x0, x21
	mov	w2, #1048                       ; =0x418
	bl	_memcpy
LBB10_25:
	add	x0, sp, #160
	mov	w1, #1080                       ; =0x438
	bl	_bzero
	mov	x0, x19
	bl	_neoclr_worker_leave
	mov	x0, x22
	b	LBB10_9
LBB10_26:
	bl	_abort
LBB10_27:
	bl	___stack_chk_fail
	.loh AdrpLdr	Lloh43, Lloh44
	.loh AdrpLdrGotLdr	Lloh40, Lloh41, Lloh42
	.loh AdrpLdr	Lloh45, Lloh46
	.loh AdrpLdrGotLdr	Lloh47, Lloh48, Lloh49
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpLdrGot	Lloh38, Lloh39
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_enter            ; -- Begin function neoclr_worker_enter
	.p2align	2
_neoclr_worker_enter:                   ; @neoclr_worker_enter
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh52:
	adrp	x0, _executing@TLVPPAGE
Lloh53:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x8, x19
	b.ne	LBB11_2
; %bb.1:
	ldr	x0, [x19]
	bl	_heap_lock
Lloh54:
	adrp	x0, _entered@TLVPPAGE
Lloh55:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	x19, [x0]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB11_2:
	bl	_abort
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpLdr	Lloh54, Lloh55
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_leave            ; -- Begin function neoclr_worker_leave
	.p2align	2
_neoclr_worker_leave:                   ; @neoclr_worker_leave
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh56:
	adrp	x0, _entered@TLVPPAGE
Lloh57:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	x9, x8
	b.ne	LBB12_3
; %bb.1:
	str	xzr, [x0]
	ldr	x8, [x8]
	add	x0, x8, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB12_3
; %bb.2:
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB12_3:
	bl	_abort
	.loh AdrpLdr	Lloh56, Lloh57
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function pool_slots
lCPI13_0:
	.long	8                               ; 0x8
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_pool_slots:                            ; @pool_slots
	.cfi_startproc
; %bb.0:
	mov	w8, #20888                      ; =0x5198
	add	x8, x0, x8
	str	x8, [x1]
	mov	w8, #20904                      ; =0x51a8
	add	x8, x0, x8
	str	x8, [x1, #16]
	mov	w8, #20920                      ; =0x51b8
	add	x8, x0, x8
	str	x8, [x1, #32]
	mov	w8, #20936                      ; =0x51c8
	add	x8, x0, x8
	str	x8, [x1, #48]
Lloh58:
	adrp	x8, lCPI13_0@PAGE
Lloh59:
	ldr	d0, [x8, lCPI13_0@PAGEOFF]
	str	d0, [x1, #8]
	str	d0, [x1, #24]
	str	d0, [x1, #40]
	str	d0, [x1, #56]
	mov	w8, #20952                      ; =0x51d8
	add	x8, x0, x8
	mov	w9, #20968                      ; =0x51e8
	add	x9, x0, x9
	mov	w10, #20984                     ; =0x51f8
	add	x10, x0, x10
	mov	w11, #21000                     ; =0x5208
	add	x11, x0, x11
	str	x8, [x1, #64]
	str	x9, [x1, #80]
	str	x10, [x1, #96]
	str	x11, [x1, #112]
	str	d0, [x1, #72]
	str	d0, [x1, #88]
	str	d0, [x1, #104]
	str	d0, [x1, #120]
	mov	w8, #21016                      ; =0x5218
	add	x8, x0, x8
	mov	w9, #21032                      ; =0x5228
	add	x9, x0, x9
	mov	w10, #21048                     ; =0x5238
	add	x10, x0, x10
	mov	w11, #21064                     ; =0x5248
	add	x11, x0, x11
	str	x8, [x1, #128]
	str	x9, [x1, #144]
	str	x10, [x1, #160]
	str	x11, [x1, #176]
	str	d0, [x1, #136]
	str	d0, [x1, #152]
	str	d0, [x1, #168]
	str	d0, [x1, #184]
	mov	w8, #21080                      ; =0x5258
	add	x8, x0, x8
	mov	w9, #21096                      ; =0x5268
	add	x9, x0, x9
	mov	w10, #21112                     ; =0x5278
	add	x10, x0, x10
	mov	w11, #21128                     ; =0x5288
	add	x11, x0, x11
	str	x8, [x1, #192]
	str	x9, [x1, #208]
	str	x10, [x1, #224]
	str	x11, [x1, #240]
	str	d0, [x1, #200]
	str	d0, [x1, #216]
	str	d0, [x1, #232]
	str	d0, [x1, #248]
	mov	w8, #21144                      ; =0x5298
	add	x8, x0, x8
	mov	w9, #21160                      ; =0x52a8
	add	x9, x0, x9
	mov	w10, #21176                     ; =0x52b8
	add	x10, x0, x10
	mov	w11, #21192                     ; =0x52c8
	add	x11, x0, x11
	str	x8, [x1, #256]
	str	x9, [x1, #272]
	str	x10, [x1, #288]
	str	x11, [x1, #304]
	str	d0, [x1, #264]
	str	d0, [x1, #280]
	str	d0, [x1, #296]
	str	d0, [x1, #312]
	mov	w8, #21208                      ; =0x52d8
	add	x8, x0, x8
	mov	w9, #21224                      ; =0x52e8
	add	x9, x0, x9
	mov	w10, #21240                     ; =0x52f8
	add	x10, x0, x10
	mov	w11, #21256                     ; =0x5308
	add	x11, x0, x11
	str	x8, [x1, #320]
	str	x9, [x1, #336]
	str	x10, [x1, #352]
	str	x11, [x1, #368]
	str	d0, [x1, #328]
	str	d0, [x1, #344]
	str	d0, [x1, #360]
	str	d0, [x1, #376]
	mov	w8, #21272                      ; =0x5318
	add	x8, x0, x8
	mov	w9, #21288                      ; =0x5328
	add	x9, x0, x9
	mov	w10, #21304                     ; =0x5338
	add	x10, x0, x10
	mov	w11, #21320                     ; =0x5348
	add	x11, x0, x11
	str	x8, [x1, #384]
	str	x9, [x1, #400]
	str	x10, [x1, #416]
	str	x11, [x1, #432]
	str	d0, [x1, #392]
	str	d0, [x1, #408]
	str	d0, [x1, #424]
	str	d0, [x1, #440]
	mov	w8, #21336                      ; =0x5358
	add	x8, x0, x8
	mov	w9, #21352                      ; =0x5368
	add	x9, x0, x9
	mov	w10, #21368                     ; =0x5378
	add	x10, x0, x10
	mov	w11, #21384                     ; =0x5388
	add	x11, x0, x11
	str	x8, [x1, #448]
	str	x9, [x1, #464]
	str	x10, [x1, #480]
	str	x11, [x1, #496]
	str	d0, [x1, #456]
	str	d0, [x1, #472]
	str	d0, [x1, #488]
	str	d0, [x1, #504]
	ldr	w8, [x0, #436]
	cbz	w8, LBB13_10
; %bb.1:
	mov	x9, #0                          ; =0x0
	add	x10, x0, #1552
	add	x11, x0, #1720
	mov	w8, #32                         ; =0x20
	mov	w12, #1208                      ; =0x4b8
	b	LBB13_4
LBB13_2:                                ;   in Loop: Header=BB13_4 Depth=1
	mov	x14, x8
LBB13_3:                                ;   in Loop: Header=BB13_4 Depth=1
	add	x8, x13, #56
	add	w15, w14, #1
	add	x16, x1, w14, uxtw #4
	str	x8, [x16]
	str	d0, [x16, #8]
	add	w8, w14, #2
	add	x15, x1, w15, uxtw #4
	add	x16, x13, #64
	str	x16, [x15]
	str	d0, [x15, #8]
	add	w15, w14, #3
	add	x8, x1, w8, uxtw #4
	add	x16, x13, #72
	str	x16, [x8]
	str	d0, [x8, #8]
	add	w8, w14, #4
	add	x15, x1, w15, uxtw #4
	add	x16, x13, #80
	str	x16, [x15]
	str	d0, [x15, #8]
	add	w15, w14, #5
	add	x8, x1, w8, uxtw #4
	add	x16, x13, #88
	str	x16, [x8]
	str	d0, [x8, #8]
	add	w8, w14, #6
	add	x15, x1, w15, uxtw #4
	add	x16, x13, #96
	str	x16, [x15]
	str	d0, [x15, #8]
	add	w15, w14, #7
	add	x8, x1, w8, uxtw #4
	add	x16, x13, #104
	str	x16, [x8]
	str	d0, [x8, #8]
	add	w8, w14, #8
	add	x14, x1, w15, uxtw #4
	add	x13, x13, #112
	str	x13, [x14]
	str	d0, [x14, #8]
	add	x9, x9, #1
	ldr	w13, [x0, #436]
	add	x11, x11, #1208
	cmp	x9, x13
	b.hs	LBB13_11
LBB13_4:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB13_8 Depth 2
	add	w15, w8, #1
	add	x14, x1, w8, uxtw #4
	madd	x13, x9, x12, x10
	add	x16, x13, #48
	str	x16, [x14]
	str	d0, [x14, #8]
	add	w14, w8, #2
	add	x15, x1, w15, uxtw #4
	add	x16, x13, #136
	str	x16, [x15]
	str	d0, [x15, #8]
	ldr	w15, [x13, #144]
	cbz	w15, LBB13_3
; %bb.5:                                ;   in Loop: Header=BB13_4 Depth=1
	ldr	w15, [x13, #148]
	cmp	w15, #65
	b.hs	LBB13_12
; %bb.6:                                ;   in Loop: Header=BB13_4 Depth=1
	add	w8, w8, #3
	add	x14, x1, w14, uxtw #4
	add	x15, x13, #152
	str	x15, [x14]
	str	d0, [x14, #8]
	ldr	w14, [x13, #148]
	cbz	w14, LBB13_2
; %bb.7:                                ;   in Loop: Header=BB13_4 Depth=1
	mov	x14, #0                         ; =0x0
	mov	x15, x11
LBB13_8:                                ;   Parent Loop BB13_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	w16, w8, w14
	add	x16, x1, w16, uxtw #4
	str	x15, [x16]
	str	d0, [x16, #8]
	add	x14, x14, #1
	ldr	w16, [x13, #148]
	add	x15, x15, #16
	cmp	x14, x16
	b.lo	LBB13_8
; %bb.9:                                ;   in Loop: Header=BB13_4 Depth=1
	add	w14, w8, w14
	b	LBB13_3
LBB13_10:
	mov	w8, #32                         ; =0x20
LBB13_11:
	mov	x0, x8
	ret
LBB13_12:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_abort
	.loh AdrpLdr	Lloh58, Lloh59
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_root_new        ; -- Begin function neoclr_workers_root_new
	.p2align	2
_neoclr_workers_root_new:               ; @neoclr_workers_root_new
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x21, x1
	mov	x19, x0
	bl	_heap_lock
	mov	w8, #0                          ; =0x0
	mov	x9, #-512                       ; =0xfffffffffffffe00
	b	LBB14_3
LBB14_1:                                ;   in Loop: Header=BB14_3 Depth=1
	ldr	x10, [x10, #21392]
	cmn	x10, #1
	cset	w10, ne
LBB14_2:                                ;   in Loop: Header=BB14_3 Depth=1
	orr	w8, w10, w8
	adds	x9, x9, #16
	b.eq	LBB14_5
LBB14_3:                                ; =>This Inner Loop Header: Depth=1
	add	x10, x19, x9
	ldr	x11, [x10, #21400]
	cbz	x11, LBB14_1
; %bb.4:                                ;   in Loop: Header=BB14_3 Depth=1
	mov	w10, #0                         ; =0x0
	b	LBB14_2
LBB14_5:
	str	xzr, [sp, #8]
	ldr	w9, [x19, #452]
	cmp	w9, #0
	ccmp	w8, #0, #4, eq
	b.eq	LBB14_7
; %bb.6:
	add	x0, x19, #1512
	add	x3, sp, #8
	mov	w1, #8                          ; =0x8
	mov	w2, #3                          ; =0x3
	bl	_neoclr_gc_allocate_v1
	cbz	w0, LBB14_10
LBB14_7:
	mov	w21, #0                         ; =0x0
LBB14_8:
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB14_17
; %bb.9:
	mov	x0, x21
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB14_10:
	ldr	x8, [sp, #8]
	str	x21, [x8]
	ldr	x8, [sp, #8]
	cbz	x8, LBB14_16
; %bb.11:
	mov	x9, #0                          ; =0x0
	mov	w10, #20888                     ; =0x5198
	add	x11, x19, x10
	mov	w10, #1                         ; =0x1
	b	LBB14_13
LBB14_12:                               ;   in Loop: Header=BB14_13 Depth=1
	cmp	x9, #31
	add	x12, x9, #1
	cset	w10, lo
	add	x11, x11, #16
	mov	x9, x12
	cmp	x12, #32
	b.eq	LBB14_7
LBB14_13:                               ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x11]
	cbnz	x12, LBB14_12
; %bb.14:                               ;   in Loop: Header=BB14_13 Depth=1
	ldur	x12, [x11, #-8]
	cmn	x12, #1
	b.eq	LBB14_12
; %bb.15:
	add	x12, x12, #1
	stp	x12, x8, [x11, #-8]
	ldr	x8, [x19]
	stp	x8, x12, [x20]
	mov	w8, #1                          ; =0x1
	stp	w9, w8, [x20, #16]
	and	w21, w10, #0x1
	b	LBB14_8
LBB14_16:
	stp	xzr, xzr, [x20]
	mov	w21, #1                         ; =0x1
	str	xzr, [x20, #16]
	b	LBB14_8
LBB14_17:
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_root_read       ; -- Begin function neoclr_workers_root_read
	.p2align	2
_neoclr_workers_root_read:              ; @neoclr_workers_root_read
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x21, x1
	mov	x19, x0
	bl	_heap_lock
	ldr	w8, [x21, #20]
	cmp	w8, #1
	b.ne	LBB15_6
; %bb.1:
	ldr	w8, [x21, #16]
	ldr	x9, [x21]
	ldr	x10, [x19]
	cmp	x9, x10
	ccmp	w8, #31, #2, eq
	b.hi	LBB15_6
; %bb.2:
	add	x8, x19, x8, lsl #4
	ldr	x1, [x8, #20888]
	cbz	x1, LBB15_6
; %bb.3:
	ldr	x9, [x21, #8]
	mov	w10, #20880                     ; =0x5190
	add	x22, x8, x10
	ldr	x8, [x22]
	cmp	x8, x9
	b.ne	LBB15_6
; %bb.4:
	str	xzr, [sp, #8]
	str	wzr, [sp, #4]
	add	x0, x19, #464
	add	x2, sp, #8
	add	x3, sp, #4
	bl	_neoclr_gc_allocation_info_v1
	mov	w21, #0                         ; =0x0
	ldr	x8, [sp, #8]
	cmp	w0, #0
	ccmp	x8, #8, #0, eq
	b.lo	LBB15_7
; %bb.5:
	ldr	x8, [x22, #8]
	ldr	x8, [x8]
	str	x8, [x20]
	mov	w21, #1                         ; =0x1
	b	LBB15_7
LBB15_6:
	mov	w21, #0                         ; =0x0
	str	xzr, [sp, #8]
	str	wzr, [sp, #4]
LBB15_7:
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB15_9
; %bb.8:
	mov	x0, x21
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB15_9:
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_root_release    ; -- Begin function neoclr_workers_root_release
	.p2align	2
_neoclr_workers_root_release:           ; @neoclr_workers_root_release
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x0
Lloh60:
	adrp	x0, _entered@TLVPPAGE
Lloh61:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh62:
	adrp	x0, _reading@TLVPPAGE
Lloh63:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh64:
	adrp	x0, _mutating@TLVPPAGE
Lloh65:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB16_11
; %bb.1:
	add	x0, x19, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB16_11
; %bb.2:
	ldr	w8, [x20, #20]
	cmp	w8, #1
	b.ne	LBB16_8
; %bb.3:
	mov	w21, #0                         ; =0x0
	ldr	x8, [x20]
	ldr	x9, [x19]
	cmp	x8, x9
	b.ne	LBB16_9
; %bb.4:
	ldr	w8, [x20, #16]
	cmp	w8, #31
	b.hi	LBB16_9
; %bb.5:
	add	x8, x19, x8, lsl #4
	ldr	x9, [x8, #20888]
	cbz	x9, LBB16_8
; %bb.6:
	ldr	x9, [x20, #8]
	mov	w10, #20880                     ; =0x5190
	add	x8, x8, x10
	ldr	x10, [x8]
	cmp	x10, x9
	b.ne	LBB16_8
; %bb.7:
	str	xzr, [x8, #8]
	mov	w21, #1                         ; =0x1
	b	LBB16_9
LBB16_8:
	mov	w21, #0                         ; =0x0
LBB16_9:
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB16_11
; %bb.10:
	mov	x0, x21
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB16_11:
	bl	_abort
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpLdr	Lloh60, Lloh61
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function neoclr_workers_submit
lCPI17_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_neoclr_workers_submit
	.p2align	2
_neoclr_workers_submit:                 ; @neoclr_workers_submit
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x4
	mov	x21, x3
	mov	x22, x2
	mov	x24, x1
	mov	x19, x0
Lloh66:
	adrp	x0, _entered@TLVPPAGE
Lloh67:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh68:
	adrp	x0, _reading@TLVPPAGE
Lloh69:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh70:
	adrp	x0, _mutating@TLVPPAGE
Lloh71:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB17_19
; %bb.1:
	add	x0, x19, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB17_19
; %bb.2:
	ldr	w8, [x24, #20]
	cmp	w8, #1
	b.ne	LBB17_16
; %bb.3:
	mov	w23, #0                         ; =0x0
	ldr	x8, [x24]
	ldr	x9, [x19]
	cmp	x8, x9
	b.ne	LBB17_17
; %bb.4:
	ldr	w9, [x24, #16]
	cmp	w9, #31
	b.hi	LBB17_17
; %bb.5:
	add	x9, x19, x9, lsl #4
	ldr	x10, [x9, #20888]
	cbz	x10, LBB17_16
; %bb.6:
	mov	w23, #0                         ; =0x0
	ldr	x10, [x24, #8]
	mov	w11, #20880                     ; =0x5190
	add	x9, x9, x11
	ldr	x11, [x9]
	cmp	x11, x10
	csel	x9, x9, xzr, eq
	cbz	x22, LBB17_17
; %bb.7:
	ldr	w12, [x19, #452]
	cbnz	w12, LBB17_17
; %bb.8:
	cmp	x11, x10
	b.ne	LBB17_17
; %bb.9:
	ldr	x11, [x19, #8]
	cmn	x11, #1
	b.eq	LBB17_16
; %bb.10:
	ldr	w13, [x19, #436]
	cbz	w13, LBB17_16
; %bb.11:
	mov	x12, #0                         ; =0x0
	mov	w10, #0                         ; =0x0
	mov	w14, #1208                      ; =0x4b8
	umull	x13, w13, w14
	b	LBB17_13
LBB17_12:                               ;   in Loop: Header=BB17_13 Depth=1
	mov	w23, #0                         ; =0x0
	add	w10, w10, #1
	add	x12, x12, #1208
	cmp	x13, x12
	b.eq	LBB17_17
LBB17_13:                               ; =>This Inner Loop Header: Depth=1
	add	x14, x19, x12
	ldr	w15, [x14, #1584]
	cbnz	w15, LBB17_12
; %bb.14:                               ;   in Loop: Header=BB17_13 Depth=1
	ldr	x14, [x14, #1560]
	cmn	x14, #1
	b.eq	LBB17_12
; %bb.15:
	add	x11, x11, #1
	str	x11, [x19, #8]
	add	x12, x19, x12
	str	x11, [x12, #1568]
	add	x11, x14, #1
	str	x11, [x12, #1560]
	ldr	x9, [x9, #8]
	str	x9, [x12, #1600]
	str	x22, [x12, #2744]
	str	x21, [x12, #2752]
	str	wzr, [x12, #1596]
	str	xzr, [x12, #1672]
	str	xzr, [x12, #1688]
	str	xzr, [x12, #1680]
Lloh72:
	adrp	x9, lCPI17_0@PAGE
Lloh73:
	ldr	d0, [x9, lCPI17_0@PAGEOFF]
	str	d0, [x12, #1584]
	stp	x8, x11, [x20]
	mov	w8, #2                          ; =0x2
	stp	w10, w8, [x20, #16]
	add	x2, x12, #1552
	mov	x0, x19
	mov	w1, #5                          ; =0x5
	mov	w3, #0                          ; =0x0
	bl	_trace_emit
	add	x0, x19, #336
	bl	_pthread_cond_signal
	mov	w23, #1                         ; =0x1
	b	LBB17_17
LBB17_16:
	mov	w23, #0                         ; =0x0
LBB17_17:
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB17_19
; %bb.18:
	mov	x0, x23
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB17_19:
	bl	_abort
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh72, Lloh73
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function trace_emit
_trace_emit:                            ; @trace_emit
	.cfi_startproc
; %bb.0:
	ldr	x8, [x0, #128]
	cbz	x8, LBB18_10
; %bb.1:
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x0
Lloh74:
	adrp	x0, _trace_pool@TLVPPAGE
Lloh75:
	ldr	x0, [x0, _trace_pool@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh76:
	adrp	x0, _trace_worker@TLVPPAGE
Lloh77:
	ldr	x0, [x0, _trace_worker@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	w9, [x0]
	cmp	x8, x19
	csel	x22, x9, xzr, eq
	mov	w8, #24                         ; =0x18
	umaddl	x21, w22, w8, x19
	ldp	x8, x9, [x21, #152]!
	add	x20, x9, #1
	str	x20, [x21, #8]
	ldr	x9, [x19, #136]
	cmp	x8, x9
	b.ne	LBB18_3
LBB18_2:
	ldr	x8, [x21, #16]
	add	x8, x8, #1
	str	x8, [x21, #16]
	b	LBB18_9
LBB18_3:
	mov	x23, x2
	mov	x24, x1
	mov	x25, x3
	mov	x1, sp
	mov	w0, #6                          ; =0x6
	bl	_clock_gettime
	cbnz	w0, LBB18_2
; %bb.4:
	mov	w8, #51712                      ; =0xca00
	movk	w8, #15258, lsl #16
	ldp	x9, x10, [sp]
	madd	x8, x9, x8, x10
	cbz	x8, LBB18_2
; %bb.5:
	ldp	x9, x10, [x19, #128]
	mul	x10, x10, x22
	ldr	x11, [x21]
	add	x12, x11, #1
	str	x12, [x21]
	mov	w12, #40                        ; =0x28
	madd	x9, x10, x12, x9
	madd	x9, x11, x12, x9
	cbz	x23, LBB18_7
; %bb.6:
	ldr	x10, [x23, #8]
	sub	x11, x23, x19
	sub	x11, x11, #1552
	lsr	x11, x11, #3
	mov	w12, #32551                     ; =0x7f27
	movk	w12, #49043, lsl #16
	mul	w11, w11, w12
	b	LBB18_8
LBB18_7:
	mov	x10, #0                         ; =0x0
	mov	w11, #-1                        ; =0xffffffff
LBB18_8:
	stp	x8, x20, [x9]
	str	x10, [x9, #16]
	stp	w24, w11, [x9, #24]
	str	w25, [x9, #32]
LBB18_9:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
LBB18_10:
	ret
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpLdr	Lloh74, Lloh75
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_cancel          ; -- Begin function neoclr_workers_cancel
	.p2align	2
_neoclr_workers_cancel:                 ; @neoclr_workers_cancel
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x0
Lloh78:
	adrp	x0, _entered@TLVPPAGE
Lloh79:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh80:
	adrp	x0, _reading@TLVPPAGE
Lloh81:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh82:
	adrp	x0, _mutating@TLVPPAGE
Lloh83:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB19_15
; %bb.1:
	add	x0, x19, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB19_15
; %bb.2:
	ldr	w8, [x20, #20]
	cmp	w8, #2
	b.ne	LBB19_8
; %bb.3:
	ldr	x8, [x20]
	ldr	x9, [x19]
	cmp	x8, x9
	b.ne	LBB19_8
; %bb.4:
	ldr	w8, [x20, #16]
	ldr	w9, [x19, #436]
	cmp	w8, w9
	b.hs	LBB19_8
; %bb.5:
	mov	w9, #1208                       ; =0x4b8
	umaddl	x9, w8, w9, x19
	ldr	w8, [x9, #1584]
	cbz	w8, LBB19_8
; %bb.6:
	ldr	x10, [x20, #8]
	add	x20, x9, #1552
	ldr	x9, [x20, #8]
	cmp	x9, x10
	ccmp	w8, #3, #4, eq
	b.eq	LBB19_8
; %bb.7:
	ldr	w8, [x20, #36]
	cbz	w8, LBB19_11
LBB19_8:
	mov	w20, #0                         ; =0x0
LBB19_9:
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB19_15
; %bb.10:
	mov	x0, x20
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB19_11:
	mov	w21, #1                         ; =0x1
	str	w21, [x20, #36]
	mov	x0, x19
	mov	w1, #9                          ; =0x9
	mov	x2, x20
	mov	w3, #0                          ; =0x0
	bl	_trace_emit
	ldr	w8, [x20, #32]
	cmp	w8, #1
	b.ne	LBB19_14
; %bb.12:
	str	xzr, [x20, #48]
	str	w21, [x20, #40]
	ldr	x0, [x20]
	ldr	x8, [x0, #16]
	cmn	x8, #1
	b.eq	LBB19_15
; %bb.13:
	add	x8, x8, #1
	str	x8, [x0, #16]
	str	x8, [x20, #24]
	mov	w8, #3                          ; =0x3
	str	w8, [x20, #32]
	mov	w1, #8                          ; =0x8
	mov	x2, x20
	mov	w3, #1                          ; =0x1
	bl	_trace_emit
	ldr	x8, [x20]
	add	x0, x8, #384
	bl	_pthread_cond_broadcast
LBB19_14:
	add	x0, x19, #384
	bl	_pthread_cond_broadcast
	mov	w20, #1                         ; =0x1
	b	LBB19_9
LBB19_15:
	bl	_abort
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpLdr	Lloh78, Lloh79
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_cancelled        ; -- Begin function neoclr_worker_cancelled
	.p2align	2
_neoclr_worker_cancelled:               ; @neoclr_worker_cancelled
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
Lloh84:
	adrp	x0, _entered@TLVPPAGE
Lloh85:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh86:
	adrp	x0, _reading@TLVPPAGE
Lloh87:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh88:
	adrp	x0, _mutating@TLVPPAGE
Lloh89:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB20_4
; %bb.1:
	ldr	x8, [x19]
	add	x0, x8, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB20_4
; %bb.2:
	ldr	w20, [x19, #36]
	ldr	x8, [x19]
	add	x0, x8, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB20_4
; %bb.3:
	mov	x0, x20
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB20_4:
	bl	_abort
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpLdr	Lloh84, Lloh85
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_read_begin       ; -- Begin function neoclr_worker_read_begin
	.p2align	2
_neoclr_worker_read_begin:              ; @neoclr_worker_read_begin
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh90:
	adrp	x0, _executing@TLVPPAGE
Lloh91:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x8, x19
	b.ne	LBB21_8
; %bb.1:
	ldr	x21, [x19]
Lloh92:
	adrp	x0, _entered@TLVPPAGE
Lloh93:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh94:
	adrp	x0, _reading@TLVPPAGE
Lloh95:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x20, x0
	ldr	x9, [x0]
Lloh96:
	adrp	x0, _mutating@TLVPPAGE
Lloh97:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB21_8
; %bb.2:
	add	x0, x21, #272
	bl	_pthread_mutex_lock
	cbz	w0, LBB21_4
	b	LBB21_8
LBB21_3:                                ;   in Loop: Header=BB21_4 Depth=1
	add	x0, x21, #384
	add	x1, x21, #272
	bl	_pthread_cond_wait
	cbnz	w0, LBB21_8
LBB21_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x21, #448]
	cbnz	w8, LBB21_3
; %bb.5:                                ;   in Loop: Header=BB21_4 Depth=1
	ldr	w8, [x21, #444]
	cbnz	w8, LBB21_3
; %bb.6:
	ldr	w8, [x21, #440]
	add	w8, w8, #1
	str	w8, [x21, #440]
	str	x19, [x20]
	ldr	x19, [x19, #48]
	add	x0, x21, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB21_8
; %bb.7:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB21_8:
	bl	_abort
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpLdr	Lloh92, Lloh93
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_read_end         ; -- Begin function neoclr_worker_read_end
	.p2align	2
_neoclr_worker_read_end:                ; @neoclr_worker_read_end
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh98:
	adrp	x0, _reading@TLVPPAGE
Lloh99:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x19, x0
	ldr	x9, [x0]
Lloh100:
	adrp	x0, _executing@TLVPPAGE
Lloh101:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x9, x8
	ccmp	x10, x8, #0, eq
	b.ne	LBB22_7
; %bb.1:
	ldr	x20, [x8]
	add	x0, x20, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB22_7
; %bb.2:
	ldr	w8, [x20, #440]
	cbz	w8, LBB22_7
; %bb.3:
	str	xzr, [x19]
	subs	w8, w8, #1
	str	w8, [x20, #440]
	b.ne	LBB22_5
; %bb.4:
	add	x0, x20, #384
	bl	_pthread_cond_broadcast
LBB22_5:
	add	x0, x20, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB22_7
; %bb.6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB22_7:
	bl	_abort
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpLdr	Lloh98, Lloh99
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_mutate_begin     ; -- Begin function neoclr_worker_mutate_begin
	.p2align	2
_neoclr_worker_mutate_begin:            ; @neoclr_worker_mutate_begin
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
Lloh102:
	adrp	x0, _executing@TLVPPAGE
Lloh103:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x8, x19
	b.ne	LBB23_8
; %bb.1:
	ldr	x21, [x19]
Lloh104:
	adrp	x0, _entered@TLVPPAGE
Lloh105:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh106:
	adrp	x0, _reading@TLVPPAGE
Lloh107:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh108:
	adrp	x0, _mutating@TLVPPAGE
Lloh109:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB23_8
; %bb.2:
	mov	x20, x0
	add	x0, x21, #272
	bl	_pthread_mutex_lock
	cbz	w0, LBB23_4
	b	LBB23_8
LBB23_3:                                ;   in Loop: Header=BB23_4 Depth=1
	add	x0, x21, #384
	add	x1, x21, #272
	bl	_pthread_cond_wait
	cbnz	w0, LBB23_8
LBB23_4:                                ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x21, #448]
	cbnz	w8, LBB23_3
; %bb.5:                                ;   in Loop: Header=BB23_4 Depth=1
	ldr	w8, [x21, #440]
	cbnz	w8, LBB23_3
; %bb.6:
	ldr	w8, [x21, #444]
	add	w8, w8, #1
	str	w8, [x21, #444]
	str	x19, [x20]
	ldr	x19, [x19, #48]
	add	x0, x21, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB23_8
; %bb.7:
	mov	x0, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB23_8:
	bl	_abort
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpLdr	Lloh108, Lloh109
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpLdr	Lloh104, Lloh105
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_mutate_end       ; -- Begin function neoclr_worker_mutate_end
	.p2align	2
_neoclr_worker_mutate_end:              ; @neoclr_worker_mutate_end
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x8, x0
Lloh110:
	adrp	x0, _mutating@TLVPPAGE
Lloh111:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	mov	x19, x0
	ldr	x9, [x0]
Lloh112:
	adrp	x0, _executing@TLVPPAGE
Lloh113:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x9, x8
	ccmp	x10, x8, #0, eq
	b.ne	LBB24_7
; %bb.1:
	ldr	x20, [x8]
	add	x0, x20, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB24_7
; %bb.2:
	ldr	w8, [x20, #444]
	cbz	w8, LBB24_7
; %bb.3:
	str	xzr, [x19]
	subs	w8, w8, #1
	str	w8, [x20, #444]
	b.ne	LBB24_5
; %bb.4:
	add	x0, x20, #384
	bl	_pthread_cond_broadcast
LBB24_5:
	add	x0, x20, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB24_7
; %bb.6:
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB24_7:
	bl	_abort
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpLdr	Lloh110, Lloh111
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_mutate_poll      ; -- Begin function neoclr_worker_mutate_poll
	.p2align	2
_neoclr_worker_mutate_poll:             ; @neoclr_worker_mutate_poll
	.cfi_startproc
; %bb.0:
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	bl	_neoclr_worker_mutate_end
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_neoclr_worker_mutate_begin
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_capture          ; -- Begin function neoclr_worker_capture
	.p2align	2
_neoclr_worker_capture:                 ; @neoclr_worker_capture
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh114:
	adrp	x0, _entered@TLVPPAGE
Lloh115:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	x9, x8
	b.ne	LBB26_2
; %bb.1:
	ldr	x0, [x8, #48]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB26_2:
	bl	_abort
	.loh AdrpLdr	Lloh114, Lloh115
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_allocate         ; -- Begin function neoclr_worker_allocate
	.p2align	2
_neoclr_worker_allocate:                ; @neoclr_worker_allocate
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh116:
	adrp	x0, _entered@TLVPPAGE
Lloh117:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
	cmp	x9, x8
	b.ne	LBB27_2
; %bb.1:
	str	xzr, [sp, #8]
	ldr	x8, [x8]
	add	x0, x8, #1512
	add	x3, sp, #8
	bl	_neoclr_gc_allocate_v1
	ldr	x8, [sp, #8]
	cmp	w0, #0
	csel	x0, x8, xzr, eq
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
LBB27_2:
	bl	_abort
	.loh AdrpLdr	Lloh116, Lloh117
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_result           ; -- Begin function neoclr_worker_result
	.p2align	2
_neoclr_worker_result:                  ; @neoclr_worker_result
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x1
	mov	x19, x0
Lloh118:
	adrp	x0, _entered@TLVPPAGE
Lloh119:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x8, x19
	b.ne	LBB28_4
; %bb.1:
	ldr	x1, [x20, #16]
	cbz	x1, LBB28_3
; %bb.2:
	ldr	x8, [x19]
	add	x0, x8, #464
	add	x2, sp, #8
	add	x3, sp, #4
	bl	_neoclr_gc_allocation_info_v1
	cbnz	w0, LBB28_4
LBB28_3:
	ldr	q0, [x20]
	ldr	x8, [x20, #16]
	str	x8, [x19, #136]
	stur	q0, [x19, #120]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB28_4:
	bl	_abort
	.loh AdrpLdr	Lloh118, Lloh119
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_local_store      ; -- Begin function neoclr_worker_local_store
	.p2align	2
_neoclr_worker_local_store:             ; @neoclr_worker_local_store
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x21, x2
	mov	x22, x1
	mov	x19, x0
Lloh120:
	adrp	x0, _entered@TLVPPAGE
Lloh121:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x9, [x0]
Lloh122:
	adrp	x0, _mutating@TLVPPAGE
Lloh123:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cmp	x9, x19
	ccmp	x8, x19, #4, ne
	b.ne	LBB29_11
; %bb.1:
	mov	x20, x0
	cmp	x8, x19
	b.ne	LBB29_3
; %bb.2:
	ldr	x8, [x19]
	add	x0, x8, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB29_11
LBB29_3:
	cmp	w22, #7
	b.hi	LBB29_6
; %bb.4:
	cbz	x21, LBB29_7
; %bb.5:
	ldr	x8, [x19]
	add	x0, x8, #464
	add	x2, sp, #8
	add	x3, sp, #4
	mov	x1, x21
	bl	_neoclr_gc_allocation_info_v1
	cbz	w0, LBB29_7
LBB29_6:
	mov	w21, #0                         ; =0x0
	b	LBB29_8
LBB29_7:
	add	x8, x19, w22, uxtw #3
	str	x21, [x8, #56]
	mov	w21, #1                         ; =0x1
LBB29_8:
	ldr	x8, [x20]
	cmp	x8, x19
	b.ne	LBB29_10
; %bb.9:
	ldr	x8, [x19]
	add	x0, x8, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB29_11
LBB29_10:
	mov	x0, x21
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB29_11:
	bl	_abort
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpLdr	Lloh120, Lloh121
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_worker_local_load       ; -- Begin function neoclr_worker_local_load
	.p2align	2
_neoclr_worker_local_load:              ; @neoclr_worker_local_load
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x8, x0
Lloh124:
	adrp	x0, _entered@TLVPPAGE
Lloh125:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh126:
	adrp	x0, _mutating@TLVPPAGE
Lloh127:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x9, x8
	ccmp	x10, x8, #4, ne
	b.ne	LBB30_4
; %bb.1:
	cmp	w1, #7
	b.hi	LBB30_3
; %bb.2:
	add	x8, x8, w1, uxtw #3
	ldr	x0, [x8, #56]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB30_3:
	mov	x0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB30_4:
	bl	_abort
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpLdr	Lloh124, Lloh125
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_wait            ; -- Begin function neoclr_workers_wait
	.p2align	2
_neoclr_workers_wait:                   ; @neoclr_workers_wait
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x0
Lloh128:
	adrp	x0, _executing@TLVPPAGE
Lloh129:
	ldr	x0, [x0, _executing@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
	cbz	x8, LBB31_3
; %bb.1:
	mov	w0, #-1                         ; =0xffffffff
	mov	w9, #60000                      ; =0xea60
	cmp	w2, w9
	b.hi	LBB31_27
; %bb.2:
	ldr	x8, [x8]
	cmp	x8, x19
	b.ne	LBB31_4
	b	LBB31_27
LBB31_3:
	mov	w8, #60000                      ; =0xea60
	cmp	w2, w8
	b.hi	LBB31_5
LBB31_4:
	mov	x21, x2
	mov	x1, sp
	mov	w0, #0                          ; =0x0
	bl	_clock_gettime
	cbz	w0, LBB31_6
LBB31_5:
	mov	w0, #-1                         ; =0xffffffff
	b	LBB31_27
LBB31_6:
	ubfx	w8, w21, #3, #13
	mov	w9, #8389                       ; =0x20c5
	mul	w8, w8, w9
	lsr	w8, w8, #20
	mov	w9, #1000                       ; =0x3e8
	msub	w9, w8, w9, w21
	ldp	x10, x11, [sp]
	add	x8, x10, x8
	and	x9, x9, #0xffff
	mov	w10, #16960                     ; =0x4240
	movk	w10, #15, lsl #16
	umaddl	x9, w9, w10, x11
	stp	x8, x9, [sp]
	mov	w10, #51712                     ; =0xca00
	movk	w10, #15258, lsl #16
	cmp	x9, x10
	b.lt	LBB31_8
; %bb.7:
	add	x8, x8, #1
	mov	x10, #-51712                    ; =0xffffffffffff3600
	movk	x10, #50277, lsl #16
	add	x9, x9, x10
	stp	x8, x9, [sp]
LBB31_8:
Lloh130:
	adrp	x0, _entered@TLVPPAGE
Lloh131:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh132:
	adrp	x0, _reading@TLVPPAGE
Lloh133:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh134:
	adrp	x0, _mutating@TLVPPAGE
Lloh135:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB31_29
; %bb.9:
	add	x0, x19, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB31_29
; %bb.10:
	add	x21, x19, #1552
	mov	w22, #1208                      ; =0x4b8
LBB31_11:                               ; =>This Inner Loop Header: Depth=1
	ldr	w8, [x20, #20]
	cmp	w8, #2
	b.ne	LBB31_25
; %bb.12:                               ;   in Loop: Header=BB31_11 Depth=1
	ldr	x8, [x20]
	ldr	x9, [x19]
	cmp	x8, x9
	b.ne	LBB31_25
; %bb.13:                               ;   in Loop: Header=BB31_11 Depth=1
	ldr	w8, [x20, #16]
	ldr	w9, [x19, #436]
	cmp	w8, w9
	b.hs	LBB31_25
; %bb.14:                               ;   in Loop: Header=BB31_11 Depth=1
	umaddl	x9, w8, w22, x21
	ldr	w8, [x9, #32]
	cbz	w8, LBB31_25
; %bb.15:                               ;   in Loop: Header=BB31_11 Depth=1
	ldr	x10, [x20, #8]
	ldr	x9, [x9, #8]
	cmp	x9, x10
	b.ne	LBB31_25
; %bb.16:                               ;   in Loop: Header=BB31_11 Depth=1
	cmp	w8, #3
	b.eq	LBB31_28
; %bb.17:                               ;   in Loop: Header=BB31_11 Depth=1
	add	x0, x19, #384
	add	x1, x19, #272
	mov	x2, sp
	bl	_pthread_cond_timedwait
	cbz	w0, LBB31_11
; %bb.18:
	cmp	w0, #60
	b.ne	LBB31_25
; %bb.19:
	ldr	w8, [x20, #20]
	cmp	w8, #2
	b.ne	LBB31_25
; %bb.20:
	ldr	x8, [x20]
	ldr	x9, [x19]
	cmp	x8, x9
	b.ne	LBB31_25
; %bb.21:
	ldr	w8, [x20, #16]
	ldr	w9, [x19, #436]
	cmp	w8, w9
	b.hs	LBB31_25
; %bb.22:
	mov	w9, #1208                       ; =0x4b8
	umaddl	x9, w8, w9, x21
	ldr	w8, [x9, #32]
	cbz	w8, LBB31_25
; %bb.23:
	ldr	x10, [x20, #8]
	ldr	x9, [x9, #8]
	cmp	x9, x10
	b.ne	LBB31_25
; %bb.24:
	cmp	w8, #3
	cset	w20, eq
	b	LBB31_26
LBB31_25:
	mov	w20, #-1                        ; =0xffffffff
LBB31_26:
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	mov	x8, x0
	mov	x0, x20
	cbnz	w8, LBB31_29
LBB31_27:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB31_28:
	mov	w20, #1                         ; =0x1
	b	LBB31_26
LBB31_29:
	bl	_abort
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpLdr	Lloh134, Lloh135
	.loh AdrpLdr	Lloh132, Lloh133
	.loh AdrpLdr	Lloh130, Lloh131
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_dispatch        ; -- Begin function neoclr_workers_dispatch
	.p2align	2
_neoclr_workers_dispatch:               ; @neoclr_workers_dispatch
	.cfi_startproc
; %bb.0:
	sub	sp, sp, #192
	stp	x28, x27, [sp, #96]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	add	x29, sp, #176
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	stp	x3, x2, [sp, #56]               ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	ldr	x23, [x0, #24]
	bl	_pthread_self
	mov	x1, x0
	mov	x0, x23
	bl	_pthread_equal
	mov	x8, x0
	mov	w0, #-1                         ; =0xffffffff
	cmp	w19, #16
	b.hi	LBB32_71
; %bb.1:
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	cbz	x9, LBB32_71
; %bb.2:
	cbz	w8, LBB32_71
; %bb.3:
Lloh136:
	adrp	x0, _entered@TLVPPAGE
Lloh137:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	str	x0, [sp, #48]                   ; 8-byte Folded Spill
	ldr	x8, [x0]
Lloh138:
	adrp	x0, _reading@TLVPPAGE
Lloh139:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	ldr	x9, [x0]
Lloh140:
	adrp	x0, _mutating@TLVPPAGE
Lloh141:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	str	x0, [sp, #32]                   ; 8-byte Folded Spill
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB32_72
; %bb.4:
	add	x0, x20, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB32_72
; %bb.5:
	ldr	w8, [x20, #460]
	cbz	w8, LBB32_8
; %bb.6:
	add	x0, x20, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB32_72
; %bb.7:
	mov	w0, #-1                         ; =0xffffffff
	b	LBB32_71
LBB32_8:
	mov	w27, #0                         ; =0x0
	mov	w8, #1                          ; =0x1
	str	w8, [x20, #460]
	mov	w8, #10008                      ; =0x2718
	add	x21, x20, x8
	mov	w8, #8800                       ; =0x2260
	add	x23, x20, x8
	mov	w8, #7592                       ; =0x1da8
	add	x24, x20, x8
	mov	w8, #6384                       ; =0x18f0
	add	x22, x20, x8
	mov	w8, #5176                       ; =0x1438
	add	x26, x20, x8
	add	x8, x20, #1552
	stp	x8, x24, [sp, #8]               ; 16-byte Folded Spill
	mov	w28, #9664                      ; =0x25c0
	str	x26, [sp, #24]                  ; 8-byte Folded Spill
LBB32_9:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB32_30 Depth 2
                                        ;     Child Loop BB32_17 Depth 2
	cmp	w27, w19
	b.eq	LBB32_70
; %bb.10:                               ;   in Loop: Header=BB32_9 Depth=1
	ldr	w10, [x20, #436]
	cbz	w10, LBB32_69
; %bb.11:                               ;   in Loop: Header=BB32_9 Depth=1
	cmp	w10, #8
	b.hs	LBB32_27
; %bb.12:                               ;   in Loop: Header=BB32_9 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	w25, #0                         ; =0x0
LBB32_13:                               ;   in Loop: Header=BB32_9 Depth=1
	and	x10, x10, #0x7
	cbz	x10, LBB32_21
; %bb.14:                               ;   in Loop: Header=BB32_9 Depth=1
	ldr	x11, [sp, #8]                   ; 8-byte Folded Reload
	mov	w12, #1208                      ; =0x4b8
	madd	x11, x8, x12, x11
	b	LBB32_17
LBB32_15:                               ;   in Loop: Header=BB32_17 Depth=2
	mov	x25, x8
	mov	x9, x11
LBB32_16:                               ;   in Loop: Header=BB32_17 Depth=2
	add	w8, w8, #1
	add	x11, x11, #1208
	subs	x10, x10, #1
	b.eq	LBB32_21
LBB32_17:                               ;   Parent Loop BB32_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w12, [x11, #32]
	cmp	w12, #3
	b.ne	LBB32_16
; %bb.18:                               ;   in Loop: Header=BB32_17 Depth=2
	ldr	w12, [x11, #44]
	cbnz	w12, LBB32_16
; %bb.19:                               ;   in Loop: Header=BB32_17 Depth=2
	cbz	x9, LBB32_15
; %bb.20:                               ;   in Loop: Header=BB32_17 Depth=2
	ldr	x12, [x11, #24]
	ldr	x13, [x9, #24]
	cmp	x12, x13
	b.lo	LBB32_15
	b	LBB32_16
LBB32_21:                               ;   in Loop: Header=BB32_9 Depth=1
	cbz	x9, LBB32_69
; %bb.22:                               ;   in Loop: Header=BB32_9 Depth=1
	mov	x26, x22
	mov	x24, x23
	mov	x23, x21
	mov	x21, x27
	ldr	x27, [sp, #64]                  ; 8-byte Folded Reload
	mov	x28, x19
	ldr	x22, [x20]
	ldr	x19, [x9, #8]
	mov	w8, #1                          ; =0x1
	str	w8, [x9, #44]
	add	x0, x20, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB32_72
; %bb.23:                               ;   in Loop: Header=BB32_9 Depth=1
	stp	x22, x19, [sp, #72]
	mov	w8, #2                          ; =0x2
	stp	w25, w8, [sp, #88]
	add	x1, sp, #72
	mov	x0, x20
	ldr	x2, [sp, #56]                   ; 8-byte Folded Reload
	blr	x27
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	mov	x19, x28
	mov	x27, x21
	mov	x21, x23
	mov	x23, x24
	mov	x22, x26
	ldp	x24, x26, [sp, #16]             ; 16-byte Folded Reload
	mov	w28, #9664                      ; =0x25c0
	cbnz	x8, LBB32_72
; %bb.24:                               ;   in Loop: Header=BB32_9 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB32_72
; %bb.25:                               ;   in Loop: Header=BB32_9 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldr	x8, [x8]
	cbnz	x8, LBB32_72
; %bb.26:                               ;   in Loop: Header=BB32_9 Depth=1
	add	w27, w27, #1
	add	x0, x20, #272
	bl	_pthread_mutex_lock
	cbz	w0, LBB32_9
	b	LBB32_72
LBB32_27:                               ;   in Loop: Header=BB32_9 Depth=1
	mov	x11, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	w25, #0                         ; =0x0
	lsr	x12, x10, #3
	umull	x12, w12, w28
	mov	w17, #29368                     ; =0x72b8
	mov	w0, #28160                      ; =0x6e00
	mov	w1, #26952                      ; =0x6948
	mov	w2, #25744                      ; =0x6490
	mov	w3, #24536                      ; =0x5fd8
	mov	w4, #23328                      ; =0x5b20
	mov	w5, #22120                      ; =0x5668
	b	LBB32_30
LBB32_28:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x9, x21, x11
	add	w25, w8, #7
LBB32_29:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x8, x8, #8
	add	x11, x11, x28
	cmp	x12, x11
	b.eq	LBB32_13
LBB32_30:                               ;   Parent Loop BB32_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x13, x20, x11
	prfm	pldl1keep, [x13, #20912]
	ldr	w14, [x13, #1584]
	cmp	w14, #3
	b.ne	LBB32_35
; %bb.31:                               ;   in Loop: Header=BB32_30 Depth=2
	ldr	w14, [x13, #1596]
	cbnz	w14, LBB32_35
; %bb.32:                               ;   in Loop: Header=BB32_30 Depth=2
	cbz	x9, LBB32_34
; %bb.33:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x14, x20, x11
	ldr	x14, [x14, #1576]
	ldr	x15, [x9, #24]
	cmp	x14, x15
	b.hs	LBB32_35
LBB32_34:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x9, x13, #1552
	mov	x25, x8
LBB32_35:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x14, x13, x5
	prfm	pldl1keep, [x14]
	ldr	w14, [x13, #2792]
	cmp	w14, #3
	b.ne	LBB32_40
; %bb.36:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x14, x20, x11
	ldr	w14, [x14, #2804]
	cbnz	w14, LBB32_40
; %bb.37:                               ;   in Loop: Header=BB32_30 Depth=2
	cbz	x9, LBB32_39
; %bb.38:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x14, x20, x11
	ldr	x14, [x14, #2784]
	ldr	x15, [x9, #24]
	cmp	x14, x15
	b.hs	LBB32_40
LBB32_39:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x9, x13, #2760
	add	w25, w8, #1
LBB32_40:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x15, x13, x4
	add	x14, x20, x11
	prfm	pldl1keep, [x15]
	ldr	w15, [x14, #4000]
	cmp	w15, #3
	b.ne	LBB32_45
; %bb.41:                               ;   in Loop: Header=BB32_30 Depth=2
	ldr	w15, [x14, #4012]
	cbnz	w15, LBB32_45
; %bb.42:                               ;   in Loop: Header=BB32_30 Depth=2
	cbz	x9, LBB32_44
; %bb.43:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x15, x20, x11
	ldr	x15, [x15, #3992]
	ldr	x16, [x9, #24]
	cmp	x15, x16
	b.hs	LBB32_45
LBB32_44:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x9, x14, #3968
	add	w25, w8, #2
LBB32_45:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x15, x13, x3
	prfm	pldl1keep, [x15]
	ldr	w14, [x14, #5208]
	cmp	w14, #3
	b.ne	LBB32_50
; %bb.46:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x14, x20, x11
	ldr	w14, [x14, #5220]
	cbnz	w14, LBB32_50
; %bb.47:                               ;   in Loop: Header=BB32_30 Depth=2
	cbz	x9, LBB32_49
; %bb.48:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x14, x20, x11
	ldr	x14, [x14, #5200]
	ldr	x15, [x9, #24]
	cmp	x14, x15
	b.hs	LBB32_50
LBB32_49:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x9, x26, x11
	add	w25, w8, #3
LBB32_50:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x15, x13, x2
	add	x14, x20, x11
	prfm	pldl1keep, [x15]
	ldr	w15, [x14, #6416]
	cmp	w15, #3
	b.ne	LBB32_55
; %bb.51:                               ;   in Loop: Header=BB32_30 Depth=2
	ldr	w15, [x14, #6428]
	cbnz	w15, LBB32_55
; %bb.52:                               ;   in Loop: Header=BB32_30 Depth=2
	cbz	x9, LBB32_54
; %bb.53:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x15, x20, x11
	ldr	x15, [x15, #6408]
	ldr	x16, [x9, #24]
	cmp	x15, x16
	b.hs	LBB32_55
LBB32_54:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x9, x22, x11
	add	w25, w8, #4
LBB32_55:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x15, x13, x1
	prfm	pldl1keep, [x15]
	ldr	w14, [x14, #7624]
	cmp	w14, #3
	b.ne	LBB32_60
; %bb.56:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x14, x20, x11
	ldr	w14, [x14, #7636]
	cbnz	w14, LBB32_60
; %bb.57:                               ;   in Loop: Header=BB32_30 Depth=2
	cbz	x9, LBB32_59
; %bb.58:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x14, x20, x11
	ldr	x14, [x14, #7616]
	ldr	x15, [x9, #24]
	cmp	x14, x15
	b.hs	LBB32_60
LBB32_59:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x9, x24, x11
	add	w25, w8, #5
LBB32_60:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x15, x13, x0
	add	x14, x20, x11
	prfm	pldl1keep, [x15]
	ldr	w15, [x14, #8832]
	cmp	w15, #3
	b.ne	LBB32_65
; %bb.61:                               ;   in Loop: Header=BB32_30 Depth=2
	ldr	w15, [x14, #8844]
	cbnz	w15, LBB32_65
; %bb.62:                               ;   in Loop: Header=BB32_30 Depth=2
	cbz	x9, LBB32_64
; %bb.63:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x15, x20, x11
	ldr	x15, [x15, #8824]
	ldr	x16, [x9, #24]
	cmp	x15, x16
	b.hs	LBB32_65
LBB32_64:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x9, x23, x11
	add	w25, w8, #6
LBB32_65:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x13, x13, x17
	prfm	pldl1keep, [x13]
	ldr	w13, [x14, #10040]
	cmp	w13, #3
	b.ne	LBB32_29
; %bb.66:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x13, x20, x11
	ldr	w13, [x13, #10052]
	cbnz	w13, LBB32_29
; %bb.67:                               ;   in Loop: Header=BB32_30 Depth=2
	cbz	x9, LBB32_28
; %bb.68:                               ;   in Loop: Header=BB32_30 Depth=2
	add	x13, x20, x11
	ldr	x13, [x13, #10032]
	ldr	x14, [x9, #24]
	cmp	x13, x14
	b.lo	LBB32_28
	b	LBB32_29
LBB32_69:
	mov	x19, x27
LBB32_70:
	str	wzr, [x20, #460]
	add	x0, x20, #272
	bl	_pthread_mutex_unlock
	mov	x8, x0
	mov	x0, x19
	cbnz	w8, LBB32_72
LBB32_71:
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB32_72:
	bl	_abort
	.loh AdrpLdr	Lloh140, Lloh141
	.loh AdrpLdr	Lloh138, Lloh139
	.loh AdrpLdr	Lloh136, Lloh137
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_fault_copy      ; -- Begin function neoclr_workers_fault_copy
	.p2align	2
_neoclr_workers_fault_copy:             ; @neoclr_workers_fault_copy
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cbz	x2, LBB33_3
; %bb.1:
	cbnz	x3, LBB33_4
; %bb.2:
	cbz	x4, LBB33_4
LBB33_3:
	mov	w0, #-1                         ; =0xffffffff
	b	LBB33_16
LBB33_4:
	mov	x23, x4
	mov	x19, x3
	mov	x21, x2
	mov	x22, x0
	mov	x20, x1
	bl	_heap_lock
	ldr	w8, [x20, #20]
	cmp	w8, #2
	b.ne	LBB33_13
; %bb.5:
	mov	x9, x20
	ldr	x10, [x20]
	mov	x8, x22
	ldr	x11, [x22]
	cmp	x10, x11
	b.ne	LBB33_14
; %bb.6:
	ldr	w10, [x9, #16]
	ldr	w11, [x8, #436]
	cmp	w10, w11
	b.hs	LBB33_14
; %bb.7:
	mov	w11, #1208                      ; =0x4b8
	umaddl	x11, w10, w11, x8
	ldr	w10, [x11, #1584]
	cbz	w10, LBB33_14
; %bb.8:
	ldr	x9, [x9, #8]
	add	x24, x11, #1552
	ldr	x11, [x24, #8]
	cmp	x11, x9
	b.ne	LBB33_14
; %bb.9:
	cmp	w10, #3
	b.ne	LBB33_17
; %bb.10:
	ldr	x10, [x24, #152]
	cbz	x10, LBB33_18
; %bb.11:
	ldr	x20, [x10]
	cmp	x20, x23
	b.ls	LBB33_19
; %bb.12:
	mov	w19, #-2                        ; =0xfffffffe
	b	LBB33_15
LBB33_13:
	mov	w19, #-1                        ; =0xffffffff
	mov	x8, x22
	b	LBB33_15
LBB33_14:
	mov	w19, #-1                        ; =0xffffffff
LBB33_15:
	add	x0, x8, #272
	bl	_pthread_mutex_unlock
	mov	x8, x0
	mov	x0, x19
	cbnz	w8, LBB33_23
LBB33_16:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB33_17:
	mov	w19, #0                         ; =0x0
	b	LBB33_15
LBB33_18:
	mov	x20, #0                         ; =0x0
	b	LBB33_21
LBB33_19:
	cbz	x20, LBB33_21
; %bb.20:
	add	x1, x10, #8
	mov	x0, x19
	mov	x2, x20
	bl	_memcpy
	mov	x9, x21
	mov	x8, x22
	b	LBB33_22
LBB33_21:
	mov	x9, x21
LBB33_22:
	ldr	d0, [x24, #144]
	str	d0, [x9]
	str	x20, [x9, #8]
	mov	w19, #1                         ; =0x1
	b	LBB33_15
LBB33_23:
	bl	_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_take            ; -- Begin function neoclr_workers_take
	.p2align	2
_neoclr_workers_take:                   ; @neoclr_workers_take
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x22, x4
	mov	x20, x3
	mov	x21, x2
	mov	x23, x1
	mov	x19, x0
Lloh142:
	adrp	x0, _entered@TLVPPAGE
Lloh143:
	ldr	x0, [x0, _entered@TLVPPAGEOFF]
	ldr	x8, [x0]
	blr	x8
	ldr	x8, [x0]
Lloh144:
	adrp	x0, _reading@TLVPPAGE
Lloh145:
	ldr	x0, [x0, _reading@TLVPPAGEOFF]
	ldr	x9, [x0]
	blr	x9
	ldr	x9, [x0]
Lloh146:
	adrp	x0, _mutating@TLVPPAGE
Lloh147:
	ldr	x0, [x0, _mutating@TLVPPAGEOFF]
	ldr	x10, [x0]
	blr	x10
	ldr	x10, [x0]
	cmp	x8, #0
	ccmp	x9, #0, #0, eq
	ccmp	x10, #0, #0, eq
	b.ne	LBB34_20
; %bb.1:
	add	x0, x19, #272
	bl	_pthread_mutex_lock
	cbnz	w0, LBB34_20
; %bb.2:
	ldr	w8, [x23, #20]
	cmp	w8, #2
	b.ne	LBB34_10
; %bb.3:
	ldr	x8, [x23]
	ldr	x9, [x19]
	cmp	x8, x9
	b.ne	LBB34_10
; %bb.4:
	ldr	w9, [x23, #16]
	ldr	w10, [x19, #436]
	cmp	w9, w10
	b.hs	LBB34_10
; %bb.5:
	mov	w10, #1208                      ; =0x4b8
	umaddl	x10, w9, w10, x19
	ldr	w9, [x10, #1584]
	cbz	w9, LBB34_10
; %bb.6:
	ldr	x11, [x23, #8]
	add	x24, x10, #1552
	ldr	x10, [x24, #8]
	cmp	x10, x11
	b.ne	LBB34_10
; %bb.7:
	cmp	w9, #3
	b.ne	LBB34_17
; %bb.8:
	ldr	x9, [x24, #136]
	cbz	x9, LBB34_18
; %bb.9:
	mov	x10, #0                         ; =0x0
	mov	w11, #20888                     ; =0x5198
	add	x12, x19, x11
	mov	w11, #1                         ; =0x1
	b	LBB34_14
LBB34_10:
	mov	w23, #-1                        ; =0xffffffff
LBB34_11:
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbnz	w0, LBB34_20
; %bb.12:
	mov	x0, x23
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB34_13:                               ;   in Loop: Header=BB34_14 Depth=1
	mov	w23, #0                         ; =0x0
	cmp	x10, #31
	add	x13, x10, #1
	cset	w11, lo
	add	x12, x12, #16
	mov	x10, x13
	cmp	x13, #32
	b.eq	LBB34_11
LBB34_14:                               ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x12]
	cbnz	x13, LBB34_13
; %bb.15:                               ;   in Loop: Header=BB34_14 Depth=1
	ldur	x13, [x12, #-8]
	cmn	x13, #1
	b.eq	LBB34_13
; %bb.16:
	add	x13, x13, #1
	stp	x13, x9, [x12, #-8]
	stp	x8, x13, [x22]
	mov	w8, #1                          ; =0x1
	stp	w10, w8, [x22, #16]
	tbnz	w11, #0, LBB34_19
LBB34_17:
	mov	w23, #0                         ; =0x0
	b	LBB34_11
LBB34_18:
	stp	xzr, xzr, [x22]
	str	xzr, [x22, #16]
LBB34_19:
	ldr	w8, [x24, #40]
	str	w8, [x21]
	ldur	q0, [x24, #120]
	str	q0, [x20]
	str	xzr, [x20, #16]
	add	x0, x24, #144
	mov	w1, #1048                       ; =0x418
	bl	_bzero
	stp	xzr, xzr, [x24, #120]
	str	xzr, [x24, #136]
	add	x8, x24, #1192
	str	wzr, [x24, #32]
	movi.2d	v0, #0000000000000000
	str	q0, [x8]
	mov	w23, #1                         ; =0x1
	b	LBB34_11
LBB34_20:
	bl	_abort
	.loh AdrpLdr	Lloh146, Lloh147
	.loh AdrpLdr	Lloh144, Lloh145
	.loh AdrpLdr	Lloh142, Lloh143
	.cfi_endproc
                                        ; -- End function
	.globl	_neoclr_workers_collect         ; -- Begin function neoclr_workers_collect
	.p2align	2
_neoclr_workers_collect:                ; @neoclr_workers_collect
	.cfi_startproc
; %bb.0:
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x29, sp, #32
	mov	w9, #19824                      ; =0x4d70
Lloh148:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh149:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #4, lsl #12             ; =16384
	sub	sp, sp, #3440
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x0
Lloh150:
	adrp	x8, ___stack_chk_guard@GOTPAGE
Lloh151:
	ldr	x8, [x8, ___stack_chk_guard@GOTPAGEOFF]
Lloh152:
	ldr	x8, [x8]
	stur	x8, [x29, #-40]
	ldr	x21, [x0, #24]
	bl	_pthread_self
	mov	x1, x0
	mov	x0, x21
	bl	_pthread_equal
	cbz	w0, LBB35_5
; %bb.1:
	mov	x0, x19
	bl	_heap_lock
	add	x21, sp, #104
	add	x1, sp, #104
	mov	x0, x19
	bl	_pool_slots
	str	xzr, [sp, #96]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #32]
	stp	q0, q0, [sp]
	add	x8, x19, #464
	str	x8, [sp, #8]
	str	x21, [sp, #48]
	str	w0, [sp, #64]
	mov	x1, sp
	mov	x0, x8
	bl	_neoclr_gc_collect_v1
	cmp	w0, #0
	cset	w21, eq
	cbnz	w0, LBB35_3
; %bb.2:
	ldr	x8, [x19, #1528]
	str	x8, [x20]
LBB35_3:
	add	x0, x19, #272
	bl	_pthread_mutex_unlock
	cbz	w0, LBB35_6
; %bb.4:
	bl	_abort
LBB35_5:
	mov	w21, #0                         ; =0x0
LBB35_6:
	ldur	x8, [x29, #-40]
Lloh153:
	adrp	x9, ___stack_chk_guard@GOTPAGE
Lloh154:
	ldr	x9, [x9, ___stack_chk_guard@GOTPAGEOFF]
Lloh155:
	ldr	x9, [x9]
	cmp	x9, x8
	b.ne	LBB35_8
; %bb.7:
	mov	x0, x21
	add	sp, sp, #4, lsl #12             ; =16384
	add	sp, sp, #3440
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB35_8:
	bl	___stack_chk_fail
	.loh AdrpLdrGotLdr	Lloh150, Lloh151, Lloh152
	.loh AdrpLdrGotLdr	Lloh153, Lloh154, Lloh155
	.loh AdrpLdrGot	Lloh148, Lloh149
	.cfi_endproc
                                        ; -- End function
	.section	__DATA,__data
	.p2align	3, 0x0                          ; @next_identity
_next_identity:
	.quad	1                               ; 0x1

.tbss _executing$tlv$init, 8, 3         ; @executing

	.section	__DATA,__thread_vars,thread_local_variables
_executing:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_executing$tlv$init

	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"[]"

.tbss _entered$tlv$init, 8, 3           ; @entered

	.section	__DATA,__thread_vars,thread_local_variables
_entered:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_entered$tlv$init

.tbss _reading$tlv$init, 8, 3           ; @reading

_reading:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_reading$tlv$init

.tbss _mutating$tlv$init, 8, 3          ; @mutating

_mutating:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_mutating$tlv$init

.tbss _trace_pool$tlv$init, 8, 3        ; @trace_pool

_trace_pool:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_trace_pool$tlv$init

.tbss _trace_worker$tlv$init, 4, 2      ; @trace_worker

_trace_worker:
	.quad	__tlv_bootstrap
	.quad	0
	.quad	_trace_worker$tlv$init

.subsections_via_symbols
